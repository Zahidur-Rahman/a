"""
Test Suite for Contextual Reference Handling in Agent Router
Tests how the router handles "this", "these", "his", "him" etc. that refer to recent chat content.
"""
import asyncio
from backend.app.services.agent_router import DynamicAgentRouter
from backend.app.services.agent_registry import AgentRegistry
from backend.app.models.chat_graph_state import ChatGraphState
from backend.app.models.conversation import ChatMessage

class TestContextualReferences:
    """Test suite for contextual reference handling."""
    
    def __init__(self):
        self.agent_registry = AgentRegistry()
        self.router = DynamicAgentRouter(self.agent_registry)
        self.business_id = "123"
        self.user_id = "test_user"
    
    async def test_customer_contextual_references(self):
        """Test contextual references in customer context."""
        print("\n=== Test 1: Customer Contextual References ===")
        
        # First, establish customer context
        conversation_history = [
            ChatMessage(role="user", content="show me customers"),
            ChatMessage(role="assistant", content="Here are the customers:\n1. John Doe (CUS-000001) - john@example.com - 1234567890\n2. Jane Smith (CUS-000002) - jane@example.com - 0987654321")
        ]
        
        test_cases = [
            ("update his phone", "customer", "his phone refers to customer data"),
            ("delete this customer", "customer", "this customer refers to listed customer"),
            ("show me these details", "customer", "these details refers to customer info"),
            ("change that email", "customer", "that email refers to customer email"),
            ("update them", "customer", "them refers to customers"),
            ("his details", "customer", "his details refers to customer"),
            ("this one", "customer", "this one refers to customer")
        ]
        
        for message, expected_agent, description in test_cases:
            state = ChatGraphState(
                message=message,
                business_id=self.business_id,
                user_id=self.user_id,
                conversation_history=conversation_history
            )
            
            result = await self.router.classify_and_route(state.model_dump())
            actual_agent = result.get('routed_agent', 'unknown')
            reasoning = result.get('routing_reasoning', 'none')
            
            print(f"'{message}' → {actual_agent} (expected: {expected_agent})")
            print(f"  Reasoning: {reasoning}")
            print(f"  Description: {description}")
            
            assert actual_agent == expected_agent, f"Expected {expected_agent}, got {actual_agent} for '{message}'"
            print("  ✅ PASSED\n")
    
    async def test_general_contextual_references(self):
        """Test contextual references in general context."""
        print("\n=== Test 2: General Contextual References ===")
        
        # Establish general context
        conversation_history = [
            ChatMessage(role="user", content="hello"),
            ChatMessage(role="assistant", content="Hi! How can I help you today?"),
            ChatMessage(role="user", content="show me sales report"),
            ChatMessage(role="assistant", content="Here's the sales report for this month...")
        ]
        
        test_cases = [
            ("this is helpful", "general", "this refers to general help"),
            ("that's interesting", "general", "that refers to general content"),
            ("thanks for this", "general", "this refers to general assistance"),
            ("that report looks good", "general", "that report refers to general report")
        ]
        
        for message, expected_agent, description in test_cases:
            state = ChatGraphState(
                message=message,
                business_id=self.business_id,
                user_id=self.user_id,
                conversation_history=conversation_history
            )
            
            result = await self.router.classify_and_route(state.model_dump())
            actual_agent = result.get('routed_agent', 'unknown')
            reasoning = result.get('routing_reasoning', 'none')
            
            print(f"'{message}' → {actual_agent} (expected: {expected_agent})")
            print(f"  Reasoning: {reasoning}")
            print(f"  Description: {description}")
            
            assert actual_agent == expected_agent, f"Expected {expected_agent}, got {actual_agent} for '{message}'"
            print("  ✅ PASSED\n")
    
    async def test_mixed_context_references(self):
        """Test contextual references when context is mixed or unclear."""
        print("\n=== Test 3: Mixed Context References ===")
        
        # Mixed context - both customer and general
        conversation_history = [
            ChatMessage(role="user", content="hello"),
            ChatMessage(role="assistant", content="Hi! How can I help you?"),
            ChatMessage(role="user", content="show me customers"),
            ChatMessage(role="assistant", content="Here are customers: John (CUS-000001)"),
            ChatMessage(role="user", content="thanks"),
            ChatMessage(role="assistant", content="You're welcome!")
        ]
        
        test_cases = [
            ("update this", "customer", "this in mixed context should favor customer due to recent customer data"),
            ("that's good", "general", "that in mixed context should favor general due to thanks"),
            ("delete it", "customer", "it in mixed context should favor customer due to recent customer data")
        ]
        
        for message, expected_agent, description in test_cases:
            state = ChatGraphState(
                message=message,
                business_id=self.business_id,
                user_id=self.user_id,
                conversation_history=conversation_history
            )
            
            result = await self.router.classify_and_route(state.model_dump())
            actual_agent = result.get('routed_agent', 'unknown')
            reasoning = result.get('routing_reasoning', 'none')
            
            print(f"'{message}' → {actual_agent} (expected: {expected_agent})")
            print(f"  Reasoning: {reasoning}")
            print(f"  Description: {description}")
            
            # Note: These might be ambiguous, so we'll be more lenient
            print(f"  Result: {'✅ PASSED' if actual_agent == expected_agent else '⚠️  DIFFERENT (but acceptable)'}\n")
    
    async def test_confirmation_with_context(self):
        """Test confirmations that should route based on context."""
        print("\n=== Test 4: Confirmation with Context ===")
        
        # Customer confirmation context
        customer_context = [
            ChatMessage(role="user", content="delete customer CUS-000001"),
            ChatMessage(role="assistant", content="Are you sure you want to delete this customer?")
        ]
        
        # General confirmation context
        general_context = [
            ChatMessage(role="user", content="can you help me?"),
            ChatMessage(role="assistant", content="Of course! What do you need help with?")
        ]
        
        test_cases = [
            ("yes", customer_context, "customer", "yes in customer confirmation context"),
            ("no", customer_context, "customer", "no in customer confirmation context"),
            ("yes", general_context, "general", "yes in general context"),
            ("ok", customer_context, "customer", "ok in customer context"),
            ("sounds good", general_context, "general", "sounds good in general context")
        ]
        
        for message, context_history, expected_agent, description in test_cases:
            state = ChatGraphState(
                message=message,
                business_id=self.business_id,
                user_id=self.user_id,
                conversation_history=context_history
            )
            
            result = await self.router.classify_and_route(state.model_dump())
            actual_agent = result.get('routed_agent', 'unknown')
            reasoning = result.get('routing_reasoning', 'none')
            
            print(f"'{message}' in {expected_agent} context → {actual_agent}")
            print(f"  Reasoning: {reasoning}")
            print(f"  Description: {description}")
            
            assert actual_agent == expected_agent, f"Expected {expected_agent}, got {actual_agent} for '{message}' in {expected_agent} context"
            print("  ✅ PASSED\n")
    
    async def test_context_analysis_details(self):
        """Test detailed context analysis for references."""
        print("\n=== Test 5: Context Analysis Details ===")
        
        # Test with detailed customer data
        conversation_history = [
            ChatMessage(role="user", content="find customer with email john@example.com"),
            ChatMessage(role="assistant", content="Found customer: John Doe (CUS-000001)\nPhone: 1234567890\nEmail: john@example.com\nOrganization: TechCorp")
        ]
        
        state = ChatGraphState(
            message="update his phone to 9876543210",
            business_id=self.business_id,
            user_id=self.user_id,
            conversation_history=conversation_history
        )
        
        result = await self.router.classify_and_route(state.model_dump())
        
        print(f"Message: 'update his phone to 9876543210'")
        print(f"Routed to: {result.get('routed_agent', 'unknown')}")
        print(f"Confidence: {result.get('routing_confidence', 'unknown')}")
        print(f"Reasoning: {result.get('routing_reasoning', 'none')}")
        print(f"Context Analysis: {result.get('context_analysis', {})}")
        
        # Should route to customer agent
        assert result.get('routed_agent') == 'customer', "Should route to customer agent for contextual reference to customer data"
        
        # Check that reasoning includes contextual reference analysis
        reasoning = result.get('routing_reasoning', '')
        assert 'contextual' in reasoning.lower() or 'reference' in reasoning.lower(), "Reasoning should mention contextual reference"
        
        print("  ✅ PASSED\n")
    
    async def test_edge_cases(self):
        """Test edge cases for contextual references."""
        print("\n=== Test 6: Edge Cases ===")
        
        test_cases = [
            # No context
            ("this", [], "general", "no context should default to general"),
            # Ambiguous references
            ("it", [], "general", "ambiguous reference with no context"),
            # Multiple references
            ("this and that", [], "general", "multiple references with no context"),
            # Very short context
            ("this", [ChatMessage(role="user", content="hi")], "general", "minimal context"),
        ]
        
        for message, context_history, expected_agent, description in test_cases:
            state = ChatGraphState(
                message=message,
                business_id=self.business_id,
                user_id=self.user_id,
                conversation_history=context_history
            )
            
            result = await self.router.classify_and_route(state.model_dump())
            actual_agent = result.get('routed_agent', 'unknown')
            reasoning = result.get('routing_reasoning', 'none')
            
            print(f"'{message}' with {len(context_history)} context messages → {actual_agent}")
            print(f"  Reasoning: {reasoning}")
            print(f"  Description: {description}")
            
            # For edge cases, we're more lenient
            print(f"  Result: {'✅ PASSED' if actual_agent == expected_agent else '⚠️  DIFFERENT (acceptable for edge case)'}\n")
    
    async def run_all_tests(self):
        """Run all contextual reference tests."""
        print("Starting Contextual Reference Tests...")
        print("=" * 60)
        
        try:
            await self.test_customer_contextual_references()
            await self.test_general_contextual_references()
            await self.test_mixed_context_references()
            await self.test_confirmation_with_context()
            await self.test_context_analysis_details()
            await self.test_edge_cases()
            
            print("=" * 60)
            print("✅ All contextual reference tests completed!")
            
        except Exception as e:
            print(f"\n❌ Test failed with error: {e}")
            import traceback
            traceback.print_exc()

async def main():
    """Main test runner."""
    tester = TestContextualReferences()
    await tester.run_all_tests()

if __name__ == "__main__":
    asyncio.run(main())
