"""
Enhanced Agent Router with LLM-Powered Intelligence and Dynamic Understanding

This router replaces static keyword matching with intelligent LLM-based routing
that understands synonyms, context, and natural language variations.
"""

import json
import logging
from typing import Dict, Any, Optional
from ..services.groq_llm_service import GroqLLMService

logger = logging.getLogger(__name__)

class EnhancedAgentRouter:
    """
    Intelligent agent router that uses LLM for dynamic understanding of user intent.
    Replaces rigid pattern matching with contextual, synonym-aware routing.
    """
    
    def __init__(self, agent_registry=None):
        self.llm_service = GroqLLMService()
        self.agent_registry = agent_registry
        
        # Enhanced pause reason mapping - route ALL customer-related pauses to customer agent
        self.customer_pause_reasons = {
            'customer_identification_needed', 'multiple_customers_selection', 
            'field_selection_needed', 'update_confirmation', 'bulk_update_confirmation',
            'confirm_update', 'confirm_delete', 'missing_mandatory_fields', 
            'specify_update_fields', 'clarification_needed', 'customer_selection_needed'
        }
    
    async def classify_and_route(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """
        Enhanced dynamic classification and routing with intelligent understanding.
        """
        try:
            from ..models.chat_graph_state import ChatGraphState
            
            # Convert state to ChatGraphState for consistency
            if isinstance(state, dict):
                context = ChatGraphState(**state)
            else:
                context = state
            
            # Priority 1: Handle pause states (highest priority)
            current_pause_reason = getattr(context, 'pause_reason', None)
            logger.info(f"[EnhancedRouter] Checking pause_reason: {current_pause_reason}")
            
            if current_pause_reason in self.customer_pause_reasons:
                logger.info(f"[EnhancedRouter] Routing to customer agent due to pause_reason: {current_pause_reason}")
                return await self._route_to_agent('customer', state, 'pause_resume', current_pause_reason)
            
            # Priority 2: Intelligent LLM-based classification
            agent_type = await self._intelligent_classification(context)
            
            logger.info(f"[AGENT_CLASSIFIED] {agent_type} for: '{context.message}'")
            
            # Route to the classified agent
            return await self._route_to_agent(agent_type, state, 'intelligent_classification', 'LLM-based routing')
            
        except Exception as e:
            logger.error(f"[EnhancedRouter] Error in classification/routing: {e}")
            # Fallback to general agent
            return await self._route_to_agent('general', state, 'error_fallback', str(e))
    
    async def _intelligent_classification(self, context) -> str:
        """
        Use LLM for intelligent agent classification with synonym understanding.
        """
        try:
            # Build conversation context
            conversation_context = self._build_conversation_context(context)
            
            # Enhanced classification prompt with synonym understanding
            classification_prompt = f"""
You are an expert agent router with advanced natural language understanding.

AVAILABLE AGENTS:
🔹 customer: Customer/client management, data operations, and relationship workflows
🔹 general: General business operations, greetings, and non-customer tasks

INTELLIGENT ROUTING RULES:
1. **Synonym Understanding**: Treat equivalent terms the same
   - "customer" = "client" 
   - "both" = "all" (when referring to multiple items)
   - "update both" = "update all" = bulk update operation
   - "modify" = "change" = "edit" = "update"
   - "remove" = "delete" = "cancel"

2. **Context Awareness**: Consider conversation history and flow
   - If recent messages show customer operations → customer agent
   - If user is responding to customer-related questions → customer agent
   - If providing customer data (phone, email, etc.) → customer agent

3. **Natural Language Intent**: Understand user's actual goal
   - "update both customers" → customer agent (bulk operation)
   - "change his phone" → customer agent (customer data update)
   - "delete these records" → customer agent (if records are customer data)
   - "hello" → general agent (greeting)
   - "show sales report" → general agent (business operation)

4. **Confirmation Handling**: Route confirmations to appropriate agent
   - "yes" after customer operation prompt → customer agent
   - "sounds good" in customer context → customer agent
   - "absolutely" for customer confirmation → customer agent

CONVERSATION CONTEXT:
{conversation_context}

CURRENT USER MESSAGE: "{context.message}"

Analyze the user's intent and respond with EXACTLY ONE WORD: "customer" or "general"

Examples:
- "update both" → customer (both = all, customer operation)
- "modify his details" → customer (customer data operation)
- "sounds good" (after customer prompt) → customer (confirmation in context)
- "hello there" → general (greeting)
- "show me analytics" → general (business operation)
"""

            response = await self.llm_service.chat([
                {"role": "system", "content": classification_prompt},
                {"role": "user", "content": context.message}
            ])
            
            # Parse response
            agent_type = response.strip().lower()
            if agent_type in ['customer', 'general']:
                return agent_type
            
            # Fallback if response is unclear
            if 'customer' in response.lower():
                return 'customer'
            elif 'general' in response.lower():
                return 'general'
            else:
                # Final fallback based on keywords
                return self._keyword_fallback(context.message)
                
        except Exception as e:
            logger.error(f"[EnhancedRouter] LLM classification error: {e}")
            return self._keyword_fallback(context.message)
    
    def _keyword_fallback(self, message: str) -> str:
        """Fast keyword-based fallback classification."""
        message_lower = message.lower().strip()
        
        # Customer keywords (high priority)
        customer_keywords = [
            'customer', 'client', 'update', 'modify', 'change', 'delete', 'remove',
            'add customer', 'create customer', 'find customer', 'search customer',
            'phone', 'email', 'organization', 'both', 'all customers'
        ]
        
        if any(keyword in message_lower for keyword in customer_keywords):
            return 'customer'
        
        return 'general'
    
    def _build_conversation_context(self, context) -> str:
        """Build intelligent conversation context."""
        if not hasattr(context, 'conversation_history') or not context.conversation_history:
            return "No previous conversation"
        
        # Get last 4 messages for context
        recent_messages = context.conversation_history[-4:]
        context_parts = []
        
        for msg in recent_messages:
            if hasattr(msg, 'role') and hasattr(msg, 'content'):
                role, content = msg.role, msg.content
            elif isinstance(msg, dict):
                role = msg.get('role', 'user')
                content = msg.get('content', '')
            else:
                continue
            
            # Truncate long messages
            display_content = content[:100] + "..." if len(content) > 100 else content
            context_parts.append(f"{role}: {display_content}")
        
        return "\n".join(context_parts) if context_parts else "No context"
    
    async def _route_to_agent(self, agent_type: str, state: Dict[str, Any], 
                             routing_method: str, reasoning: str) -> Dict[str, Any]:
        """Route request to specified agent with metadata."""
        try:
            # Get the agent
            agent = self.agent_registry.get_agent(agent_type)
            if not agent:
                logger.error(f"[EnhancedRouter] Agent '{agent_type}' not found, falling back to general")
                agent = self.agent_registry.get_agent('general')
                agent_type = 'general'
            
            # Execute with the selected agent
            result = await agent.ainvoke(state)
            
            # Add routing metadata
            if isinstance(result, dict):
                result['routed_agent'] = agent_type
                result['routing_method'] = routing_method
                result['routing_reasoning'] = reasoning
            
            logger.info(f"[AGENT_USED] {agent_type}")
            return result
            
        except Exception as e:
            logger.error(f"[EnhancedRouter] Error routing to {agent_type}: {e}")
            # Emergency fallback
            fallback_agent = self.agent_registry.get_agent('general')
            result = await fallback_agent.ainvoke(state)
            
            if isinstance(result, dict):
                result['routed_agent'] = 'general'
                result['routing_method'] = 'emergency_fallback'
                result['routing_reasoning'] = f'Error routing to {agent_type}: {str(e)}'
            
            return result
