from .mistral_llm_service import MistralLLMService
from ..models.chat_graph_state import ChatGraphState
from ..models.conversation import ChatMessage
import logging
import re
import time
import hashlib
import json
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass
from collections import defaultdict

logger = logging.getLogger(__name__)

@dataclass
class RoutingDecision:
    """Represents a routing decision with confidence and reasoning."""
    agent_type: str
    confidence: float
    reasoning: str
    fallback_agents: List[str]
    metadata: Dict[str, Any]

@dataclass
class AgentCapability:
    """Represents an agent's capabilities and constraints."""
    name: str
    description: str
    keywords: List[str]
    complexity_score: int  # 1-10, higher means more complex queries
    priority: int  # Higher priority agents get preference in ties
    constraints: Dict[str, Any]

class DynamicAgentRouter:
    def __init__(self, agent_registry=None):
        self.llm_service = MistralLLMService()
        self.agent_registry = agent_registry
        self.classification_history = []  # Track classification decisions for learning
        self.classification_cache = {}  # Cache for similar queries (performance optimization)
        self.cache_ttl = 300  # Cache TTL in seconds (5 minutes)
        
        # Enhanced routing capabilities
        self.agent_capabilities = self._initialize_agent_capabilities()
        self.routing_patterns = defaultdict(list)  # Learn routing patterns
        self.confidence_threshold = 0.7  # Minimum confidence for routing
        self.learning_enabled = True  # Enable adaptive learning
        self.context_memory = {}  # Remember context between interactions
        
        # Enhanced context awareness
        self.conversation_flows = {}  # Track active conversation flows
        self.user_intent_history = []  # Track user intent patterns
        self.agent_performance = {}  # Track agent performance metrics
        self.context_weights = {
            'recent_messages': 0.4,
            'explicit_keywords': 0.3,
            'conversation_flow': 0.2,
            'user_intent': 0.1
        }
        
        # Dynamic routing intelligence with learning
        self.routing_history = []  # Track routing decisions for learning
        self.feedback_data = {}    # User feedback on routing quality
        self.adaptation_patterns = {}  # Learned patterns from successful routings
        self.context_memory = {}   # Remember user contexts across sessions
        self.routing_confidence_threshold = 0.75  # Adaptive threshold
        self.learning_rate = 0.1   # How quickly to adapt patterns
    
    def _initialize_agent_capabilities(self) -> Dict[str, AgentCapability]:
        """Dynamic agent capabilities that evolve based on usage patterns."""
        # Base capabilities that will be enhanced dynamically by LLM
        return {
            'customer': AgentCapability(
                name='customer',
                description='Customer and client management with intelligent workflow handling',
                keywords=[],  # Will be populated dynamically by LLM
                complexity_score=8,
                priority=3,
                constraints={
                    'requires_database': True,
                    'data_sensitive': True,
                    'llm_enhanced': True,
                    'dynamic_routing': True
                }
            ),
            'general': AgentCapability(
                name='general',
                description='General business operations and conversations',
                keywords=[],  # Will be populated dynamically by LLM
                complexity_score=5,
                priority=1,
                constraints={
                    'fallback_agent': True,
                    'general_purpose': True,
                    'llm_enhanced': True
                }
            )
        }
        
    async def route_query(self, state: ChatGraphState) -> ChatGraphState:
        """Dynamic LLM-driven query routing with intelligent context awareness."""
        try:
            # Use LLM for primary routing decision with enhanced context
            routing_result = await self._llm_dynamic_routing(state)
            
            # Apply routing decision
            state.routing_decision = routing_result['agent']
            
            # Add routing metadata
            if not hasattr(state, 'routing_metadata'):
                state.routing_metadata = {}
            
            state.routing_metadata.update({
                'confidence': routing_result['confidence'],
                'reasoning': routing_result['reasoning'],
                'context_analysis': routing_result.get('context_analysis', ''),
                'routing_method': 'llm_dynamic',
                'contextual_target': routing_result.get('contextual_target', None)
            })
            
            logger.info(f"[DynamicRouter] '{state.message}' → {state.routing_decision} agent (confidence: {routing_result['confidence']:.2f})")
            logger.info(f"[DynamicRouter] Reasoning: {routing_result['reasoning']}")
            
            return state
            
        except Exception as e:
            logger.error(f"[DynamicRouter] Error in LLM routing: {e}")
            # Fallback to rule-based routing
            return await self._fallback_rule_based_routing(state)

    async def classify_and_route(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """
        Enhanced dynamic classification and routing with comprehensive context awareness.
        Uses multi-dimensional analysis for optimal agent selection.
        """
        try:
            # Convert state to ChatGraphState for consistency
            if isinstance(state, dict):
                context = ChatGraphState(**state)
            else:
                context = state
            
            # Track user session for context continuity
            user_id = getattr(context, 'user_id', 'default')
            self._update_user_context(user_id, context)
            
            # Dynamic pause state handling using LLM intelligence
            current_pause_reason = getattr(context, 'pause_reason', None)
            logger.info(f"[AgentRouter] Checking pause_reason: {current_pause_reason}")
            
            if current_pause_reason:
                # Use LLM to determine if this should continue with the paused agent
                pause_analysis = await self._analyze_pause_continuation(context, current_pause_reason)
                
                if pause_analysis['should_continue']:
                    try:
                        logger.info(f"[AgentRouter] LLM determined to continue with {pause_analysis['target_agent']} for pause: {current_pause_reason}")
                        agent = self.agent_registry.get_agent(pause_analysis['target_agent'])
                        result = await agent.ainvoke(state)
                        
                        if isinstance(result, dict):
                            result['routed_agent'] = pause_analysis['target_agent']
                            result['routing_confidence'] = pause_analysis['confidence']
                            result['routing_reason'] = f"LLM pause analysis: {pause_analysis['reasoning']}"
                        
                        return result
                    except Exception as pause_error:
                        logger.error(f"[AgentRouter] Error handling pause state: {pause_error}")
                        # Clear pause state and proceed with normal routing
                        self._clear_pause_state(context)

            # Use pure LLM-driven classification without static fallbacks
            classification_result = await self._dynamic_agent_classification(context)
            
            # Extract agent type and confidence
            if isinstance(classification_result, dict):
                agent_type = classification_result.get('agent_type', 'general')
                confidence = classification_result.get('confidence', 0.5)
                reasoning = classification_result.get('reasoning', '')
            else:
                agent_type = classification_result
                confidence = 0.8
                reasoning = 'direct_classification'
            
            logger.info(f"[AGENT_CLASSIFIED] {agent_type} (confidence: {confidence:.2f}) for: '{context.message}'")
            logger.info(f"[AGENT_REASONING] {reasoning}")
            
            # Track the classification decision
            self._track_classification(context.message, agent_type, confidence)
            
            # Get the appropriate agent
            agent = self.agent_registry.get_agent(agent_type)
            if not agent:
                logger.error(f"[AgentRouter] Agent '{agent_type}' not found, falling back to general")
                agent = self.agent_registry.get_agent('general')
                agent_type = 'general'
            
            # Execute with the selected agent
            result = await agent.ainvoke(state)
            
            # Add comprehensive routing metadata to result
            if isinstance(result, dict):
                result['routed_agent'] = agent_type
                result['routing_confidence'] = confidence
                result['routing_reasoning'] = reasoning
                result['context_analysis'] = self._get_context_summary(context)
            
            # Update performance metrics
            self._update_agent_performance(agent_type, confidence)
            
            return result
            
        except Exception as e:
            logger.error(f"[AgentRouter] Error in classification/routing: {e}")
            logger.error(f"[AgentRouter] Message was: '{context.message if hasattr(context, 'message') else 'unknown'}'")
            
            # Enhanced fallback with context awareness
            try:
                fallback_result = await self._intelligent_fallback(context)
                return fallback_result
                
            except Exception as fallback_error:
                logger.error(f"[AgentRouter] Even fallback failed: {fallback_error}")
                # Last resort: general agent
                fallback_agent = self.agent_registry.get_agent('general')
                result = await fallback_agent.ainvoke(state)
                
                if isinstance(result, dict):
                    result['routed_agent'] = 'general'
                    result['routing_confidence'] = 'emergency_fallback'
                
                return result
    
    async def _analyze_pause_continuation(self, context: ChatGraphState, pause_reason: str) -> Dict[str, Any]:
        """Use LLM to analyze whether to continue with paused agent or switch."""
        try:
            conversation_context = self._build_conversation_summary(context)
            
            pause_analysis_prompt = f"""You are an expert at analyzing conversation flow and determining agent continuity.

CONVERSATION CONTEXT:
{conversation_context}

CURRENT PAUSE REASON: {pause_reason}
USER MESSAGE: "{context.message}"

Available agents: customer, general

Analyze whether the user wants to:
1. CONTINUE with the paused operation (→ continue with same agent)
2. SWITCH to a different operation (→ route to appropriate agent)
3. CANCEL the operation (→ route based on new intent)

Consider:
- Does the message provide information for the paused operation?
- Is this a confirmation/cancellation of the paused operation?
- Is this a completely new request that should override the pause?
- What agent is best suited for handling this message?

Respond with JSON:
{{
    "should_continue": true/false,
    "target_agent": "customer" or "general",
    "confidence": 0.0-1.0,
    "reasoning": "detailed explanation",
    "action_type": "continue|switch|cancel"
}}"""

            response = await self.llm_service.chat([
                {"role": "system", "content": "You are a conversation flow analyst. Always respond with valid JSON."},
                {"role": "user", "content": pause_analysis_prompt}
            ])
            
            result = self._parse_llm_json_response(response.strip())
            
            # Validate result
            if 'should_continue' not in result or 'target_agent' not in result:
                logger.warning(f"[AgentRouter] Invalid pause analysis result: {result}")
                return {
                    'should_continue': True,
                    'target_agent': 'customer',  # Safe default for pause scenarios
                    'confidence': 0.5,
                    'reasoning': 'LLM analysis failed, using safe default'
                }
            
            return result
            
        except Exception as e:
            logger.error(f"[AgentRouter] Error in pause analysis: {e}")
            return {
                'should_continue': True,
                'target_agent': 'customer',
                'confidence': 0.5,
                'reasoning': f'Error in analysis: {str(e)}'
            }

    async def _dynamic_agent_classification(self, context: ChatGraphState) -> Dict[str, Any]:
        """Completely LLM-driven agent classification without static rules."""
        try:
            # Build comprehensive context
            conversation_summary = self._build_conversation_summary(context)
            context_analysis = self._analyze_recent_context_for_references(context)
            
            # Pure LLM classification without static keyword fallbacks
            classification_prompt = f"""You are an intelligent agent router with deep understanding of business conversations.

AVAILABLE AGENTS:
🤖 **customer**: All customer/client related operations, data management, and workflows
🤖 **general**: Greetings, general business operations, and non-customer specific tasks

CONVERSATION CONTEXT:
{conversation_summary}

CONTEXT INTELLIGENCE:
- Last displayed customer: {context_analysis.get('last_displayed_customer', 'None')}
- Has customer data: {context_analysis.get('has_customer_data', False)}
- Reference type: {context_analysis.get('reference_type', 'unclear')}
- Customer confidence: {context_analysis.get('customer_confidence', 0.0):.2f}

CURRENT MESSAGE: "{context.message}"

ROUTING INTELLIGENCE:
1. **Semantic Understanding**: Understand the true intent behind the words
2. **Context Continuation**: Maintain workflow continuity from previous messages
3. **Reference Resolution**: Handle "his", "her", "this", "that" based on context
4. **Intent Recognition**: Detect create, read, update, delete, search operations
5. **Natural Language**: Handle confirmations, cancellations, and clarifications

Analyze the message and determine the best routing decision based on semantic meaning and context.

Respond with JSON:
{{
    "agent_type": "customer" or "general",
    "confidence": 0.0-1.0,
    "reasoning": "detailed semantic analysis",
    "intent_type": "create|read|update|delete|search|confirm|cancel|greeting|general",
    "requires_context": true/false,
    "contextual_target": "customer_id if applicable or null"
}}"""

            response = await self.llm_service.chat([
                {"role": "system", "content": "You are an expert semantic analysis and routing system. Always respond with valid JSON."},
                {"role": "user", "content": classification_prompt}
            ])
            
            result = self._parse_llm_json_response(response.strip())
            
            # Enhance with context if available
            if context_analysis.get('last_displayed_customer') and result.get('agent_type') == 'customer':
                result['contextual_target'] = context_analysis['last_displayed_customer']
            
            # Apply adaptive learning boost
            adaptive_boost = self._get_adaptive_confidence_boost(context.message, result.get('agent_type', 'general'))
            result['confidence'] = min(0.98, result.get('confidence', 0.8) + adaptive_boost)
            
            if adaptive_boost > 0:
                result['reasoning'] += f" [+{adaptive_boost:.2f} adaptive learning boost]"
            
            return result
            
        except Exception as e:
            logger.error(f"[AgentRouter] Error in dynamic classification: {e}")
            return await self._emergency_fallback_routing(context)
    
    async def _emergency_fallback_routing(self, context: ChatGraphState) -> Dict[str, Any]:
        """Emergency fallback using minimal LLM analysis."""
        try:
            simple_prompt = f"""Route this message to either 'customer' or 'general' agent.
Message: "{context.message}"
If it mentions customers, client data, or customer operations → customer
Otherwise → general
Respond with just: customer or general"""
            
            response = await self.llm_service.chat([
                {"role": "user", "content": simple_prompt}
            ])
            
            agent = 'customer' if 'customer' in response.lower() else 'general'
            
            return {
                'agent_type': agent,
                'confidence': 0.6,
                'reasoning': 'Emergency fallback routing',
                'intent_type': 'unknown'
            }
            
        except Exception as e:
            logger.error(f"[AgentRouter] Emergency fallback failed: {e}")
            return {
                'agent_type': 'general',
                'confidence': 0.3,
                'reasoning': 'Complete fallback to general agent'
            }

    async def _analyze_and_classify(self, context: ChatGraphState) -> Dict[str, Any]:
        """Legacy method - now redirects to dynamic classification."""
        return await self._dynamic_agent_classification(context)
    
    async def adapt_to_user_patterns(self, user_id: str) -> None:
        """LLM-driven adaptation to specific user patterns."""
        try:
            if user_id not in self.conversation_flows:
                return
            
            user_flow = self.conversation_flows[user_id]
            if len(user_flow.get('themes', [])) < 5:
                return  # Need more data
            
            adaptation_prompt = f"""Analyze this user's conversation patterns and suggest adaptations.

USER PATTERNS:
- Total conversations: {user_flow.get('conversation_count', 0)}
- Recent themes: {user_flow.get('themes', [])[-10:]}
- Last activity: {user_flow.get('last_activity', 0)}

RECOMMEND ADAPTATIONS:
1. Preferred agent routing bias
2. Confidence threshold adjustments
3. Context sensitivity changes

Respond with JSON:
{{
    "agent_bias": "customer|general|none",
    "confidence_adjustment": -0.2 to +0.2,
    "context_sensitivity": "high|medium|low",
    "reasoning": "detailed analysis"
}}"""

            response = await self.llm_service.chat([
                {"role": "system", "content": "You are a user behavior analyst. Always respond with valid JSON."},
                {"role": "user", "content": adaptation_prompt}
            ])
            
            adaptation = self._parse_llm_json_response(response.strip())
            
            # Apply user-specific adaptations
            if user_id not in self.context_memory:
                self.context_memory[user_id] = {}
            
            self.context_memory[user_id].update({
                'agent_bias': adaptation.get('agent_bias', 'none'),
                'confidence_adjustment': adaptation.get('confidence_adjustment', 0.0),
                'context_sensitivity': adaptation.get('context_sensitivity', 'medium'),
                'adapted_at': time.time()
            })
            
            logger.info(f"[AgentRouter] Adapted routing for user {user_id}: {adaptation.get('reasoning', 'No reasoning')}")
            
        except Exception as e:
            logger.error(f"[AgentRouter] Error in user adaptation: {e}")
    
    def get_user_adaptation(self, user_id: str) -> Dict[str, Any]:
        """Get user-specific routing adaptations."""
        return self.context_memory.get(user_id, {
            'agent_bias': 'none',
            'confidence_adjustment': 0.0,
            'context_sensitivity': 'medium'
        })
    
    async def continuous_learning_cycle(self) -> None:
        """Run continuous learning and optimization cycle."""
        try:
            # Auto-optimize every 50 routing decisions
            if len(self.routing_history) % 50 == 0 and len(self.routing_history) > 0:
                await self.optimize_routing_dynamically()
            
            # Adapt to user patterns periodically
            for user_id in list(self.conversation_flows.keys()):
                if time.time() - self.conversation_flows[user_id].get('last_activity', 0) < 3600:  # Active in last hour
                    await self.adapt_to_user_patterns(user_id)
            
            logger.info(f"[AgentRouter] Continuous learning cycle completed. {len(self.routing_history)} routes analyzed.")
            
        except Exception as e:
            logger.error(f"[AgentRouter] Error in continuous learning: {e}")

    # Legacy static methods - deprecated in favor of LLM-driven classification
    # Kept for compatibility but redirected to dynamic methods
    
    def _analyze_explicit_keywords(self, context: ChatGraphState) -> Dict[str, Any]:
        """Legacy method - redirects to dynamic classification."""
        import asyncio
        return asyncio.run(self._dynamic_agent_classification(context))
    
    def _analyze_conversation_context(self, context: ChatGraphState) -> Dict[str, Any]:
        """Legacy method - redirects to dynamic classification."""
        import asyncio
        return asyncio.run(self._dynamic_agent_classification(context))
    
    def _analyze_user_intent(self, context: ChatGraphState) -> Dict[str, Any]:
        """Legacy method - redirects to dynamic classification."""
        import asyncio
        return asyncio.run(self._dynamic_agent_classification(context))
    
    def _analyze_recent_context_for_references(self, context: ChatGraphState) -> Dict[str, Any]:
        """Analyze recent conversation context to understand what contextual references refer to."""
        if not context.conversation_history:
            return {
                'has_customer_data': False,
                'has_general_data': False,
                'customer_confidence': 0.0,
                'reference_type': 'no_context'
            }
        
        # Analyze last 8 messages for context (increased from 6)
        recent_messages = context.conversation_history[-8:]
        customer_indicators = 0
        general_indicators = 0
        customer_data_indicators = 0
        customer_operations = 0
        recent_customer_mentions = 0
        last_displayed_customer = None
        
        for msg in recent_messages:
            content = getattr(msg, 'content', '') if hasattr(msg, 'content') else str(msg)
            content_lower = content.lower()
            role = getattr(msg, 'role', 'user') if hasattr(msg, 'role') else 'user'
            
            # Detect customer information display (assistant responses showing customer data)
            if role == 'assistant' and any(indicator in content_lower for indicator in 
                ['customer information', 'customer id:', 'email address:', 'phone number:', 'organization:', 'customer details']):
                # Extract customer ID from displayed information
                import re
                customer_id_matches = re.findall(r'customer id[:\s]+([a-z]+-\d{6})', content_lower)
                if customer_id_matches:
                    last_displayed_customer = customer_id_matches[-1].upper()  # Get the most recent one
                    recent_customer_mentions += 4  # Strong indicator of displayed customer
                    customer_indicators += 3
            
            # Strong customer operation indicators (recent updates, creates, etc.)
            if any(word in content_lower for word in ['customer status', 'updated to', 'successfully updated', 'customer id', 'update successful', 'customer information']):
                customer_operations += 3  # Strong indicator
                customer_indicators += 2
            
            # Customer operation indicators
            if any(word in content_lower for word in ['customer', 'client', 'add customer', 'create customer', 'update customer', 'delete customer']):
                customer_indicators += 2
            
            # Customer data indicators (stronger weighting for data fields)
            if any(word in content_lower for word in ['phone', 'email', 'address', 'organization', 'customer id', 'cus-', 'status', 'tax']):
                customer_data_indicators += 2
                customer_indicators += 1
                # Extract customer IDs for reference
                if 'cus-' in content_lower:
                    import re
                    customer_ids = re.findall(r'cus-\d{6}', content_lower)
                    if customer_ids:
                        last_displayed_customer = customer_ids[-1].upper()  # Most recent customer ID
            
            # Recent customer mentions in assistant responses
            if any(word in content_lower for word in ['customer information', 'customer details', 'update successful', 'customer status']):
                recent_customer_mentions += 3
                customer_indicators += 2
            
            # Customer reference indicators
            if any(word in content_lower for word in ['his', 'her', 'this customer', 'that customer', 'these customers']):
                customer_indicators += 1
            
            # General indicators
            if any(word in content_lower for word in ['hello', 'hi', 'thanks', 'help', 'sales', 'report', 'business']):
                general_indicators += 1
        
        # Enhanced decision logic
        has_customer_data = (customer_indicators > 0 or customer_data_indicators > 0 or 
                           customer_operations > 0 or recent_customer_mentions > 0)
        has_general_data = general_indicators > 0 and not has_customer_data
        
        # Calculate confidence with enhanced weighting
        total_indicators = customer_indicators + general_indicators + customer_operations + recent_customer_mentions
        customer_score = customer_indicators + customer_operations + recent_customer_mentions
        customer_confidence = customer_score / total_indicators if total_indicators > 0 else 0.0
        
        # Boost confidence for recent customer operations
        if customer_operations > 0 or recent_customer_mentions > 0:
            customer_confidence = min(1.0, customer_confidence + 0.3)
        
        # Determine reference type with enhanced detection
        if last_displayed_customer:
            reference_type = 'last_displayed_customer'
        elif customer_operations > 0 or recent_customer_mentions > 0:
            reference_type = 'recent_customer_operation'
        elif customer_data_indicators > 0:
            reference_type = 'customer_data'
        elif customer_indicators > 0:
            reference_type = 'customer_operations'
        elif general_indicators > 0:
            reference_type = 'general_conversation'
        else:
            reference_type = 'unclear'
        
        return {
            'has_customer_data': has_customer_data,
            'has_general_data': has_general_data,
            'customer_confidence': customer_confidence,
            'reference_type': reference_type,
            'customer_indicators': customer_indicators,
            'general_indicators': general_indicators,
            'customer_data_indicators': customer_data_indicators,
            'customer_operations': customer_operations,
            'recent_customer_mentions': recent_customer_mentions,
            'last_displayed_customer': last_displayed_customer
        }
    
    async def _llm_dynamic_routing(self, state: ChatGraphState) -> Dict[str, Any]:
        """Advanced LLM-driven dynamic routing with comprehensive context analysis."""
        try:
            # Build comprehensive conversation context
            conversation_summary = self._build_conversation_summary(state)
            context_analysis = self._analyze_recent_context_for_references(state)
            
            # Advanced LLM routing prompt
            system_prompt = """You are an advanced AI agent router with deep understanding of business conversations and context. Your job is to intelligently route user queries to the most appropriate specialized agent.

AVAILABLE AGENTS:
🤖 **customer**: Complete customer lifecycle management (CRUD operations, data management, relationship tracking)
🤖 **general**: General business operations, greetings, analytics, reporting, and non-customer tasks

ROUTING INTELLIGENCE FRAMEWORK:

1. **CONTEXTUAL AWARENESS**: Analyze conversation flow to understand references
   - "his status" after customer data display → customer agent + customer ID context
   - "update her phone" after customer lookup → customer agent + specific customer
   - "delete this" in customer context → customer agent + targeted deletion

2. **INTENT RECOGNITION**: Understand user's actual goal beyond surface words
   - "add customer" → customer agent (explicit)
   - "both customers need updating" → customer agent (bulk operation)
   - "sounds good" after customer confirmation → customer agent (workflow continuation)
   - "hello" → general agent (greeting)
   - "show me analytics" → general agent (reporting)

3. **DYNAMIC WORKFLOW AWARENESS**: Consider ongoing operations
   - Active customer operations → continue with customer agent
   - Confirmation responses → route to agent handling the operation
   - Data collection phases → route to appropriate agent

4. **NATURAL LANGUAGE UNDERSTANDING**: Handle varied expressions
   - "that person's email" = customer field query
   - "the one with gmail" = customer search
   - "everyone from ABC Corp" = bulk customer operation
   - "never mind" = operation cancellation (context-dependent routing)

5. **PROACTIVE CONTEXT RESOLUTION**: Extract actionable insights
   - Identify which customer is being referenced
   - Detect bulk vs individual operations
   - Recognize continuation vs new requests

RESPOND WITH JSON:
{
    "agent": "customer" or "general",
    "confidence": 0.0-1.0,
    "reasoning": "detailed explanation of routing decision",
    "context_analysis": "analysis of conversation context",
    "contextual_target": "customer ID or target if applicable",
    "operation_type": "create|read|update|delete|search|general|greeting|confirmation",
    "complexity_score": 1-10,
    "requires_context": true/false
}"""

            user_prompt = f"""CONVERSATION CONTEXT:
{conversation_summary}

CONTEXT ANALYSIS:
- Last displayed customer: {context_analysis.get('last_displayed_customer', 'None')}
- Customer data present: {context_analysis.get('has_customer_data', False)}
- Reference type: {context_analysis.get('reference_type', 'unclear')}
- Customer confidence: {context_analysis.get('customer_confidence', 0.0):.2f}

CURRENT USER MESSAGE: "{state.message}"

Route this query intelligently considering the full context:"""

            response = await self.llm_service.chat([
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ])
            
            # Parse LLM response
            result = self._parse_llm_json_response(response.strip())
            
            # Validate and enhance result
            if 'agent' not in result or result['agent'] not in ['customer', 'general']:
                logger.warning(f"[DynamicRouter] Invalid agent in LLM response: {result}")
                return await self._fallback_rule_based_routing(state)
            
            # Enhance with context target if contextual reference detected
            if context_analysis.get('last_displayed_customer') and result['agent'] == 'customer':
                result['contextual_target'] = context_analysis['last_displayed_customer']
            
            # Apply user-specific adaptations
            user_id = getattr(state, 'user_id', 'default')
            user_adaptation = self.get_user_adaptation(user_id)
            
            # Adjust confidence based on user patterns
            confidence_adjustment = user_adaptation.get('confidence_adjustment', 0.0)
            result['confidence'] = min(0.98, max(0.3, result['confidence'] + confidence_adjustment))
            
            # Apply agent bias if configured
            agent_bias = user_adaptation.get('agent_bias', 'none')
            if agent_bias != 'none' and result['confidence'] < 0.8:
                if agent_bias == result['agent']:
                    result['confidence'] = min(0.98, result['confidence'] + 0.1)
                    result['reasoning'] += f" [+0.1 user bias: {agent_bias}]"
            
            # Ensure minimum confidence for LLM decisions
            result['confidence'] = max(0.7, result.get('confidence', 0.8))
            
            # Apply adaptive learning boost
            adaptive_boost = self._get_adaptive_confidence_boost(state.message, result['agent'])
            result['confidence'] = min(0.98, result['confidence'] + adaptive_boost)
            
            if adaptive_boost > 0:
                result['reasoning'] += f" [+{adaptive_boost:.2f} adaptive boost]"
                logger.info(f"[DynamicRouter] Applied adaptive learning boost: +{adaptive_boost:.2f}")
            
            return result
            
        except Exception as e:
            logger.error(f"[DynamicRouter] Error in LLM dynamic routing: {e}")
            return await self._fallback_rule_based_routing(state)
    
    def _build_conversation_summary(self, state: ChatGraphState) -> str:
        """Build intelligent conversation summary for LLM routing context."""
        if not state.conversation_history:
            return "No previous conversation"
        
        # Get recent messages with intelligent summarization
        recent_messages = state.conversation_history[-6:]
        summary_parts = []
        
        # Track conversation themes
        customer_operations = []
        general_topics = []
        contextual_refs = []
        
        for msg in recent_messages:
            content = getattr(msg, 'content', '') if hasattr(msg, 'content') else str(msg)
            role = getattr(msg, 'role', 'user') if hasattr(msg, 'role') else 'user'
            
            # Truncate long messages
            display_content = content[:200] + "..." if len(content) > 200 else content
            
            # Categorize message content
            content_lower = content.lower()
            if any(op in content_lower for op in ['customer', 'client', 'add', 'update', 'delete', 'create']):
                customer_operations.append(f"{role}: {display_content}")
            elif any(ref in content_lower for ref in ['his', 'her', 'this', 'that', 'these']):
                contextual_refs.append(f"{role}: {display_content}")
            elif any(topic in content_lower for topic in ['hello', 'thanks', 'help', 'report', 'analytics']):
                general_topics.append(f"{role}: {display_content}")
            else:
                summary_parts.append(f"{role}: {display_content}")
        
        # Build intelligent summary
        summary = ""
        if customer_operations:
            summary += "\n[CUSTOMER OPERATIONS]\n" + "\n".join(customer_operations[-3:])
        if contextual_refs:
            summary += "\n[CONTEXTUAL REFERENCES]\n" + "\n".join(contextual_refs[-2:])
        if general_topics:
            summary += "\n[GENERAL TOPICS]\n" + "\n".join(general_topics[-2:])
        if summary_parts:
            summary += "\n[OTHER MESSAGES]\n" + "\n".join(summary_parts[-2:])
        
        return summary.strip() or "Brief conversation"
    
    async def _fallback_rule_based_routing(self, state: ChatGraphState) -> ChatGraphState:
        """Fallback to rule-based routing when LLM fails."""
        message_lower = state.message.lower().strip()
        
        # Quick rule-based decisions
        if any(keyword in message_lower for keyword in ['customer', 'client', 'add customer', 'update customer', 'delete customer']):
            state.routing_decision = "customer"
            logger.info(f"[FallbackRouter] Keyword match → customer agent")
        else:
            state.routing_decision = "general"
            logger.info(f"[FallbackRouter] Default → general agent")
        
        return state

    async def _llm_classification(self, context: ChatGraphState) -> Dict[str, Any]:
        """Enhanced LLM-based classification with better context awareness and reduced static fallbacks."""
        try:
            # Build comprehensive context
            conversation_context = self._build_enhanced_context(context)
            
            # Enhanced LLM prompt with better business understanding
            system_prompt = """You are an expert agent router with advanced conversation understanding and business context awareness.

AVAILABLE AGENTS:
🔹 customer: Complete customer/client lifecycle management with intelligent workflows
🔹 general: General business operations, greetings, and non-customer specific tasks

CUSTOMER AGENT CAPABILITIES (Enhanced):
✅ **Smart Customer Operations**: Create, read, update, delete with validation
✅ **Intelligent Identification**: Context-aware customer identification ("his details", "that customer", "last customer")
✅ **Dynamic Field Management**: LLM-powered field validation and collection
✅ **Conversation Continuity**: Maintains context across multi-turn interactions
✅ **Bulk Operations**: Handle multiple customers intelligently ("update all", "delete these")
✅ **Error Recovery**: Natural language error handling and correction
✅ **Confirmation Flows**: Smart confirmation with context preservation

CONTEXT-AWARE ROUTING RULES:
🎯 **Contextual References**: 
   - "his", "her", "this", "that" + customer context → customer agent
   - "update his phone" (after customer discussion) → customer agent
   - "delete this" (in customer context) → customer agent

🎯 **Intent Continuation**:
   - Providing data for ongoing customer operation → customer agent
   - Yes/no responses to customer confirmations → customer agent
   - Field values in customer context → customer agent

🎯 **Natural Language Understanding**:
   - "both customers" = bulk operation → customer agent
   - "the one with gmail" = contextual search → customer agent
   - "sounds good" (in customer context) → customer agent

🎯 **Smart Disambiguation**:
   - "show customers" vs "show me the options" (context-dependent)
   - "delete that" vs "delete this file" (business context)
   - "his details" vs "his company" (customer vs general)

CONTEXTUAL REFERENCE ANALYSIS:
📋 Look at recent conversation to understand what contextual references point to
📋 Customer operations in progress take priority for related references
📋 General conversation context routes general references appropriately

ROUTING EXAMPLES:
- "update his phone to 123456789" (after customer data shown) → customer
- "delete this customer" (after customer search) → customer  
- "show me these details" (after customer query) → customer
- "that's helpful" (after general help) → general
- "his company makes software" (general discussion) → general
- "update both customers" → customer (bulk operation)
- "the last customer" → customer (positional reference)

Respond with JSON:
{{
    "agent_type": "customer" or "general",
    "confidence": 0.0-1.0,
    "reasoning": "detailed explanation including context analysis",
    "context_type": "customer_operation|general_conversation|ambiguous",
    "reference_analysis": "analysis of contextual references if any"
}}"""

            user_prompt = f"""CONVERSATION CONTEXT:
{conversation_context}

CURRENT QUERY: "{context.message}"

Analyze and route with full context awareness:"""

            response = await self.llm_service.chat([
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ])
            
            # Parse JSON response with enhanced fallback
            try:
                import json
                result = self._parse_llm_json_response(response.strip())
                
                # Validate and enhance result
                if 'agent_type' in result and result['agent_type'] in ['customer', 'general']:
                    result['confidence'] = max(0.7, result.get('confidence', 0.8))  # Boost confidence for valid LLM responses
                    result['reasoning'] = f"LLM: {result.get('reasoning', 'Intelligent routing based on context')}"
                    return result
                else:
                    logger.warning(f"[AgentRouter] Invalid agent_type in LLM response: {result}")
                    return self._enhanced_keyword_fallback(context.message)
                    
            except json.JSONDecodeError:
                # Enhanced fallback for invalid JSON
                logger.warning(f"[AgentRouter] Failed to parse LLM response as JSON: {response}")
                return self._enhanced_keyword_fallback(context.message)
                    
        except Exception as e:
            logger.error(f"[AgentRouter] Error in LLM classification: {e}")
            return self._enhanced_keyword_fallback(context.message)
    
    def _parse_llm_json_response(self, response: str) -> dict:
        """Parse JSON response from LLM, handling markdown code blocks and other formatting issues."""
        import json
        import re
        
        # Clean the response
        response = response.strip()
        
        # Remove markdown code blocks
        if response.startswith('```json'):
            response = response[7:]  # Remove ```json
        elif response.startswith('```'):
            response = response[3:]   # Remove ```
        
        if response.endswith('```'):
            response = response[:-3]  # Remove ending ```
        
        # Remove any extra whitespace
        response = response.strip()
        
        # Try to extract JSON if it's embedded in other text
        json_match = re.search(r'\{.*\}', response, re.DOTALL)
        if json_match:
            response = json_match.group(0)
        
        try:
            return json.loads(response)
        except json.JSONDecodeError as e:
            logger.error(f"[AgentRouter] Failed to parse JSON: {e}, cleaned response: {response[:200]}...")
            # Return a default fallback structure
            return {
                'agent_type': 'general',
                'confidence': 0.3,
                'reasoning': 'JSON parsing failed, using fallback'
            }
    
    def _enhanced_keyword_fallback(self, message: str) -> Dict[str, Any]:
        """Enhanced fallback with smarter keyword detection"""
        message_lower = message.lower().strip()
        
        # Priority 1: Strong customer indicators (high confidence)
        strong_customer_patterns = [
            r'\b(add|create|insert)\s+.*customer\b',
            r'\b(update|modify|change)\s+.*customer\b', 
            r'\b(delete|remove)\s+.*customer\b',
            r'\b(find|search|show|list)\s+.*customer\b',
            r'\bcus-\d{6}\b',  # Customer ID pattern
            r'\b(his|her)\s+(phone|email|details|info)\b',
            r'\b(update|change)\s+(his|her|this|that)\b'
        ]
        
        for pattern in strong_customer_patterns:
            if re.search(pattern, message_lower):
                return {
                    'agent_type': 'customer',
                    'confidence': 0.9,
                    'reasoning': f'Enhanced fallback: Strong customer pattern detected - {pattern}'
                }
        
        # Priority 2: Moderate customer indicators
        moderate_customer_patterns = [
            r'\bcustomer\b', r'\bclient\b', r'\bphone\b', r'\bemail\b',
            r'\bupdate\b', r'\bmodify\b', r'\bdelete\b', r'\bremove\b'
        ]
        
        customer_score = sum(1 for pattern in moderate_customer_patterns if re.search(pattern, message_lower))
        
        if customer_score >= 2:  # Multiple customer-related terms
            return {
                'agent_type': 'customer',
                'confidence': 0.7,
                'reasoning': f'Enhanced fallback: Multiple customer terms detected (score: {customer_score})'
            }
        elif customer_score >= 1:
            return {
                'agent_type': 'customer',
                'confidence': 0.6,
                'reasoning': f'Enhanced fallback: Customer term detected (score: {customer_score})'
            }
        
        # Default to general with context note
        return {
            'agent_type': 'general',
            'confidence': 0.5,
            'reasoning': 'Enhanced fallback: No strong customer indicators, routing to general'
        }
    
    def _combine_analyses(self, keyword_analysis, context_analysis, intent_analysis, llm_analysis) -> Dict[str, Any]:
        """Dynamic analysis combination with LLM-weighted scoring."""
        # Dynamic weight adjustment based on context quality
        base_weights = {
            'llm': 0.5,      # Increased LLM weight for dynamic routing
            'context': 0.3,  # Context is crucial for continuity
            'keyword': 0.15, # Keywords as supporting evidence
            'intent': 0.05   # Intent as final tiebreaker
        }
        
        # Adjust weights based on context quality
        context_quality = context_analysis.get('customer_confidence', 0.0)
        if context_quality > 0.8:
            # High context quality - boost context weight
            base_weights['context'] += 0.2
            base_weights['llm'] -= 0.1
            base_weights['keyword'] -= 0.1
        elif context_quality < 0.3:
            # Low context quality - rely more on LLM and keywords
            base_weights['llm'] += 0.15
            base_weights['keyword'] += 0.1
            base_weights['context'] -= 0.25
        
        # Calculate dynamic weighted scores
        customer_score = 0
        general_score = 0
        confidence_factors = []
        
        analyses = {
            'keyword': keyword_analysis,
            'context': context_analysis,
            'intent': intent_analysis,
            'llm': llm_analysis
        }
        
        for method, analysis_data in analyses.items():
            weight = base_weights[method]
            confidence = analysis_data.get('confidence', 0.5)
            
            if analysis_data.get('agent_type') == 'customer':
                customer_score += confidence * weight
                confidence_factors.append(f"{method}({confidence:.2f}*{weight:.2f})")
            else:
                general_score += confidence * weight
        
        # Determine final decision with confidence boosting
        if customer_score > general_score:
            final_agent = 'customer'
            final_confidence = min(0.95, customer_score + 0.1)  # Boost customer agent confidence
        else:
            final_agent = 'general'
            final_confidence = general_score
        
        # Enhanced reasoning with methodology transparency
        primary_factor = max(analyses.keys(), key=lambda k: analyses[k].get('confidence', 0) * base_weights[k])
        reasoning = f"Dynamic routing: {final_agent} agent selected. Primary factor: {primary_factor} ({analyses[primary_factor].get('reasoning', 'N/A')})"
        
        return {
            'agent_type': final_agent,
            'confidence': final_confidence,
            'reasoning': reasoning,
            'methodology': 'dynamic_llm_weighted',
            'confidence_factors': confidence_factors
        }
    
    def _build_enhanced_context(self, context: ChatGraphState) -> str:
        """Build enhanced conversation context with flow awareness and contextual reference highlighting."""
        if not context.conversation_history:
            return "No previous conversation"
        
        # Get recent messages with enhanced analysis
        recent_messages = context.conversation_history[-8:]
        context_parts = []
        
        # Track conversation themes and flows
        customer_theme_score = 0
        general_theme_score = 0
        customer_data_mentioned = False
        recent_customer_data = []
        last_displayed_customer = None
        customer_display_detected = False
        
        for msg in recent_messages:
            content = getattr(msg, 'content', '') if hasattr(msg, 'content') else str(msg)
            role = getattr(msg, 'role', 'user') if hasattr(msg, 'role') else 'user'
            
            # Analyze content for themes
            content_lower = content.lower()
            if any(word in content_lower for word in ['customer', 'client', 'phone', 'email', 'update', 'delete', 'add']):
                customer_theme_score += 1
            
            # Detect customer information display (assistant responses showing customer data)
            if role == 'assistant' and any(indicator in content_lower for indicator in 
                ['customer information', 'customer id:', 'email address:', 'phone number:', 'organization:', 'customer details']):
                customer_display_detected = True
                # Extract customer ID from displayed information
                import re
                customer_id_matches = re.findall(r'customer id[:\s]+([a-z]+-\d{6})', content_lower)
                if customer_id_matches:
                    last_displayed_customer = customer_id_matches[-1].upper()  # Get the most recent one
            
            # Check for customer data mentions
            if any(word in content_lower for word in ['phone', 'email', 'address', 'organization', 'customer id', 'cus-']):
                customer_data_mentioned = True
                # Extract customer data for context
                if 'cus-' in content_lower:
                    import re
                    customer_ids = re.findall(r'cus-\d{6}', content_lower)
                    recent_customer_data.extend([cid.upper() for cid in customer_ids])
                    if customer_ids:
                        last_displayed_customer = customer_ids[-1].upper()  # Most recent customer ID
            
            if any(word in content_lower for word in ['hello', 'hi', 'thanks', 'help', 'sales', 'report']):
                general_theme_score += 1
            
            # Format message with contextual reference highlighting
            display_content = content[:150] + "..." if len(content) > 150 else content
            
            # Highlight contextual references in the message
            if any(ref in content_lower for ref in ['this', 'these', 'that', 'those', 'his', 'her', 'him', 'it', 'them']):
                display_content = f"🔍 {display_content} [CONTAINS CONTEXTUAL REFERENCE]"
            
            context_parts.append(f"{role}: {display_content}")
        
        # Add context analysis with customer data information
        context_analysis = ""
        if customer_theme_score > general_theme_score:
            context_analysis = "[CONTEXT: Active customer conversation detected] "
            if customer_data_mentioned:
                context_analysis += "[CUSTOMER DATA: Recently mentioned] "
            if recent_customer_data:
                context_analysis += f"[CUSTOMER IDs: {', '.join(set(recent_customer_data))}] "
            if last_displayed_customer:
                context_analysis += f"[LAST DISPLAYED CUSTOMER: {last_displayed_customer}] "
        elif general_theme_score > customer_theme_score:
            context_analysis = "[CONTEXT: General business conversation] "
        
        # Add flow information if available
        if hasattr(context, 'current_flow') and context.current_flow:
            context_analysis += f"[FLOW: {context.current_flow}] "
        
        # Add contextual reference analysis
        current_message_lower = context.message.lower()
        has_contextual_ref = any(ref in current_message_lower for ref in ['this', 'these', 'that', 'those', 'his', 'her', 'him', 'it', 'them'])
        if has_contextual_ref:
            context_analysis += "[CURRENT MESSAGE: Contains contextual reference] "
            if last_displayed_customer:
                context_analysis += f"[CONTEXTUAL TARGET: {last_displayed_customer}] "
        
        context_str = "\n".join(context_parts) if context_parts else "No context"
        return context_analysis + context_str
    
    def _update_user_context(self, user_id: str, context: ChatGraphState):
        """Update user context for continuity."""
        if user_id not in self.conversation_flows:
            self.conversation_flows[user_id] = {
                'last_agent': None,
                'conversation_count': 0,
                'themes': [],
                'last_activity': time.time()
            }
        
        flow = self.conversation_flows[user_id]
        flow['conversation_count'] += 1
        flow['last_activity'] = time.time()
        
        # Track conversation themes
        message_lower = context.message.lower()
        if any(word in message_lower for word in ['customer', 'client']):
            flow['themes'].append('customer')
        elif any(word in message_lower for word in ['hello', 'hi', 'thanks']):
            flow['themes'].append('general')
        
        # Keep only recent themes
        flow['themes'] = flow['themes'][-10:]
    
    def _clear_pause_state(self, context: ChatGraphState):
        """Clear pause state from context."""
        if hasattr(context, 'pause_reason'):
            context.pause_reason = None
        if hasattr(context, 'pause_message'):
            context.pause_message = None
        if hasattr(context, 'confirm'):
            context.confirm = None
        if hasattr(context, 'resume_from_pause'):
            context.resume_from_pause = None
    
    def _get_context_summary(self, context: ChatGraphState) -> Dict[str, Any]:
        """Get context summary for debugging and analysis."""
        return {
            'message_length': len(context.message),
            'conversation_length': len(context.conversation_history) if context.conversation_history else 0,
            'has_pause_reason': hasattr(context, 'pause_reason') and context.pause_reason is not None,
            'current_flow': getattr(context, 'current_flow', None),
            'user_id': getattr(context, 'user_id', 'unknown')
        }
    
    def track_routing_success(self, query: str, routed_agent: str, user_satisfaction: float = None, execution_success: bool = True):
        """Track routing decisions for adaptive learning."""
        routing_record = {
            'timestamp': time.time(),
            'query': query,
            'routed_agent': routed_agent,
            'execution_success': execution_success,
            'user_satisfaction': user_satisfaction,
            'query_pattern': self._extract_query_pattern(query)
        }
        
        self.routing_history.append(routing_record)
        
        # Keep only recent history for memory efficiency
        if len(self.routing_history) > 1000:
            self.routing_history = self.routing_history[-800:]
        
        # Update adaptation patterns
        self._update_adaptation_patterns(routing_record)
    
    def _extract_query_pattern(self, query: str) -> Dict[str, Any]:
        """Extract learnable patterns from queries."""
        query_lower = query.lower().strip()
        
        return {
            'length': len(query.split()),
            'has_contextual_ref': any(ref in query_lower for ref in ['his', 'her', 'this', 'that', 'these']),
            'has_customer_keywords': any(kw in query_lower for kw in ['customer', 'client', 'phone', 'email']),
            'is_question': query.strip().endswith('?'),
            'is_command': any(cmd in query_lower for cmd in ['add', 'create', 'update', 'delete', 'show', 'find']),
            'complexity_score': min(10, len(query.split()) + query.count(',') + query.count('and'))
        }
    
    def _update_adaptation_patterns(self, routing_record: Dict[str, Any]):
        """Update learned patterns based on routing success."""
        pattern = routing_record['query_pattern']
        agent = routing_record['routed_agent']
        success = routing_record['execution_success']
        
        # Create pattern key
        pattern_key = f"{pattern['has_contextual_ref']}_{pattern['has_customer_keywords']}_{pattern['is_question']}"
        
        if pattern_key not in self.adaptation_patterns:
            self.adaptation_patterns[pattern_key] = {
                'customer_success_rate': 0.5,
                'general_success_rate': 0.5,
                'total_samples': 0,
                'confidence_boost': 0.0
            }
        
        pattern_data = self.adaptation_patterns[pattern_key]
        pattern_data['total_samples'] += 1
        
        # Update success rates with learning rate
        if agent == 'customer':
            old_rate = pattern_data['customer_success_rate']
            new_sample = 1.0 if success else 0.0
            pattern_data['customer_success_rate'] = old_rate + self.learning_rate * (new_sample - old_rate)
        else:
            old_rate = pattern_data['general_success_rate']
            new_sample = 1.0 if success else 0.0
            pattern_data['general_success_rate'] = old_rate + self.learning_rate * (new_sample - old_rate)
        
        # Calculate confidence boost based on success patterns
        success_diff = abs(pattern_data['customer_success_rate'] - pattern_data['general_success_rate'])
        pattern_data['confidence_boost'] = min(0.2, success_diff * 0.3)
    
    def _get_adaptive_confidence_boost(self, query: str, predicted_agent: str) -> float:
        """Get confidence boost based on learned patterns."""
        pattern = self._extract_query_pattern(query)
        pattern_key = f"{pattern['has_contextual_ref']}_{pattern['has_customer_keywords']}_{pattern['is_question']}"
        
        if pattern_key in self.adaptation_patterns:
            pattern_data = self.adaptation_patterns[pattern_key]
            
            # Boost confidence if learned pattern supports the prediction
            if predicted_agent == 'customer' and pattern_data['customer_success_rate'] > 0.7:
                return pattern_data['confidence_boost']
            elif predicted_agent == 'general' and pattern_data['general_success_rate'] > 0.7:
                return pattern_data['confidence_boost']
        
        return 0.0
    
    def _update_agent_performance(self, agent_type: str, confidence: float):
        """Update agent performance metrics with enhanced tracking."""
        if agent_type not in self.agent_performance:
            self.agent_performance[agent_type] = {
                'total_requests': 0,
                'total_confidence': 0,
                'average_confidence': 0,
                'success_rate': 0.8,  # Default assumption
                'last_used': time.time()
            }
        
        perf = self.agent_performance[agent_type]
        perf['total_requests'] += 1
        perf['total_confidence'] += confidence
        perf['average_confidence'] = perf['total_confidence'] / perf['total_requests']
        perf['last_used'] = time.time()
        
        # Adaptive threshold adjustment based on performance
        if perf['average_confidence'] > 0.9 and perf['success_rate'] > 0.85:
            self.routing_confidence_threshold = max(0.6, self.routing_confidence_threshold - 0.02)
        elif perf['average_confidence'] < 0.7 or perf['success_rate'] < 0.7:
            self.routing_confidence_threshold = min(0.9, self.routing_confidence_threshold + 0.02)
    
    async def _intelligent_fallback(self, context: ChatGraphState) -> Dict[str, Any]:
        """Intelligent fallback with context awareness."""
        try:
            # Use fallback classification
            fallback_agent = self._fallback_classification(context.message)
            
            # Get agent and execute
            agent = self.agent_registry.get_agent(fallback_agent)
            result = await agent.ainvoke(context.model_dump())
            
            if isinstance(result, dict):
                result['routed_agent'] = fallback_agent
                result['routing_confidence'] = 'intelligent_fallback'
                result['routing_reasoning'] = 'fallback_classification'
            
            return result
            
        except Exception as e:
            logger.error(f"[AgentRouter] Error in intelligent fallback: {e}")
            raise e
    
    async def _classify_query_dynamically(self, context: ChatGraphState) -> str:
        """
        Optimized dynamic LLM-based agent classification with conversation context.
        Uses conversation history and intent analysis for accurate routing.
        """
        try:
            # Build optimized conversation context (last 6 messages)
            conversation_context = self._build_optimized_context(context)
            
            # Enhanced dynamic classification prompt with improved conversation understanding
            system_prompt = """You are an expert agent router with advanced conversation understanding and context awareness. Make intelligent routing decisions based on conversation flow and user intent.

AVAILABLE AGENTS:
🔹 customer: Customer/Client data operations, relationship management, and customer workflows
🔹 general: All other business queries, greetings, and general conversation

CUSTOMER AGENT RESPONSIBILITIES:
✅ Creating/adding new customers or clients
✅ Searching/finding existing customer information  
✅ Updating customer details and records
✅ Deleting/removing customers from system
✅ Listing customers with various filters
✅ Customer relationship management tasks
✅ Customer data validation and collection
✅ Handling incomplete customer information
✅ Confirmations for customer operations (yes/no responses)
✅ Continuing ongoing customer workflows
✅ Collecting missing customer data fields
✅ Customer data corrections and updates

GENERAL AGENT RESPONSIBILITIES:
✅ Greetings and casual conversation
✅ Business operations (orders, sales, inventory, products)
✅ Reports and analytics (non-customer specific)
✅ System information and help requests
✅ General business inquiries
✅ Non-customer confirmations

CRITICAL ROUTING RULES:
🚨 **EXPLICIT CUSTOMER KEYWORDS OVERRIDE CONTEXT**: If user message contains "customer", "client", "add customer", "create customer", "find customer", "search customer", "update customer", "delete customer" → ALWAYS route to customer agent regardless of conversation history
🚨 **CANCELLATION RECOVERY**: After a cancelled operation, treat new explicit requests as fresh operations
🚨 **KEYWORD PRIORITY**: Direct customer operation keywords take precedence over conversational context

CONTEXT ANALYSIS RULES:
🎯 **Workflow Continuity**: If previous messages show active customer operations → route to customer
🎯 **Data Collection**: If user is providing customer data (phone, email, etc.) → route to customer
🎯 **Dynamic Confirmation Context**: Route natural language confirmations/rejections to the agent handling the pending operation
🎯 **Natural Language Understanding**: "sounds good", "let's do it", "forget it", "never mind" → route based on context
🎯 **Topic Switching**: Clear topic changes from customer to general → route to general
🎯 **Implicit References**: "his details", "update him", "delete this" in customer context → route to customer
🎯 **Keyword Equivalence**: "client" = "customer" (treat identically)

ENHANCED ROUTING LOGIC:
1. **Keywords First**: Check for explicit customer operation keywords before analyzing context
2. **Intent Recognition**: Understand user's actual goal beyond surface words
3. **Workflow Preservation**: Maintain active customer operations until completion
4. **Smart Confirmations**: Route confirmations based on what's being confirmed
5. **Fresh Start**: After cancellations, treat new requests as independent operations
6. **Explicit Customer Operations**: Always route customer keywords to customer agent

EXAMPLES:
- "add a customer" → customer (explicit keyword - ALWAYS customer regardless of context)
- "add customer" → customer (explicit keyword - ALWAYS customer regardless of context)
- "create customer" → customer (explicit keyword - ALWAYS customer regardless of context)
- "yes" (after customer delete confirmation) → customer (workflow context)
- "sounds good" (after customer update request) → customer (natural confirmation)
- "forget it" (during customer operation) → customer (natural cancellation)
- "let's do it" (after confirmation prompt) → customer (natural agreement)
- "never mind" (during any operation) → customer (natural cancellation)
- "his phone number is 123456789" → customer (data collection context)
- "hello" → general (greeting)
- "show me sales report" → general (non-customer operation)

Respond with EXACTLY ONE WORD: "customer" or "general" """

            user_prompt = f"""CONVERSATION CONTEXT:
{conversation_context}

CURRENT QUERY: "{context.message}"

Route to:"""
            
            # Single optimized LLM call
            logger.info(f"[AgentRouter] Sending to LLM: '{context.message}'")
            classification_response = await self.llm_service.chat([
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ])
            
            logger.info(f"[AgentRouter] LLM Raw Response: '{classification_response}'")
            
            # Fast parsing with fallback
            raw = classification_response.strip().lower()
            cleaned = re.sub(r"[^a-z]", "", raw)
            
            logger.info(f"[AgentRouter] Cleaned Response: '{cleaned}'")
            
            if cleaned in ["customer", "general"]:
                agent_type = cleaned
                logger.info(f"[AgentRouter] Direct match: {agent_type}")
            else:
                # Fallback: detect keywords in raw response
                if "customer" in raw:
                    agent_type = "customer"
                    logger.info(f"[AgentRouter] Keyword match: customer")
                elif "general" in raw:
                    agent_type = "general"
                    logger.info(f"[AgentRouter] Keyword match: general")
                else:
                    logger.warning(f"[AgentRouter] Invalid classification '{classification_response}', using fallback classification")
                    fallback_result = self._fallback_classification(context.message)
                    logger.info(f"[AgentRouter] Fallback result: {fallback_result}")
                    return fallback_result
                
            logger.info(f"[AgentRouter] Final LLM classification: {agent_type}")
            return agent_type
            
        except Exception as e:
            logger.error(f"[AgentRouter] Error in dynamic classification: {e}")
            # Fallback to rule-based classification
            return self._fallback_classification(context.message)
    
    def _build_optimized_context(self, context: ChatGraphState) -> str:
        """Build intelligent conversation context with workflow awareness."""
        if not context.conversation_history:
            return "No previous conversation"
        
        # Get last 8 messages for better context (increased from 6)
        recent_messages = context.conversation_history[-8:]
        context_parts = []
        
        # Track conversation themes
        customer_keywords = ['customer', 'client', 'add', 'create', 'update', 'delete', 'search', 'find', 'phone', 'email']
        customer_score = 0
        
        for msg in recent_messages:
            # Process message content
            if hasattr(msg, 'role') and hasattr(msg, 'content'):
                role, content = msg.role, msg.content
            elif isinstance(msg, dict):
                role = msg.get('role', 'user')
                content = msg.get('content', '')
            else:
                continue
            
            # Analyze content for customer-related themes
            content_lower = content.lower()
            for keyword in customer_keywords:
                if keyword in content_lower:
                    customer_score += 1
            
            # Preserve important context, truncate less important messages
            if any(word in content_lower for word in ['confirm', 'yes', 'no', 'cancel', 'phone', 'email']):
                # Keep confirmation and data messages full
                display_content = content[:200] + "..." if len(content) > 200 else content
            else:
                # Truncate general messages more aggressively
                display_content = content[:80] + "..." if len(content) > 80 else content
            
            context_parts.append(f"{role}: {display_content}")
        
        # Add context analysis
        context_analysis = ""
        if customer_score > 2:
            context_analysis = "[CONTEXT: Active customer conversation detected] "
        elif customer_score > 0:
            context_analysis = "[CONTEXT: Some customer references found] "
        
        context_str = "\n".join(context_parts) if context_parts else "No context"
        return context_analysis + context_str
    
    def _build_conversation_context(self, context: ChatGraphState) -> str:
        """Legacy method - redirects to optimized version."""
        return self._build_optimized_context(context)
    
    def _generate_cache_key(self, context: ChatGraphState) -> str:
        """Generate a cache key based on message and recent context."""
        # Use message + last 2 conversation turns for cache key
        cache_input = context.message.lower().strip()
        
        if context.conversation_history:
            recent = context.conversation_history[-2:]
            for msg in recent:
                if hasattr(msg, 'content'):
                    cache_input += msg.content[:50]  # First 50 chars only
                elif isinstance(msg, dict):
                    cache_input += msg.get('content', '')[:50]
        
        return hashlib.md5(cache_input.encode()).hexdigest()
    
    def _get_cached_classification(self, cache_key: str) -> str:
        """Get cached classification if valid and not expired."""
        if cache_key in self.classification_cache:
            cached_data = self.classification_cache[cache_key]
            if time.time() - cached_data['timestamp'] < self.cache_ttl:
                return cached_data['agent_type']
            else:
                # Remove expired cache entry
                del self.classification_cache[cache_key]
        return None
    
    def _cache_classification(self, cache_key: str, agent_type: str):
        """Cache the classification result."""
        self.classification_cache[cache_key] = {
            'agent_type': agent_type,
            'timestamp': time.time()
        }
        
        # Limit cache size to prevent memory bloat
        if len(self.classification_cache) > 1000:
            # Remove oldest 200 entries
            sorted_items = sorted(self.classification_cache.items(), 
                                key=lambda x: x[1]['timestamp'])
            for key, _ in sorted_items[:200]:
                del self.classification_cache[key]
    
    def _fallback_classification(self, message: str) -> str:
        """
        Optimized fallback classification using fast pattern matching.
        This is used only when LLM classification fails.
        """
        message_lower = message.lower().strip()
        
        # PRIORITY: Customer operations - check first before greetings
        customer_keywords = [
            'customer', 'client', 'add customer', 'create customer', 'new customer',
            'find customer', 'search customer', 'update customer', 'delete customer',
            'list customer', 'show customer', 'customer data', 'customer info',
            'last customer', 'latest customer', 'recent customer', 'last 5 customer',
            'last 10 customer', 'top customer', 'all customer', 'customer count'
        ]
        
        # Quick keyword check for performance - PRIORITY CHECK
        if any(keyword in message_lower for keyword in customer_keywords):
            return 'customer'
        
        # Greetings and general conversation - only after customer check
        greeting_patterns = ['hi', 'hello', 'hey', 'good morning', 'good afternoon', 'good evening', 'how are you', 'thanks', 'thank you']
        if any(pattern in message_lower for pattern in greeting_patterns):
            return 'general'
        
        # Default to general for everything else
        return 'general'

    def _track_classification(self, query: str, agent_type: str, confidence: str = 'high'):
        """
        Track classification decisions for potential learning and improvement.
        """
        classification_record = {
            'query': query,
            'agent_type': agent_type,
            'confidence': confidence,
            'timestamp': time.time()
        }
        self.classification_history.append(classification_record)
        
        # Keep only last 1000 classifications to prevent memory bloat
        if len(self.classification_history) > 1000:
            self.classification_history = self.classification_history[-1000:]
    
    def get_classification_stats(self):
        """
        Get comprehensive statistics about classification decisions and performance.
        """
        if not self.classification_history:
            return {
                'total': 0, 'customer': 0, 'general': 0,
                'customer_percentage': 0, 'general_percentage': 0,
                'average_confidence': 0, 'performance_metrics': {}
            }
        
        total = len(self.classification_history)
        customer_count = sum(1 for record in self.classification_history if record['agent_type'] == 'customer')
        general_count = sum(1 for record in self.classification_history if record['agent_type'] == 'general')
        
        # Calculate average confidence
        total_confidence = sum(record.get('confidence', 0.5) for record in self.classification_history)
        average_confidence = total_confidence / total if total > 0 else 0
        
        return {
            'total': total,
            'customer': customer_count,
            'general': general_count,
            'customer_percentage': (customer_count / total) * 100 if total > 0 else 0,
            'general_percentage': (general_count / total) * 100 if total > 0 else 0,
            'average_confidence': average_confidence,
            'performance_metrics': self.agent_performance,
            'conversation_flows': len(self.conversation_flows),
            'cache_size': len(self.classification_cache)
        }
    
    def get_agent_performance_metrics(self) -> Dict[str, Any]:
        """Get detailed agent performance metrics."""
        return {
            'agent_performance': self.agent_performance,
            'conversation_flows': self.conversation_flows,
            'routing_patterns': dict(self.routing_patterns),
            'cache_utilization': len(self.classification_cache),
            'learning_enabled': self.learning_enabled
        }
    
    def reset_performance_metrics(self):
        """Reset all performance metrics and learning data."""
        self.classification_history = []
        self.classification_cache = {}
        self.conversation_flows = {}
        self.agent_performance = {}
        self.routing_patterns = defaultdict(list)
        logger.info("[AgentRouter] Performance metrics reset")
    
    async def optimize_routing_dynamically(self):
        """LLM-driven optimization of routing patterns and weights."""
        try:
            if len(self.routing_history) < 10:
                return  # Need sufficient data for optimization
            
            # Analyze recent routing patterns
            recent_routes = self.routing_history[-50:]  # Last 50 routes
            
            # Build optimization prompt
            optimization_prompt = f"""You are a routing optimization expert analyzing agent routing patterns.

RECENT ROUTING PERFORMANCE:
- Total routes analyzed: {len(recent_routes)}
- Customer agent routes: {sum(1 for r in recent_routes if r['routed_agent'] == 'customer')}
- General agent routes: {sum(1 for r in recent_routes if r['routed_agent'] == 'general')}
- Average success rate: {sum(r.get('execution_success', True) for r in recent_routes) / len(recent_routes):.2f}

CURRENT CONFIGURATION:
- Confidence threshold: {self.routing_confidence_threshold}
- Learning rate: {self.learning_rate}

PATTERN ANALYSIS:
{self._analyze_routing_patterns()}

Recommend optimizations for:
1. Confidence threshold adjustment (0.6-0.9)
2. Learning rate adjustment (0.05-0.2)
3. New routing strategies

Respond with JSON:
{{
    "confidence_threshold": 0.6-0.9,
    "learning_rate": 0.05-0.2,
    "optimization_reasoning": "detailed analysis",
    "suggested_improvements": ["list of specific improvements"],
    "priority_adjustments": {{
        "customer_priority": 1.0-2.0,
        "general_priority": 1.0-2.0
    }}
}}"""

            response = await self.llm_service.chat([
                {"role": "system", "content": "You are a performance optimization analyst. Always respond with valid JSON."},
                {"role": "user", "content": optimization_prompt}
            ])
            
            optimization = self._parse_llm_json_response(response.strip())
            
            # Apply optimizations safely
            old_threshold = self.routing_confidence_threshold
            old_learning_rate = self.learning_rate
            
            self.routing_confidence_threshold = optimization.get('confidence_threshold', old_threshold)
            self.learning_rate = optimization.get('learning_rate', old_learning_rate)
            
            logger.info(f"[AgentRouter] Dynamic optimization applied:")
            logger.info(f"  Confidence threshold: {old_threshold:.2f} → {self.routing_confidence_threshold:.2f}")
            logger.info(f"  Learning rate: {old_learning_rate:.2f} → {self.learning_rate:.2f}")
            logger.info(f"  Reasoning: {optimization.get('optimization_reasoning', 'No reasoning provided')}")
            
        except Exception as e:
            logger.error(f"[AgentRouter] Error in dynamic optimization: {e}")
    
    def _analyze_routing_patterns(self) -> str:
        """Analyze current routing patterns for optimization."""
        if not self.routing_history:
            return "No routing history available"
        
        patterns = []
        
        # Success rates by agent
        customer_routes = [r for r in self.routing_history if r['routed_agent'] == 'customer']
        general_routes = [r for r in self.routing_history if r['routed_agent'] == 'general']
        
        if customer_routes:
            customer_success = sum(r.get('execution_success', True) for r in customer_routes) / len(customer_routes)
            patterns.append(f"Customer agent success rate: {customer_success:.2f}")
        
        if general_routes:
            general_success = sum(r.get('execution_success', True) for r in general_routes) / len(general_routes)
            patterns.append(f"General agent success rate: {general_success:.2f}")
        
        # Common query patterns
        query_patterns = defaultdict(int)
        for route in self.routing_history[-20:]:
            pattern = route.get('query_pattern', {})
            if pattern:
                key = f"contextual:{pattern.get('has_contextual_ref', False)}_customer_kw:{pattern.get('has_customer_keywords', False)}"
                query_patterns[key] += 1
        
        patterns.append("Common patterns: " + ", ".join([f"{k}({v})" for k, v in query_patterns.items()]))
        
        return "; ".join(patterns)
    
    async def get_dynamic_routing_insights(self) -> Dict[str, Any]:
        """Generate LLM-powered insights about routing performance."""
        try:
            stats = self.get_classification_stats()
            
            insights_prompt = f"""Analyze these routing statistics and provide actionable insights.

ROUTING STATISTICS:
- Total requests: {stats['total']}
- Customer agent: {stats['customer_percentage']:.1f}%
- General agent: {stats['general_percentage']:.1f}%
- Average confidence: {stats['average_confidence']:.2f}

ADAPTATION PATTERNS:
{len(self.adaptation_patterns)} learned patterns

PERFORMANCE METRICS:
{stats['performance_metrics']}

Provide insights about:
1. Routing effectiveness
2. Potential improvements
3. Pattern recognition quality
4. Confidence calibration

Respond with JSON:
{{
    "overall_health": "excellent|good|fair|poor",
    "key_insights": ["list of insights"],
    "improvement_suggestions": ["list of suggestions"],
    "confidence_assessment": "analysis of confidence levels",
    "pattern_quality": "assessment of learned patterns"
}}"""

            response = await self.llm_service.chat([
                {"role": "system", "content": "You are a routing performance analyst. Always respond with valid JSON."},
                {"role": "user", "content": insights_prompt}
            ])
            
            insights = self._parse_llm_json_response(response.strip())
            
            # Add raw statistics
            insights['raw_statistics'] = stats
            insights['adaptation_patterns_count'] = len(self.adaptation_patterns)
            insights['routing_history_size'] = len(self.routing_history)
            
            return insights
            
        except Exception as e:
            logger.error(f"[AgentRouter] Error generating insights: {e}")
            return {
                'overall_health': 'unknown',
                'key_insights': ['Error generating insights'],
                'improvement_suggestions': ['Unable to analyze due to error'],
                'error': str(e)
            }

    def get_router_health_status(self) -> Dict[str, Any]:
        """Get comprehensive router health and status information."""
        try:
            stats = self.get_classification_stats()
            
            # Calculate health metrics
            total_routes = len(self.routing_history)
            recent_routes = self.routing_history[-50:] if total_routes >= 50 else self.routing_history
            
            success_rate = sum(r.get('execution_success', True) for r in recent_routes) / len(recent_routes) if recent_routes else 1.0
            avg_confidence = stats.get('average_confidence', 0.0)
            
            # Determine overall health
            if success_rate > 0.9 and avg_confidence > 0.8:
                health = 'excellent'
            elif success_rate > 0.8 and avg_confidence > 0.7:
                health = 'good'
            elif success_rate > 0.7 and avg_confidence > 0.6:
                health = 'fair'
            else:
                health = 'poor'
            
            return {
                'overall_health': health,
                'success_rate': success_rate,
                'average_confidence': avg_confidence,
                'total_routes': total_routes,
                'active_users': len(self.conversation_flows),
                'learned_patterns': len(self.adaptation_patterns),
                'cache_utilization': len(self.classification_cache),
                'routing_distribution': {
                    'customer': stats.get('customer_percentage', 0),
                    'general': stats.get('general_percentage', 0)
                },
                'configuration': {
                    'confidence_threshold': self.routing_confidence_threshold,
                    'learning_rate': self.learning_rate,
                    'learning_enabled': self.learning_enabled
                },
                'recommendations': self._generate_health_recommendations(success_rate, avg_confidence)
            }
            
        except Exception as e:
            logger.error(f"[AgentRouter] Error getting health status: {e}")
            return {
                'overall_health': 'unknown',
                'error': str(e)
            }
    
    def _generate_health_recommendations(self, success_rate: float, avg_confidence: float) -> List[str]:
        """Generate health improvement recommendations."""
        recommendations = []
        
        if success_rate < 0.8:
            recommendations.append("Low success rate detected - consider reviewing routing patterns")
        
        if avg_confidence < 0.7:
            recommendations.append("Low confidence levels - consider improving LLM prompts or adding training data")
        
        if len(self.adaptation_patterns) < 10:
            recommendations.append("Few learned patterns - system needs more interaction data for better adaptation")
        
        if len(self.conversation_flows) > 1000:
            recommendations.append("High memory usage - consider implementing conversation cleanup")
        
        if not recommendations:
            recommendations.append("Router is performing well - continue monitoring")
        
        return recommendations

# Create an alias for backward compatibility
AgentRouter = DynamicAgentRouter

 