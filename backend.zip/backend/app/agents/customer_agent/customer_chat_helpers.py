from backend.app.services.vector_search import FaissVectorSearchService
from backend.app.mcp.mcp_client import MCPClient
import logging
import re

logger = logging.getLogger(__name__)

# Initialize services
vector_search_service = FaissVectorSearchService()
mcp_client = MCPClient(script_path="backend/app/mcp/server_enhanced.py")

async def get_next_customer_id(business_id) -> str:
    """
    Generate the next customer ID in format CUS-XXXXXX where XXXXXX is a 6-digit auto-incremented number.
    This function is bulletproof and handles all edge cases.
    """
    logger.info(f"[CustomerID] Starting ID generation for business_id: {business_id}")
    
    try:
        # Step 1: Get all existing customer IDs with CUS- prefix for this business
        sql_query = f"""
        SELECT xcus FROM cacus 
        WHERE zid = {business_id} 
        AND xcus IS NOT NULL 
        AND xcus LIKE 'CUS-______'
        ORDER BY xcus
        """
        
        logger.info(f"[CustomerID] Executing query: {sql_query}")
        result = await mcp_client.execute_query(sql_query, str(business_id))
        
        # Step 2: Parse the MCP result carefully
        existing_numbers = []
        
        if isinstance(result, dict):
            if 'error' in result:
                logger.error(f"[CustomerID] Query error: {result['error']}")
                # On error, fall back to count-based approach
                raise Exception(f"Query failed: {result['error']}")
            
            if 'content' in result and result['content']:
                try:
                    import json
                    parsed = json.loads(result['content'][0]['text'])
                    rows = parsed.get('results', [])
                    
                    logger.info(f"[CustomerID] Found {len(rows)} existing customer records")
                    
                    # Step 3: Extract all existing numbers
                    for row in rows:
                        xcus = row.get('xcus', '')
                        if xcus and len(xcus) == 10 and xcus.startswith('CUS-'):
                            try:
                                # Extract the 6-digit number after CUS-
                                number_part = xcus[4:]
                                if number_part.isdigit() and len(number_part) == 6:
                                    existing_numbers.append(int(number_part))
                            except (ValueError, IndexError):
                                logger.warning(f"[CustomerID] Skipping invalid format: {xcus}")
                                continue
                    
                    logger.info(f"[CustomerID] Valid existing numbers: {sorted(existing_numbers)}")
                    
                except Exception as parse_error:
                    logger.error(f"[CustomerID] Error parsing result: {parse_error}")
                    logger.error(f"[CustomerID] Raw content: {result.get('content')}")
                    raise parse_error
        
        # Step 4: Determine next number
        if existing_numbers:
            next_number = max(existing_numbers) + 1
            logger.info(f"[CustomerID] Next number based on max({max(existing_numbers)}): {next_number}")
        else:
            next_number = 1
            logger.info(f"[CustomerID] No existing customers found, starting with: 1")
        
        # Step 5: Generate the ID
        generated_id = f"CUS-{next_number:06d}"
        logger.info(f"[CustomerID] Generated ID: {generated_id}")
        
        # Step 6: Verify uniqueness (double-check)
        verify_query = f"SELECT COUNT(*) as count FROM cacus WHERE zid = {business_id} AND xcus = '{generated_id}'"
        verify_result = await mcp_client.execute_query(verify_query, str(business_id))
        
        if isinstance(verify_result, dict) and 'content' in verify_result:
            try:
                import json
                verify_parsed = json.loads(verify_result['content'][0]['text'])
                verify_count = verify_parsed.get('results', [{}])[0].get('count', 0)
                
                if verify_count > 0:
                    logger.error(f"[CustomerID] Generated ID {generated_id} already exists! Falling back to timestamp.")
                    # Emergency fallback
                    import time
                    timestamp_number = int(time.time() * 1000) % 1000000
                    generated_id = f"CUS-{timestamp_number:06d}"
                    logger.warning(f"[CustomerID] Emergency fallback ID: {generated_id}")
            except Exception as verify_error:
                logger.warning(f"[CustomerID] Could not verify uniqueness: {verify_error}")
        
        return generated_id
        
    except Exception as e:
        logger.error(f"[CustomerID] All methods failed: {e}")
        
        # Ultimate fallback - timestamp-based
        import time
        import random
        timestamp = int(time.time() * 1000)
        random_part = random.randint(1, 999)
        fallback_number = (timestamp + random_part) % 1000000
        fallback_id = f"CUS-{fallback_number:06d}"
        
        logger.warning(f"[CustomerID] Using ultimate fallback: {fallback_id}")
        return fallback_id

async def get_customer_schema_context(business_id: str, query: str):
    """
    Get customer table schema context using vector search.
    """
    try:
        # Search for customer-related schemas
        schema_context = await vector_search_service.search_schemas(
            business_id, f"customer table {query}", top_k=2
        )
        return schema_context
    except Exception as e:
        logger.error(f"Error getting customer schema context: {e}")
        return []

async def get_customer_schema_context_for_flow(business_id: str, flow: str):
    """
    Get customer table schema context for specific flow operations.
    """
    try:
        flow_queries = {
            'select': "customer table columns fields select query",
            'update': "customer table columns fields update modify",
            'delete': "customer table primary key customer identification",
            'insert': "customer table columns fields insert create new"
        }
        
        query = flow_queries.get(flow, "customer table schema")
        schema_context = await vector_search_service.search_schemas(
            business_id, query, top_k=3
        )
        return schema_context
    except Exception as e:
        logger.error(f"Error getting customer schema context for flow {flow}: {e}")
        return []

def build_customer_sql_prompt(context, conversation_history, schema_context, reactive_context=None):
    """
    Build SQL generation prompt specifically for customer operations with context awareness.
    Enhanced to support reactive questioning and flow-specific context.
    """
    schema_text = ""
    customer_table_columns = []
    
    if schema_context:
        for schema in schema_context:
            table_name = schema.get('table_name', 'Unknown')
            if 'customer' in table_name.lower() or 'cacus' in table_name.lower():
                schema_text += f"\nTable: {table_name}\n"
                schema_text += f"Description: {schema.get('schema_description', 'Customer data table')}\n"
                schema_text += "Columns:\n"
                
                for col in schema.get('columns', []):
                    col_name = col.get('name', 'Unknown')
                    col_type = col.get('type', 'Unknown')
                    col_desc = col.get('description', 'No description')
                    schema_text += f"  - {col_name}: {col_type} ({col_desc})\n"
                    customer_table_columns.append(col_name)
                
                # Add relationship info
                if schema.get('relationships'):
                    schema_text += "Relationships:\n"
                    for rel in schema.get('relationships', []):
                        rel_type = rel.get('relationship_type', 'unknown')
                        if rel_type == 'primary_key':
                            schema_text += f"  - PRIMARY KEY: {rel.get('from_column', 'Unknown')}\n"
                        elif rel_type == 'foreign_key':
                            schema_text += f"  - FOREIGN KEY: {rel.get('from_column', 'Unknown')} -> {rel.get('referenced_table', 'Unknown')}.{rel.get('referenced_column', 'Unknown')}\n"
                schema_text += "\n"
    else:
        schema_text = "No customer table schema found."

    # Extract recent data context for reference resolution (skip for CREATE_CUSTOMER)
    recent_data_context = ""
    recent_customers = []
    customer_action = getattr(context, 'customer_action', '')
    
    if conversation_history and customer_action != 'CREATE_CUSTOMER':
        # Look for recent customer data in conversation - use last 8 messages
        for msg in reversed(conversation_history[-8:]):
            role = msg.get('role', '') if isinstance(msg, dict) else getattr(msg, 'role', '')
            content = msg.get('content', '') if isinstance(msg, dict) else getattr(msg, 'content', '')
            
            if role == 'assistant' and ('Customer ID:' in content or 'CUS-' in content):
                # Extract all customer IDs from the content
                import re
                customer_ids = re.findall(r'CUS-\d{6}', content)
                recent_customers.extend(customer_ids)
                
                # Store full context without truncation
                recent_data_context = f"\nRECENT DATA CONTEXT:\nThe system just showed these customers:\n{content}\n"
                break
    
    # Create a list of recent customer IDs for contextual queries
    recent_customer_ids = list(set(recent_customers))  # Remove duplicates
    contextual_ids_text = ""
    if recent_customer_ids and customer_action != 'CREATE_CUSTOMER':
        contextual_ids_text = f"\nRECENT CUSTOMER IDS: {', '.join(recent_customer_ids)}"
    
    # Add reactive context if available
    reactive_context_text = ""
    if reactive_context:
        reactive_context_text = f"\nREACTIVE CONTEXT:\n"
        if reactive_context.get('flow_state'):
            reactive_context_text += f"Current Flow State: {reactive_context['flow_state']}\n"
        if reactive_context.get('clarification_provided'):
            reactive_context_text += f"Clarification Provided: {reactive_context['clarification_provided']}\n"
        if reactive_context.get('missing_info_resolved'):
            reactive_context_text += f"Resolved Missing Info: {reactive_context['missing_info_resolved']}\n"

    sql_prompt = f"""You are an expert SQL assistant for PostgreSQL customer operations with contextual awareness.

CUSTOMER TABLE SCHEMA:
{schema_text}

CONVERSATION CONTEXT:
"""
    
    # For CREATE_CUSTOMER operations, completely isolate from conversation history
    customer_action = getattr(context, 'customer_action', '')
    if customer_action == 'CREATE_CUSTOMER':
        # Only include the current message for new customer creation to prevent field carryover
        sql_prompt += f"USER: {context.message}\n"
        sql_prompt += "\nIMPORTANT: This is a NEW customer creation. Do NOT use any field values from previous conversations or context. Only extract fields from the current USER message above.\n"
    else:
        # Use last 8 messages for conversation context for other operations
        recent_conversation = conversation_history[-8:] if len(conversation_history) > 8 else conversation_history
        for msg in recent_conversation:
            role = msg.get('role', 'unknown') if isinstance(msg, dict) else getattr(msg, 'role', 'unknown')
            content = msg.get('content', '') if isinstance(msg, dict) else getattr(msg, 'content', '')
            sql_prompt += f"{role.upper()}: {content}\n"
    
    sql_prompt += recent_data_context
    sql_prompt += contextual_ids_text
    sql_prompt += reactive_context_text
    
    sql_prompt += f"""
CURRENT REQUEST: {context.message}

CONTEXTUAL REFERENCE HANDLING:
- When user says "these customers", "from these", "who has phone from these" - refer to the RECENT DATA CONTEXT above
- Extract specific customer IDs from recent data when user references "these", "his", "its", "those", "this customer", "that customer"
- For filtering queries on recent data, use WHERE xcus IN ('CUS-XXXXX', 'CUS-YYYYY', ...) with actual IDs from context
- PRONOUN RESOLUTION EXAMPLES:
  * "update his phone" → UPDATE cacus SET xphone = 'new_phone' WHERE zid = {context.business_id} AND xcus = 'MOST_RECENT_CUSTOMER_ID'
  * "delete this customer" → DELETE FROM cacus WHERE zid = {context.business_id} AND xcus = 'MOST_RECENT_CUSTOMER_ID'
  * "his email address" → SELECT xemail FROM cacus WHERE zid = {context.business_id} AND xcus = 'MOST_RECENT_CUSTOMER_ID'
  * "these customers with phone" → SELECT * FROM cacus WHERE zid = {context.business_id} AND xcus IN (RECENT_CUSTOMER_IDS) AND xphone IS NOT NULL
- If recent customer IDs are available: {recent_customer_ids}
- Example: If recent data shows CUS-000115, CUS-000114, CUS-000113 and user asks "who has phone from these"
  Generate: SELECT * FROM cacus WHERE zid = {context.business_id} AND xcus IN ('CUS-000115', 'CUS-000114', 'CUS-000113') AND xphone IS NOT NULL

CUSTOMER SQL RULES:
1. For INSERT operations:
    - zid (business_id) = {context.business_id} (ALWAYS required as INTEGER)
    - xcus (customer_id) will be AUTO-GENERATED by the system - NEVER include xcus in INSERT statements
    - MANDATORY FIELDS (required for all customer inserts):
      * xphone: Must be 10 or 11 digits (INTEGER, no quotes) - NEVER use NULL
      * xemail: Must be valid email format (STRING with quotes) - NEVER use NULL  
      * xgcus: Must be one of: 'Corporate', 'Dealer', 'Retail', 'Inter Company' (STRING with quotes) - NEVER use NULL
      * xtaxscope: Must be one of: 'Local-Registered', 'Zero-Registered' (STRING with quotes) - NEVER use NULL
    - Use NULL for ANY optional missing fields, NEVER use empty strings or dummy data
    - Only insert fields that user has provided or NULL for missing optional ones
    - NO DUMMY VALUES: Use NULL for missing optional fields only

2. For SELECT operations:
   - Always include WHERE zid = {context.business_id}
   - Use ORDER BY xcus DESC for recent customers
   - Use ILIKE for name/text searches: WHERE xorg ILIKE '%search%'
   - For filtering by existing values: WHERE xphone IS NOT NULL (for customers with phone numbers)
   - For filtering by missing values: WHERE xphone IS NULL (for customers without phone numbers)
   - IMPORTANT SELECT PATTERNS:
     * "last customer" or "latest customer" → SELECT * FROM cacus WHERE zid = {context.business_id} ORDER BY xcus DESC LIMIT 1
     * "last N customers" → SELECT * FROM cacus WHERE zid = {context.business_id} ORDER BY xcus DESC LIMIT N
     * "all customers" → SELECT * FROM cacus WHERE zid = {context.business_id} ORDER BY xcus DESC
     * "customers with phone" → SELECT * FROM cacus WHERE zid = {context.business_id} AND xphone IS NOT NULL ORDER BY xcus DESC
     * "customers without email" → SELECT * FROM cacus WHERE zid = {context.business_id} AND xemail IS NULL ORDER BY xcus DESC
     * "search by name/org" → SELECT * FROM cacus WHERE zid = {context.business_id} AND xorg ILIKE '%searchterm%' ORDER BY xcus DESC
   - NEVER use specific customer IDs unless explicitly provided by user
   - For vague queries like "customer" or "last customer", use ORDER BY xcus DESC LIMIT 1

3. For UPDATE operations:
   - CRITICAL: Always include WHERE zid = {context.business_id} AND xcus = 'CUS-XXXXXX'
   - MUST require specific customer identification - either explicit ID or "last customer"
   - If user is vague (like "update customer"), DO NOT generate SQL - instead generate an error message asking for specific identification
   - NEVER use dummy data like 'new_phone', 'new_email', 'new_customer_type' etc.
   - Only update fields that user wants to change with REAL values provided by user
   - Examples:
     * "update CUS-123456 phone to 01234567890" → UPDATE cacus SET xphone = 01234567890 WHERE zid = {context.business_id} AND xcus = 'CUS-123456'
     * "update last customer email to john@company.com" → UPDATE cacus SET xemail = 'john@company.com' WHERE zid = {context.business_id} AND xcus = (SELECT xcus FROM cacus WHERE zid = {context.business_id} ORDER BY xcus DESC LIMIT 1)

4. For DELETE operations:
   - CRITICAL: Must have specific customer identification
   - If user provides specific customer ID: DELETE FROM cacus WHERE zid = {context.business_id} AND xcus = 'CUS-XXXXXX'
   - If user says "delete last customer": DELETE FROM cacus WHERE zid = {context.business_id} AND xcus = (SELECT xcus FROM cacus WHERE zid = {context.business_id} ORDER BY xcus DESC LIMIT 1)
   - If user says "delete last N customers": DELETE FROM cacus WHERE zid = {context.business_id} AND xcus IN (SELECT xcus FROM cacus WHERE zid = {context.business_id} ORDER BY xcus DESC LIMIT N)
   - If user says "delete all of them" or "delete these customers" referring to recently shown data: DELETE FROM cacus WHERE zid = {context.business_id} AND xcus IN (RECENT_CUSTOMER_IDS_FROM_CONTEXT)
   - If user is vague (like "delete customer"), DO NOT generate SQL - instead generate an error message asking for specific identification
   - NEVER use customer IDs from conversation history unless explicitly mentioned by user
   - ALWAYS generate DELETE queries directly, not SELECT queries for deletion requests
   - Use subqueries to identify customers when needed, but generate DELETE statements

EXAMPLES:
- When user provides complete data: INSERT INTO cacus (zid, xemail, xphone, xgcus, xtaxscope, xorg) VALUES ({context.business_id}, 'john@example.com', 01234567890, 'Corporate', 'Local-Registered', 'TechCorp')
- When user says "add customer" without data: INSERT INTO cacus (zid) VALUES ({context.business_id})
- IMPORTANT: Generate INSERT with ONLY the fields user provided - validation system will collect missing mandatory fields
- SELECT last customer: SELECT * FROM cacus WHERE zid = {context.business_id} ORDER BY xcus DESC LIMIT 1
- SELECT last 5 customers: SELECT * FROM cacus WHERE zid = {context.business_id} ORDER BY xcus DESC LIMIT 5
- SELECT all customers: SELECT * FROM cacus WHERE zid = {context.business_id} ORDER BY xcus DESC
- SELECT with phone: SELECT * FROM cacus WHERE zid = {context.business_id} AND xphone IS NOT NULL ORDER BY xcus DESC
- SELECT without phone: SELECT * FROM cacus WHERE zid = {context.business_id} AND xphone IS NULL ORDER BY xcus DESC
- SELECT by organization: SELECT * FROM cacus WHERE zid = {context.business_id} AND xorg ILIKE '%ptech%' ORDER BY xcus DESC
- SELECT contextual with phone: SELECT * FROM cacus WHERE zid = {context.business_id} AND xcus IN ('CUS-000115', 'CUS-000114', 'CUS-000113') AND xphone IS NOT NULL ORDER BY xcus DESC
- UPDATE: UPDATE cacus SET xemail = 'new@email.com' WHERE zid = {context.business_id} AND xcus = 'CUS-000001'
- DELETE with specific ID: DELETE FROM cacus WHERE zid = {context.business_id} AND xcus = 'CUS-000001'
- DELETE last customer: DELETE FROM cacus WHERE zid = {context.business_id} AND xcus = (SELECT xcus FROM cacus WHERE zid = {context.business_id} ORDER BY xcus DESC LIMIT 1)
- DELETE last 3 customers: DELETE FROM cacus WHERE zid = {context.business_id} AND xcus IN (SELECT xcus FROM cacus WHERE zid = {context.business_id} ORDER BY xcus DESC LIMIT 3)
- DELETE all recently shown: DELETE FROM cacus WHERE zid = {context.business_id} AND xcus IN ('CUS-000120', 'CUS-000119', 'CUS-000118', 'CUS-000117', 'CUS-000116', 'CUS-000115', 'CUS-000114', 'CUS-000113', 'CUS-000112', 'CUS-000111')
- DELETE all customers: DELETE FROM cacus WHERE zid = {context.business_id}

CRITICAL RULES:
- Always use zid as INTEGER value in SQL, never quoted as string
- xphone is INTEGER type - use actual numbers (123456789) or NULL for missing values
- NEVER include xcus in INSERT statements - it will be auto-generated
- The system will automatically add xcus after SQL generation
- DO NOT use dummy data or assume missing fields - let validation system collect them
- Only include fields explicitly provided by the user in the INSERT statement

OUTPUT: Generate ONLY the SQL query, no explanations or markdown.
"""
    
    return sql_prompt

def build_customer_system_prompt(context, conversation_history, schema_context):
    """
    Build system prompt for customer conversations.
    """
    schema_text = ""
    if schema_context:
        for schema in schema_context:
            table_name = schema.get('table_name', 'Unknown')
            if 'customer' in table_name.lower() or 'cacus' in table_name.lower():
                schema_text += f"\nCustomer Table: {table_name}\n"
                schema_text += "Available Fields:\n"
                for col in schema.get('columns', []):
                    col_name = col.get('name', 'Unknown')
                    col_desc = col.get('description', 'No description')
                    schema_text += f"  - {col_name}: {col_desc}\n"
    else:
        schema_text = "Customer table schema not available."

    system_prompt = f"""You are a specialized customer management assistant.

CUSTOMER DATA STRUCTURE:
{schema_text}

CONVERSATION HISTORY:
"""
    
    # Use last 8 messages for conversation context
    recent_conversation = conversation_history[-8:] if len(conversation_history) > 8 else conversation_history
    for msg in recent_conversation:
        role = msg.get('role', 'unknown') if isinstance(msg, dict) else getattr(msg, 'role', 'unknown')
        content = msg.get('content', '') if isinstance(msg, dict) else getattr(msg, 'content', '')
        system_prompt += f"{role.upper()}: {content}\n"
    
    system_prompt += f"""
CURRENT REQUEST: {context}

CUSTOMER MANAGEMENT GUIDELINES:
1. For NEW CUSTOMERS:
   - Accept ANY customer information provided by user
   - DO NOT require all fields - user can add partial information
   - Use empty strings '' for any missing fields, NEVER dummy data
   - Customer ID (xcus) is MANDATORY and will be auto-generated as CUS-XXXXXX format
   - Business ID (zid) is automatically set from context
   - If user provides only email, create customer with just email and empty strings for other fields
   - The system automatically handles xcus field generation - users don't need to provide it

2. For CUSTOMER SEARCH:
   - Search by name, email, phone, or organization
   - Show relevant customer details clearly
   - Offer to refine search if multiple matches

3. For CUSTOMER UPDATES:
   - MUST identify the specific customer first (customer ID or "last customer")
   - If user is vague, ask: "Which customer would you like to update? Please provide the customer ID or say 'show me customers' to see the list."
   - Confirm changes before applying
   - Show what will be changed
   - Only update fields user wants to change

4. For CUSTOMER DELETION:
   - MUST require explicit customer identification (customer ID or "last customer")  
   - If user is vague, ask: "Which customer would you like to delete? Please provide the customer ID or say 'show me customers' to see the list."
   - Warn about permanent deletion
   - Show customer details before confirmation
   - Require explicit confirmation

RESPONSE STYLE:
- Be friendly and professional
- Accept partial customer information (don't insist on all fields)
- Use empty strings for missing data, never dummy values
- Confirm actions before execution
- Provide clear status updates
- Handle errors gracefully
"""
    
    return system_prompt

def clean_sql_from_llm(sql_response):
    """
    Clean SQL response from LLM, removing markdown and prefixes.
    """
    sql_query = sql_response.strip()
    
    # Remove markdown code blocks
    if sql_query.startswith('```'):
        lines = sql_query.split('\n')
        if len(lines) > 1:
            sql_lines = []
            for line in lines[1:]:
                if line.strip() == '```':
                    break
                sql_lines.append(line)
            sql_query = '\n'.join(sql_lines).strip()
    
    # Remove common prefixes
    lines = sql_query.split('\n')
    if lines:
        first_line = lines[0].strip()
        prefixes_to_remove = ['sql query:', 'sql:', 'query:', 'answer:']
        for prefix in prefixes_to_remove:
            if first_line.lower().startswith(prefix):
                first_line = first_line[len(prefix):].strip()
                break
        lines[0] = first_line
        sql_query = '\n'.join(lines).strip()
    
    # Remove trailing semicolon
    sql_query = sql_query.rstrip(';').strip()
    
    return sql_query

def extract_customer_fields_from_message(message: str) -> dict:
    """
    Extract customer field information from natural language message.
    """
    fields = {}
    message_lower = message.lower()
    
    # Email extraction
    email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
    email_match = re.search(email_pattern, message)
    if email_match:
        fields['xemail'] = email_match.group()
    
    # Phone extraction (basic patterns)
    phone_patterns = [
        r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b',  # 123-456-7890 or 123.456.7890 or 1234567890
        r'\b\(\d{3}\)\s?\d{3}[-.]?\d{4}\b',  # (123) 456-7890
        r'\b\+\d{1,3}[-.]?\d{3,14}\b'  # International format
    ]
    
    for pattern in phone_patterns:
        phone_match = re.search(pattern, message)
        if phone_match:
            fields['xphone'] = phone_match.group()
            break
    
    # Organization extraction (look for "organization:", "company:", "org:")
    org_patterns = [
        r'(?:organization|company|org):\s*([^\n,]+)',
        r'(?:works at|from)\s+([A-Za-z0-9\s&.-]+)',
        r'(?:organization|company)\s+(?:is\s+)?([A-Za-z0-9\s&.-]+)'
    ]
    
    for pattern in org_patterns:
        org_match = re.search(pattern, message_lower)
        if org_match:
            fields['xorg'] = org_match.group(1).strip()
            break
    
    # Customer group extraction
    group_patterns = [
        r'(?:customer group|group):\s*([^\n,]+)',
        r'(?:vip|premium|standard|basic|gold|silver|bronze)',
        r'(?:group|tier)\s+(?:is\s+)?([A-Za-z0-9\s]+)'
    ]
    
    for pattern in group_patterns:
        group_match = re.search(pattern, message_lower)
        if group_match:
            fields['xgcus'] = group_match.group(1).strip() if group_match.groups() else group_match.group()
            break
    
    return fields

def format_customer_result(result_data):
    """
    Dynamic customer result formatter with intelligent display logic.
    - Single record: Clean, formatted text without tables
    - Multiple records: Beautiful HTML table with enhanced styling
    - Never shows internal field names (zid, etc.) or empty values
    - Dynamically adapts to available data fields
    """
    if not result_data:
        return "No customer data found."
    
    # Ensure result_data is a list
    if isinstance(result_data, dict):
        result_data = [result_data]
    
    # Filter out internal fields and empty values dynamically
    filtered_data = []
    for record in result_data:
        if isinstance(record, dict):
            filtered_record = {}
            for key, value in record.items():
                # Skip internal fields and empty/null values
                if (key.lower() not in ['zid', 'id', 'created_at', 'updated_at', 'ztime', 'zutime'] 
                    and value is not None 
                    and str(value).strip() 
                    and str(value).strip() not in ['None', '', 'null', 'NULL']):
                    
                    # Convert field names to user-friendly labels dynamically
                    friendly_name = get_friendly_field_name(key)
                    filtered_record[friendly_name] = value
            
            if filtered_record:  # Only add if there's displayable data
                filtered_data.append(filtered_record)
    
    if not filtered_data:
        return "No customer information available to display."
    
    # Dynamic formatting based on record count and complexity
    if len(filtered_data) == 1:
        # Single record: Use clean text format for better readability
        return format_single_customer_display(filtered_data[0])
    else:
        # Multiple records: Always use enhanced HTML table for better data visualization
        return format_customer_table_display(filtered_data)

async def get_dynamic_field_name(field_name, context=None):
    """
    Dynamically generate user-friendly field names using LLM with context awareness.
    Falls back to static mapping if LLM fails.
    """
    try:
        from backend.app.services.mistral_llm_service import MistralLLMService
        llm_service = MistralLLMService()
        
        # Build context for better field interpretation
        context_info = ""
        if context:
            context_info = f"\nContext: Customer management system, business operations"
        
        field_prompt = f"""You are a database field interpreter. Convert technical database field names to user-friendly labels.

Database Field: "{field_name}"{context_info}

Rules:
- Convert technical names to natural, user-friendly labels
- Consider business context and common terminology
- Keep labels concise but clear
- Use title case

Examples:
- "xcus" → "Customer ID"
- "xemail" → "Email Address"  
- "xorg" → "Organization"
- "xgcus" → "Customer Type"
- "xtaxscope" → "Tax Classification"
- "xphone" → "Phone Number"
- "xaddress" → "Address"

Generate a user-friendly label for "{field_name}":"""

        response = await llm_service.chat([
            {"role": "system", "content": "You are a field name interpreter. Respond with only the user-friendly label, nothing else."},
            {"role": "user", "content": field_prompt}
        ])
        
        friendly_name = response.strip()
        logger.info(f"[DynamicFieldName] '{field_name}' → '{friendly_name}'")
        return friendly_name
        
    except Exception as e:
        logger.error(f"[DynamicFieldName] Error generating friendly name for '{field_name}': {e}")
        # Fallback to enhanced static mapping
        return get_fallback_field_name(field_name)

def get_fallback_field_name(field_name):
    """Enhanced fallback field name mapping with better intelligence."""
    field_mapping = {
        'xcus': 'Customer ID',
        'xemail': 'Email Address',
        'xphone': 'Phone Number',
        'xmobile': 'Mobile Number',
        'xorg': 'Organization',
        'xgcus': 'Customer Type',
        'xtaxscope': 'Tax Classification',
        'xfirst': 'First Name',
        'xlast': 'Last Name',
        'xaddress': 'Address',
        'xadd1': 'Primary Address',
        'xadd2': 'Secondary Address',
        'xcity': 'City',
        'xstate': 'State/Province',
        'xcountry': 'Country',
        'xzip': 'ZIP/Postal Code',
        'xstatuscus': 'Customer Status',
        'xurl': 'Website',
        'xfax': 'Fax Number',
        'xtitle': 'Job Title',
        'xsalute': 'Salutation'
    }
    
    if field_name in field_mapping:
        return field_mapping[field_name]
    
    # Intelligent transformation for unknown fields
    clean_name = field_name
    if clean_name.startswith('x'):
        clean_name = clean_name[1:]  # Remove x prefix
    
    # Convert underscores and camelCase
    clean_name = clean_name.replace('_', ' ')
    
    # Title case with business intelligence
    words = clean_name.split()
    title_words = []
    for word in words:
        if word.lower() in ['id', 'url', 'api', 'crm', 'erp']:
            title_words.append(word.upper())
        else:
            title_words.append(word.capitalize())
    
    return ' '.join(title_words)

def get_friendly_field_name(field_name):
    """Legacy synchronous wrapper for backward compatibility."""
    return get_fallback_field_name(field_name)

def format_single_customer_display(customer):
    """Format a single customer record with enhanced presentation."""
    if not customer:
        return "No customer information available."
    
    lines = ["📋 **Customer Information:**", ""]
    
    # Prioritize important fields
    priority_fields = ['Customer ID', 'First Name', 'Last Name', 'Email', 'Phone', 'Mobile', 'Organization', 'Customer Group', 'Tax Scope']
    
    # Show priority fields first
    for field in priority_fields:
        if field in customer and customer[field]:
            lines.append(f"**{field}:** {customer[field]}")
    
    # Show remaining fields
    for field, value in customer.items():
        if field not in priority_fields and value:
            lines.append(f"**{field}:** {value}")
    
    return "\n".join(lines)

def format_customer_table_display(customers):
    """Create a dynamic, beautiful HTML table for customer data with responsive design."""
    if not customers:
        return "No customers to display."
    
    # Get all unique fields across customers dynamically
    all_fields = set()
    for customer in customers:
        all_fields.update(customer.keys())
    
    # Dynamic field prioritization based on available data
    priority_order = [
        'Customer ID', 'First Name', 'Last Name', 'Full Name', 'Name',
        'Email', 'Phone', 'Mobile', 'Contact', 
        'Organization', 'Company', 'Business',
        'Customer Group', 'Customer Type', 'Group',
        'Tax Scope', 'Status', 'Active'
    ]
    ordered_fields = []
    
    # Add priority fields first (only if they exist in data)
    for field in priority_order:
        if field in all_fields:
            ordered_fields.append(field)
            all_fields.remove(field)
    
    # Add remaining fields alphabetically for consistent display
    ordered_fields.extend(sorted(all_fields))
    
    # Limit fields for better mobile display (max 6 columns)
    if len(ordered_fields) > 6:
        # Keep most important fields and add "..." indicator
        ordered_fields = ordered_fields[:5] + ['...']
    
    # Build enhanced HTML table with modern styling
    html = ['<div style="overflow-x: auto; margin: 20px 0; border-radius: 12px; box-shadow: 0 8px 32px rgba(0,0,0,0.12); background: white;">']
    html.append('<table style="border-collapse: collapse; width: 100%; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, \'Helvetica Neue\', Arial, sans-serif; font-size: 14px;">')
    
    # Enhanced header with gradient
    html.append('<thead>')
    html.append('<tr style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; position: sticky; top: 0; z-index: 10;">')
    for field in ordered_fields:
        html.append(f'<th style="padding: 18px 24px; text-align: left; font-weight: 600; font-size: 13px; letter-spacing: 0.5px; text-transform: uppercase; border: none; white-space: nowrap;">{field}</th>')
    html.append('</tr>')
    html.append('</thead>')
    
    # Enhanced body with hover effects
    html.append('<tbody>')
    for i, customer in enumerate(customers):
        row_bg = '#f8fafc' if i % 2 == 0 else 'white'
        hover_bg = '#e2e8f0'
        
        html.append(f'<tr style="background-color: {row_bg}; transition: all 0.2s ease; border-bottom: 1px solid #e2e8f0;" onmouseover="this.style.backgroundColor=\'{hover_bg}\'; this.style.transform=\'scale(1.001)\'" onmouseout="this.style.backgroundColor=\'{row_bg}\'; this.style.transform=\'scale(1)\'">')
        
        for field in ordered_fields:
            value = customer.get(field, '')
            
            # Special styling for different field types
            if field == 'Customer ID':
                cell_style = 'padding: 16px 24px; font-weight: 600; color: #4f46e5; font-family: monospace; font-size: 13px;'
            elif field in ['Email']:
                cell_style = 'padding: 16px 24px; color: #059669; font-family: monospace; font-size: 13px;'
            elif field in ['Phone', 'Mobile']:
                cell_style = 'padding: 16px 24px; color: #7c3aed; font-family: monospace; font-size: 13px;'
            elif field in ['Customer Group', 'Tax Scope']:
                cell_style = 'padding: 16px 24px; background-color: #f1f5f9; border-radius: 6px; margin: 2px; font-weight: 500; color: #475569;'
            else:
                cell_style = 'padding: 16px 24px; color: #334155; vertical-align: top;'
            
            # Handle empty values
            display_value = value if value else '—'
            html.append(f'<td style="{cell_style}">{display_value}</td>')
        
        html.append('</tr>')
    html.append('</tbody>')
    html.append('</table>')
    html.append('</div>')
    
    # Add summary information
    customer_count = len(customers)
    summary = f'<div style="margin-top: 16px; padding: 12px 24px; background: #f1f5f9; border-radius: 8px; color: #475569; font-size: 14px; font-weight: 500;">📊 Showing {customer_count} customer{"s" if customer_count != 1 else ""}</div>'
    
    return ''.join(html) + summary
