"""
DYNAMIC INSERT FLOW - Optimized customer creation with:
- LLM-driven immediate data detection and validation
- Dynamic decision making throughout the pipeline
- Intelligent progressive data collection
- Enhanced performance and maintainability
- Secure field mapping and validation
"""
from backend.app.models.chat_graph_state import ChatGraphState
from backend.app.services.mistral_llm_service import MistralLLMService
from backend.app.services.vector_search import FaissVectorSearchService
from backend.app.mcp.mcp_client import MCPClient
from backend.app.agents.customer_agent.customer_chat_helpers import (
    get_next_customer_id, build_customer_sql_prompt, clean_sql_from_llm, 
    extract_customer_fields_from_message, format_customer_result,
    get_customer_schema_context_for_flow
)
from backend.app.agents.customer_agent.negative_vibe_detector import negative_vibe_detector
from backend.app.agents.customer_agent.flow_interruption_handler import flow_interruption_handler
import logging
import json
import re
import importlib

logger = logging.getLogger(__name__)

# Initialize services
llm_service = MistralLLMService()
vector_search_service = FaissVectorSearchService()
mcp_client = MCPClient(script_path="backend/app/mcp/server_enhanced.py")

def is_valid_email(email):
    """Validate email format."""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None

def is_valid_phone(phone):
    """Validate phone number (10 or 11 digits)."""
    if not phone or not phone.isdigit():
        return False
    return len(phone) in [10, 11]

def extract_insert_fields_from_sql(sql):
    """Extract field names and values from INSERT SQL statement."""
    # Pattern to match INSERT INTO table (columns) VALUES (values)
    pattern = r'INSERT\s+INTO\s+\w+\s*\(([^)]+)\)\s*VALUES\s*\(([^)]+)\)'
    match = re.search(pattern, sql, re.IGNORECASE | re.DOTALL)
    
    if not match:
        return {}
    
    columns_str = match.group(1).strip()
    values_str = match.group(2).strip()
    
    # Split columns and values, handling commas inside quotes
    columns = parse_sql_list(columns_str)
    values = parse_sql_list(values_str)
    
    # Create field dictionary
    fields = {}
    for i, col in enumerate(columns):
        if i < len(values):
            fields[col.strip()] = values[i].strip()
    
    return fields

def parse_sql_list(sql_list_str):
    """Parse SQL list handling commas inside quotes."""
    parts = []
    current = ""
    in_quotes = False
    quote_char = None
    
    for char in sql_list_str:
        if char in ["'", '"'] and not in_quotes:
            in_quotes = True
            quote_char = char
            current += char
        elif char == quote_char and in_quotes:
            in_quotes = False
            quote_char = None
            current += char
        elif char == ',' and not in_quotes:
            parts.append(current.strip())
            current = ""
        else:
            current += char
    
    if current.strip():
        parts.append(current.strip())
    
    return parts

async def generate_insert_sql_node(context):
    """🚀 DYNAMIC INSERT FLOW - Ultra-intelligent customer creation with immediate data detection"""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    logger.info(f"[🚀DynamicInsertFlow] Starting DYNAMIC INSERT flow for: {context.message}")
    
    # Set current flow with context preservation
    context.current_flow = "insert"
    context.original_query = getattr(context, 'original_query', context.message)
    
    # 🛡️ STEP 1: Enhanced flow control with context awareness
    flow_control = await _check_insert_flow_control(context)
    if flow_control['should_exit']:
        return _format_response(flow_control['response'])
    
    # 📊 STEP 2: Get enhanced schema context
    if not hasattr(context, 'schema_context') or not context.schema_context:
        context.schema_context = await get_customer_schema_context_for_flow(context.business_id, "insert")
    
    # 🧠 STEP 3: INTELLIGENCE BOOST - Check for immediate complete data in single message
    immediate_data_result = await _check_immediate_complete_data(context)
    
    if immediate_data_result['is_complete']:
        logger.info(f"[🚀DynamicInsertFlow] IMMEDIATE COMPLETE DATA detected: {immediate_data_result}")
        # Skip data collection - proceed directly with complete data
        context.collected_field_values = immediate_data_result['field_data']
        context.duplicate_check_done = False
        return await _proceed_with_complete_data(context, immediate_data_result)
    
    # 🎯 STEP 4: Progressive data collection for incomplete data
    if not hasattr(context, 'collected_field_values') or not context.collected_field_values:
        context.collected_field_values = {}
    
    # Enhanced data completeness analysis
    data_analysis = await _analyze_customer_data_completeness_enhanced(context)
    
    if not data_analysis['is_complete']:
        logger.info("[🚀DynamicInsertFlow] Customer data incomplete, using intelligent collection")
        
        # Update collected field values with any new data from current message
        new_fields = await _extract_fields_from_current_message_enhanced(context)
        context.collected_field_values.update(new_fields)
        
        # Generate dynamic data collection prompt
        context.response = await _generate_dynamic_data_collection_prompt(context, data_analysis)
        context.pause_reason = "intelligent_data_collection"
        context.insert_phase = "progressive_collection"
        context.next = "PauseNode"
        return context.model_dump()
    
    # 🚀 STEP 5: All data collected - proceed with validation and creation
    logger.info("[🚀DynamicInsertFlow] All data collected, proceeding with creation")
    return await _proceed_with_complete_data(context, data_analysis)

async def validate_insert_fields_node(context):
    """
    Enhanced validation for customer insert operations with reactive error handling.
    Mandatory fields: xphone (10-11 digits), xemail (valid email), xgcus, xorg
    """
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    logger.info(f"[ReactiveInsertValidation] Validating fields for SQL: {context.sql}")
    
    try:
        # Check for flow interruption during validation
        interruption_check = await _check_insert_flow_interruption(context)
        if interruption_check['is_interrupted']:
            return interruption_check['response']
        
        # Check for negative vibe
        negative_vibe = await negative_vibe_detector.detect_negative_vibe(
            context.message, context.conversation_history
        )
        
        if negative_vibe['is_negative']:
            logger.info("[ReactiveInsertValidation] Negative vibe detected, canceling flow")
            context = _clear_insert_flow_state(context)
            context.response = negative_vibe['suggested_response']
            context.next = "CustomerResponse"
            return context.model_dump()
        
        # Required fields for customer insertion
        required_fields = ['xemail', 'xphone', 'xgcus', 'xorg']
        
        # Extract fields from SQL
        sql_fields = extract_insert_fields_from_sql(context.sql)
        logger.info(f"[ReactiveInsertValidation] Extracted fields: {sql_fields}")
        
        # Enhanced validation with detailed error reporting
        validation_result = await _validate_customer_fields(sql_fields, required_fields)
        
        # Initialize collected field values if not present
        if not hasattr(context, 'collected_field_values') or context.collected_field_values is None:
            context.collected_field_values = {}
        
        # Store valid fields in collected values
        for field, value in sql_fields.items():
            if field in required_fields:
                clean_value = value.strip("'\"")
                if clean_value:  # Only store non-empty values
                    context.collected_field_values[field] = clean_value
        
        if validation_result['missing_fields'] or validation_result['validation_errors']:
            # Store incomplete SQL for later completion
            context.incomplete_sql = context.sql
            context.missing_mandatory_fields = validation_result['missing_fields']
            
            # Generate enhanced progress and error message
            progress_message = await _generate_validation_progress_message(
                context, required_fields, validation_result
            )
            
            context.pause_message = progress_message
            context.pause_reason = "missing_mandatory_fields"
            context.next = "PauseNode"
            
            logger.info(f"[ReactiveInsertValidation] Missing fields: {validation_result['missing_fields']}, Errors: {validation_result['validation_errors']}")
            return context.model_dump()
        
        # All fields are valid, proceed to duplicate check
        logger.info("[ReactiveInsertValidation] All mandatory fields validated successfully")
        context.next = "CheckDuplicateCustomer"
        return context.model_dump()
        
    except Exception as e:
        logger.error(f"[ReactiveInsertValidation] Error during validation: {e}")
        context.response = "Error validating customer information. Please try again."
        context.next = "CustomerResponse"
        return context.model_dump()

async def collect_missing_fields_node(context):
    """📝 DYNAMIC FIELD COLLECTION - Enhanced collection with intelligent processing"""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    logger.info(f"[📝DynamicFieldCollection] Processing: {context.message}")
    
    try:
        # Check for flow control first
        flow_control = await _check_insert_flow_control(context)
        if flow_control['should_exit']:
            return _format_response(flow_control['response'])
        
        # Initialize collected_field_values dictionary if not present
        if not hasattr(context, 'collected_field_values') or context.collected_field_values is None:
            context.collected_field_values = {}
        
        # Extract fields from current message using enhanced extraction
        extracted_fields = await _extract_fields_from_current_message_enhanced(context)
        logger.info(f"[📝DynamicFieldCollection] Extracted from message: {extracted_fields}")
        
        # Accumulate fields in dictionary - preserve existing values, add new ones
        fields_updated = False
        for field, value in extracted_fields.items():
            if value and value.strip():  # Only update with non-empty values
                old_value = context.collected_field_values.get(field)
                context.collected_field_values[field] = value.strip()
                if old_value != value.strip():
                    fields_updated = True
                    logger.info(f"[📝DynamicFieldCollection] Updated {field}: {old_value} -> {value.strip()}")
        
        # Re-analyze completeness with updated field dictionary
        data_analysis = await _analyze_customer_data_completeness_enhanced(context)
        
        if data_analysis['is_complete']:
            # All mandatory fields collected, proceed to creation pipeline
            logger.info("[📝DynamicFieldCollection] All mandatory fields collected, proceeding with creation")
            context.duplicate_check_done = False  # Reset for duplicate check
            context.insert_phase = "creation_pipeline"
            return await _proceed_with_complete_data(context, data_analysis)
        else:
            # Still missing fields, generate intelligent continuation prompt
            logger.info(f"[📝DynamicFieldCollection] Still missing fields: {data_analysis['missing_fields']}")
            
            if fields_updated:
                # Show progress if fields were updated
                context.response = await _generate_dynamic_data_collection_prompt(context, data_analysis)
            else:
                # No new fields extracted, provide clarification
                context.response = await _generate_field_clarification_prompt_enhanced(context, data_analysis)
            
            context.pause_reason = "intelligent_data_collection"
            context.insert_phase = "progressive_collection"
            context.next = "PauseNode"
            return context.model_dump()
        
    except Exception as e:
        logger.error(f"[📝DynamicFieldCollection] Error: {e}")
        context.response = "Error processing the information. Please try again with the required customer details."
        context.next = "CustomerResponse"
        return context.model_dump()

async def _generate_field_clarification_prompt_enhanced(context, data_analysis):
    """Generate enhanced clarification prompt when no new fields were extracted"""
    try:
        missing_fields = data_analysis.get('missing_fields', [])
        field_info = await _get_cached_field_info(context.business_id)
        
        missing_names = [field_info['mappings'].get(field, field) for field in missing_fields]
        
        prompt_parts = [
            "🔍 **I need more specific information**",
            "",
            f"I couldn't extract the required fields from your message. Still missing: **{', '.join(missing_names)}**",
            "",
            "📝 **Please provide in one of these formats:**",
            "• `Email: john@company.com`",
            "• `Phone: 1234567890`", 
            "• `Organization: ABC Corporation`",
            "• `Customer Group: Premium`",
            "• `Status: Active`",
            "• `Tax Scope: Domestic`",
            "",
            "📊 **Or all together:**",
            "• `Email: john@company.com, Phone: 1234567890, Organization: ABC Corp, Group: Premium, Status: Active, Tax: Domestic`",
            "",
            "💡 **Or in natural language:**",
            "• `The customer's email is john@company.com with phone 1234567890 from ABC Corp`"
        ]
        
        return "\n".join(prompt_parts)
        
    except Exception as e:
        logger.error(f"[🚀DynamicInsertFlow] Error generating enhanced clarification prompt: {e}")
        return "Please provide the missing customer information in a clear format."

async def generate_customer_id_node(context):
    """
    Enhanced customer ID generation node with better error handling.
    """
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    logger.info("[CustomerIDGeneration] Starting customer ID generation")
    
    try:
        # Force reload and get fresh function reference
        from backend.app.agents.customer_agent import customer_chat_helpers
        importlib.reload(customer_chat_helpers)
        
        # Generate next customer ID with fresh function
        next_customer_id = await customer_chat_helpers.get_next_customer_id(context.business_id)
        logger.info(f"[CustomerIDGeneration] Generated ID: {next_customer_id}")
        
        # Inject customer ID into SQL
        if context.sql and next_customer_id:
            # Add xcus field to INSERT statement
            if 'xcus' not in context.sql.lower():
                # Find INSERT INTO pattern and add xcus
                insert_pattern = r'INSERT\s+INTO\s+(\w+)\s*\(([^)]+)\)\s*VALUES\s*\(([^)]+)\)'
                match = re.search(insert_pattern, context.sql, re.IGNORECASE)
                
                if match:
                    table_name = match.group(1)
                    columns = match.group(2).strip()
                    values = match.group(3).strip()
                    
                    # Add xcus to columns and values
                    new_columns = f"{columns}, xcus"
                    new_values = f"{values}, '{next_customer_id}'"
                    
                    context.sql = f"INSERT INTO {table_name} ({new_columns}) VALUES ({new_values})"
                    logger.info(f"[CustomerIDGeneration] Updated SQL with ID: {context.sql}")
        
        context.next = "ExecuteInsertSQL"
        return context.model_dump()
        
    except Exception as e:
        logger.error(f"[CustomerIDGeneration] Error: {e}")
        context.response = f"Error generating customer ID: {str(e)}"
        context.next = "CustomerResponse"
        return context.model_dump()

async def execute_insert_sql_node(context):
    """Execute customer INSERT SQL operations with enhanced error handling and success reporting."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    logger.info(f"[ReactiveInsertExecution] Executing: {context.sql}")
    
    try:
        # Final validation before execution
        if not context.sql or 'INSERT' not in context.sql.upper():
            context.response = "Invalid SQL statement for customer creation. Please try again."
            context.next = "CustomerResponse"
            return context.model_dump()
        
        # Execute SQL via MCP
        result = await mcp_client.execute_query(context.sql, context.business_id)
        
        if isinstance(result, dict) and 'content' in result:
            try:
                # Parse MCP response
                parsed = json.loads(result['content'][0]['text'])
                
                if parsed.get('success'):
                    # Enhanced success handling with customer details
                    success_message = await _generate_success_message(context, parsed)
                    context.response = success_message
                    
                    # Clear insert flow state on success
                    context = _clear_insert_flow_state(context)
                    
                    logger.info("[ReactiveInsertExecution] Customer created successfully")
                else:
                    # Enhanced error handling
                    error_msg = parsed.get('error', 'Unknown error occurred')
                    context.response = await _handle_insert_error(error_msg)
                    
            except (json.JSONDecodeError, KeyError, IndexError) as e:
                logger.error(f"[ReactiveInsertExecution] Error parsing result: {e}")
                context.response = "Customer creation completed but I had trouble confirming the details. The customer may have been created successfully."
        else:
            context.response = "Customer creation request was processed, but I couldn't confirm the result."
            
    except Exception as e:
        logger.error(f"[ReactiveInsertExecution] Execution error: {e}")
        
        # Enhanced error categorization
        error_str = str(e).lower()
        if 'duplicate' in error_str or 'unique' in error_str:
            context.response = (
                "❌ A customer with this email or phone number already exists. "
                "Please check the information and try again with different details."
            )
        elif 'constraint' in error_str or 'foreign key' in error_str:
            context.response = (
                "❌ Invalid customer group or organization specified. "
                "Please check the customer group and organization values."
            )
        else:
            context.response = f"❌ Error creating customer: {str(e)}"
    
    context.next = "CustomerResponse"
    return context.model_dump()

# --- DYNAMIC HELPER FUNCTIONS FOR OPTIMIZED INSERT FLOW ---

def _format_response(response_dict):
    """Format response dictionary for consistent output"""
    return response_dict

async def _check_insert_flow_control(context):
    """Enhanced LLM-powered flow control with context awareness"""
    try:
        # Build richer context for better LLM understanding
        conversation_context = _build_conversation_context(context)
        
        flow_control_prompt = f"""You are an expert at understanding user intent in customer creation operations.

CONVERSATION CONTEXT:
{conversation_context}

CURRENT USER MESSAGE: "{context.message}"
CURRENT OPERATION: Customer INSERT flow

Analyze the user's message for:
1. **NEGATIVE SENTIMENT**: Wants to cancel, stop, or abort ("cancel", "stop", "nevermind", "quit")
2. **INTENT SWITCHING**: Wants to switch to different operation:
   - UPDATE: "update customer", "modify customer"
   - DELETE: "delete customer", "remove customer"
   - SELECT: "show customers", "list customers" (standalone, not for reference)
3. **CONTINUATION**: Providing information for current creation (field values, confirmations)

IMPORTANT: Distinguish between:
- "show customers" (intent switch) vs "show me an example" (help for creation)
- "update info" (intent switch) vs "update this field" (correction in creation)

Respond with JSON:
{{
    "should_exit": boolean,
    "exit_reason": "negative_sentiment|intent_switch|none",
    "new_intent": "update|delete|select|none",
    "confidence": 0.0-1.0,
    "reasoning": "clear explanation",
    "suggested_response": "appropriate response if exiting"
}}

Examples:
- "cancel this" → {{"should_exit": true, "exit_reason": "negative_sentiment"}}
- "show customers instead" → {{"should_exit": true, "exit_reason": "intent_switch", "new_intent": "select"}}
- "email: john@example.com" → {{"should_exit": false}} (providing data)
- "phone is 123456789" → {{"should_exit": false}} (providing data)"""
        
        response = await llm_service.chat([
            {"role": "system", "content": "You are an intent analysis expert. Always respond with valid JSON."},
            {"role": "user", "content": flow_control_prompt}
        ])
        
        try:
            result = _parse_json_response(response)
            logger.info(f"[🚀DynamicInsertFlow] Flow control analysis: {result}")
            
            if result.get('should_exit', False) and result.get('confidence', 0) > 0.7:
                exit_reason = result.get('exit_reason', 'unknown')
                new_intent = result.get('new_intent', 'none')
                
                # Clear insert flow state
                context = _clear_insert_flow_state(context)
                
                # Use LLM-suggested response or generate dynamic one
                if result.get('suggested_response'):
                    response_content = result['suggested_response']
                else:
                    response_content = await _generate_dynamic_response(
                        context, "flow_exit", 
                        {"exit_reason": exit_reason, "new_intent": new_intent, "reasoning": result.get('reasoning')}
                    )
                
                if exit_reason == 'negative_sentiment':
                    context.response = response_content
                    context.next = "CustomerResponse"
                elif exit_reason == 'intent_switch':
                    context = await _handle_intent_switch(context, new_intent, response_content)
                
                return {'should_exit': True, 'response': context.model_dump()}
            
            return {'should_exit': False}
            
        except json.JSONDecodeError as e:
            logger.error(f"[🚀DynamicInsertFlow] JSON parsing error: {e}, response: {response}")
            return {'should_exit': False}
            
    except Exception as e:
        logger.error(f"[🚀DynamicInsertFlow] Flow control error: {e}")
        return {'should_exit': False}

def _build_conversation_context(context):
    """Build rich conversation context for LLM analysis"""
    conversation_context = ""
    if hasattr(context, 'conversation_history') and context.conversation_history:
        recent_messages = context.conversation_history[-4:]
        for i, msg in enumerate(recent_messages):
            role = msg.role if hasattr(msg, 'role') else msg.get('role', 'user')
            content = msg.content if hasattr(msg, 'content') else msg.get('content', '')
            conversation_context += f"{i+1}. {role.upper()}: {content}\n"
    return conversation_context

def _parse_json_response(response: str) -> dict:
    """Parse JSON response from LLM, handling markdown code blocks."""
    response = response.strip()
    
    # Remove markdown code blocks
    if response.startswith('```json'):
        response = response[7:]
    elif response.startswith('```'):
        response = response[3:]
    
    if response.endswith('```'):
        response = response[:-3]
    
    response = response.strip()
    
    # Try to extract JSON if embedded in other text
    json_match = re.search(r'\{.*\}', response, re.DOTALL)
    if json_match:
        response = json_match.group(0)
    
    try:
        return json.loads(response)
    except json.JSONDecodeError as e:
        logger.error(f"[JSONParser] Failed to parse JSON: {e}, cleaned response: {response[:200]}...")
        raise json.JSONDecodeError(f"Could not parse LLM JSON response: {e}", response, 0)

async def _check_immediate_complete_data(context):
    """Check if the user message contains complete customer data for immediate creation"""
    try:
        # Get field information for intelligent mapping
        field_info = await _get_cached_field_info(context.business_id)
        field_mappings = field_info.get('mappings', {})
        
        # Build intelligent complete data detection prompt
        immediate_data_prompt = f"""You are an expert at detecting complete customer data in messages for immediate creation.

USER MESSAGE: "{context.message}"
AVAILABLE FIELDS: {json.dumps(field_mappings, indent=2)}

Analyze if this message contains COMPLETE customer data with ALL mandatory components:
1. **Email address**: Valid email format
2. **Phone number**: Valid phone number (10-15 digits)
3. **Organization**: Company/organization name
4. **Customer group**: Customer type/category
5. **Customer status**: Status (Active, Inactive, etc.)
6. **Tax scope**: Tax classification

📝 EXAMPLES OF COMPLETE DATA:
- "add customer john@email.com 123456789 TechCorp Premium Active Domestic" → COMPLETE
- "create customer email: jane@test.com, phone: 987654321, org: ABC Inc, group: Standard, status: Active, tax: International" → COMPLETE
- "new customer: bob@company.com, 555123456, MegaCorp, VIP customer, Active status, Standard tax scope" → COMPLETE

❌ EXAMPLES NEEDING MORE DATA:
- "add customer john@email.com" → NOT COMPLETE (missing phone, org, group, status, tax)
- "create customer with email and phone" → NOT COMPLETE (no actual values)
- "new customer for TechCorp" → NOT COMPLETE (missing most fields)

Map extracted data to database field names using the available fields mapping.

Respond with JSON:
{{
    "is_complete": boolean,
    "field_data": {{"database_field": "extracted_value"}},
    "confidence": 0.0-1.0,
    "reasoning": "explanation of analysis",
    "missing_fields": ["list of any missing mandatory fields"]
}}

EXAMPLE:
- "add customer john@tech.com 123456789 TechCorp Premium Active Domestic" → {{"is_complete": true, "field_data": {{"xemail": "john@tech.com", "xphone": "123456789", "xorg": "TechCorp", "xgcus": "Premium", "xstatuscus": "Active", "xtaxscope": "Domestic"}}, "confidence": 0.95}}"""
        
        response = await llm_service.chat([
            {"role": "system", "content": "You are an expert complete data detector. Always respond with valid JSON."},
            {"role": "user", "content": immediate_data_prompt}
        ])
        
        try:
            result = _parse_json_response(response)
            logger.info(f"[🚀DynamicInsertFlow] Immediate complete data analysis: {result}")
            return result
            
        except json.JSONDecodeError as e:
            logger.error(f"[🚀DynamicInsertFlow] JSON parsing error in immediate data check: {e}")
            return {'is_complete': False, 'field_data': {}, 'confidence': 0.0}
            
    except Exception as e:
        logger.error(f"[🚀DynamicInsertFlow] Error in immediate complete data check: {e}")
        return {'is_complete': False, 'field_data': {}, 'confidence': 0.0}

async def _get_cached_field_info(business_id):
    """Get cached field information or generate and cache it"""
    # Simplified field info for insert operations
    return {
        'descriptions': {
            'xemail': {'description': 'Email address', 'type': 'text'},
            'xphone': {'description': 'Phone number', 'type': 'text'},
            'xorg': {'description': 'Organization', 'type': 'text'},
            'xgcus': {'description': 'Customer group', 'type': 'text'},
            'xstatuscus': {'description': 'Customer status', 'type': 'text'},
            'xtaxscope': {'description': 'Tax scope', 'type': 'text'}
        },
        'mappings': {
            'xemail': 'Email Address',
            'xphone': 'Phone Number',
            'xorg': 'Organization',
            'xgcus': 'Customer Group',
            'xstatuscus': 'Customer Status',
            'xtaxscope': 'Tax Scope'
        }
    }

async def _proceed_with_complete_data(context, data_result):
    """Proceed with customer creation using complete data"""
    try:
        # Perform duplicate check first
        duplicate_result = await _check_for_duplicate_customers_enhanced(context)
        
        if duplicate_result['has_duplicates']:
            context.response = await _generate_dynamic_duplicate_handling_prompt(context, duplicate_result)
            context.pause_reason = "duplicate_customer_found"
            context.insert_phase = "duplicate_handling"
            context.next = "PauseNode"
            return context.model_dump()
        
        # No duplicates - proceed with creation
        context.duplicate_check_done = True
        context.insert_phase = None
        context.pause_reason = None
        
        # Generate final SQL with complete data
        return await _generate_final_insert_sql_enhanced(context)
        
    except Exception as e:
        logger.error(f"[🚀DynamicInsertFlow] Error proceeding with complete data: {e}")
        context.response = f"Error processing customer data: {str(e)}"
        context.next = "CustomerResponse"
        return context.model_dump()

async def _extract_fields_from_current_message_enhanced(context):
    """Enhanced field extraction using LLM with better accuracy"""
    try:
        field_info = await _get_cached_field_info(context.business_id)
        
        extraction_prompt = f"""Extract customer information from this message and return as JSON.

Message: "{context.message}"
Available Fields: {json.dumps(field_info['mappings'], indent=2)}

Extract these fields if clearly present:
- Email address (must be valid format with @ and .)
- Phone number (10-15 digits)
- Organization/company name
- Customer group/type/category
- Customer status (Active, Inactive, etc.)
- Tax scope (Domestic, International, etc.)

Return JSON format with database field names:
{{
    "xemail": "email_if_found",
    "xphone": "phone_if_found", 
    "xorg": "organization_if_found",
    "xgcus": "customer_group_if_found",
    "xstatuscus": "status_if_found",
    "xtaxscope": "tax_scope_if_found"
}}

Only include fields that are clearly present. Return empty JSON {{}} if no fields found."""
        
        response = await llm_service.chat([
            {"role": "system", "content": "You are a data extraction expert. Extract customer information and return valid JSON only."},
            {"role": "user", "content": extraction_prompt}
        ])
        
        # Clean response and parse JSON
        clean_response = response.strip()
        if clean_response.startswith('```json'):
            clean_response = clean_response[7:-3].strip()
        elif clean_response.startswith('```'):
            clean_response = clean_response[3:-3].strip()
        
        extracted = json.loads(clean_response)
        
        # Validate extracted data
        validated_fields = {}
        for field, value in extracted.items():
            if field in ['xemail', 'xphone', 'xorg', 'xgcus', 'xstatuscus', 'xtaxscope'] and value and str(value).strip():
                validated_fields[field] = str(value).strip()
        
        return validated_fields
        
    except Exception as e:
        logger.debug(f"[🚀DynamicInsertFlow] Enhanced field extraction failed: {e}")
        # Fallback to basic extraction
        return await _extract_fields_from_current_message(context)

async def _generate_dynamic_data_collection_prompt(context, data_analysis):
    """Generate intelligent data collection prompt with progress and examples"""
    try:
        field_info = await _get_cached_field_info(context.business_id)
        collected_fields = data_analysis.get('collected_fields', {})
        missing_fields = data_analysis.get('missing_fields', [])
        
        # Build progress indicators
        progress_items = []
        for field in ['xemail', 'xphone', 'xorg', 'xgcus', 'xstatuscus', 'xtaxscope']:
            field_name = field_info['mappings'].get(field, field)
            if field in collected_fields and collected_fields[field]:
                progress_items.append(f"✅ **{field_name}**: {collected_fields[field]}")
            else:
                progress_items.append(f"❌ **{field_name}**: Missing")
        
        # Generate dynamic examples based on missing fields
        examples = []
        if 'xemail' in missing_fields:
            examples.append("• `Email: john@company.com`")
        if 'xphone' in missing_fields:
            examples.append("• `Phone: 1234567890`")
        if 'xorg' in missing_fields:
            examples.append("• `Organization: ABC Corporation`")
        if 'xgcus' in missing_fields:
            examples.append("• `Customer Group: Premium`")
        if 'xstatuscus' in missing_fields:
            examples.append("• `Status: Active`")
        if 'xtaxscope' in missing_fields:
            examples.append("• `Tax Scope: Domestic`")
        
        prompt_parts = [
            "📝 **Dynamic Customer Creation - Smart Data Collection**",
            "",
            "**Current Progress:**"
        ]
        prompt_parts.extend(progress_items)
        
        if missing_fields:
            prompt_parts.extend([
                "",
                "🎯 **You can provide the missing information in any of these ways:**",
                "",
                "**One field at a time:**"
            ])
            prompt_parts.extend(examples[:3])  # Show first 3 examples
            
            prompt_parts.extend([
                "",
                "**Multiple fields together:**",
                "• `Email: john@company.com, Phone: 1234567890, Organization: ABC Corp`",
                "",
                "**Natural language:**",
                "• `The customer's email is john@company.com and phone is 1234567890`",
                "",
                "Please provide the missing information:"
            ])
        
        return "\n".join(prompt_parts)
        
    except Exception as e:
        logger.error(f"[🚀DynamicInsertFlow] Error generating dynamic collection prompt: {e}")
        return "Please provide the remaining customer information to continue."

async def _check_for_duplicate_customers_enhanced(context):
    """Enhanced duplicate checking with better analysis"""
    try:
        collected_fields = getattr(context, 'collected_field_values', {})
        email = collected_fields.get('xemail')
        phone = collected_fields.get('xphone')
        
        if not email and not phone:
            return {'has_duplicates': False, 'duplicates': []}
        
        # Build comprehensive duplicate check query
        conditions = []
        if email:
            conditions.append(f"xemail = '{email}'")
        if phone:
            conditions.append(f"xphone = '{phone}'")
        
        duplicate_check_sql = f"""
        SELECT xcus, xemail, xphone, xorg, xfirst, xlast 
        FROM cacus 
        WHERE zid = {context.business_id} 
        AND ({' OR '.join(conditions)})
        """
        
        result = await mcp_client.execute_query(duplicate_check_sql, context.business_id)
        
        if isinstance(result, dict) and 'content' in result:
            try:
                parsed = json.loads(result['content'][0]['text'])
                duplicates = parsed.get('results', [])
                
                return {
                    'has_duplicates': len(duplicates) > 0,
                    'duplicates': duplicates,
                    'match_types': _analyze_duplicate_matches(duplicates, email, phone)
                }
            except (json.JSONDecodeError, KeyError, IndexError):
                pass
        
        return {'has_duplicates': False, 'duplicates': []}
        
    except Exception as e:
        logger.error(f"[🚀DynamicInsertFlow] Error checking duplicates: {e}")
        return {'has_duplicates': False, 'duplicates': []}

def _analyze_duplicate_matches(duplicates, email, phone):
    """Analyze what type of duplicates were found"""
    match_types = []
    for dup in duplicates:
        if email and dup.get('xemail') == email:
            match_types.append('email')
        if phone and dup.get('xphone') == phone:
            match_types.append('phone')
    return list(set(match_types))

async def _generate_dynamic_duplicate_handling_prompt(context, duplicate_result):
    """Generate intelligent duplicate handling prompt"""
    try:
        duplicates = duplicate_result.get('duplicates', [])
        match_types = duplicate_result.get('match_types', [])
        
        duplicate_info = []
        for dup in duplicates[:3]:  # Show max 3 duplicates
            name_parts = [dup.get('xfirst', ''), dup.get('xlast', '')]
            name = ' '.join(filter(None, name_parts)) or 'Unknown'
            info = f"• **{dup.get('xcus', 'Unknown')}** - {name} ({dup.get('xemail', 'No email')})"
            if dup.get('xorg'):
                info += f" from {dup['xorg']}"
            duplicate_info.append(info)
        
        match_description = ""
        if 'email' in match_types and 'phone' in match_types:
            match_description = "A customer with the **same email AND phone number** already exists"
        elif 'email' in match_types:
            match_description = "A customer with the **same email address** already exists"
        elif 'phone' in match_types:
            match_description = "A customer with the **same phone number** already exists"
        
        prompt = (
            f"⚠️ **Duplicate Customer Detected**\n\n"
            f"{match_description}:\n\n"
            f"{''.join(duplicate_info)}\n\n"
            f"🤔 **What would you like to do?**\n"
            f"• **Update existing customer** - Modify the existing customer's information\n"
            f"• **Create anyway** - Create a new customer with different contact information\n"
            f"• **Cancel** - Stop the customer creation process\n\n"
            f"Please let me know how you'd like to proceed:"
        )
        
        return prompt
        
    except Exception as e:
        logger.error(f"[🚀DynamicInsertFlow] Error generating duplicate prompt: {e}")
        return "Duplicate customer detected. Please choose how to proceed."

async def _generate_final_insert_sql_enhanced(context):
    """Generate final INSERT SQL with enhanced validation and security"""
    try:
        collected_fields = getattr(context, 'collected_field_values', {})
        
        if not collected_fields:
            context.response = "No customer data collected. Please provide customer information."
            context.next = "CustomerResponse"
            return context.model_dump()
        
        # Verify all mandatory fields are present
        required_fields = ['xemail', 'xphone', 'xorg', 'xgcus', 'xstatuscus', 'xtaxscope']
        missing_fields = [field for field in required_fields 
                         if field not in collected_fields or not collected_fields[field] or not collected_fields[field].strip()]
        
        if missing_fields:
            logger.warning(f"[🚀DynamicInsertFlow] Missing fields during final SQL generation: {missing_fields}")
            data_analysis = await _analyze_customer_data_completeness_enhanced(context)
            context.response = await _generate_dynamic_data_collection_prompt(context, data_analysis)
            context.pause_reason = "intelligent_data_collection"
            context.insert_phase = "progressive_collection"
            context.next = "PauseNode"
            return context.model_dump()
        
        # Generate INSERT SQL with secure field handling
        columns = ['zid']
        values = [str(context.business_id)]
        
        # Add collected fields in consistent order
        for field in required_fields:
            if field in collected_fields:
                columns.append(field)
                escaped_value = collected_fields[field].replace("'", "''")
                values.append(f"'{escaped_value}'")
        
        # Add any additional collected fields
        for field, value in collected_fields.items():
            if field not in required_fields and field not in columns:
                columns.append(field)
                escaped_value = value.replace("'", "''")
                values.append(f"'{escaped_value}'")
        
        columns_str = ', '.join(columns)
        values_str = ', '.join(values)
        context.sql = f"INSERT INTO cacus ({columns_str}) VALUES ({values_str})"
        
        logger.info(f"[🚀DynamicInsertFlow] Generated enhanced final SQL: {context.sql}")
        
        # Clear state and proceed to validation
        context.insert_phase = None
        context.pause_reason = None
        context.next = "ValidateInsertFields"
        return context.model_dump()
        
    except Exception as e:
        logger.error(f"[🚀DynamicInsertFlow] Error generating enhanced final SQL: {e}")
        context.response = f"Error generating customer creation SQL: {str(e)}"
        context.next = "CustomerResponse"
        return context.model_dump()

async def _generate_dynamic_response(context, response_type, response_data):
    """Generate dynamic responses using LLM"""
    try:
        # Simple dynamic response generation for common cases
        if response_type == "flow_exit":
            exit_reason = response_data.get('exit_reason', 'unknown')
            if exit_reason == 'negative_sentiment':
                return "Customer creation cancelled. How can I help you instead?"
            elif exit_reason == 'intent_switch':
                new_intent = response_data.get('new_intent', 'unknown')
                return f"Switching to {new_intent} operation. How can I help you?"
        
        return "I'm here to help! What would you like to do?"
        
    except Exception as e:
        logger.error(f"[🚀DynamicInsertFlow] Error generating dynamic response: {e}")
        return "How can I help you?"

async def _handle_intent_switch(context, new_intent, response_content):
    """Handle intent switching to other operations"""
    try:
        if new_intent == 'select':
            context.query_classification = "SEARCH_CUSTOMER"
            context.next = "GenerateSelectSQL"
        elif new_intent == 'update':
            context.query_classification = "UPDATE_CUSTOMER"
            context.next = "GenerateUpdateSQL"
        elif new_intent == 'delete':
            context.query_classification = "DELETE_CUSTOMER"
            context.next = "GenerateDeleteSQL"
        else:
            context.next = "GeneralCustomerChat"
        
        context.response = response_content
        return context
        
    except Exception as e:
        logger.error(f"[🚀DynamicInsertFlow] Error handling intent switch: {e}")
        context.response = "How can I help you?"
        context.next = "CustomerResponse"
        return context

def _clear_insert_flow_state(context):
    """Clear all INSERT flow related state with enhanced cleanup."""
    # Core flow state
    context.insert_phase = None
    context.pause_reason = None
    context.pause_message = None
    context.current_flow = None
    context.collected_field_values = None
    context.duplicate_check_done = None
    context.incomplete_sql = None
    context.missing_mandatory_fields = None
    
    return context

async def _analyze_customer_data_completeness_enhanced(context):
    """Enhanced analysis of customer data completeness with collected field values."""
    try:
        # Initialize collected field values if not present
        if not hasattr(context, 'collected_field_values') or not context.collected_field_values:
            context.collected_field_values = {}
        
        # Extract fields from current message
        current_fields = await _extract_fields_from_current_message(context)
        
        # Combine with previously collected fields
        all_fields = {**context.collected_field_values, **current_fields}
        
        # Update mandatory fields list to include all schema-required fields  
        required_fields = ['xemail', 'xphone', 'xorg', 'xgcus', 'xstatuscus', 'xtaxscope']
        
        # Check completeness
        missing_fields = []
        for field in required_fields:
            if field not in all_fields or not all_fields[field] or not all_fields[field].strip():
                missing_fields.append(field)
        
        # Field name mapping for user-friendly messages
        field_names = {
            'xemail': 'Email Address',
            'xphone': 'Phone Number', 
            'xorg': 'Organization',
            'xgcus': 'Customer Group',
            'xstatuscus': 'Customer Status',
            'xtaxscope': 'Tax Scope'
        }
        
        # Generate suggested questions for missing fields
        suggested_questions = []
        for field in missing_fields:
            field_name = field_names.get(field, field)
            if field == 'xemail':
                suggested_questions.append(f"What is the customer's email address?")
            elif field == 'xphone':
                suggested_questions.append(f"What is their phone number?")
            elif field == 'xorg':
                suggested_questions.append(f"What organization/company do they belong to?")
            elif field == 'xgcus':
                suggested_questions.append(f"What customer group/type should they be assigned to?")
            elif field == 'xstatuscus':
                suggested_questions.append(f"What is the customer's status?")
            elif field == 'xtaxscope':
                suggested_questions.append(f"What is their tax scope?")
        
        return {
            'is_complete': len(missing_fields) == 0,
            'missing_fields': missing_fields,
            'suggested_questions': suggested_questions,
            'collected_fields': all_fields,
            'confidence': 1.0 - (len(missing_fields) / len(required_fields))
        }
        
    except Exception as e:
        logger.error(f"[InsertFlow] Error in enhanced data completeness analysis: {e}")
        return {
            'is_complete': False,
            'missing_fields': ['xemail', 'xphone', 'xorg', 'xgcus', 'xstatuscus', 'xtaxscope'],
            'suggested_questions': ['Please provide complete customer information'],
            'collected_fields': {},
            'confidence': 0.0
        }

async def _extract_fields_from_current_message(context):
    """Extract customer fields from the current message."""
    try:
        # Use existing helper function
        extracted_fields = extract_customer_fields_from_message(context.message)
        
        # Enhanced extraction with regex patterns
        email_pattern = r'\b[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}\b'
        phone_pattern = r'\b\d{10,11}\b'
        
        email_match = re.search(email_pattern, context.message)
        phone_match = re.search(phone_pattern, context.message)
        
        if email_match and 'xemail' not in extracted_fields:
            extracted_fields['xemail'] = email_match.group()
            
        if phone_match and 'xphone' not in extracted_fields:
            extracted_fields['xphone'] = phone_match.group()
        
        # Clean extracted fields
        cleaned_fields = {}
        for field, value in extracted_fields.items():
            clean_value = str(value).strip().strip("'\"")
            if clean_value:
                cleaned_fields[field] = clean_value
        
        return cleaned_fields
        
    except Exception as e:
        logger.error(f"[InsertFlow] Error extracting fields from message: {e}")
        return {}

async def _extract_fields_with_llm(message):
    """Use LLM to extract customer fields from natural language."""
    try:
        extraction_prompt = f"""Extract customer information from this message and return as JSON.

Message: "{message}"

Extract these fields if present:
- email: Email address (must contain @ and .)
- phone: Phone number (10-11 digits only)
- organization: Company/organization name
- customer_group: Customer type/group/category

Return JSON format:
{{
    "xemail": "email_if_found",
    "xphone": "phone_if_found", 
    "xorg": "organization_if_found",
    "xgcus": "customer_group_if_found"
}}

Only include fields that are clearly present. Return empty JSON {{}} if no fields found."""
        
        response = await llm_service.chat([
            {"role": "system", "content": "You are a data extraction expert. Extract customer information and return valid JSON only."},
            {"role": "user", "content": extraction_prompt}
        ])
        
        # Clean response and parse JSON
        clean_response = response.strip()
        if clean_response.startswith('```json'):
            clean_response = clean_response[7:-3].strip()
        elif clean_response.startswith('```'):
            clean_response = clean_response[3:-3].strip()
        
        extracted = json.loads(clean_response)
        
        # Validate extracted data
        validated_fields = {}
        for field, value in extracted.items():
            if field in ['xemail', 'xphone', 'xorg', 'xgcus'] and value and str(value).strip():
                validated_fields[field] = str(value).strip()
        
        return validated_fields
        
    except Exception as e:
        logger.debug(f"[InsertFlow] LLM field extraction failed: {e}")
        return {}

async def _generate_field_clarification_prompt(context, data_analysis):
    """Generate clarification prompt when no new fields were extracted."""
    try:
        missing_fields = data_analysis.get('missing_fields', [])
        field_names = {
            'xemail': 'Email Address',
            'xphone': 'Phone Number',
            'xorg': 'Organization',
            'xgcus': 'Customer Group'
        }
        
        missing_names = [field_names.get(field, field) for field in missing_fields]
        
        prompt_parts = [
            "🔍 **I need more specific information**",
            "",
            f"I couldn't extract the required fields from your message. Still missing: **{', '.join(missing_names)}**",
            "",
            "**Please provide in one of these formats:**",
            "• `Email: john@company.com`",
            "• `Phone: 1234567890`", 
            "• `Organization: ABC Corporation`",
            "• `Customer Group: Premium`",
            "",
            "**Or all together:**",
            "• `Email: john@company.com, Phone: 1234567890, Organization: ABC Corp, Group: Premium`"
        ]
        
        return "\n".join(prompt_parts)
        
    except Exception as e:
        logger.error(f"[InsertFlow] Error generating clarification prompt: {e}")
        return "Please provide the missing customer information in a clear format."

async def _generate_progressive_data_collection_prompt(context, data_analysis):
    """Generate structured data collection prompt with examples and clear field requirements."""
    try:
        # Field name mapping with examples
        field_info = {
            'xemail': {
                'name': 'Email Address',
                'example': 'john.doe@company.com',
                'description': 'Valid email address'
            },
            'xphone': {
                'name': 'Phone Number',
                'example': '1234567890 or 01798695259',
                'description': '5-15 digit phone number'
            },
            'xorg': {
                'name': 'Organization',
                'example': 'ABC Corporation, Tech Solutions Ltd',
                'description': 'Company or organization name'
            },
            'xgcus': {
                'name': 'Customer Group',
                'example': 'Premium, Standard, VIP, Corporate',
                'description': 'Customer type or category'
            },
            'xstatuscus': {
                'name': 'Customer Status',
                'example': 'Active, Inactive, Pending, Suspended',
                'description': 'Current status of the customer'
            },
            'xtaxscope': {
                'name': 'Tax Scope',
                'example': 'Domestic, International, Exempt, Standard',
                'description': 'Tax classification scope'
            }
        }
        
        # Show current progress
        progress_items = []
        collected_fields = data_analysis.get('collected_fields', {})
        
        for field in ['xemail', 'xphone', 'xorg', 'xgcus', 'xstatuscus', 'xtaxscope']:
            field_data = field_info[field]
            if field in collected_fields and collected_fields[field]:
                progress_items.append(f"✅ **{field_data['name']}**: {collected_fields[field]}")
            else:
                progress_items.append(f"❌ **{field_data['name']}**: Missing")
        
        # Generate prompt
        prompt_parts = [
            "📝 **Customer Creation - Mandatory Information Required**",
            "",
            "**Current Progress:**"
        ]
        prompt_parts.extend(progress_items)
        
        # Add detailed field requirements for missing fields
        missing_fields = data_analysis.get('missing_fields', [])
        if missing_fields:
            prompt_parts.extend([
                "",
                "**📋 Required Fields (with examples):**",
                ""
            ])
            
            for field in missing_fields:
                field_data = field_info[field]
                prompt_parts.extend([
                    f"**{field_data['name']}** ({field_data['description']})",
                    f"   Example: `{field_data['example']}`",
                    ""
                ])
            
            prompt_parts.extend([
                "**💡 How to provide information:**",
                "• You can provide one field at a time: `Email: john@company.com`",
                "• Or multiple fields together: `Email: john@company.com, Phone: 1234567890, Organization: ABC Corp, Group: Premium`",
                "• Or in natural language: `The customer's email is john@company.com and phone is 1234567890`",
                "",
                "Please provide the missing information:"
            ])
        
        return "\n".join(prompt_parts)
        
    except Exception as e:
        logger.error(f"[InsertFlow] Error generating progressive prompt: {e}")
        return "Please provide the remaining customer information to continue."

async def _generate_final_insert_sql(context):
    """Generate final INSERT SQL only after all mandatory fields are collected."""
    try:
        # Get all collected field values
        collected_fields = getattr(context, 'collected_field_values', {})
        
        if not collected_fields:
            context.response = "No customer data collected. Please provide customer information."
            context.next = "CustomerResponse"
            return context.model_dump()
        
        # Verify all mandatory fields are present before generating SQL
        required_fields = ['xemail', 'xphone', 'xorg', 'xgcus', 'xstatuscus', 'xtaxscope']
        missing_fields = []
        
        for field in required_fields:
            if field not in collected_fields or not collected_fields[field] or not collected_fields[field].strip():
                missing_fields.append(field)
        
        if missing_fields:
            # Still missing mandatory fields - should not happen but safety check
            logger.warning(f"[ReactiveInsertFlow] Attempted to generate SQL with missing fields: {missing_fields}")
            data_analysis = await _analyze_customer_data_completeness_enhanced(context)
            context.response = await _generate_progressive_data_collection_prompt(context, data_analysis)
            context.pause_reason = "missing_mandatory_fields"
            context.insert_phase = "data_collection"
            context.next = "PauseNode"
            return context.model_dump()
        
        # All mandatory fields present - generate final INSERT SQL
        columns = ['zid']  # Always include business ID
        values = [str(context.business_id)]
        
        # Add collected fields in consistent order
        for field in required_fields:
            if field in collected_fields:
                columns.append(field)
                escaped_value = collected_fields[field].replace("'", "''")  # Escape quotes
                values.append(f"'{escaped_value}'")
        
        # Add any additional fields that were collected
        for field, value in collected_fields.items():
            if field not in required_fields and field not in columns:
                columns.append(field)
                escaped_value = value.replace("'", "''")  # Escape quotes
                values.append(f"'{escaped_value}'")
        
        # Generate final SQL
        columns_str = ', '.join(columns)
        values_str = ', '.join(values)
        context.sql = f"INSERT INTO cacus ({columns_str}) VALUES ({values_str})"
        
        logger.info(f"[ReactiveInsertFlow] Generated final SQL with all mandatory fields: {context.sql}")
        
        # Clear collection state and proceed to validation
        context.insert_phase = None
        context.pause_reason = None
        context.next = "ValidateInsertFields"
        return context.model_dump()
        
    except Exception as e:
        logger.error(f"[InsertFlow] Error generating final SQL: {e}")
        context.response = f"Error generating customer creation SQL: {str(e)}"
        context.next = "CustomerResponse"
        return context.model_dump()

async def _check_for_duplicate_customers(context):
    """Check for duplicate customers based on collected data."""
    try:
        collected_fields = getattr(context, 'collected_field_values', {})
        email = collected_fields.get('xemail')
        phone = collected_fields.get('xphone')
        
        if not email and not phone:
            return {'has_duplicates': False, 'duplicates': []}
        
        # Build duplicate check query
        conditions = []
        if email:
            conditions.append(f"xemail = '{email}'")
        if phone:
            conditions.append(f"xphone = '{phone}'")
        
        duplicate_check_sql = f"""
        SELECT xcus, xemail, xphone, xorg 
        FROM cacus 
        WHERE zid = {context.business_id} 
        AND ({' OR '.join(conditions)})
        """
        
        result = await mcp_client.execute_query(duplicate_check_sql, context.business_id)
        
        if isinstance(result, dict) and 'content' in result:
            try:
                parsed = json.loads(result['content'][0]['text'])
                duplicates = parsed.get('results', [])
                
                return {
                    'has_duplicates': len(duplicates) > 0,
                    'duplicates': duplicates
                }
            except (json.JSONDecodeError, KeyError, IndexError):
                pass
        
        return {'has_duplicates': False, 'duplicates': []}
        
    except Exception as e:
        logger.error(f"[InsertFlow] Error checking duplicates: {e}")
        return {'has_duplicates': False, 'duplicates': []}

async def _generate_duplicate_handling_prompt(context, duplicate_result):
    """Generate prompt for handling duplicate customers."""
    try:
        duplicates = duplicate_result.get('duplicates', [])
        
        duplicate_info = []
        for dup in duplicates[:3]:  # Show max 3 duplicates
            info = f"• {dup.get('xcus', 'Unknown')} - {dup.get('xemail', 'No email')}"
            if dup.get('xorg'):
                info += f" ({dup['xorg']})"
            duplicate_info.append(info)
        
        prompt = (
            f"⚠️ **Duplicate Customer Found**\n\n"
            f"A customer with this contact information already exists:\n\n"
            f"{''.join(duplicate_info)}\n\n"
            f"Would you like to:\n"
            f"• Update the existing customer instead?\n"
            f"• Create a new customer with different contact information?\n"
            f"• Cancel the operation?"
        )
        
        return prompt
        
    except Exception as e:
        logger.error(f"[InsertFlow] Error generating duplicate prompt: {e}")
        return "Duplicate customer detected. Please choose how to proceed."

async def _analyze_customer_data_completeness(context):
    """Analyze if customer data is complete enough for insertion."""
    try:
        message = context.message.lower()
        
        # Required fields
        required_fields = ['email', 'phone', 'organization', 'customer group']
        
        # Strategy 3: Key-value pair extraction
        kv_patterns = {
            'xemail': [r'email[:\s]+([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})', 
                      r'e-?mail[:\s]+([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})'],
            'xphone': [r'phone[:\s]+(\d{5,15})', r'number[:\s]+(\d{5,15})', 
                      r'contact[:\s]+(\d{5,15})', r'mobile[:\s]+(\d{5,15})'],
            'xorg': [r'org(?:anization)?[:\s]+([^,\n]+)', r'company[:\s]+([^,\n]+)', 
                    r'business[:\s]+([^,\n]+)', r'firm[:\s]+([^,\n]+)',
                    r'org\s+is\s+([^,\n]+)', r'organization\s+is\s+([^,\n]+)'],
            'xgcus': [r'group[:\s]+([^,\n]+)', r'type[:\s]+([^,\n]+)', 
                     r'category[:\s]+([^,\n]+)', r'class[:\s]+([^,\n]+)',
                     r'customer\s+group[:\s]+([^,\n]+)', r'group\s+is\s+([^,\n]+)'],
            'xstatuscus': [r'status[:\s]+([^,\n]+)', r'customer\s+status[:\s]+([^,\n]+)',
                          r'status\s+is\s+([^,\n]+)'],
            'xtaxscope': [r'tax\s+scope[:\s]+([^,\n]+)', r'taxscope[:\s]+([^,\n]+)',
                         r'tax[:\s]+([^,\n]+)', r'scope[:\s]+([^,\n]+)']
        }
        
        found_fields = []
        for field, patterns in kv_patterns.items():
            for pattern in patterns:
                match = re.search(pattern, message)
                if match:
                    found_fields.append(field)
                    break
        
        # Use LLM for deeper analysis
        analysis_prompt = f"""
Analyze this customer creation request for data completeness:

User Message: "{context.message}"

Required Information:
1. Email address (valid format)
2. Phone number (10-11 digits)
3. Organization/Company name
4. Customer group/type

Determine:
1. Is all required information present?
2. What specific information is missing?
3. What clarification questions should be asked?

Return JSON:
{{
    "is_complete": boolean,
    "missing_fields": ["list of missing required fields"],
    "suggested_questions": ["list of clarifying questions"],
    "confidence": float (0-1)
}}
"""
        
        analysis_response = await llm_service.chat([
            {"role": "system", "content": analysis_prompt},
            {"role": "user", "content": context.message}
        ])
        
        try:
            analysis = json.loads(analysis_response)
            # Combine rule-based and LLM analysis
            analysis['is_complete'] = len(found_fields) >= 3 and analysis.get('is_complete', False)
            return analysis
        except json.JSONDecodeError:
            return {
                'is_complete': len(found_fields) >= 3,
                'missing_fields': [field for field in required_fields if field not in found_fields],
                'suggested_questions': ['What is the customer\'s email address?', 'What is their phone number?'],
                'confidence': 0.6
            }
            
    except Exception as e:
        logger.error(f"[InsertFlow] Error analyzing data completeness: {e}")
        return {
            'is_complete': False,
            'missing_fields': ['email', 'phone', 'organization', 'customer_group'],
            'suggested_questions': ['Please provide the customer\'s complete information'],
            'confidence': 0.0
        }

async def _generate_data_collection_prompt(context, data_analysis):
    """Generate data collection prompt for insert operations."""
    try:
        questions = [
            "📝 **Customer Creation - Information Collection**",
            "",
            "I need some additional information to create the customer record.",
            ""
        ]
        
        # Add specific missing field requests
        if data_analysis.get('missing_fields'):
            questions.extend([
                "**Missing Information:**",
                *[f"• {field.replace('_', ' ').title()}" for field in data_analysis['missing_fields']],
                ""
            ])
        
        # Add clarification questions
        if data_analysis.get('suggested_questions'):
            questions.extend([
                "**Please provide:**",
                *[f"• {q}" for q in data_analysis['suggested_questions'][:3]],
                ""
            ])
        
        questions.extend([
            "**Required Fields:**",
            "• Email address (valid format)",
            "• Phone number (10-11 digits)",
            "• Organization/Company name",
            "• Customer group/type",
            "",
            "Please provide the missing information:"
        ])
        
        return "\n".join(questions)
        
    except Exception as e:
        logger.error(f"[InsertFlow] Error generating data collection prompt: {e}")
        return "Please provide the customer's email, phone number, organization, and customer group."

async def _build_dynamic_insert_sql_prompt(context):
    """Build dynamic SQL prompt for insert operations with enhanced context."""
    
    # Get schema context
    schema_info = "\n".join(context.schema_context) if context.schema_context else "Customer table: cacus"
    
    sql_prompt = f"""
You are a SQL expert generating INSERT queries for customer data.

Database Schema:
{schema_info}

Business Context:
- Business ID (zid): {context.business_id} (ALWAYS include in INSERT)
- Customer table: cacus
- Customer ID will be auto-generated (do not include xcus in INSERT)

User Request: "{context.message}"

Conversation Context:
{' '.join([msg.content for msg in context.conversation_history[-3:]])}

Generate an INSERT SQL query that:
1. ALWAYS includes zid = {context.business_id}
2. Extracts customer information from the user message
3. Uses proper SQL syntax for PostgreSQL
4. Maps user input to correct database fields:
   - Email → xemail
   - Phone → xphone
   - Organization → xorg
   - Customer Group → xgcus
   - First Name → xfirst
   - Last Name → xlast

Examples:
- "create customer john@example.com, phone 1234567890, Acme Corp, VIP" → INSERT INTO cacus (zid, xemail, xphone, xorg, xgcus) VALUES ({context.business_id}, 'john@example.com', '1234567890', 'Acme Corp', 'VIP');
- "add customer Jane Smith, jane@test.com, 9876543210, Test Inc, Standard" → INSERT INTO cacus (zid, xfirst, xlast, xemail, xphone, xorg, xgcus) VALUES ({context.business_id}, 'Jane', 'Smith', 'jane@test.com', '9876543210', 'Test Inc', 'Standard');

Return only the SQL query, no explanations.
"""
    
    return sql_prompt

async def _validate_customer_fields(sql_fields, required_fields):
    """Enhanced validation of customer fields with detailed error reporting."""
    try:
        missing_fields = []
        validation_errors = []
        
        # Check for missing required fields
        for field in required_fields:
            if field not in sql_fields or not sql_fields[field] or sql_fields[field].strip("'\"") == '':
                missing_fields.append(field)
        
        # Validate existing fields with enhanced checks
        for field, value in sql_fields.items():
            clean_value = value.strip("'\"")
            
            if field == 'xemail' and clean_value:
                if not is_valid_email(clean_value):
                    validation_errors.append(f"Email format is invalid: {clean_value}")
                elif len(clean_value) > 100:
                    validation_errors.append(f"Email is too long (max 100 characters): {clean_value}")
                    
            elif field == 'xphone' and clean_value:
                if not is_valid_phone(clean_value):
                    validation_errors.append(f"Phone number must be 10 or 11 digits: {clean_value}")
                elif not clean_value.isdigit():
                    validation_errors.append(f"Phone number should contain only digits: {clean_value}")
                if clean_value.isdigit() and len(clean_value) >= 5:
                    cleaned_fields[field] = clean_value
            elif field == 'xorg' and clean_value:
                if len(clean_value) > 200:
                    validation_errors.append(f"Organization name is too long (max 200 characters): {clean_value}")
                if len(clean_value.strip()) >= 1:
                    cleaned_fields[field] = clean_value.strip()
            elif field == 'xgcus' and clean_value:
                if len(clean_value) > 50:
                    validation_errors.append(f"Customer group is too long (max 50 characters): {clean_value}")
                if len(clean_value.strip()) >= 1:
                    cleaned_fields[field] = clean_value.strip()
            elif field in ['xstatuscus', 'xtaxscope'] and clean_value:
                if len(clean_value.strip()) >= 1:
                    cleaned_fields[field] = clean_value.strip()
        
        return {
            'missing_fields': missing_fields,
            'validation_errors': validation_errors,
            'is_valid': len(missing_fields) == 0 and len(validation_errors) == 0,
            'cleaned_fields': cleaned_fields
        }
        
    except Exception as e:
        logger.error(f"[InsertFlow] Error validating fields: {e}")
        return {
            'missing_fields': required_fields,
            'validation_errors': ['Error during validation'],
            'is_valid': False
        }

async def _generate_validation_progress_message(context, required_fields, validation_result):
    """Generate enhanced progress message for validation."""
    try:
        progress_items = []
        
        # Field mapping for display
        field_names = {
            'xemail': 'Email Address',
            'xphone': 'Phone Number',
            'xgcus': 'Customer Group',
            'xorg': 'Organization'
        }
        
        # Show progress for each required field
        for field in required_fields:
            field_name = field_names.get(field, field)
            
            if hasattr(context, 'collected_field_values') and field in context.collected_field_values:
                progress_items.append(f"✅ {field_name}: {context.collected_field_values[field]}")
            else:
                progress_items.append(f"❌ {field_name}: Missing")
        
        progress_message = "**Customer Creation Progress:**\n" + "\n".join(progress_items)
        
        # Add validation errors if any
        if validation_result.get('validation_errors'):
            error_message = "\n\n**Validation Errors:**\n" + "\n".join([f"• {error}" for error in validation_result['validation_errors']])
            progress_message += error_message
        
        # Add missing field requests
        if validation_result.get('missing_fields'):
            missing_field_names = [field_names.get(field, field) for field in validation_result['missing_fields']]
            progress_message += f"\n\nPlease provide the missing information: {', '.join(missing_field_names)}"
        
        return progress_message
        
    except Exception as e:
        logger.error(f"[InsertFlow] Error generating progress message: {e}")
        return "Please provide the required customer information to continue."

async def _extract_and_validate_fields(message):
    """Enhanced field extraction with validation."""
    try:
        # Use existing helper function as base
        extracted_fields = extract_customer_fields_from_message(message)
        
        # Enhanced extraction with regex patterns
        email_pattern = r'\b[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}\b'
        phone_pattern = r'\b\d{10,11}\b'
        
        email_match = re.search(email_pattern, message)
        phone_match = re.search(phone_pattern, message)
        
        if email_match and 'xemail' not in extracted_fields:
            extracted_fields['xemail'] = email_match.group()
            
        if phone_match and 'xphone' not in extracted_fields:
            extracted_fields['xphone'] = phone_match.group()
        
        # Clean and validate extracted fields
        validated_fields = {}
        for field, value in extracted_fields.items():
            clean_value = str(value).strip()
            if clean_value:
                validated_fields[field] = clean_value
        
        return validated_fields
        
    except Exception as e:
        logger.error(f"[InsertFlow] Error extracting fields: {e}")
        return {}

async def _update_sql_with_collected_fields(incomplete_sql, collected_fields):
    """Update incomplete SQL with collected field values."""
    try:
        updated_sql = incomplete_sql
        
        # Replace or add field values in SQL
        for field, value in collected_fields.items():
            # Escape single quotes in values
            escaped_value = value.replace("'", "''")
            
            # Check if field already exists in SQL
            field_pattern = rf"{field}\s*=\s*'[^']*'"
            if re.search(field_pattern, updated_sql, re.IGNORECASE):
                # Replace existing value
                updated_sql = re.sub(field_pattern, f"{field} = '{escaped_value}'", updated_sql, flags=re.IGNORECASE)
            else:
                # Add new field to INSERT statement
                values_match = re.search(r'VALUES\s*\(([^)]+)\)', updated_sql, re.IGNORECASE)
                columns_match = re.search(r'INSERT\s+INTO\s+\w+\s*\(([^)]+)\)', updated_sql, re.IGNORECASE)
                
                if values_match and columns_match:
                    columns = columns_match.group(1)
                    values = values_match.group(1)
                    
                    # Add field to columns and values
                    new_columns = f"{columns}, {field}"
                    new_values = f"{values}, '{escaped_value}'"
                    
                    # Replace in SQL
                    updated_sql = re.sub(r'INSERT\s+INTO\s+(\w+)\s*\([^)]+\)', 
                                       f'INSERT INTO \\1 ({new_columns})', updated_sql, flags=re.IGNORECASE)
                    updated_sql = re.sub(r'VALUES\s*\([^)]+\)', 
                                       f'VALUES ({new_values})', updated_sql, flags=re.IGNORECASE)
        
        return updated_sql
        
    except Exception as e:
        logger.error(f"[InsertFlow] Error updating SQL: {e}")
        return incomplete_sql

async def _generate_success_message(context, parsed_result):
    """Generate enhanced success message with customer details."""
    try:
        # Extract customer ID from SQL
        customer_id_match = re.search(r"'(CUS-\d{6})'", context.sql)
        if customer_id_match:
            new_customer_id = customer_id_match.group(1)
            
            # Fetch the newly created customer details
            fetch_sql = f"SELECT * FROM cacus WHERE zid = {context.business_id} AND xcus = '{new_customer_id}'"
            fetch_result = await mcp_client.execute_query(fetch_sql, context.business_id)
            
            if isinstance(fetch_result, dict) and 'content' in fetch_result:
                try:
                    parsed_fetch = json.loads(fetch_result['content'][0]['text'])
                    customer_data = parsed_fetch.get('results', [])
                    
                    if customer_data:
                        customer_details = format_customer_result(customer_data)
                        return f"🎉 **Customer Successfully Created!**\n\n{customer_details}"
                    else:
                        return f"✅ Customer successfully created! Customer ID: **{new_customer_id}**"
                except Exception:
                    return f"✅ Customer successfully created! Customer ID: **{new_customer_id}**"
        
        return "✅ Customer has been successfully created! The customer ID has been automatically generated."
        
    except Exception as e:
        logger.error(f"[InsertFlow] Error generating success message: {e}")
        return "✅ Customer has been successfully created!"

async def _handle_insert_error(error_msg):
    """Enhanced error handling for insert operations."""
    try:
        error_lower = error_msg.lower()
        
        if 'duplicate' in error_lower or 'unique' in error_lower:
            return (
                "❌ **Duplicate Customer Detected**\n\n"
                "A customer with this email or phone number already exists. "
                "Please check the information and try again with different details."
            )
        elif 'constraint' in error_lower or 'foreign key' in error_lower:
            return (
                "❌ **Invalid Reference Data**\n\n"
                "The customer group or organization specified is invalid. "
                "Please check these values and try again."
            )
        elif 'not null' in error_lower:
            return (
                "❌ **Missing Required Information**\n\n"
                "Some required fields are missing. Please provide all mandatory customer information."
            )
        else:
            return f"❌ **Customer Creation Failed**\n\nError: {error_msg}"
            
    except Exception as e:
        logger.error(f"[InsertFlow] Error handling insert error: {e}")
        return f"❌ Failed to create customer: {error_msg}"

async def _check_insert_flow_interruption(context):
    """Check for flow interruption during insert operations."""
    try:
        interruption = await flow_interruption_handler.check_interruption(
            context.message, 
            context.conversation_history,
            current_flow="insert"
        )
        
        if interruption['is_interrupted']:
            logger.info(f"[InsertFlow] Flow interrupted: {interruption['new_intent']}")
            
            # Clear insert flow state
            context = _clear_insert_flow_state(context)
            
            # Handle the interruption
            if interruption['new_intent'] in ['select', 'search', 'list']:
                context.query_classification = "SEARCH_CUSTOMER"
                context.next = "GenerateSelectSQL"
            elif interruption['new_intent'] == 'update':
                context.query_classification = "UPDATE_CUSTOMER"
                context.next = "GenerateUpdateSQL"
            elif interruption['new_intent'] == 'delete':
                context.query_classification = "DELETE_CUSTOMER"
                context.next = "GenerateDeleteSQL"
            else:
                context.next = "GeneralCustomerChat"
            
            return {
                'is_interrupted': True,
                'response': context.model_dump()
            }
        
        return {'is_interrupted': False}
        
    except Exception as e:
        logger.error(f"[InsertFlow] Error checking interruption: {e}")
        return {'is_interrupted': False}

def _clear_insert_flow_state(context):
    """Clear insert flow specific state."""
    # Clear insert-specific fields
    if hasattr(context, 'collected_field_values'):
        delattr(context, 'collected_field_values')
    if hasattr(context, 'incomplete_sql'):
        delattr(context, 'incomplete_sql')
    if hasattr(context, 'missing_mandatory_fields'):
        delattr(context, 'missing_mandatory_fields')
    if hasattr(context, 'insert_phase'):
        delattr(context, 'insert_phase')
    
    # Clear general flow state
    context.pause_reason = None
    context.pause_message = None
    context.current_flow = None
    
    return context

# New node for duplicate checking
async def check_duplicate_customer_node(context):
    """Check for duplicate customers before insertion."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    logger.info("[ReactiveInsertDuplicateCheck] Checking for duplicate customers")
    
    try:
        # Extract email and phone from SQL
        sql_fields = extract_insert_fields_from_sql(context.sql)
        email = sql_fields.get('xemail', '').strip("'\"")
        phone = sql_fields.get('xphone', '').strip("'\"")
        
        if email or phone:
            # Build duplicate check query
            conditions = []
            if email:
                conditions.append(f"xemail = '{email}'")
            if phone:
                conditions.append(f"xphone = '{phone}'")
            
            duplicate_check_sql = f"""
            SELECT xcus, xemail, xphone, xorg 
            FROM cacus 
            WHERE zid = {context.business_id} 
            AND ({' OR '.join(conditions)})
            """
            
            result = await mcp_client.execute_query(duplicate_check_sql, context.business_id)
            
            if isinstance(result, dict) and 'content' in result:
                try:
                    parsed = json.loads(result['content'][0]['text'])
                    duplicates = parsed.get('results', [])
                    
                    if duplicates:
                        # Found duplicates, show them to user
                        duplicate_info = []
                        for dup in duplicates[:3]:  # Show max 3 duplicates
                            info = f"• {dup.get('xcus', 'Unknown')} - {dup.get('xemail', 'No email')}"
                            if dup.get('xorg'):
                                info += f" ({dup['xorg']})"
                            duplicate_info.append(info)
                        
                        context.response = (
                            f"⚠️ **Duplicate Customer Found**\n\n"
                            f"A customer with this {'email' if email in str(duplicates) else 'phone number'} already exists:\n\n"
                            f"{''.join(duplicate_info)}\n\n"
                            f"Would you like to:\n"
                            f"• Update the existing customer instead?\n"
                            f"• Create a new customer with different contact information?\n"
                            f"• Cancel the operation?"
                        )
                        context.next = "CustomerResponse"
                        return context.model_dump()
                        
                except (json.JSONDecodeError, KeyError, IndexError):
                    pass
        
        # No duplicates found, proceed to customer ID generation
        context.next = "GenerateCustomerID"
        return context.model_dump()
        
    except Exception as e:
        logger.error(f"[ReactiveInsertDuplicateCheck] Error: {e}")
        # Continue with insertion on error
        context.next = "GenerateCustomerID"
        return context.model_dump()
