"""
Reactive Customer Update Flow - Handles customer data modification with dynamic customer selection and field updates
"""
from backend.app.models.chat_graph_state import ChatGraphState
from backend.app.services.mistral_llm_service import MistralLLMService
from backend.app.services.vector_search import FaissVectorSearchService
from backend.app.mcp.mcp_client import MCPClient
from backend.app.agents.customer_agent.customer_chat_helpers import (
    build_customer_sql_prompt, clean_sql_from_llm, format_customer_result,
    get_customer_schema_context_for_flow
)
from backend.app.agents.customer_agent.reactive_questioning import ReactiveQuestioningSystem
from backend.app.agents.customer_agent.negative_vibe_detector import negative_vibe_detector
from backend.app.agents.customer_agent.flow_interruption_handler import flow_interruption_handler
import logging
import json
import re

logger = logging.getLogger(__name__)

# Initialize services
llm_service = MistralLLMService()
vector_search_service = FaissVectorSearchService()
mcp_client = MCPClient(script_path="backend/app/mcp/server_enhanced.py")
reactive_questioning = ReactiveQuestioningSystem()

async def generate_update_sql_node(context):
    """Generate SQL for customer UPDATE operations with reactive customer selection and field identification."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    logger.info(f"[ReactiveUpdateFlow] Starting UPDATE flow for: {context.message}")
    
    # Set current flow
    context.current_flow = "update"
    
    # Check for negative vibe first
    negative_vibe = await negative_vibe_detector.detect_negative_vibe(
        context.message, context.conversation_history
    )
    
    if negative_vibe['is_negative']:
        logger.info("[ReactiveUpdateFlow] Negative vibe detected, canceling flow")
        context = _clear_update_flow_state(context)
        context.response = negative_vibe['suggested_response']
        context.next = "CustomerResponse"
        return context.model_dump()
    
    # Check for flow interruption (DELETE, INSERT, or SELECT intent)
    interruption_check = await _check_update_flow_interruption(context)
    if interruption_check['is_interrupted']:
        return interruption_check['response']
    
    # Get schema context for update operations
    if not hasattr(context, 'schema_context') or not context.schema_context:
        context.schema_context = await get_customer_schema_context_for_flow(context.business_id, "update")
    
    # PHASE 1: Customer Selection - Always start here if not already selected
    if not hasattr(context, 'selected_customer_id') or not context.selected_customer_id:
        logger.info("[ReactiveUpdateFlow] Phase 1: Customer selection needed")
        
        # Analyze if customer identification is clear
        customer_clarity = await _analyze_customer_identification_for_update(context)
        
        if customer_clarity['is_clear']:
            # Customer is clearly identified, fetch and confirm
            customer_data = await _fetch_identified_customer(context, customer_clarity)
            if customer_data:
                context.selected_customer_id = customer_data.get('xcus')
                context.selected_customer_data = customer_data
                context.update_phase = "field_selection"
                # Proceed to field selection
                return await _proceed_to_field_selection(context)
            else:
                context.response = "Customer not found. Please provide a valid customer ID, email, or other identifier."
                context.next = "CustomerResponse"
                return context.model_dump()
        else:
            # Customer identification unclear - need to ask for clarification or show options
            context.response = await _generate_customer_selection_prompt_for_update(context, customer_clarity)
            context.pause_reason = "customer_selection_needed"
            context.update_phase = "customer_selection"
            context.next = "PauseNode"
            return context.model_dump()
    
    # PHASE 2: Field Selection - Customer already selected
    elif hasattr(context, 'update_phase') and context.update_phase == "field_selection":
        logger.info("[ReactiveUpdateFlow] Phase 2: Field selection")
        return await _handle_field_selection_phase(context)
    
    # PHASE 3: Final UPDATE SQL Generation - Both customer and fields selected
    else:
        logger.info("[ReactiveUpdateFlow] Phase 3: Generating final UPDATE SQL")
        return await _generate_final_update_sql(context)

async def _analyze_customer_identification_for_update(context):
    """Analyze if customer identification is clear using LLM with conversation context."""
    try:
        identification_prompt = f"""
Analyze if the customer identification is clear enough for an UPDATE operation.

User Message: "{context.message}"
Conversation History: {[msg.content for msg in context.conversation_history[-4:]]}

Check for:
1. Specific customer ID (CUS-XXXXXX format)
2. Clear references like "last customer", "recent customer"
3. Unique identifiers like email, phone, or name
4. Contextual references from previous conversation

Respond with JSON:
{{
    "is_clear": boolean,
    "identification_type": "customer_id/reference/unique_field/contextual/none",
    "identified_value": "the specific identifier if found",
    "missing_info": ["what information is needed"],
    "confidence": "high/medium/low"
}}

Examples:
- "update customer CUS-000123" → is_clear: true, type: "customer_id"
- "update last customer" → is_clear: true, type: "reference"
- "update customer with email john@example.com" → is_clear: true, type: "unique_field"
- "update customer" → is_clear: false, missing: ["customer identification"]
"""
        
        response = await llm_service.chat([
            {"role": "system", "content": identification_prompt},
            {"role": "user", "content": context.message}
        ])
        
        import json
        try:
            result = json.loads(response)
            return result
        except json.JSONDecodeError:
            # Fallback analysis
            has_customer_id = bool(re.search(r'CUS-\d{6}', context.message))
            has_reference = any(ref in context.message.lower() for ref in ['last', 'recent', 'previous'])
            return {
                "is_clear": has_customer_id or has_reference,
                "identification_type": "customer_id" if has_customer_id else "reference" if has_reference else "none",
                "missing_info": [] if (has_customer_id or has_reference) else ["customer identification"]
            }
            
    except Exception as e:
        logger.error(f"[CustomerIdentification] Error: {e}")
        return {
            "is_clear": False,
            "identification_type": "none",
            "missing_info": ["customer identification"]
        }

async def _check_update_flow_interruption(context):
    """Check for flow interruption with deep SELECT vs UPDATE intent analysis."""
    try:
        interruption_prompt = f"""
You are analyzing a user message in the context of a customer UPDATE flow to determine if they want to:
1. Continue with UPDATE operation
2. Switch to standalone SELECT operation  
3. Switch to DELETE operation
4. Switch to INSERT operation
5. Cancel the operation

CRITICAL: Pay special attention to SELECT requests during UPDATE flow.

Current Flow: UPDATE (customer modification)
User Message: "{context.message}"
Conversation Context: {[msg.content for msg in context.conversation_history[-4:]]}

DEEP ANALYSIS REQUIRED:
- If user says "select customer" or "show customer" during UPDATE, determine if they want:
  a) To SELECT a customer FOR the UPDATE operation (continue UPDATE flow)
  b) To perform a standalone SELECT operation (interrupt UPDATE flow)

Consider:
1. Context clues: "select customer to update" vs "show me customer details"
2. Previous conversation: Are they in middle of UPDATE process?
3. Phrasing: "select for update" vs "just show me"
4. Intent: Modification vs Information retrieval

Respond with JSON:
{{
    "is_interrupted": boolean,
    "target_operation": "update/select/delete/insert/cancel/none",
    "intent_analysis": {{
        "is_select_for_update": boolean,
        "is_standalone_select": boolean,
        "confidence": "high/medium/low"
    }},
    "reasoning": "detailed explanation of decision",
    "suggested_response": "response to user if interrupted"
}}

Examples:
- "select customer CUS-123 to update email" → continue UPDATE (is_interrupted: false)
- "show me customer CUS-123 details" → standalone SELECT (is_interrupted: true, target: "select")
- "find customers with gmail" → standalone SELECT (is_interrupted: true, target: "select")
- "delete this customer instead" → DELETE (is_interrupted: true, target: "delete")
- "cancel update" → CANCEL (is_interrupted: true, target: "cancel")
"""
        
        response = await llm_service.chat([
            {"role": "system", "content": interruption_prompt},
            {"role": "user", "content": context.message}
        ])
        
        import json
        try:
            result = json.loads(response)
            
            if result.get('is_interrupted', False):
                target_op = result.get('target_operation', 'none')
                
                if target_op == 'cancel':
                    context = _clear_update_flow_state(context)
                    context.response = result.get('suggested_response', "UPDATE operation canceled. How can I help you?")
                    context.next = "CustomerResponse"
                    return {'is_interrupted': True, 'response': context.model_dump()}
                
                elif target_op == 'select':
                    # Standalone SELECT - clear UPDATE state and switch to SELECT flow
                    context = _clear_update_flow_state(context)
                    context.current_flow = "select"
                    context.query_classification = "SEARCH_CUSTOMER"
                    context.response = result.get('suggested_response', "Switching to customer search.")
                    context.next = "VectorSearch"
                    return {'is_interrupted': True, 'response': context.model_dump()}
                
                elif target_op in ['delete', 'insert']:
                    context = _clear_update_flow_state(context)
                    context.current_flow = target_op
                    context.response = result.get('suggested_response', f"Switching to {target_op} operation.")
                    context.next = "GenerateCustomerSQL"
                    return {'is_interrupted': True, 'response': context.model_dump()}
            
            return {'is_interrupted': False}
            
        except json.JSONDecodeError:
            return {'is_interrupted': False}
            
    except Exception as e:
        logger.error(f"[UpdateFlowInterruption] Error: {e}")
        return {'is_interrupted': False}

async def _fetch_identified_customer(context, customer_clarity):
    """Fetch customer data based on identification analysis."""
    try:
        identification_type = customer_clarity.get('identification_type', 'none')
        identified_value = customer_clarity.get('identified_value', '')
        
        if identification_type == 'customer_id':
            # Direct customer ID lookup
            sql = f"SELECT * FROM cacus WHERE zid = {context.business_id} AND xcus = '{identified_value}'"
        elif identification_type == 'reference':
            # Reference like "last customer", "recent customer"
            if 'last' in identified_value.lower() or 'recent' in identified_value.lower():
                sql = f"SELECT * FROM cacus WHERE zid = {context.business_id} ORDER BY xcus DESC LIMIT 1"
            else:
                return None
        elif identification_type == 'unique_field':
            # Email, phone, or other unique field
            if '@' in identified_value:
                sql = f"SELECT * FROM cacus WHERE zid = {context.business_id} AND xemail = '{identified_value}'"
            elif identified_value.replace('-', '').replace(' ', '').isdigit():
                sql = f"SELECT * FROM cacus WHERE zid = {context.business_id} AND xphone = '{identified_value}'"
            else:
                # Try name search
                sql = f"SELECT * FROM cacus WHERE zid = {context.business_id} AND (xfirst ILIKE '%{identified_value}%' OR xlast ILIKE '%{identified_value}%')"
        else:
            return None
        
        result = await mcp_client.execute_query(sql, context.business_id)
        
        if isinstance(result, dict) and 'content' in result:
            try:
                parsed = json.loads(result['content'][0]['text'])
                customers = parsed.get('results', [])
                return customers[0] if customers else None
            except (json.JSONDecodeError, KeyError, IndexError):
                return None
        
        return None
        
    except Exception as e:
        logger.error(f"[FetchCustomer] Error: {e}")
        return None

async def _generate_customer_selection_prompt_for_update(context, customer_clarity):
    """Generate customer selection prompt specifically for UPDATE operations."""
    try:
        missing_info = customer_clarity.get('missing_info', [])
        
        # Get recent customers as examples
        recent_customers_sql = f"SELECT xcus, xemail, xfirst, xlast FROM cacus WHERE zid = {context.business_id} ORDER BY xcus DESC LIMIT 5"
        result = await mcp_client.execute_query(recent_customers_sql, context.business_id)
        
        examples = []
        if isinstance(result, dict) and 'content' in result:
            try:
                parsed = json.loads(result['content'][0]['text'])
                customers = parsed.get('results', [])
                for i, cust in enumerate(customers, 1):
                    cid = cust.get('xcus', 'Unknown')
                    email = cust.get('xemail', 'No email')
                    name = f"{cust.get('xfirst', '')} {cust.get('xlast', '')}".strip()
                    examples.append(f"{i}. {cid} - {email} ({name or 'No name'})")
            except (json.JSONDecodeError, KeyError, IndexError):
                pass
        
        example_text = "\\n".join(examples) if examples else "No recent customers found"
        
        prompt = f"""**🔍 Which customer would you like to update?**

I need to identify the specific customer for the UPDATE operation.

**📋 Recent Customers:**
{example_text}

**💡 You can specify a customer by:**
• **Customer ID**: "CUS-000123"
• **Email**: "john@example.com"  
• **Phone**: "1234567890"
• **Name**: "John Smith"
• **Reference**: "last customer", "recent customer"
• **Pick from list**: "customer 1", "the first one"

**📝 Examples:**
• "Update customer CUS-000123"
• "Update the customer with email john@example.com"
• "Update last customer"
• "Update customer 1 from the list"

**Which customer would you like to update?**"""
        
        return prompt
        
    except Exception as e:
        logger.error(f"[CustomerSelectionPrompt] Error: {e}")
        return "Which customer would you like to update? Please provide a customer ID, email, or other identifier."

async def _proceed_to_field_selection(context):
    """Proceed to field selection phase after customer is identified."""
    try:
        customer = context.selected_customer_data
        customer_id = customer.get('xcus', 'Unknown')
        
        # Show current field values and ask what to update
        field_display = []
        important_fields = ['xcus', 'xemail', 'xphone', 'xfirst', 'xlast', 'xorg', 'xgcus']
        
        for field in important_fields:
            if field in customer:
                value = customer[field]
                display_value = value if value is not None and str(value).strip() else "**NULL**"
                field_display.append(f"• **{field}**: {display_value}")
        
        current_values = "\\n".join(field_display)
        
        context.response = f"""**✅ Customer Selected: {customer_id}**

**📋 Current Field Values:**
{current_values}

**🔧 What would you like to update?**

**📝 Examples:**
• "Update email to newemail@example.com"
• "Change phone to +1234567890"
• "Set first name to John and last name to Doe"
• "Update organization to New Company Inc"

**Which fields would you like to update?**"""
        
        context.pause_reason = "field_selection_needed"
        context.next = "PauseNode"
        return context.model_dump()
        
    except Exception as e:
        logger.error(f"[FieldSelection] Error: {e}")
        context.response = f"Customer {context.selected_customer_id} selected. What would you like to update?"
        context.pause_reason = "field_selection_needed"
        context.next = "PauseNode"
        return context.model_dump()

async def _handle_field_selection_phase(context):
    """Handle field selection phase of UPDATE flow."""
    try:
        # Extract field updates from user message
        field_updates = await _extract_field_updates_from_message(context)
        
        if not field_updates:
            context.response = "I couldn't identify which fields to update. Please specify the field name and new value, for example: 'update email to newemail@example.com'"
            context.pause_reason = "field_selection_needed"
            context.next = "PauseNode"
            return context.model_dump()
        
        # Store field updates and proceed to final SQL generation
        context.field_updates = field_updates
        context.update_phase = "confirmation"
        
        return await _generate_final_update_sql(context)
        
    except Exception as e:
        logger.error(f"[FieldSelectionPhase] Error: {e}")
        context.response = "Error processing field updates. Please try again."
        context.next = "CustomerResponse"
        return context.model_dump()

async def _generate_final_update_sql(context):
    """Generate final UPDATE SQL with customer and field information."""
    try:
        customer_id = context.selected_customer_id
        field_updates = getattr(context, 'field_updates', {})
        
        if not customer_id or not field_updates:
            context.response = "Missing customer or field information for UPDATE. Please start over."
            context.next = "CustomerResponse"
            return context.model_dump()
        
        # Build SET clause
        set_clauses = []
        for field, value in field_updates.items():
            if value.upper() == 'NULL' or value.upper() == 'EMPTY':
                set_clauses.append(f"{field} = NULL")
            else:
                set_clauses.append(f"{field} = '{value}'")
        
        set_clause = ", ".join(set_clauses)
        
        # Generate UPDATE SQL
        context.sql = f"UPDATE cacus SET {set_clause} WHERE zid = {context.business_id} AND xcus = '{customer_id}'"
        context.customer_action = "update"
        context.next = "CustomerDependencyCheck"
        
        logger.info(f"[FinalUpdateSQL] Generated: {context.sql}")
        return context.model_dump()
        
    except Exception as e:
        logger.error(f"[FinalUpdateSQL] Error: {e}")
        context.response = f"Error generating UPDATE SQL: {str(e)}"
        context.next = "CustomerResponse"
        return context.model_dump()

async def _extract_field_updates_from_message(context):
    """Extract field updates from user message using LLM."""
    try:
        extraction_prompt = f"""
Extract field updates from the user's message for a customer UPDATE operation.

User Message: "{context.message}"
Customer Data: {context.selected_customer_data}

Extract field names and their new values. Map common terms to database fields:
- email → xemail
- phone → xphone  
- first name → xfirst
- last name → xlast
- organization → xorg
- customer group → xgcus
- address → xaddress
- city → xcity
- state → xstate
- zip → xzip
- country → xcountry

Respond with JSON:
{{
    "field_updates": {{
        "field_name": "new_value"
    }},
    "confidence": "high/medium/low"
}}

Examples:
- "update email to john@new.com" → {{"xemail": "john@new.com"}}
- "change phone to 1234567890" → {{"xphone": "1234567890"}}
- "set first name to John and last name to Doe" → {{"xfirst": "John", "xlast": "Doe"}}
"""
        
        response = await llm_service.chat([
            {"role": "system", "content": extraction_prompt},
            {"role": "user", "content": context.message}
        ])
        
        import json
        try:
            result = json.loads(response)
            return result.get('field_updates', {})
        except json.JSONDecodeError:
            return {}
            
    except Exception as e:
        logger.error(f"[FieldExtraction] Error: {e}")
        return {}

async def _analyze_field_update_requirements_for_update(context):
    """Analyze if field update requirements are clear using LLM with schema context."""
    try:
        # Get available fields from schema
        schema_fields = await _extract_updateable_fields_from_schema(context.schema_context)
        
        field_analysis_prompt = f"""
Analyze if the field update requirements are clear for a customer UPDATE operation.

User Message: "{context.message}"
Available Customer Fields: {schema_fields}
Conversation History: {[msg.content for msg in context.conversation_history[-3:]]}

Check for:
1. Specific field names mentioned (email, phone, name, etc.)
2. New values provided for fields
3. Clear update instructions

Respond with JSON:
{{
    "is_clear": boolean,
    "identified_fields": {{
        "field_name": "new_value"
    }},
    "missing_info": ["what field information is needed"],
    "requires_current_values": boolean,
    "confidence": "high/medium/low"
}}

Examples:
- "update email to john@new.com" → is_clear: true, fields: {{"xemail": "john@new.com"}}
- "change phone number to 1234567890" → is_clear: true, fields: {{"xphone": "1234567890"}}
- "update customer info" → is_clear: false, missing: ["specific fields and values"]
- "update customer CUS-123" → is_clear: false, missing: ["which fields to update"]
"""
        
        response = await llm_service.chat([
            {"role": "system", "content": field_analysis_prompt},
            {"role": "user", "content": context.message}
        ])
        
        import json
        try:
            result = json.loads(response)
            return result
        except json.JSONDecodeError:
            # Fallback analysis
            has_field_mentions = any(field in context.message.lower() for field in ['email', 'phone', 'name', 'organization'])
            has_values = '=' in context.message or ' to ' in context.message
            return {
                "is_clear": has_field_mentions and has_values,
                "identified_fields": {},
                "missing_info": [] if (has_field_mentions and has_values) else ["specific fields and values"],
                "requires_current_values": not (has_field_mentions and has_values)
            }
            
    except Exception as e:
        logger.error(f"[FieldAnalysis] Error: {e}")
        return {
            "is_clear": False,
            "identified_fields": {},
            "missing_info": ["field update requirements"],
            "requires_current_values": True
        }

# --- Helper Functions for Reactive UPDATE Flow ---

def _clear_update_flow_state(context):
    """Clear all UPDATE flow related state."""
    context.update_phase = None
    context.selected_customer_data = None
    context.customer_selection_context = None
    context.field_selection_context = None
    context.pause_reason = None
    context.pause_message = None
    context.current_flow = None
    return context

async def _generate_customer_selection_prompt(context, customer_clarity):
    """Generate customer selection prompt with helpful examples."""
    try:
        # Show recent customers for context
        show_customers_sql = f"SELECT xcus, xemail, xphone, xorg, xfirst, xlast FROM cacus WHERE zid = {context.business_id} ORDER BY xcus DESC LIMIT 5"
        result = await mcp_client.execute_query(show_customers_sql, context.business_id)
        
        customer_examples = ""
        if isinstance(result, dict) and 'content' in result:
            try:
                parsed = json.loads(result['content'][0]['text'])
                customers = parsed.get('results', [])
                
                if customers:
                    customer_examples = "\n**Recent Customers:**\n"
                    for i, customer in enumerate(customers[:3], 1):
                        customer_id = customer.get('xcus', 'Unknown')
                        email = customer.get('xemail', 'No email')
                        name = f"{customer.get('xfirst', '')} {customer.get('xlast', '')}".strip() or 'No name'
                        customer_examples += f"{i}. {customer_id} - {name} ({email})\n"
            except Exception:
                pass
        
        prompt = f"""Which customer would you like to update?

Please specify the customer by:
• **Customer ID**: e.g., "CUS-000123"
• **Reference**: e.g., "last customer", "most recent customer"
• **Email**: e.g., "customer with email john@example.com"
• **Name**: e.g., "customer named John Smith"
{customer_examples}
💡 **Examples:**
• "Update customer CUS-000115"
• "Update the last customer"
• "Update customer with email john@example.com"""
        
        return prompt
        
    except Exception as e:
        logger.error(f"[CustomerSelectionPrompt] Error: {e}")
        return "Which customer would you like to update? Please provide a customer ID (CUS-XXXXXX) or say 'last customer' for the most recent one."

async def _fetch_customer_for_field_selection(context):
    """Fetch customer data to show current values for field selection."""
    try:
        # Build SELECT query based on identification type
        if 'CUS-' in context.message:
            customer_id = re.search(r'CUS-\d{6}', context.message).group()
            sql = f"SELECT * FROM cacus WHERE zid = {context.business_id} AND xcus = '{customer_id}'"
        elif any(ref in context.message.lower() for ref in ['last', 'recent', 'latest']):
            sql = f"SELECT * FROM cacus WHERE zid = {context.business_id} ORDER BY xcus DESC LIMIT 1"
        else:
            # Try to find by email or name patterns
            sql = f"SELECT * FROM cacus WHERE zid = {context.business_id} ORDER BY xcus DESC LIMIT 1"
        
        result = await mcp_client.execute_query(sql, context.business_id)
        
        if isinstance(result, dict) and 'content' in result:
            parsed = json.loads(result['content'][0]['text'])
            customers = parsed.get('results', [])
            return customers[0] if customers else None
        
        return None
        
    except Exception as e:
        logger.error(f"[FetchCustomer] Error: {e}")
        return None

async def _generate_field_selection_prompt(context, field_clarity, customer_data):
    """Generate field selection prompt showing current values."""
    try:
        if not customer_data:
            return "I couldn't find the customer. Please specify which customer you want to update first."
        
        customer_id = customer_data.get('xcus', 'Unknown')
        
        # Show current field values
        current_values = f"""**Current values for customer {customer_id}:**

• **Email**: {customer_data.get('xemail', 'Not set')}
• **Phone**: {customer_data.get('xphone', 'Not set')}
• **First Name**: {customer_data.get('xfirst', 'Not set')}
• **Last Name**: {customer_data.get('xlast', 'Not set')}
• **Organization**: {customer_data.get('xorg', 'Not set')}
• **Customer Group**: {customer_data.get('xgcus', 'Not set')}
• **Tax Scope**: {customer_data.get('xtax_scope', 'Not set')}

Which field(s) would you like to update? Please specify:

💡 **Examples:**
• "Update email to john@newemail.com"
• "Change phone to 1234567890"
• "Update first name to John and last name to Smith"
• "Change organization to NewCompany Inc"""
        
        return current_values
        
    except Exception as e:
        logger.error(f"[FieldSelectionPrompt] Error: {e}")
        return "Which field would you like to update? Please specify the field name and new value."

async def _extract_updateable_fields_from_schema(schema_context):
    """Extract updateable field names from schema context."""
    try:
        # Common customer fields that can be updated
        updateable_fields = [
            'xemail', 'xphone', 'xfirst', 'xlast', 'xorg', 
            'xgcus', 'xtax_scope', 'xaddress', 'xcity', 'xstate'
        ]
        
        # If schema context available, extract actual field names
        if schema_context:
            # Simple extraction - look for field patterns
            import re
            field_matches = re.findall(r'\b(x\w+)\b', schema_context)
            if field_matches:
                updateable_fields.extend(field_matches)
        
        return list(set(updateable_fields))  # Remove duplicates
        
    except Exception as e:
        logger.error(f"[ExtractFields] Error: {e}")
        return ['xemail', 'xphone', 'xfirst', 'xlast', 'xorg']

async def _build_dynamic_update_sql_prompt(context):
    """Build dynamic UPDATE SQL prompt using context and conversation history."""
    schema_context = context.schema_context or ""
    
    # Build conversation context
    conversation_context = ""
    if context.conversation_history:
        recent_messages = context.conversation_history[-6:]
        conversation_context = "\n".join([
            f"{msg.role}: {msg.content}" for msg in recent_messages
        ])
    
    # Include customer selection context if available
    customer_context = ""
    if hasattr(context, 'selected_customer_data') and context.selected_customer_data:
        customer_context = f"\nSelected Customer Data: {context.selected_customer_data}"
    
    sql_prompt = f"""
You are a SQL expert generating UPDATE queries for customer data modification.

Customer Table Schema and Context:
{schema_context}

Business ID (zid): {context.business_id} (ALWAYS include in WHERE clause as integer)

Recent Conversation:
{conversation_context}
{customer_context}

Generate a precise SQL UPDATE query based on the user's request.

Rules:
1. ALWAYS include WHERE zid = {context.business_id} AND xcus = 'CUSTOMER_ID' (zid as integer)
2. Use appropriate column names from the schema
3. Handle multiple field updates in single query when possible
4. Ensure proper data types and formatting
5. Never update xcus (customer ID) or zid (business ID)

Examples:
- "update email to john@new.com for CUS-000123" → UPDATE cacus SET xemail = 'john@new.com' WHERE zid = {context.business_id} AND xcus = 'CUS-000123';
- "change phone to 1234567890 for last customer" → UPDATE cacus SET xphone = '1234567890' WHERE zid = {context.business_id} AND xcus = (SELECT xcus FROM cacus WHERE zid = {context.business_id} ORDER BY xcus DESC LIMIT 1);
- "update name to John Smith for CUS-000123" → UPDATE cacus SET xfirst = 'John', xlast = 'Smith' WHERE zid = {context.business_id} AND xcus = 'CUS-000123';

Return only the SQL query, no explanations.
"""
    
    return sql_prompt

async def validate_customer_exists_node(context):
    """Validate that the customer exists and show current field values for update operations."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    logger.info(f"[CustomerUpdateValidation] Validating customer exists for: {context.sql}")
    
    try:
        # Extract customer identifier from UPDATE SQL
        customer_id = None
        
        # Try to extract xcus (customer ID) from WHERE clause
        xcus_match = re.search(r"xcus\s*=\s*['\"]([^'\"]+)['\"]", context.sql, re.IGNORECASE)
        if xcus_match:
            customer_id = xcus_match.group(1)
        
        if not customer_id:
            # Try to extract from other patterns
            id_patterns = [
                r"WHERE.*['\"]([A-Z]{3}-\d{6})['\"]",  # General CUS-XXXXXX pattern
                r"customer.*id.*['\"]([A-Z]{3}-\d{6})['\"]"  # Customer ID mentions
            ]
            
            for pattern in id_patterns:
                match = re.search(pattern, context.sql, re.IGNORECASE)
                if match:
                    customer_id = match.group(1)
                    break
        
        if customer_id:
            # Verify customer exists and get current field values
            check_sql = f"SELECT * FROM cacus WHERE zid = {context.business_id} AND xcus = '{customer_id}'"
            result = await mcp_client.execute_query(check_sql, context.business_id)
            
            if isinstance(result, dict) and 'content' in result:
                try:
                    parsed = json.loads(result['content'][0]['text'])
                    customers = parsed.get('results', [])
                    
                    if customers:
                        # Customer exists, store details and show current field values
                        context.customer_details = customers[0]
                        
                        # Show current field values and ask which fields to update
                        await _show_current_field_values_and_ask_for_updates(context)
                        return context.model_dump()
                    else:
                        context.response = f"Customer with ID '{customer_id}' not found. Please check the customer ID and try again."
                        context.next = "CustomerResponse"
                        return context.model_dump()
                        
                except (json.JSONDecodeError, KeyError, IndexError) as e:
                    logger.error(f"[CustomerUpdateValidation] Error parsing validation result: {e}")
            
        # If we can't find a specific customer ID, try to execute a SELECT version to see what would be affected
        select_sql = context.sql.replace("UPDATE", "SELECT *\nFROM", 1)
        select_sql = re.sub(r'\s+SET\s+.*?(?=WHERE|$)', '', select_sql, flags=re.IGNORECASE | re.DOTALL)
        
        result = await mcp_client.execute_query(select_sql, context.business_id)
        
        if isinstance(result, dict) and 'content' in result:
            try:
                parsed = json.loads(result['content'][0]['text'])
                customers = parsed.get('results', [])
                
                if customers:
                    if len(customers) == 1:
                        # Single customer found
                        context.customer_details = customers[0]
                        await _show_current_field_values_and_ask_for_updates(context)
                        logger.info(f"[CustomerUpdateValidation] Single customer found for update")
                        return context.model_dump()
                    else:
                        # Multiple customers would be affected
                        # Store list and ask whether to update all or choose one
                        context.customers_for_update = customers
                        preview_list = []
                        for i, cust in enumerate(customers[:5], 1):
                            cid = cust.get('xcus', 'Unknown')
                            email = cust.get('xemail', 'No email')
                            preview_list.append(f"{i}. {cid} ({email})")
                        more_text = f"\n... and {len(customers)-5} more" if len(customers) > 5 else ""
                        preview_text = "\n".join(preview_list) + more_text
                        context.response = (
                            f"This would affect {len(customers)} customers:\n{preview_text}\n\n"
                            f"Reply with a specific Customer ID (e.g., CUS-000123), pick a number (1-{min(len(customers),5)}), "
                            f"or say 'update all'."
                        )
                        context.pause_reason = "customer_selection_needed"
                        context.next = "PauseNode"
                        return context.model_dump()
                else:
                    context.response = "No customers found matching your update criteria. Please check your request and try again."
                    context.next = "CustomerResponse"
                    return context.model_dump()
                    
            except (json.JSONDecodeError, KeyError, IndexError) as e:
                logger.error(f"[CustomerUpdateValidation] Error parsing result: {e}")
        
        # Fallback if validation fails
        context.response = "Unable to validate customer for update. Please provide a specific customer ID or more details."
        context.next = "CustomerResponse"
        return context.model_dump()
        
    except Exception as e:
        logger.error(f"[CustomerUpdateValidation] Error: {e}")
        context.response = f"Error validating customer for update: {str(e)}"
        context.next = "CustomerResponse"
        return context.model_dump()

async def _show_current_field_values_and_ask_for_updates(context):
    """Show current field values and ask which fields to update."""
    try:
        customer = context.customer_details
        customer_id = customer.get('xcus', 'Unknown')
        
        # Get field definitions from schema context
        field_descriptions = {}
        if hasattr(context, 'schema_context') and context.schema_context:
            for schema in context.schema_context:
                if 'customer' in schema.get('table_name', '').lower():
                    for col in schema.get('columns', []):
                        field_descriptions[col.get('name', '')] = col.get('description', '')
        
        # Show ALL current field values including NULLs
        field_display = []
        important_fields = ['xcus', 'xemail', 'xphone', 'xorg', 'xgcus', 'xtaxscope', 'xfirst', 'xlast', 'xaddress', 'xcity', 'xstate', 'xzip', 'xcountry']
        
        for field in important_fields:
            if field in customer:
                value = customer[field]
                display_value = value if value is not None and str(value).strip() else "**NULL**"
                field_desc = field_descriptions.get(field, field)
                field_display.append(f"• **{field_desc}** ({field}): {display_value}")
        
        # Add all other fields that exist in the customer record
        for field, value in customer.items():
            if field not in important_fields:
                display_value = value if value is not None and str(value).strip() else "**NULL**"
                field_desc = field_descriptions.get(field, field)
                field_display.append(f"• **{field_desc}** ({field}): {display_value}")
        
        current_values = "\n".join(field_display)
        
        # Ask which fields to update with comprehensive guidance
        context.response = f"""**📋 Current Field Values for Customer {customer_id}:**

{current_values}

**🔧 Which fields would you like to update?**

**You can update any of the fields above. Please specify:**
• Field name and new value
• Multiple fields at once
• Use the field names shown in parentheses

**📝 Examples:**
• "Update email to john@newemail.com"
• "Change phone to +1234567890 and organization to New Company Inc"
• "Set first name to John, last name to Doe, and address to 123 Main St"
• "Update xgcus to VIP and xtaxscope to Business"

**💡 Tips:**
• Use the field names in parentheses for exact matching
• You can update multiple fields in one message
• Leave fields unchanged by not mentioning them
• Use 'NULL' or 'empty' to clear a field value

**Which fields would you like to update?**"""
        
        context.pause_reason = "field_selection_needed"
        context.next = "PauseNode"
        
    except Exception as e:
        logger.error(f"[CustomerUpdateValidation] Error showing field values: {e}")
        context.response = "Customer found. What would you like to update?"
        context.pause_reason = "field_selection_needed"
        context.next = "PauseNode"

async def confirm_update_operation_node(context):
    """Confirm UPDATE operations with customer details."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    logger.info("[CustomerUpdateConfirm] Preparing confirmation")
    
    try:
        if hasattr(context, 'customer_details') and context.customer_details:
            customer = context.customer_details
            
            # Format customer details for confirmation
            customer_info = []
            field_mapping = {
                'xcus': 'Customer ID',
                'xemail': 'Email',
                'xphone': 'Phone',
                'xgcus': 'Customer Group',
                'xorg': 'Organization'
            }
            
            for field, label in field_mapping.items():
                if field in customer and customer[field]:
                    customer_info.append(f"• {label}: {customer[field]}")
            
            customer_display = "\n".join(customer_info) if customer_info else "Customer details available"
            
            # Extract what will be updated from SQL
            update_info = "the specified fields"
            set_match = re.search(r'SET\s+(.*?)(?:\s+WHERE|$)', context.sql, re.IGNORECASE | re.DOTALL)
            if set_match:
                update_info = set_match.group(1).strip()
            
            context.pause_message = (
                f"**Confirm Customer Update**\n\n"
                f"**Customer to Update:**\n{customer_display}\n\n"
                f"**Changes:** {update_info}\n\n"
                f"Do you want to proceed with this update? (yes/no)"
            )
            
            context.pause_reason = "confirm_update"
            context.next = "PauseNode"
        else:
            # No customer details available, proceed with update
            context.next = "ExecuteUpdateSQL"
            
    except Exception as e:
        logger.error(f"[CustomerUpdateConfirm] Error: {e}")
        context.next = "ExecuteUpdateSQL"
    
    return context.model_dump()

async def execute_update_sql_node(context):
    """Execute customer UPDATE SQL operations via MCP."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    logger.info(f"[CustomerUpdateSQL] Executing: {context.sql}")
    
    try:
        # Execute SQL via MCP
        result = await mcp_client.execute_query(context.sql, context.business_id)
        
        if isinstance(result, dict) and 'content' in result:
            try:
                # Parse MCP response
                parsed = json.loads(result['content'][0]['text'])
                
                if parsed.get('success'):
                    affected_rows = parsed.get('affected_rows', 0)
                    
                    if affected_rows > 0:
                        # Try to fetch updated customer details
                        if hasattr(context, 'customer_details') and context.customer_details:
                            customer_id = context.customer_details.get('xcus')
                            if customer_id:
                                fetch_sql = f"SELECT * FROM cacus WHERE zid = {context.business_id} AND xcus = '{customer_id}'"
                                fetch_result = await mcp_client.execute_query(fetch_sql, context.business_id)
                                
                                if isinstance(fetch_result, dict) and 'content' in fetch_result:
                                    try:
                                        parsed_fetch = json.loads(fetch_result['content'][0]['text'])
                                        customer_data = parsed_fetch.get('results', [])
                                        
                                        if customer_data:
                                            customer_details = format_customer_result(customer_data)
                                            context.response = f"✅ Customer has been successfully updated!\n\n{customer_details}"
                                        else:
                                            context.response = f"✅ Customer has been successfully updated! ({affected_rows} record(s) affected)"
                                    except Exception as format_error:
                                        logger.error(f"[CustomerUpdateSQL] Error formatting updated customer: {format_error}")
                                        context.response = f"✅ Customer has been successfully updated! ({affected_rows} record(s) affected)"
                                else:
                                    context.response = f"✅ Customer has been successfully updated! ({affected_rows} record(s) affected)"
                            else:
                                context.response = f"✅ Customer has been successfully updated! ({affected_rows} record(s) affected)"
                        else:
                            context.response = f"✅ Customer has been successfully updated! ({affected_rows} record(s) affected)"
                    else:
                        context.response = "No customers were updated. Please check your criteria and try again."
                else:
                    error_msg = parsed.get('error', 'Unknown error occurred')
                    context.response = f"Failed to update customer: {error_msg}"
                    
            except (json.JSONDecodeError, KeyError, IndexError) as e:
                logger.error(f"[CustomerUpdateSQL] Error parsing result: {e}")
                context.response = "Customer update completed but I had trouble confirming the details."
        else:
            context.response = "Customer update request was processed."
            
    except Exception as e:
        logger.error(f"[CustomerUpdateSQL] Execution error: {e}")
        context.response = f"I encountered an error while updating the customer: {str(e)}"
    
    context.next = "CustomerResponse"
    return context.model_dump()

async def customer_selection_for_update_node(context):
    """Handle customer selection phase specifically for UPDATE operations with SELECT-for-UPDATE intent detection."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    logger.info(f"[CustomerSelectionForUpdate] Processing customer selection: {context.message}")
    
    try:
        # Detect if this is a SELECT-for-UPDATE vs standalone SELECT
        intent_analysis = await _analyze_select_intent_for_update(context)
        
        if intent_analysis['intent'] == 'STANDALONE_SELECT':
            # This is a standalone SELECT query, not customer selection for UPDATE
            logger.info("[CustomerSelectionForUpdate] Detected standalone SELECT, routing to VectorSearch")
            context.next = "VectorSearch"
            context.current_flow = "select"  # Switch to SELECT flow
            return context.model_dump()
        
        # Check for negative intent or cancellation
        negative_intent = await _detect_negative_intent_during_update(context)
        if negative_intent:
            logger.info("[CustomerSelectionForUpdate] Negative intent detected, cancelling UPDATE flow")
            context.response = "UPDATE operation cancelled. How else can I help you?"
            context.next = "CustomerResponse"
            context.current_flow = None
            context.pause_reason = None
            return context.model_dump()
        
        # Process customer selection for UPDATE
        selected_customer = await _process_customer_selection_for_update(context)
        
        if selected_customer:
            # Customer selected, store details and move to field selection
            context.customer_details = selected_customer
            context.pause_reason = "field_selection_needed"
            context.next = "FieldSelectionForUpdate"
            return context.model_dump()
        else:
            # Need more clarification
            context.response = await _generate_customer_selection_questions(context)
            context.pause_reason = "customer_selection_needed"
            context.next = "PauseNode"
            return context.model_dump()
            
    except Exception as e:
        logger.error(f"[CustomerSelectionForUpdate] Error: {e}")
        context.response = "I had trouble processing your customer selection. Please try again."
        context.pause_reason = "customer_selection_needed"
        context.next = "PauseNode"
        return context.model_dump()

async def field_selection_for_update_node(context):
    """Show current field values and collect field updates with enhanced guidance."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    logger.info(f"[FieldSelectionForUpdate] Processing field selection for customer: {context.customer_details.get('xcus', 'Unknown')}")
    
    try:
        # Check for negative intent or cancellation
        negative_intent = await _detect_negative_intent_during_update(context)
        if negative_intent:
            logger.info("[FieldSelectionForUpdate] Negative intent detected, cancelling UPDATE flow")
            context.response = "UPDATE operation cancelled. How else can I help you?"
            context.next = "CustomerResponse"
            context.current_flow = None
            context.pause_reason = None
            return context.model_dump()
        
        # Show current field values and ask for updates
        await _show_current_field_values_and_ask_for_updates(context)
        return context.model_dump()
        
    except Exception as e:
        logger.error(f"[FieldSelectionForUpdate] Error: {e}")
        context.response = "I had trouble showing the field values. Please try again."
        context.pause_reason = "field_selection_needed"
        context.next = "PauseNode"
        return context.model_dump()

async def _analyze_select_intent_for_update(context):
    """Analyze if a SELECT query during UPDATE flow is standalone or for customer selection."""
    try:
        # Check conversation context and user query to determine intent
        conversation_context = ""
        if hasattr(context, 'conversation_history') and context.conversation_history:
            # Get last few messages for context
            recent_messages = context.conversation_history[-6:] if len(context.conversation_history) > 6 else context.conversation_history
            for msg in recent_messages:
                if hasattr(msg, 'content'):
                    conversation_context += f"{msg.role}: {msg.content}\n"
                elif isinstance(msg, dict):
                    conversation_context += f"{msg.get('role', 'user')}: {msg.get('content', '')}\n"
        
        # Use LLM to analyze intent
        analysis_prompt = f"""
Analyze the user's query in the context of an ongoing UPDATE operation to determine intent:

CONVERSATION CONTEXT:
{conversation_context}

CURRENT USER QUERY: {context.message}

CURRENT STATE: User is in UPDATE flow and needs to select a customer to update.

Determine if this query is:
1. CUSTOMER_SELECTION: User is selecting/identifying a customer for the UPDATE operation
2. STANDALONE_SELECT: User wants to perform a separate SELECT query (show customers, search, etc.)

Consider:
- Is the user responding to "which customer to update?" 
- Are they providing customer identification (ID, email, name, etc.)?
- Or are they asking to see/show/find customers as a separate action?

Respond with JSON: {{"intent": "CUSTOMER_SELECTION" or "STANDALONE_SELECT", "confidence": 0.0-1.0, "reasoning": "explanation"}}
"""
        
        response = await llm_service.chat([
            {"role": "system", "content": analysis_prompt},
            {"role": "user", "content": context.message}
        ])
        
        # Parse response
        import json
        try:
            analysis = json.loads(response)
            return analysis
        except:
            # Fallback analysis
            message_lower = context.message.lower()
            select_keywords = ['show', 'list', 'find', 'search', 'get', 'display', 'all customers']
            selection_keywords = ['update', 'customer id', 'cus-', 'email', 'phone', 'this one', 'that one', 'number']
            
            if any(keyword in message_lower for keyword in select_keywords):
                return {"intent": "STANDALONE_SELECT", "confidence": 0.7, "reasoning": "Contains SELECT keywords"}
            elif any(keyword in message_lower for keyword in selection_keywords):
                return {"intent": "CUSTOMER_SELECTION", "confidence": 0.7, "reasoning": "Contains selection keywords"}
            else:
                return {"intent": "CUSTOMER_SELECTION", "confidence": 0.5, "reasoning": "Default to customer selection"}
                
    except Exception as e:
        logger.error(f"[UpdateFlow] Error analyzing SELECT intent: {e}")
        return {"intent": "CUSTOMER_SELECTION", "confidence": 0.5, "reasoning": "Error fallback"}

async def _detect_negative_intent_during_update(context):
    """Detect negative intent or cancellation requests during UPDATE flow."""
    try:
        message_lower = context.message.lower().strip()
        
        # Direct cancellation keywords
        cancel_keywords = [
            'cancel', 'stop', 'quit', 'exit', 'abort', 'never mind', 'nevermind',
            'forget it', 'no thanks', 'not now', 'maybe later'
        ]
        
        if any(keyword in message_lower for keyword in cancel_keywords):
            return True
        
        # Check for different operation requests (INSERT/DELETE)
        operation_switches = [
            'add customer', 'create customer', 'new customer', 'insert customer',
            'delete customer', 'remove customer', 'drop customer'
        ]
        
        if any(op in message_lower for op in operation_switches):
            return True
            
        return False
        
    except Exception as e:
        logger.error(f"[UpdateFlow] Error detecting negative intent: {e}")
        return False

async def _process_customer_selection_for_update(context):
    """Process customer selection and return customer details if found."""
    try:
        message = context.message.strip()
        
        # Try to extract customer ID
        customer_id_match = re.search(r'CUS-\d{6}', message, re.IGNORECASE)
        if customer_id_match:
            customer_id = customer_id_match.group(0).upper()
            return await _fetch_customer_by_id(context, customer_id)
        
        # Try to extract number selection (1, 2, 3, etc.)
        number_match = re.search(r'\b(\d{1,2})\b', message)
        if number_match and hasattr(context, 'customers_for_update') and context.customers_for_update:
            try:
                index = int(number_match.group(1)) - 1
                if 0 <= index < len(context.customers_for_update):
                    return context.customers_for_update[index]
            except (ValueError, IndexError):
                pass
        
        # Try to search by email, phone, or name
        if '@' in message:
            # Email search
            email = re.search(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', message)
            if email:
                return await _fetch_customer_by_field(context, 'xemail', email.group(0))
        
        # Phone search
        phone_match = re.search(r'[\d\-\+\(\)\s]{10,}', message)
        if phone_match:
            phone = re.sub(r'[^\d]', '', phone_match.group(0))
            if len(phone) >= 10:
                return await _fetch_customer_by_field(context, 'xphone', phone)
        
        # Name or organization search
        search_terms = message.lower()
        if any(word in search_terms for word in ['customer', 'named', 'called', 'from']):
            # Extract potential name or org
            name_match = re.search(r'(?:named|called|from)\s+([A-Za-z\s]+)', message, re.IGNORECASE)
            if name_match:
                search_term = name_match.group(1).strip()
                # Try organization first, then name
                customer = await _fetch_customer_by_field(context, 'xorg', search_term)
                if not customer:
                    customer = await _fetch_customer_by_field(context, 'xfirst', search_term.split()[0])
                return customer
        
        return None
        
    except Exception as e:
        logger.error(f"[UpdateFlow] Error processing customer selection: {e}")
        return None

async def _fetch_customer_by_id(context, customer_id):
    """Fetch customer by ID."""
    try:
        sql = f"SELECT * FROM cacus WHERE zid = {context.business_id} AND xcus = '{customer_id}'"
        result = await mcp_client.execute_query(sql, context.business_id)
        
        if isinstance(result, dict) and 'content' in result:
            parsed = json.loads(result['content'][0]['text'])
            customers = parsed.get('results', [])
            return customers[0] if customers else None
            
    except Exception as e:
        logger.error(f"[UpdateFlow] Error fetching customer by ID: {e}")
        return None

async def _fetch_customer_by_field(context, field, value):
    """Fetch customer by field value."""
    try:
        sql = f"SELECT * FROM cacus WHERE zid = {context.business_id} AND {field} LIKE '%{value}%' LIMIT 5"
        result = await mcp_client.execute_query(sql, context.business_id)
        
        if isinstance(result, dict) and 'content' in result:
            parsed = json.loads(result['content'][0]['text'])
            customers = parsed.get('results', [])
            
            if len(customers) == 1:
                return customers[0]
            elif len(customers) > 1:
                # Store multiple matches for user selection
                context.customers_for_update = customers
                return None  # Need user to select from multiple
            
    except Exception as e:
        logger.error(f"[UpdateFlow] Error fetching customer by field: {e}")
        return None

async def handle_field_selection_response_node(context):
    """Parse user's field selection message, map to real columns using schema context, and build UPDATE SQL SET clause."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)

    logger.info(f"[CustomerUpdateFieldSelection] Processing field selection: {context.message}")

    try:
        if not hasattr(context, 'customer_details') or not context.customer_details:
            context.response = "I need to know which customer to update first. Please provide the customer ID."
            context.pause_reason = "customer_selection_needed"
            context.next = "PauseNode"
            return context.model_dump()

        # Build a mapping of friendly names -> actual column names from schema
        friendly_to_column = {}
        if hasattr(context, 'schema_context') and context.schema_context:
            for schema in context.schema_context:
                if 'customer' in schema.get('table_name', '').lower() or 'cacus' in schema.get('table_name', '').lower():
                    for col in schema.get('columns', []):
                        col_name = col.get('name', '')
                        desc = (col.get('description') or '').strip()
                        # Populate simple heuristics
                        friendly_to_column[col_name.lower()] = col_name
                        if desc:
                            friendly_to_column[desc.lower()] = col_name
                        # Common aliases
                        aliases = {
                            'email': 'xemail', 'mail': 'xemail',
                            'phone': 'xphone', 'mobile': 'xmobile',
                            'organization': 'xorg', 'org': 'xorg', 'company': 'xorg',
                            'customer type': 'xgcus', 'type': 'xgcus',
                            'tax scope': 'xtaxscope', 'tax': 'xtaxscope',
                            'first name': 'xfirst', 'last name': 'xlast',
                            'address': 'xaddress', 'city': 'xcity', 'state': 'xstate', 'country': 'xcountry', 'zip': 'xzip'
                        }
                        for k, v in aliases.items():
                            friendly_to_column.setdefault(k, v)

        user_text = context.message.strip()

        # Extract pairs like "email to john@x.com" or "phone = 0123"; support multiple joined by 'and' or ','
        parts = re.split(r"\band\b|,", user_text, flags=re.IGNORECASE)
        updates = []
        unmapped = []

        for part in parts:
            m = re.search(r"([a-zA-Z_\s]+)\s*(?:to|=)\s*([^,]+)$", part.strip())
            if not m:
                continue
            field_label = m.group(1).strip().lower()
            value_raw = m.group(2).strip().strip("'\"")

            # Map to column
            column = friendly_to_column.get(field_label)
            if not column and field_label.startswith('x'):
                column = field_label  # assume already technical

            if not column:
                unmapped.append(field_label)
                continue

            # Quote strings except numeric-only for known integer columns like xphone
            if column in ['xphone'] and re.fullmatch(r"\d+", value_raw):
                value_sql = value_raw
            else:
                value_sql = f"'{value_raw}'"
            updates.append(f"{column} = {value_sql}")

        if not updates:
            # Ask again with guidance
            hint = "; ".join(["email to john@company.com", "phone to 01234567890", "organization to TechCorp"])
            context.response = (
                "I couldn't understand which fields to update. Please specify like: " + hint
            )
            context.pause_reason = "field_selection_needed"
            context.next = "PauseNode"
            return context.model_dump()

        if unmapped:
            context.response = (
                "These fields weren't recognized: " + ", ".join(unmapped) + ". Please use names like email, phone, organization, customer type."
            )
            context.pause_reason = "field_selection_needed"
            context.next = "PauseNode"
            return context.model_dump()

        # Determine target customers: single customer or update-all scenario
        target_ids = []
        if hasattr(context, 'customers_for_update') and context.customers_for_update:
            # If user said 'update all' earlier, we expect a flag; otherwise assume single selection flow
            message_lower = context.message.lower()
            if 'update all' in message_lower or 'all' == message_lower.strip():
                target_ids = [c.get('xcus') for c in context.customers_for_update if c.get('xcus')]
            else:
                # Try to parse a number selection (1..N)
                pick = re.search(r"\b(\d{1,3})\b", message_lower)
                if pick:
                    idx = int(pick.group(1)) - 1
                    if 0 <= idx < len(context.customers_for_update):
                        cid = context.customers_for_update[idx].get('xcus')
                        if cid:
                            target_ids = [cid]

        if not target_ids:
            # Fallback to single customer from details or from SQL
            customer_id = None
            if hasattr(context, 'customer_details') and context.customer_details:
                customer_id = context.customer_details.get('xcus')
            if not customer_id and context.sql:
                xcus_match = re.search(r"xcus\s*=\s*'([^']+)'", context.sql, re.IGNORECASE)
                if xcus_match:
                    customer_id = xcus_match.group(1)
            if not customer_id:
                context.response = "I couldn't determine which customer to update. Please provide the customer ID or pick a number from the list."
                context.pause_reason = "customer_selection_needed"
                context.next = "PauseNode"
                return context.model_dump()
            target_ids = [customer_id]

        set_clause = ", ".join(updates)
        if len(target_ids) == 1:
            context.sql = f"UPDATE cacus SET {set_clause} WHERE zid = {context.business_id} AND xcus = '{target_ids[0]}'"
        else:
            in_list = ", ".join([f"'{cid}'" for cid in target_ids])
            context.sql = f"UPDATE cacus SET {set_clause} WHERE zid = {context.business_id} AND xcus IN ({in_list})"
        logger.info(f"[CustomerUpdateFieldSelection] Built SQL: {context.sql}")

        # Proceed to confirmation
        context.next = "ConfirmUpdateOperation"
        return context.model_dump()

    except Exception as e:
        logger.error(f"[CustomerUpdateFieldSelection] Error: {e}")
        context.response = "I had trouble understanding which fields to update. Please specify again."
        context.pause_reason = "field_selection_needed"
        context.next = "PauseNode"
        return context.model_dump()
