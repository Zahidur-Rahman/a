"""
OPTIMIZED UPDATE FLOW - Streamlined customer update workflow with:
- Dynamic LLM-driven decisions throughout the pipeline
- Reduced static responses with intelligent content generation
- Optimized conversation management
- Enhanced performance and maintainability
"""
from backend.app.models.chat_graph_state import ChatGraphState
from backend.app.services.mistral_llm_service import MistralLLMService
from backend.app.services.vector_search import FaissVectorSearchService
from backend.app.mcp.mcp_client import MCPClient
from backend.app.agents.customer_agent.customer_chat_helpers import (
    build_customer_sql_prompt, clean_sql_from_llm, format_customer_result,
    get_customer_schema_context_for_flow
)
import logging
import json
import re
import asyncio

logger = logging.getLogger(__name__)

# Initialize services
llm_service = MistralLLMService()
vector_search_service = FaissVectorSearchService()
mcp_client = MCPClient(script_path="backend/app/mcp/server_enhanced.py")

class PerfectUpdateFlow:
    """Optimized Update Flow with dynamic LLM-driven decisions"""
    
    def __init__(self):
        self.llm_service = llm_service
        self.vector_service = vector_search_service
        self.mcp_client = mcp_client
        self._cache = {}  # Cache for schema context and field mappings
        
    async def execute_perfect_update_flow(self, context):
        """Main entry point for the perfect update flow"""
        if isinstance(context, dict):
            context = ChatGraphState(**context)
            
        logger.info(f"[PerfectUpdateFlow] Starting perfect update flow: {context.message}")
        logger.info(f"[PerfectUpdateFlow] Current update_phase: {getattr(context, 'update_phase', None)}")
        
        # Step 1: Check for negative sentiment or intent switching
        flow_control = await self._check_flow_control(context)
        if flow_control['should_exit']:
            return self._format_response(flow_control['response'])
            
        # Step 2: Dynamic customer identification
        logger.info(f"[PerfectUpdateFlow] Starting customer identification for: {context.message}")
        customer_identification = await self._dynamic_customer_identification(context)
        logger.info(f"[PerfectUpdateFlow] Customer identification result: {customer_identification}")
        
        if customer_identification['needs_clarification']:
            return await self._handle_customer_clarification(context, customer_identification)
            
        if customer_identification['customers_found']:
            context.identified_customers = customer_identification['customers_found']
            
            # Step 3: Handle multiple customers scenario
            if len(customer_identification['customers_found']) > 1:
                return await self._handle_multiple_customers(context, customer_identification)
                
            # Step 4: Single customer - check for immediate field updates first
            context.selected_customer = customer_identification['customers_found'][0]
            context.update_phase = "field_selection"
            
            # INTELLIGENCE BOOST: Check if field update is already clear in the message
            immediate_field_update = await self._check_immediate_field_update(context)
            
            if immediate_field_update['is_clear_update']:
                logger.info(f"[PerfectUpdateFlow] IMMEDIATE FIELD UPDATE detected: {immediate_field_update}")
                # Skip field selection - go directly to update
                field_updates = {
                    'updates': immediate_field_update['field_updates'],
                    'confidence': immediate_field_update.get('confidence', 0.9)
                }
                return await self._generate_update_sql(context, field_updates)
            else:
                # Standard field selection flow
                return await self._dynamic_field_selection(context)
            
        else:
            # Generate dynamic no customers found response
            response_content = await self._generate_dynamic_response(
                context, "no_customers_found", 
                {"criteria": context.message}
            )
            context.response = response_content
            context.next = "CustomerResponse"
            return context.model_dump()
            
    async def _check_flow_control(self, context):
        """Enhanced LLM-powered flow control with context awareness"""
        try:
            # Build richer context for better LLM understanding
            conversation_context = self._build_conversation_context(context)
            
            flow_control_prompt = f"""You are an expert at understanding user intent in customer update operations.

CONVERSATION CONTEXT:
{conversation_context}

CURRENT USER MESSAGE: "{context.message}"
CURRENT OPERATION: Customer UPDATE flow

Analyze the user's message for:
1. **NEGATIVE SENTIMENT**: Wants to cancel, stop, or abort ("cancel", "stop", "nevermind", "quit")
2. **INTENT SWITCHING**: Wants to switch to different operation:
   - INSERT: "add customer", "create new customer"
   - DELETE: "delete customer", "remove customer"
   - SELECT: "show customers", "list customers" (standalone, not for update)
3. **CONTINUATION**: Providing information for current update (customer ID, field values, confirmations)

IMPORTANT: Distinguish between:
- "delete customer" (intent switch) vs "delete this field" (update operation)
- "show customers" (intent switch) vs "show me options" (clarification for update)

Respond with JSON:
{{
    "should_exit": boolean,
    "exit_reason": "negative_sentiment|intent_switch|none",
    "new_intent": "insert|delete|select|none",
    "confidence": 0.0-1.0,
    "reasoning": "clear explanation",
    "suggested_response": "appropriate response if exiting"
}}

Examples:
- "cancel this" → {{"should_exit": true, "exit_reason": "negative_sentiment"}}
- "add a customer instead" → {{"should_exit": true, "exit_reason": "intent_switch", "new_intent": "insert"}}
- "update his email" → {{"should_exit": false}} (continuing update)
- "CUS-123456" → {{"should_exit": false}} (providing customer ID)"""
            
            response = await self.llm_service.chat([
                {"role": "system", "content": "You are an intent analysis expert. Always respond with valid JSON."},
                {"role": "user", "content": flow_control_prompt}
            ])
            
            try:
                result = self._parse_json_response(response)
                logger.info(f"[PerfectUpdateFlow] Flow control analysis: {result}")
                
                if result.get('should_exit', False) and result.get('confidence', 0) > 0.7:
                    exit_reason = result.get('exit_reason', 'unknown')
                    new_intent = result.get('new_intent', 'none')
                    
                    # Clear update flow state
                    context = self._clear_update_state(context)
                    
                    # Use LLM-suggested response or generate dynamic one
                    if result.get('suggested_response'):
                        response_content = result['suggested_response']
                    else:
                        response_content = await self._generate_dynamic_response(
                            context, "flow_exit", 
                            {"exit_reason": exit_reason, "new_intent": new_intent, "reasoning": result.get('reasoning')}
                        )
                    
                    if exit_reason == 'negative_sentiment':
                        context.response = response_content
                        context.next = "CustomerResponse"
                    elif exit_reason == 'intent_switch':
                        context = await self._handle_intent_switch(context, new_intent, response_content)
                    
                    return {'should_exit': True, 'response': context.model_dump()}
                
                return {'should_exit': False}
                
            except json.JSONDecodeError as e:
                logger.error(f"[PerfectUpdateFlow] JSON parsing error: {e}, response: {response}")
                return {'should_exit': False}
                
        except Exception as e:
            logger.error(f"[PerfectUpdateFlow] Flow control error: {e}")
            return {'should_exit': False}
            
    async def _check_immediate_field_update(self, context):
        """Check if the user message contains a clear, immediate field update request"""
        try:
            # Get field information for intelligent mapping
            field_info = await self._get_cached_field_info(context.business_id)
            field_mappings = field_info.get('mappings', {})
            
            # Build intelligent field update detection prompt
            immediate_update_prompt = f"""You are an expert at detecting immediate field update requests in customer management.

USER MESSAGE: "{context.message}"
CUSTOMER: {context.selected_customer.get('xcus', 'Unknown')}
AVAILABLE FIELDS: {json.dumps(field_mappings, indent=2)}

Analyze if this message contains a CLEAR, IMMEDIATE field update request with these components:
1. **Field identification**: Which field to update (status, phone, email, etc.)
2. **New value**: What value to set
3. **Clear intent**: Unambiguous update instruction

📝 EXAMPLES OF CLEAR UPDATES:
- "change his status to Close" → CLEAR (field: status, value: Close)
- "update phone to 123456789" → CLEAR (field: phone, value: 123456789)
- "set email to new@example.com" → CLEAR (field: email, value: new@example.com)
- "make status Active" → CLEAR (field: status, value: Active)

❌ EXAMPLES NEEDING CLARIFICATION:
- "update his info" → NOT CLEAR (which field?)
- "change the phone" → NOT CLEAR (to what value?)
- "update customer" → NOT CLEAR (which field and value?)

Map user-friendly field names to database column names using the available fields mapping.

Respond with JSON:
{{
    "is_clear_update": boolean,
    "field_updates": {{"database_field": "new_value"}},
    "confidence": 0.0-1.0,
    "reasoning": "explanation of analysis",
    "user_friendly_field": "field name user mentioned",
    "database_field": "actual database column"
}}

EXAMPLE:
- "change his status to Close" → {{"is_clear_update": true, "field_updates": {{"xstatuscus": "Close"}}, "confidence": 0.95}}"""
            
            response = await self.llm_service.chat([
                {"role": "system", "content": "You are an expert field update detector. Always respond with valid JSON."},
                {"role": "user", "content": immediate_update_prompt}
            ])
            
            try:
                result = self._parse_json_response(response)
                logger.info(f"[PerfectUpdateFlow] Immediate field update analysis: {result}")
                return result
                
            except json.JSONDecodeError as e:
                logger.error(f"[PerfectUpdateFlow] JSON parsing error in immediate field update: {e}")
                return {'is_clear_update': False, 'field_updates': {}, 'confidence': 0.0}
                
        except Exception as e:
            logger.error(f"[PerfectUpdateFlow] Error in immediate field update check: {e}")
            return {'is_clear_update': False, 'field_updates': {}, 'confidence': 0.0}
            
    async def _dynamic_customer_identification(self, context):
        """Enhanced LLM-powered customer identification with conversation context"""
        try:
            logger.info(f"[PerfectUpdateFlow] Enhanced customer identification for: '{context.message}'")
            
            # Get cached schema context
            schema_context = await self._get_cached_schema_context(context.business_id)
            
            # Build comprehensive conversation context
            conversation_context = self._build_conversation_context(context)
            
            # Enhanced identification prompt with conversation awareness
            identification_prompt = f"""You are an expert at identifying customers from user messages in customer update operations.

CUSTOMER DATABASE SCHEMA:
{self._serialize_schema_context(schema_context)}

CONVERSATION CONTEXT:
{conversation_context}

CURRENT USER MESSAGE: "{context.message}"
BUSINESS ID: {context.business_id}

Analyze the message for customer identification methods:

1. **DIRECT ID**: Explicit customer ID (CUS-123456, CUS-000123)
2. **CONTEXTUAL REFERENCE**: 
   - "his", "her", "this customer", "that customer" (refer to recent conversation)
   - "the one with email", "the customer from TechCorp"
3. **POSITIONAL REFERENCE**: "last customer", "first customer", "third customer", "recent customer"
4. **FIELD-BASED SEARCH**: Email, phone, organization name, customer name
5. **VAGUE REQUEST**: "update customer" (needs clarification)

FOR CONTEXTUAL REFERENCES:
- Look at conversation history for recently mentioned customers
- Extract customer IDs, emails, names from recent assistant responses
- "his email" = update email of recently discussed customer

Generate appropriate SQL to find the customer(s). If unclear, request clarification.

Respond with JSON:
{{
    "is_clear": boolean,
    "identification_method": "direct_id|contextual|positional|field_search|vague",
    "sql_query": "SELECT query to find customers (include WHERE zid = {context.business_id})",
    "needs_clarification": boolean,
    "clarification_message": "what to ask if unclear",
    "confidence": 0.0-1.0,
    "extracted_criteria": {{"field": "value"}},
    "reasoning": "explanation of analysis"
}}

Examples:
- "update CUS-123456" → {{"is_clear": true, "sql_query": "SELECT * FROM cacus WHERE zid = {context.business_id} AND xcus = 'CUS-123456'"}}
- "update his phone" (after showing customer data) → {{"is_clear": true, "sql_query": "SELECT * FROM cacus WHERE zid = {context.business_id} AND xcus = 'RECENT_CUSTOMER_ID'"}}
- "update last customer" → {{"is_clear": true, "sql_query": "SELECT * FROM cacus WHERE zid = {context.business_id} ORDER BY xcus DESC LIMIT 1"}}
- "update john@example.com phone" → {{"is_clear": true, "sql_query": "SELECT * FROM cacus WHERE zid = {context.business_id} AND xemail = 'john@example.com'"}}
- "update customer" → {{"is_clear": false, "needs_clarification": true}}"""
            
            response = await self.llm_service.chat([
                {"role": "system", "content": "You are a customer identification expert. Always respond with valid JSON."},
                {"role": "user", "content": identification_prompt}
            ])
            
            logger.info(f"[PerfectUpdateFlow] LLM response for customer identification: {response}")
            
            try:
                analysis = self._parse_json_response(response)
                logger.info(f"[PerfectUpdateFlow] Parsed LLM analysis: {analysis}")
                
                if analysis.get('is_clear', False) and analysis.get('sql_query'):
                    # Execute the SQL query to find customers
                    sql_query = analysis['sql_query']
                    
                    # Handle contextual references by extracting actual customer IDs
                    if "RECENT_CUSTOMER_ID" in sql_query:
                        recent_customer_id = self._extract_recent_customer_id(context)
                        if recent_customer_id:
                            sql_query = sql_query.replace("RECENT_CUSTOMER_ID", recent_customer_id)
                        else:
                            return {
                                'needs_clarification': True,
                                'clarification_message': 'I need to know which specific customer you want to update. Please provide a customer ID or more details.',
                                'customers_found': []
                            }
                    
                    logger.info(f"[PerfectUpdateFlow] Executing SQL query: {sql_query}")
                    result = await self.mcp_client.execute_query(sql_query, context.business_id)
                    logger.info(f"[PerfectUpdateFlow] MCP query result: {result}")
                    
                    customers = self._extract_customers_from_result(result)
                    
                    return {
                        'needs_clarification': False,
                        'customers_found': customers,
                        'identification_method': analysis.get('identification_method', 'unknown'),
                        'sql_used': sql_query,
                        'confidence': analysis.get('confidence', 0.8)
                    }
                else:
                    return {
                        'needs_clarification': True,
                        'clarification_message': analysis.get('clarification_message', 'Please specify which customer to update'),
                        'customers_found': [],
                        'reasoning': analysis.get('reasoning', 'Analysis unclear')
                    }
                    
            except json.JSONDecodeError as e:
                logger.error(f"[PerfectUpdateFlow] JSON parsing error: {e}")
                return {
                    'needs_clarification': True,
                    'clarification_message': 'Please specify which customer you want to update (customer ID, email, or other details)',
                    'customers_found': []
                }
                
        except Exception as e:
            logger.error(f"[PerfectUpdateFlow] Customer identification error: {e}")
            return {
                'needs_clarification': True,
                'clarification_message': 'I had trouble identifying the customer. Please provide a customer ID or more details.',
                'customers_found': []
            }
            
    async def _get_cached_schema_context(self, business_id):
        """Get cached schema context or fetch and cache it"""
        cache_key = f"schema_context_{business_id}"
        if cache_key not in self._cache:
            try:
                self._cache[cache_key] = await get_customer_schema_context_for_flow(business_id, "update")
            except Exception as e:
                logger.error(f"[PerfectUpdateFlow] Schema context error: {e}")
                self._cache[cache_key] = []
        return self._cache[cache_key]
        
    async def _handle_customer_clarification(self, context, identification_result):
        """Handle customer clarification with dynamic examples and messaging"""
        try:
            # Get recent customers dynamically
            recent_customers = await self._get_recent_customers(context.business_id, limit=5)
            
            # Generate dynamic clarification response
            clarification_content = await self._generate_dynamic_response(
                context, "customer_clarification",
                {
                    "clarification_message": identification_result.get('clarification_message'),
                    "recent_customers": recent_customers,
                    "business_context": await self._get_business_context(context.business_id)
                }
            )
            
            context.response = clarification_content
            context.pause_reason = "customer_identification_needed"
            context.update_phase = "customer_identification"
            context.next = "PauseNode"
            return context.model_dump()
            
        except Exception as e:
            logger.error(f"[PerfectUpdateFlow] Clarification error: {e}")
            # Fallback to simple clarification
            context.response = await self._generate_dynamic_response(
                context, "simple_clarification", {}
            )
            context.pause_reason = "customer_identification_needed"
            context.next = "PauseNode"
            return context.model_dump()
            
    async def _handle_multiple_customers(self, context, identification_result):
        """Handle multiple customers found scenario with dynamic response"""
        try:
            customers = identification_result['customers_found']
            
            # Generate dynamic multiple customers response
            multiple_customers_content = await self._generate_dynamic_response(
                context, "multiple_customers_found",
                {
                    "customers": customers,
                    "customer_count": len(customers),
                    "identification_method": identification_result.get('identification_method')
                }
            )
            
            context.response = multiple_customers_content
            context.multiple_customers_found = customers
            context.pause_reason = "multiple_customers_selection"
            context.update_phase = "multiple_customers_handling"
            context.next = "PauseNode"
            return context.model_dump()
            
        except Exception as e:
            logger.error(f"[PerfectUpdateFlow] Multiple customers error: {e}")
            fallback_content = await self._generate_dynamic_response(
                context, "multiple_customers_error", 
                {"customer_count": len(customers)}
            )
            context.response = fallback_content
            context.next = "CustomerResponse"
            return context.model_dump()

    async def _process_multiple_customer_selection(self, context):
        """Process user selection from multiple customers with intelligent understanding"""
        try:
            # Use LLM to understand user intent dynamically
            intent_analysis = await self._analyze_selection_intent_with_llm(context)
            
            if intent_analysis['action'] == 'bulk_update':
                # Generate dynamic bulk update initiation response
                context.update_phase = "bulk_field_selection"
                context.response = await self._generate_dynamic_response(
                    context, "bulk_update_initiation",
                    {"customer_count": len(context.multiple_customers_found)}
                )
                context.pause_reason = "field_selection_needed"
                context.next = "PauseNode"
                return context.model_dump()
            
            elif intent_analysis['action'] == 'select_specific':
                # User selected specific customer
                customer_index = intent_analysis.get('customer_index', 0)
                if 0 <= customer_index < len(context.multiple_customers_found):
                    context.selected_customer = context.multiple_customers_found[customer_index]
                    context.update_phase = "field_selection"
                    
                    # Generate dynamic single customer selection response
                    context.response = await self._generate_dynamic_response(
                        context, "single_customer_selected",
                        {"customer": context.selected_customer}
                    )
                    context.pause_reason = "field_selection_needed"
                    context.next = "PauseNode"
                    return context.model_dump()
            
            # Generate dynamic clarification for unclear selections
            context.response = await self._generate_dynamic_response(
                context, "unclear_customer_selection",
                {"customers": context.multiple_customers_found}
            )
            context.pause_reason = "multiple_customers_selection"
            context.next = "PauseNode"
            return context.model_dump()
            
        except Exception as e:
            logger.error(f"[PerfectUpdateFlow] Multiple customer selection error: {e}")
            context.response = await self._generate_dynamic_response(
                context, "selection_error", {}
            )
            context.next = "CustomerResponse"
            return context.model_dump()
            
    async def _dynamic_field_selection(self, context):
        """Dynamic field selection with intelligent field descriptions"""
        try:
            customer = context.selected_customer
            customer_id = customer.get('xcus', 'Unknown')
            
            # Get cached field descriptions and mappings
            field_info = await self._get_cached_field_info(context.business_id)
            
            # Generate dynamic field selection response
            field_selection_content = await self._generate_dynamic_response(
                context, "field_selection_display",
                {
                    "customer": customer,
                    "customer_id": customer_id,
                    "field_info": field_info,
                    "business_context": await self._get_business_context(context.business_id)
                }
            )
            
            context.response = field_selection_content
            context.customer_field_descriptions = field_info['descriptions']
            context.pause_reason = "field_selection_needed"
            context.update_phase = "field_selection"
            context.next = "PauseNode"
            return context.model_dump()
            
        except Exception as e:
            logger.error(f"[PerfectUpdateFlow] Field selection error: {e}")
            # Generate fallback response
            fallback_content = await self._generate_dynamic_response(
                context, "field_selection_fallback",
                {"customer_id": context.selected_customer.get('xcus', 'Unknown')}
            )
            context.response = fallback_content
            context.pause_reason = "field_selection_needed"
            context.next = "PauseNode"
            return context.model_dump()
            
    async def _get_cached_field_info(self, business_id):
        """Get cached field information or generate and cache it"""
        cache_key = f"field_info_{business_id}"
        if cache_key not in self._cache:
            try:
                schema_context = await self._get_cached_schema_context(business_id)
                field_descriptions = await self._extract_field_descriptions(schema_context)
                field_mappings = await self._generate_user_friendly_field_names(field_descriptions)
                
                self._cache[cache_key] = {
                    'descriptions': field_descriptions,
                    'mappings': field_mappings
                }
            except Exception as e:
                logger.error(f"[PerfectUpdateFlow] Field info generation error: {e}")
                self._cache[cache_key] = {'descriptions': {}, 'mappings': {}}
        
        return self._cache[cache_key]
        
    async def _extract_field_descriptions(self, schema_context):
        """Extract field descriptions with LLM enhancement"""
        field_descriptions = {}
        
        try:
            # Extract basic field info from schema
            for schema in schema_context:
                if 'customer' in schema.get('table_name', '').lower() or 'cacus' in schema.get('table_name', '').lower():
                    for col in schema.get('columns', []):
                        field_name = col.get('name', '')
                        description = col.get('description', '') or col.get('business_meaning', '') or field_name
                        field_type = col.get('type', 'text')
                        
                        field_descriptions[field_name] = {
                            'description': description,
                            'type': field_type,
                            'business_meaning': col.get('business_meaning', '')
                        }
            
            # Enhance descriptions using LLM if needed
            if field_descriptions:
                enhanced_descriptions = await self._enhance_field_descriptions(field_descriptions)
                field_descriptions.update(enhanced_descriptions)
                
        except Exception as e:
            logger.error(f"[PerfectUpdateFlow] Field description extraction error: {e}")
            
        return field_descriptions
        
    async def _generate_user_friendly_field_names(self, field_descriptions):
        """Generate user-friendly field names dynamically with secure fallback"""
        try:
            # Build dynamic prompt for field name generation
            field_mapping_prompt = await self._build_dynamic_prompt(
                "field_name_mapping",
                {"field_descriptions": field_descriptions}
            )
            
            response = await self.llm_service.chat([
                {"role": "system", "content": field_mapping_prompt}
            ])
            
            try:
                field_names = self._parse_json_response(response)
                logger.info(f"[PerfectUpdateFlow] Generated field names: {field_names}")
                
                # SECURITY: Ensure we never expose raw database column names
                secure_field_names = self._apply_secure_field_mapping_fallback(field_names)
                return secure_field_names
                
            except json.JSONDecodeError as e:
                logger.error(f"[PerfectUpdateFlow] Field name generation JSON error: {e}")
                # SECURE FALLBACK: Use secure mapping instead of raw descriptions
                return self._get_secure_field_mapping_fallback(field_descriptions)
                
        except Exception as e:
            logger.error(f"[PerfectUpdateFlow] Field name generation error: {e}")
            # SECURE FALLBACK: Never expose database column names
            return self._get_secure_field_mapping_fallback(field_descriptions)
    
    def _apply_secure_field_mapping_fallback(self, field_names):
        """Apply secure fallback for any missing or invalid field names"""
        from backend.app.agents.customer_agent.secure_customer_helpers import SecureCustomerDisplay
        secure_display = SecureCustomerDisplay()
        
        secure_names = {}
        for db_field, user_name in field_names.items():
            # If user name is None, empty, or same as database field, use secure mapping
            if not user_name or user_name == db_field or user_name.lower() == db_field.lower():
                secure_name = secure_display.secure_field_mapping.get(db_field.lower())
                if secure_name:
                    secure_names[db_field] = secure_name
                # Skip fields that don't have secure mappings
            else:
                secure_names[db_field] = user_name
        
        return secure_names
    
    def _get_secure_field_mapping_fallback(self, field_descriptions):
        """SECURE FALLBACK: Never expose database column names to users"""
        from backend.app.agents.customer_agent.secure_customer_helpers import SecureCustomerDisplay
        secure_display = SecureCustomerDisplay()
        
        secure_mapping = {}
        for db_field in field_descriptions.keys():
            secure_name = secure_display.secure_field_mapping.get(db_field.lower())
            if secure_name:
                secure_mapping[db_field] = secure_name
        
        return secure_mapping
        
    async def handle_update_response(self, context):
        """Handle user responses during the update flow based on phase and pause reason"""
        if isinstance(context, dict):
            context = ChatGraphState(**context)
            
        logger.info(f"[PerfectUpdateFlow] handle_update_response called - phase: {getattr(context, 'update_phase', None)}, pause_reason: {getattr(context, 'pause_reason', None)}")
        logger.info(f"[PerfectUpdateFlow] User message: '{context.message}'")
        
        phase = getattr(context, 'update_phase', None)
        pause_reason = getattr(context, 'pause_reason', None)
        
        # Route to appropriate handler based on phase
        handlers = {
            "customer_identification": self.execute_perfect_update_flow,
            "multiple_customers_handling": self._process_multiple_customer_selection,
            "field_selection": self.process_field_updates,
            "bulk_field_selection": self._process_bulk_field_updates,
        }
        
        if phase in handlers and pause_reason != "update_confirmation" and pause_reason != "bulk_update_confirmation":
            return await handlers[phase](context)
        elif pause_reason == "update_confirmation":
            return await self._handle_update_confirmation(context)
        elif pause_reason == "bulk_update_confirmation":
            return await self._handle_bulk_confirmation(context)
        else:
            # Default fallback
            logger.info(f"[PerfectUpdateFlow] No specific handler for phase: {phase}, pause_reason: {pause_reason}, falling back to execute_perfect_update_flow")
            return await self.execute_perfect_update_flow(context)

    async def _handle_update_confirmation(self, context):
        """Handle single update confirmation"""
        confirmation = await self._analyze_confirmation_response(context)
        if confirmation['confirmed']:
            return await self.execute_confirmed_update(context)
        else:
            context = self._clear_update_state(context)
            context.response = await self._generate_dynamic_response(
                context, "update_cancelled", {}
            )
            context.next = "CustomerResponse"
            return context.model_dump()

    async def _handle_bulk_confirmation(self, context):
        """Handle bulk update confirmation"""
        confirmation = await self._analyze_bulk_confirmation_response(context)
        if confirmation['confirmed']:
            return await self._execute_bulk_update(context)
        else:
            context = self._clear_update_state(context)
            context.response = await self._generate_dynamic_response(
                context, "bulk_update_cancelled", {}
            )
            context.next = "CustomerResponse"
            return context.model_dump()
                
    async def _analyze_confirmation_response(self, context):
        """Analyze user confirmation response using LLM"""
        try:
            confirmation_prompt = await self._build_dynamic_prompt(
                "confirmation_analysis",
                {
                    "user_message": context.message,
                    "operation_type": "single_update",
                    "context_data": getattr(context, 'selected_customer', {})
                }
            )
            
            response = await self.llm_service.chat([
                {"role": "system", "content": confirmation_prompt},
                {"role": "user", "content": context.message}
            ])
            
            try:
                result = self._parse_json_response(response)
                return {'confirmed': result.get('confirmed', False)}
            except (json.JSONDecodeError, KeyError):
                # Fallback to keyword analysis
                return self._simple_confirmation_analysis(context.message)
                
        except Exception as e:
            logger.error(f"[PerfectUpdateFlow] Confirmation analysis error: {e}")
            return {'confirmed': False}

    async def _extract_bulk_field_updates(self, context):
        """Extract field updates from user message for bulk operations using dynamic LLM"""
        try:
            # Build dynamic prompt for field extraction
            extraction_prompt = await self._build_dynamic_prompt(
                "bulk_field_extraction",
                {
                    "user_message": context.message,
                    "available_fields": await self._get_available_fields(context.business_id)
                }
            )
            
            response = await self.llm_service.chat([
                {"role": "system", "content": extraction_prompt}
            ])
            
            updates = self._parse_json_response(response)
            logger.info(f"[PerfectUpdateFlow] Extracted bulk updates: {updates}")
            return updates
            
        except Exception as e:
            logger.error(f"[PerfectUpdateFlow] Error extracting bulk field updates: {e}")
            return {}

    async def _process_bulk_field_updates(self, context):
        """Process bulk field updates with dynamic confirmation"""
        try:
            updates = await self._extract_bulk_field_updates(context)

            if not updates:
                context.response = await self._generate_dynamic_response(
                    context, "bulk_field_extraction_failed", {}
                )
                context.next = "PauseNode"
                return context.model_dump()

            context.bulk_update_data = updates
            customers_count = len(context.multiple_customers_found)

            # Generate dynamic confirmation message
            confirmation_content = await self._generate_dynamic_response(
                context, "bulk_update_confirmation",
                {
                    "updates": updates,
                    "customer_count": customers_count,
                    "customers": context.multiple_customers_found
                }
            )

            context.response = confirmation_content
            context.pause_reason = "bulk_update_confirmation"
            context.update_phase = "bulk_confirmation"
            context.next = "PauseNode"
            return context.model_dump()

        except Exception as e:
            logger.error(f"[PerfectUpdateFlow] Error processing bulk field updates: {e}")
            context.response = await self._generate_dynamic_response(
                context, "bulk_processing_error", {}
            )
            context.next = "CustomerResponse"
            return context.model_dump()

    async def _analyze_bulk_confirmation_response(self, context):
        """Analyze user confirmation for bulk update with LLM"""
        try:
            confirmation_prompt = await self._build_dynamic_prompt(
                "bulk_confirmation_analysis",
                {
                    "user_message": context.message,
                    "customer_count": len(getattr(context, 'multiple_customers_found', [])),
                    "operation_type": "bulk_update"
                }
            )
            
            response = await self.llm_service.chat([
                {"role": "system", "content": confirmation_prompt},
                {"role": "user", "content": context.message}
            ])
            
            try:
                result = self._parse_json_response(response)
                logger.info(f"[PerfectUpdateFlow] Bulk confirmation analysis: {result}")
                return {'confirmed': result.get('confirmed', False)}
            except (json.JSONDecodeError, KeyError):
                return self._simple_confirmation_analysis(context.message)
                
        except Exception as e:
            logger.error(f"[PerfectUpdateFlow] Bulk confirmation analysis error: {e}")
            return {'confirmed': False}

    async def _execute_bulk_update(self, context):
        """Execute bulk update with dynamic response generation"""
        try:
            updates = context.bulk_update_data
            customers = context.multiple_customers_found
            customer_ids = [c['xcus'] for c in customers]

            if not updates or not customer_ids:
                context.response = await self._generate_dynamic_response(
                    context, "bulk_update_data_missing", {}
                )
                context.next = "CustomerResponse"
                return context.model_dump()

            # Build and execute SQL
            sql = await self._build_bulk_update_sql(updates, customer_ids, context.business_id)
            result = await self.mcp_client.execute_query(sql, context.business_id)

            # Generate dynamic result response
            result_content = await self._generate_dynamic_response(
                context, "bulk_update_result",
                {
                    "result": result,
                    "customer_count": len(customer_ids),
                    "updates": updates
                }
            )

            context.response = result_content
            context = self._clear_update_state(context)
            context.next = "CustomerResponse"
            return context.model_dump()

        except Exception as e:
            logger.error(f"[PerfectUpdateFlow] Error executing bulk update: {e}")
            context.response = await self._generate_dynamic_response(
                context, "bulk_execution_error", {"error": str(e)}
            )
            context.next = "CustomerResponse"
            return context.model_dump()
            
    def _clear_update_state(self, context):
        """Clear all update flow state"""
        context.update_phase = None
        context.selected_customer = None
        context.identified_customers = None
        context.multiple_customers_found = None
        context.customer_field_descriptions = None
        context.pause_reason = None
        context.current_flow = None
        context.pending_update_sql = None
        context.bulk_update_data = None
        return context

    async def process_field_updates(self, context):
        """Process field updates with enhanced LLM extraction"""
        try:
            if not hasattr(context, 'selected_customer') or not context.selected_customer:
                return await self._handle_customer_clarification(context, {'clarification_message': 'Please select a customer first'})
            
            # Extract field updates using enhanced LLM
            field_updates = await self._extract_field_updates_with_llm(context)
            
            if not field_updates['updates']:
                context.response = await self._generate_dynamic_response(
                    context, "field_extraction_failed", {}
                )
                context.pause_reason = "field_selection_needed"
                context.next = "PauseNode"
                return context.model_dump()
            
            # Handle multiple customers if applicable
            if hasattr(context, 'multiple_customers_found') and context.multiple_customers_found:
                return await self._handle_multiple_customer_updates(context, field_updates)
            
            # Generate UPDATE SQL for single customer
            return await self._generate_update_sql(context, field_updates)
            
        except Exception as e:
            logger.error(f"[PerfectUpdateFlow] Field processing error: {e}")
            context.response = await self._generate_dynamic_response(
                context, "field_processing_error", {"error": str(e)}
            )
            context.next = "CustomerResponse"
            return context.model_dump()
            
    async def _extract_field_updates_with_llm(self, context):
        """Enhanced field updates extraction with dynamic prompting"""
        try:
            field_info = await self._get_cached_field_info(context.business_id)
            
            # Build dynamic extraction prompt
            extraction_prompt = await self._build_dynamic_prompt(
                "field_update_extraction",
                {
                    "user_message": context.message,
                    "customer_data": context.selected_customer,
                    "field_info": field_info,
                    "business_context": await self._get_business_context(context.business_id)
                }
            )
            
            response = await self.llm_service.chat([
                {"role": "system", "content": extraction_prompt},
                {"role": "user", "content": context.message}
            ])
            
            try:
                result = self._parse_json_response(response)
                logger.info(f"[PerfectUpdateFlow] Parsed field updates: {result}")
                return result
            except json.JSONDecodeError as e:
                logger.error(f"[PerfectUpdateFlow] Field extraction JSON error: {e}")
                return {'updates': {}, 'confidence': 'low', 'unclear_fields': []}
                
        except Exception as e:
            logger.error(f"[PerfectUpdateFlow] Field extraction error: {e}")
            return {'updates': {}, 'confidence': 'low', 'unclear_fields': []}
            
    async def _handle_multiple_customer_updates(self, context, field_updates):
        """Handle updates for multiple customers with dynamic analysis"""
        try:
            customers = context.multiple_customers_found
            updates = field_updates['updates']
            
            # Analyze customer selection intent
            selection_analysis = await self._analyze_customer_selection_for_update(context)
            
            if selection_analysis['update_all']:
                # Generate dynamic bulk confirmation
                customer_ids = [c.get('xcus') for c in customers if c.get('xcus')]
                
                confirmation_content = await self._generate_dynamic_response(
                    context, "bulk_update_final_confirmation",
                    {
                        "updates": updates,
                        "customer_ids": customer_ids,
                        "customer_count": len(customer_ids)
                    }
                )
                
                context.bulk_update_data = {
                    'customer_ids': customer_ids,
                    'updates': updates
                }
                context.response = confirmation_content
                context.pause_reason = "bulk_update_confirmation"
                context.next = "PauseNode"
                return context.model_dump()
                
            elif selection_analysis['selected_customer']:
                # User selected specific customer
                context.selected_customer = selection_analysis['selected_customer']
                return await self._generate_update_sql(context, field_updates)
                
            else:
                # Generate dynamic clarification for customer selection
                context.response = await self._generate_dynamic_response(
                    context, "customer_selection_clarification",
                    {"customers": customers}
                )
                context.pause_reason = "customer_selection_needed"
                context.next = "PauseNode"
                return context.model_dump()
                
        except Exception as e:
            logger.error(f"[PerfectUpdateFlow] Multiple customer update error: {e}")
            context.response = await self._generate_dynamic_response(
                context, "multiple_customer_error", {"error": str(e)}
            )
            context.next = "CustomerResponse"
            return context.model_dump()
            
    async def _analyze_customer_selection_for_update(self, context):
        """Analyze which customer(s) user wants to update using dynamic LLM"""
        try:
            customers = context.multiple_customers_found
            
            selection_prompt = await self._build_dynamic_prompt(
                "customer_selection_analysis",
                {
                    "user_message": context.message,
                    "customers": customers,
                    "customer_count": len(customers)
                }
            )
            
            response = await self.llm_service.chat([
                {"role": "system", "content": selection_prompt},
                {"role": "user", "content": context.message}
            ])
            
            try:
                result = self._parse_json_response(response)
                
                selected_customer = None
                if result.get('selected_index') is not None:
                    idx = result['selected_index']
                    if 0 <= idx < len(customers):
                        selected_customer = customers[idx]
                elif result.get('selected_customer_id'):
                    cid = result['selected_customer_id']
                    selected_customer = next((c for c in customers if c.get('xcus') == cid), None)
                
                return {
                    'update_all': result.get('update_all', False),
                    'selected_customer': selected_customer,
                    'is_clear': result.get('is_clear', False)
                }
                
            except json.JSONDecodeError:
                return {'update_all': False, 'selected_customer': None, 'is_clear': False}
                
        except Exception as e:
            logger.error(f"[PerfectUpdateFlow] Customer selection analysis error: {e}")
            return {'update_all': False, 'selected_customer': None, 'is_clear': False}
            
    async def _generate_update_sql(self, context, field_updates):
        """Generate final UPDATE SQL with dynamic confirmation"""
        try:
            customer = context.selected_customer
            customer_id = customer.get('xcus')
            updates = field_updates['updates']
            
            if not customer_id or not updates:
                context.response = await self._generate_dynamic_response(
                    context, "update_generation_failed", {}
                )
                context.next = "CustomerResponse"
                return context.model_dump()
            
            # Build SQL
            sql = await self._build_single_update_sql(updates, customer_id, context.business_id)
            
            # Generate dynamic confirmation response
            confirmation_content = await self._generate_dynamic_response(
                context, "single_update_confirmation",
                {
                    "customer": customer,
                    "updates": updates,
                    "field_mappings": (await self._get_cached_field_info(context.business_id))['mappings']
                }
            )
            
            context.response = confirmation_content
            context.pending_update_sql = sql
            context.pause_reason = "update_confirmation"
            context.next = "PauseNode"
            return context.model_dump()
            
        except Exception as e:
            logger.error(f"[PerfectUpdateFlow] SQL generation error: {e}")
            context.response = await self._generate_dynamic_response(
                context, "sql_generation_error", {"error": str(e)}
            )
            context.next = "CustomerResponse"
            return context.model_dump()
            
    async def execute_confirmed_update(self, context):
        """Execute confirmed UPDATE SQL with dynamic result processing"""
        try:
            sql = getattr(context, 'pending_update_sql', None)
            if not sql:
                context.response = await self._generate_dynamic_response(
                    context, "no_pending_update", {}
                )
                context.next = "CustomerResponse"
                return context.model_dump()
            
            # Execute UPDATE SQL
            logger.info(f"[PerfectUpdateFlow] Executing confirmed update SQL: {sql}")
            result = await self.mcp_client.execute_query(sql, context.business_id)
            logger.info(f"[PerfectUpdateFlow] Update execution result: {result}")
            
            # Generate dynamic success response with updated customer details
            success_content = await self._generate_update_success_response(context, result)
            
            context.response = success_content
            context = self._clear_update_state(context)
            context.next = "CustomerResponse"
            return context.model_dump()
            
        except Exception as e:
            logger.error(f"[PerfectUpdateFlow] Update execution error: {e}")
            context.response = await self._generate_dynamic_response(
                context, "update_execution_error", {"error": str(e)}
            )
            context.next = "CustomerResponse"
            return context.model_dump()

    async def _analyze_selection_intent_with_llm(self, context):
        """Analyze user selection intent with dynamic LLM processing"""
        try:
            customers = context.multiple_customers_found
            
            intent_prompt = await self._build_dynamic_prompt(
                "selection_intent_analysis",
                {
                    "user_message": context.message,
                    "customers": customers,
                    "customer_count": len(customers)
                }
            )
            
            response = await self.llm_service.chat([
                {"role": "system", "content": intent_prompt},
                {"role": "user", "content": context.message}
            ])
            
            try:
                result = self._parse_json_response(response)
                logger.info(f"[PerfectUpdateFlow] Selection intent analysis: {result}")
                return result
            except (json.JSONDecodeError, KeyError) as e:
                logger.error(f"[PerfectUpdateFlow] JSON parsing error in selection intent: {e}")
                return self._simple_intent_analysis(context.message, len(customers))
                
        except Exception as e:
            logger.error(f"[PerfectUpdateFlow] Selection intent analysis error: {e}")
            return {'action': 'unclear', 'confidence': 'low', 'reasoning': 'analysis error'}

    # Helper methods for dynamic content generation and processing
    
    async def _build_dynamic_prompt(self, prompt_type, context_data):
        """Build dynamic prompts based on type and context"""
        prompt_templates = {
            "flow_control_analysis": self._get_flow_control_prompt(context_data),
            "customer_identification": self._get_customer_identification_prompt(context_data),
            "field_name_mapping": self._get_field_mapping_prompt(context_data),
            "confirmation_analysis": self._get_confirmation_prompt(context_data),
            "bulk_field_extraction": self._get_bulk_extraction_prompt(context_data),
            "bulk_confirmation_analysis": self._get_bulk_confirmation_prompt(context_data),
            "field_update_extraction": self._get_field_update_prompt(context_data),
            "customer_selection_analysis": self._get_customer_selection_prompt(context_data),
            "selection_intent_analysis": self._get_selection_intent_prompt(context_data)
        }
        
        return prompt_templates.get(prompt_type, "Analyze the user request and provide appropriate response.")
    
    def _get_flow_control_prompt(self, data):
        return f"""
Analyze the user message for flow control in an UPDATE customer operation context.

Current Flow: UPDATE (customer modification)
User Message: "{data.get('user_message', '')}"
Conversation History: {data.get('conversation_history', [])}

Check for:
1. NEGATIVE SENTIMENT: cancel, stop, quit, never mind, forget it, no thanks, not now
2. INTENT SWITCHING: 
   - INSERT: add customer, create customer, new customer
   - DELETE: delete customer, remove customer, drop customer  
   - SELECT: show customers, list customers, find customers (standalone, not for update)
3. POSITIVE CONTINUATION: continue with update, proceed, yes, update customer

Respond with JSON:
{{
    "should_exit": boolean,
    "exit_reason": "negative_sentiment/intent_switch/none",
    "new_intent": "insert/delete/select/none",
    "suggested_response": "response to user",
    "confidence": "high/medium/low"
}}
"""

    def _get_customer_identification_prompt(self, data):
        return f"""
You are an expert at identifying customers for UPDATE operations using multiple data sources.

SCHEMA CONTEXT: {json.dumps(data.get('schema_context', {}), indent=2)}
USER MESSAGE: "{data.get('user_message', '')}"
CONVERSATION HISTORY: {data.get('conversation_history', [])}
BUSINESS ID: {data.get('business_id', '')}

IDENTIFICATION METHODS:
1. DIRECT ID: CUS-XXXXXX format
2. REFERENCE: "last customer", "recent customer", "first customer", "third customer"
3. FIELD SEARCH: email, phone, name, organization
4. CONTEXTUAL: "that customer", "the one we discussed"
5. POSITIONAL: "customer 1", "second customer", "third last customer"

Respond with JSON:
{{
    "is_clear": boolean,
    "identification_method": "direct_id/reference/field_search/contextual/positional/unclear",
    "sql_query": "SELECT query to find customers or null if unclear",
    "needs_clarification": boolean,
    "clarification_message": "what to ask user if unclear",
    "confidence": "high/medium/low",
    "expected_result_count": "single/multiple/unknown"
}}
"""

    def _get_field_mapping_prompt(self, data):
        return f"""CRITICAL SECURITY REQUIREMENT: Convert database field names to secure, user-friendly names.

FIELD DESCRIPTIONS: {json.dumps(data.get('field_descriptions', {}), indent=2)}

🔒 SECURITY RULES (MANDATORY):
1. NEVER expose database column names (like xstatuscus, xphone, xemail) to users
2. Create SHORT, clear, business-friendly names (2-3 words max)
3. Remove ALL technical jargon and database terminology
4. Use common business terms users understand
5. Make names intuitive and professional
6. If unsure, use generic business terms like "Status", "Phone Number", "Email Address"

✅ SECURE EXAMPLES:
- "xstatuscus" → "Status" or "Customer Status"
- "xphone" → "Phone Number"
- "xemail" → "Email Address" 
- "xorg" → "Organization"
- "xgcus" → "Customer Type" or "Customer Group"
- "xtaxscope" → "Tax Classification"
- "ztime" → "Created On" (but this should be hidden from users)
- "zutime" → "Updated On" (but this should be hidden from users)

❌ NEVER RETURN:
- Raw database field names
- Technical abbreviations
- Column names with 'x' prefix
- Internal system fields

Respond with ONLY a JSON object mapping database field names to secure user-friendly names:
{{
    "xstatuscus": "Customer Status",
    "xphone": "Phone Number",
    "xemail": "Email Address",
    "xorg": "Organization",
    "xgcus": "Customer Type"
}}"""

    async def _generate_dynamic_response(self, context, response_type, data):
        """Enhanced LLM-powered response generation with business context"""
        try:
            # Build comprehensive context for better responses
            conversation_context = self._build_conversation_context(context)
            business_context = await self._get_business_context(context.business_id)
            
            response_prompt = f"""You are a professional customer service agent generating responses for customer update operations.

CONVERSATION CONTEXT:
{conversation_context}

BUSINESS CONTEXT:
{json.dumps(business_context, indent=2)}

RESPONSE TYPE: {response_type}
DATA: {json.dumps(data, indent=2)}

Generate a natural, helpful, and professional response based on the response type:

**Response Guidelines by Type:**

1. **flow_exit**: Acknowledge the user's intent and provide helpful guidance
2. **no_customers_found**: Suggest alternative search criteria and offer help
3. **customer_clarification**: Ask for specific customer identification with examples
4. **multiple_customers_found**: Show options clearly and ask for selection preference
5. **field_selection_display**: Present available fields in user-friendly format
6. **single_update_confirmation**: Summarize changes and ask for confirmation
7. **bulk_update_confirmation**: Clearly explain bulk operation and ask for confirmation
8. **update_success_with_details**: Celebrate success and show updated information

**Style Guidelines:**
- Use friendly, professional tone
- Include relevant emojis for better UX (📋 for info, ✅ for success, ⚠️ for warnings)
- Use markdown formatting for better readability
- Provide specific examples and clear instructions
- Be concise but informative
- Always offer next steps or ask follow-up questions

Generate the response now:"""
            
            response = await self.llm_service.chat([
                {"role": "system", "content": "You are a professional customer service agent. Generate helpful, clear, and engaging responses."},
                {"role": "user", "content": response_prompt}
            ])
            
            return response.strip()
            
        except Exception as e:
            logger.error(f"[PerfectUpdateFlow] Dynamic response generation error: {e}")
            return self._get_fallback_response(response_type, data)
    
    async def _build_response_prompt(self, response_type, data):
        """Build prompts for response generation"""
        prompts = {
            "no_customers_found": f"Generate a helpful message indicating no customers found for criteria: '{data.get('criteria', '')}'. Include suggestions for better search terms.",
            "customer_clarification": f"Generate a customer clarification message with recent customers: {data.get('recent_customers', [])}. Make it helpful and instructive.",
            "multiple_customers_found": f"Generate a message for {data.get('customer_count', 0)} customers found. Show options for selection or bulk update.",
            "field_selection_display": f"Generate field selection display for customer {data.get('customer_id', '')} with available fields and current values.",
            "single_update_confirmation": f"Generate confirmation message for updating customer with changes: {data.get('updates', {})}",
            "bulk_update_confirmation": f"Generate bulk update confirmation for {data.get('customer_count', 0)} customers with changes: {data.get('updates', {})}"
        }
        
        base_prompt = prompts.get(response_type, "Generate an appropriate response for the customer update operation.")
        
        return f"""
{base_prompt}

Context Data: {json.dumps(data, indent=2)}

Generate a professional, helpful, and user-friendly response. Use markdown formatting for better readability.
Include specific examples and clear instructions where appropriate.
"""

    def _extract_recent_customer_id(self, context):
        """Extract recent customer ID from conversation history"""
        try:
            if not context.conversation_history:
                return None
                
            # Look through recent assistant responses for customer IDs
            for msg in reversed(context.conversation_history[-10:]):
                role = msg.get('role', '') if isinstance(msg, dict) else getattr(msg, 'role', '')
                content = msg.get('content', '') if isinstance(msg, dict) else getattr(msg, 'content', '')
                
                if role == 'assistant':
                    # Extract CUS-XXXXXX pattern
                    import re
                    customer_ids = re.findall(r'CUS-\d{6}', content)
                    if customer_ids:
                        # Return the most recent (first found in reverse order)
                        return customer_ids[0]
            
            return None
            
        except Exception as e:
            logger.error(f"[PerfectUpdateFlow] Error extracting recent customer ID: {e}")
            return None
    
    def _build_conversation_context(self, context):
        """Build rich conversation context for LLM prompts"""
        try:
            if not context.conversation_history:
                return "No previous conversation."
                
            context_parts = []
            recent_messages = context.conversation_history[-8:] if len(context.conversation_history) > 8 else context.conversation_history
            
            for msg in recent_messages:
                role = msg.get('role', 'unknown') if isinstance(msg, dict) else getattr(msg, 'role', 'unknown')
                content = msg.get('content', '') if isinstance(msg, dict) else getattr(msg, 'content', '')
                
                # Truncate very long messages for context efficiency
                if len(content) > 200:
                    content = content[:200] + "..."
                    
                context_parts.append(f"{role.upper()}: {content}")
            
            # Add current flow information if available
            flow_info = ""
            if hasattr(context, 'current_flow') and context.current_flow:
                flow_info = f"\n[CURRENT FLOW: {context.current_flow}]\n"
            
            return flow_info + "\n".join(context_parts)
            
        except Exception as e:
            logger.error(f"[PerfectUpdateFlow] Error building conversation context: {e}")
            return "Error building conversation context."
    
    def _parse_json_response(self, response):
        """Parse JSON response with cleanup"""
        clean_response = response.strip()
        if clean_response.startswith('```json'):
            clean_response = clean_response[7:]
        if clean_response.endswith('```'):
            clean_response = clean_response[:-3]
        clean_response = clean_response.strip()
        return json.loads(clean_response)
    
    def _serialize_schema_context(self, schema_context):
        """Convert schema context to JSON-serializable format"""
        serializable_context = []
        if schema_context:
            for item in schema_context:
                if isinstance(item, dict):
                    clean_item = {}
                    for k, v in item.items():
                        if k != '_id' and not str(type(v)).startswith("<class 'bson"):
                            try:
                                json.dumps(v)
                                clean_item[k] = v
                            except (TypeError, ValueError):
                                continue
                    serializable_context.append(clean_item)
        return serializable_context
    
    def _extract_customers_from_result(self, result):
        """Extract customers from MCP query result"""
        customers = []
        if isinstance(result, dict) and 'content' in result:
            try:
                parsed = json.loads(result['content'][0]['text'])
                customers = parsed.get('results', [])
            except (json.JSONDecodeError, KeyError, IndexError):
                pass
        return customers
    
    def _format_response(self, response):
        """Format response for return"""
        if isinstance(response, dict):
            return response
        else:
            return response.model_dump() if hasattr(response, 'model_dump') else response
    
    def _simple_confirmation_analysis(self, message):
        """Simple keyword-based confirmation analysis"""
        message_lower = message.lower().strip()
        positive_responses = ['yes', 'confirm', 'proceed', 'ok', 'sure', 'go ahead', 'do it', 'y']
        negative_responses = ['no', 'cancel', 'abort', 'stop', 'never mind', 'nevermind', 'n']
        
        if any(pos in message_lower for pos in positive_responses):
            return {'confirmed': True}
        elif any(neg in message_lower for neg in negative_responses):
            return {'confirmed': False}
        else:
            return {'confirmed': False}
    
    def _simple_intent_analysis(self, message, customer_count):
        """Simple keyword-based intent analysis"""
        message_lower = message.lower().strip()
        if any(word in message_lower for word in ['all', 'both', 'everyone', 'bulk']) and customer_count > 1:
            return {'action': 'bulk_update', 'confidence': 'medium'}
        elif any(word in message_lower for word in ['1', 'first', 'one']):
            return {'action': 'select_specific', 'customer_index': 0, 'confidence': 'medium'}
        elif any(word in message_lower for word in ['2', 'second', 'last']) and customer_count >= 2:
            return {'action': 'select_specific', 'customer_index': 1, 'confidence': 'medium'}
        else:
            return {'action': 'unclear', 'confidence': 'low'}
    
    async def _get_recent_customers(self, business_id, limit=5):
        """Get recent customers for examples"""
        try:
            sql = f"SELECT xcus, xemail, xfirst, xlast, xorg FROM cacus WHERE zid = {business_id} ORDER BY xcus DESC LIMIT {limit}"
            result = await self.mcp_client.execute_query(sql, business_id)
            return self._extract_customers_from_result(result)
        except Exception as e:
            logger.error(f"[PerfectUpdateFlow] Error getting recent customers: {e}")
            return []
    
    async def _get_business_context(self, business_id):
        """Get business-specific context for better responses"""
        # This could be enhanced to fetch actual business context
        return {"business_id": business_id, "industry": "general"}
    
    async def _get_available_fields(self, business_id):
        """Get available fields for the business"""
        try:
            field_info = await self._get_cached_field_info(business_id)
            return list(field_info['mappings'].keys())
        except Exception as e:
            logger.error(f"[PerfectUpdateFlow] Error getting available fields: {e}")
            return []
    
    async def _enhance_field_descriptions(self, field_descriptions):
        """Enhance field descriptions using LLM if needed"""
        # Can be implemented to improve field descriptions
        return {}
    
    async def _handle_intent_switch(self, context, new_intent, response_content):
        """Handle intent switching"""
        if new_intent == 'select':
            context.current_flow = "select"
            context.query_classification = "SEARCH_CUSTOMER"
            context.next = "VectorSearch"
        elif new_intent in ['insert', 'delete']:
            context.current_flow = new_intent
            context.next = "GenerateCustomerSQL"
        
        context.response = response_content
        return context
    
    async def _build_bulk_update_sql(self, updates, customer_ids, business_id):
        """Build SQL for bulk update"""
        set_clauses = []
        for field, value in updates.items():
            if value is None or str(value).lower() == 'null':
                set_clauses.append(f"{field} = NULL")
            elif isinstance(value, str):
                set_clauses.append(f"{field} = '{value}'")
            else:
                set_clauses.append(f"{field} = {value}")
        
        set_clause = ", ".join(set_clauses)
        in_clause = "', '".join(customer_ids)
        return f"UPDATE cacus SET {set_clause} WHERE zid = {business_id} AND xcus IN ('{in_clause}')"
    
    async def _build_single_update_sql(self, updates, customer_id, business_id):
        """Build SQL for single customer update"""
        set_clauses = []
        for field, value in updates.items():
            if value is None or (isinstance(value, str) and value.upper() in ['NULL', 'EMPTY', 'CLEAR']):
                set_clauses.append(f"{field} = NULL")
            elif isinstance(value, str):
                set_clauses.append(f"{field} = '{value}'")
            else:
                set_clauses.append(f"{field} = {value}")
        
        set_clause = ", ".join(set_clauses)
        return f"UPDATE cacus SET {set_clause} WHERE zid = {business_id} AND xcus = '{customer_id}'"
    
    async def _generate_update_success_response(self, context, result):
        """Generate dynamic success response"""
        try:
            if isinstance(result, dict) and 'content' in result:
                parsed = json.loads(result['content'][0]['text'])
                
                if parsed.get('success'):
                    affected_rows = parsed.get('affected_rows', 0)
                    
                    if affected_rows > 0:
                        # Fetch updated customer details
                        customer_id = context.selected_customer.get('xcus')
                        updated_customer = await self._fetch_updated_customer(customer_id, context.business_id)
                        
                        return await self._generate_dynamic_response(
                            context, "update_success_with_details",
                            {
                                "affected_rows": affected_rows,
                                "updated_customer": updated_customer,
                                "customer_id": customer_id
                            }
                        )
                    else:
                        return await self._generate_dynamic_response(
                            context, "no_records_updated", {}
                        )
                else:
                    error_msg = parsed.get('error', 'Unknown error')
                    return await self._generate_dynamic_response(
                        context, "update_failed", {"error": error_msg}
                    )
            else:
                return await self._generate_dynamic_response(
                    context, "update_processed", {}
                )
                
        except Exception as e:
            logger.error(f"[PerfectUpdateFlow] Success response generation error: {e}")
            return "Update completed successfully!"
    
    async def _fetch_updated_customer(self, customer_id, business_id):
        """Fetch updated customer details"""
        try:
            sql = f"SELECT * FROM cacus WHERE zid = {business_id} AND xcus = '{customer_id}'"
            result = await self.mcp_client.execute_query(sql, business_id)
            customers = self._extract_customers_from_result(result)
            return customers[0] if customers else None
        except Exception as e:
            logger.error(f"[PerfectUpdateFlow] Error fetching updated customer: {e}")
            return None

    # Additional helper methods for specific prompt types
    
    def _get_confirmation_prompt(self, data):
        return f"""
Analyze if the user is confirming or denying an UPDATE operation.

User message: "{data.get('user_message', '')}"
Operation type: {data.get('operation_type', 'update')}

Respond with JSON: {{"confirmed": boolean, "confidence": "high/medium/low"}}
"""

    def _get_bulk_extraction_prompt(self, data):
        return f"""
Extract field updates from the user's message for a customer database update.

User message: "{data.get('user_message', '')}"
Available fields: {data.get('available_fields', [])}

Parse the user's intent and return JSON with database field names and values:
{{"field_name": "new_value"}}
"""

    def _get_bulk_confirmation_prompt(self, data):
        return f"""
Analyze if the user is confirming a BULK UPDATE operation for {data.get('customer_count', 0)} customers.

User message: "{data.get('user_message', '')}"
Operation type: {data.get('operation_type', 'bulk_update')}

For bulk operations, look for strong confirmations.
Respond with JSON: {{"confirmed": boolean, "confidence": "high/medium/low"}}
"""

    def _get_field_update_prompt(self, data):
        return f"""
Extract field updates from user message for customer UPDATE operation.

USER MESSAGE: "{data.get('user_message', '')}"
CUSTOMER DATA: {data.get('customer_data', {})}
FIELD INFO: {data.get('field_info', {})}

Map user-friendly terms to database column names and handle special values.
Respond with JSON: {{"updates": {{"field_name": "new_value"}}, "confidence": "high/medium/low"}}
"""

    def _get_customer_selection_prompt(self, data):
        return f"""
Analyze user message to determine which customer(s) to update from multiple options.

USER MESSAGE: "{data.get('user_message', '')}"
CUSTOMERS: {data.get('customers', [])}
CUSTOMER COUNT: {data.get('customer_count', 0)}

Respond with JSON:
{{"update_all": boolean, "selected_index": number, "selected_customer_id": "string", "is_clear": boolean}}
"""

    def _get_selection_intent_prompt(self, data):
        return f"""
Analyze user intent for customer selection from multiple options.

User message: "{data.get('user_message', '')}"
Customer count: {data.get('customer_count', 0)}

Understand synonyms and natural language for bulk vs specific selection.
Respond with JSON:
{{"action": "bulk_update/select_specific/unclear", "customer_index": number, "confidence": "high/medium/low"}}
"""
    
    def _get_fallback_response(self, response_type, data):
        """SECURE fallback response that never exposes database column names"""
        from backend.app.agents.customer_agent.secure_customer_helpers import SecureCustomerDisplay
        secure_display = SecureCustomerDisplay()
        
        if response_type == "field_selection_display":
            customer_id = data.get('customer_id', 'Unknown')
            field_info = data.get('field_info', {})
            mappings = field_info.get('mappings', {})
            
            # Use secure field mappings only
            secure_fields = []
            for db_field, user_friendly_name in mappings.items():
                # Double-check security: never show raw database field names
                if user_friendly_name and user_friendly_name != db_field:
                    secure_fields.append(user_friendly_name)
                else:
                    # Use secure fallback mapping
                    secure_name = secure_display.secure_field_mapping.get(db_field.lower())
                    if secure_name:
                        secure_fields.append(secure_name)
            
            return f"""📋 **Customer Fields**

Here are the fields you can update for the customer with ID {customer_id}:

{chr(10).join([f"\u2022 {field}" for field in secure_fields])}

Which field would you like to update? You can type the field name or describe what you want to change."""
            
        elif response_type == "multiple_customers_found":
            customer_count = data.get('customer_count', 0)
            return f"""🔍 **Multiple Customers Found**

I found {customer_count} customers matching your criteria. Please specify:
\u2022 Which customer you want to update (by customer ID, email, or description)
\u2022 Or type 'all' if you want to update all of them

What would you like to do?"""
            
        elif response_type == "single_update_confirmation":
            customer = data.get('customer', {})
            updates = data.get('updates', {})
            customer_id = customer.get('xcus', 'Unknown')
            
            # Convert database field names to secure names for display
            secure_updates = []
            for db_field, value in updates.items():
                secure_name = secure_display.secure_field_mapping.get(db_field.lower(), db_field)
                secure_updates.append(f"\u2022 {secure_name}: {value}")
            
            return f"""✅ **Update Confirmation**

Ready to update customer {customer_id} with the following changes:

{chr(10).join(secure_updates)}

\u2022 Type **'confirm'** to proceed with the update
\u2022 Type **'cancel'** to abort this operation

Are you sure you want to make these changes?"""
            
        else:
            return "I can help you with your customer request. Please let me know what you need."

# Create instance for use in other modules
perfect_update_flow = PerfectUpdateFlow()