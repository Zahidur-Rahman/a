"""
DYNAMIC DELETE FLOW - Optimized customer deletion with:
- LLM-driven immediate customer identification and validation
- Dynamic decision making throughout the pipeline
- Intelligent confirmation and safety checks
- Enhanced performance and maintainability
- Secure deletion handling and audit trails
"""
from backend.app.models.chat_graph_state import ChatGraphState
from backend.app.services.mistral_llm_service import MistralLLMService
from backend.app.services.vector_search import FaissVectorSearchService
from backend.app.mcp.mcp_client import MCPClient
from backend.app.agents.customer_agent.customer_chat_helpers import (
    build_customer_sql_prompt, clean_sql_from_llm, format_customer_result,
    get_customer_schema_context_for_flow
)
from backend.app.agents.customer_agent.negative_vibe_detector import negative_vibe_detector
from backend.app.agents.customer_agent.flow_interruption_handler import flow_interruption_handler
import logging
import json
import re

logger = logging.getLogger(__name__)

# Initialize services
llm_service = MistralLLMService()
vector_search_service = FaissVectorSearchService()
mcp_client = MCPClient(script_path="backend/app/mcp/server_enhanced.py")

async def generate_delete_sql_node(context):
    """🚀 DYNAMIC DELETE FLOW - Ultra-intelligent customer deletion with immediate identification"""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    logger.info(f"[🚀DynamicDeleteFlow] Starting DYNAMIC DELETE flow for: {context.message}")
    
    # Set current flow with context preservation
    context.current_flow = "delete"
    context.original_query = getattr(context, 'original_query', context.message)
    
    # 🛡️ STEP 1: Enhanced flow control with context awareness
    flow_control = await _check_delete_flow_control(context)
    if flow_control['should_exit']:
        return _format_response(flow_control['response'])
    
    # 📊 STEP 2: Get enhanced schema context
    if not hasattr(context, 'schema_context') or not context.schema_context:
        context.schema_context = await get_customer_schema_context_for_flow(context.business_id, "delete")
    
    # 🧠 STEP 3: INTELLIGENCE BOOST - Check for immediate customer identification
    immediate_identification = await _check_immediate_customer_identification(context)
    
    if immediate_identification['is_clear']:
        logger.info(f"[🚀DynamicDeleteFlow] IMMEDIATE CUSTOMER IDENTIFICATION: {immediate_identification}")
        # Customer clearly identified - fetch and proceed to confirmation
        customers_data = await _fetch_customers_for_deletion_enhanced(context, immediate_identification)
        if customers_data:
            context.customers_to_delete = customers_data
            context.delete_phase = "immediate_confirmation"
            return await _proceed_to_dynamic_confirmation(context, immediate_identification)
        else:
            context.response = await _generate_dynamic_response(
                context, "no_customers_found", 
                {"criteria": context.message, "identification_attempt": immediate_identification}
            )
            context.next = "CustomerResponse"
            return context.model_dump()
    
    # 🎯 STEP 4: Customer identification needs clarification - intelligent questioning
    logger.info("[🚀DynamicDeleteFlow] Customer identification unclear, using intelligent selection")
    context.response = await _generate_dynamic_customer_selection_prompt(context, immediate_identification)
    context.pause_reason = "intelligent_customer_selection"
    context.delete_phase = "customer_identification"
    context.next = "PauseNode"
    return context.model_dump()

async def process_customer_selection_for_delete_node(context):
    """💯 DYNAMIC CUSTOMER SELECTION - Enhanced selection processing with intelligent validation"""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    logger.info(f"[💯DynamicDeleteSelection] Processing selection: {context.message}")
    
    try:
        # Check for flow control first
        flow_control = await _check_delete_flow_control(context)
        if flow_control['should_exit']:
            return _format_response(flow_control['response'])
        
        # Check if this is a confirmation response (user responding to confirmation prompt)
        if hasattr(context, 'delete_phase') and context.delete_phase == "final_confirmation":
            return await _handle_dynamic_confirmation_response(context)
        
        # Re-analyze customer identification clarity with new input
        customer_identification = await _check_immediate_customer_identification(context)
        
        if not customer_identification['is_clear']:
            logger.info("[💯DynamicDeleteSelection] Customer identification still unclear")
            context.response = await _generate_dynamic_customer_selection_prompt(context, customer_identification)
            context.pause_reason = "intelligent_customer_selection"
            context.delete_phase = "customer_identification"
            context.next = "PauseNode"
            return context.model_dump()
        
        # Customer clearly identified - fetch for deletion
        customers_data = await _fetch_customers_for_deletion_enhanced(context, customer_identification)
        
        if customers_data:
            context.customers_to_delete = customers_data
            context.delete_phase = "immediate_confirmation"
            return await _proceed_to_dynamic_confirmation(context, customer_identification)
        else:
            context.response = await _generate_dynamic_response(
                context, "no_customers_found", 
                {"criteria": context.message, "identification_attempt": customer_identification}
            )
            context.next = "CustomerResponse"
            return context.model_dump()
        
    except Exception as e:
        logger.error(f"[💯DynamicDeleteSelection] Error: {e}")
        context.response = "Error processing customer selection. Please try again."
        context.next = "CustomerResponse"
        context.pause_reason = None
        return context.model_dump()

async def _handle_dynamic_confirmation_response(context):
    """🔐 Handle confirmation response with intelligent validation"""
    try:
        user_response = context.message.lower().strip()
        customers_count = len(getattr(context, 'customers_to_delete', []))
        
        # Enhanced confirmation validation
        if customers_count == 1:
            # Single customer deletion - require "YES DELETE"
            if "yes delete" in user_response or user_response == "yes delete":
                logger.info("[🔐DynamicConfirmation] Single customer deletion confirmed")
                return await _execute_confirmed_deletion(context)
            elif any(word in user_response for word in ['no', 'cancel', 'abort', 'stop']):
                return await _cancel_deletion(context, "single")
            else:
                context.response = await _generate_confirmation_retry_prompt(context, "single")
                context.next = "PauseNode"
                return context.model_dump()
        else:
            # Multiple customers deletion - require "YES DELETE ALL"
            if "yes delete all" in user_response or user_response == "yes delete all":
                logger.info(f"[🔐DynamicConfirmation] Bulk deletion of {customers_count} customers confirmed")
                return await _execute_confirmed_deletion(context)
            elif any(word in user_response for word in ['no', 'cancel', 'abort', 'stop']):
                return await _cancel_deletion(context, "bulk")
            else:
                context.response = await _generate_confirmation_retry_prompt(context, "bulk")
                context.next = "PauseNode"
                return context.model_dump()
            
    except Exception as e:
        logger.error(f"[🔐DynamicConfirmation] Error: {e}")
        context.response = "Error processing confirmation. Please try again."
        context.next = "CustomerResponse"
        return context.model_dump()

async def _execute_confirmed_deletion(context):
    """🛡️ Execute confirmed deletion with enhanced SQL generation"""
    try:
        customers = context.customers_to_delete
        if not customers:
            context.response = "No customers selected for deletion."
            context.next = "CustomerResponse"
            return context.model_dump()
        
        # Generate DELETE SQL based on customers
        customer_ids = [c.get('xcus') for c in customers if c.get('xcus')]
        
        if not customer_ids:
            context.response = "Error: No valid customer IDs found for deletion."
            context.next = "CustomerResponse"
            return context.model_dump()
        
        # Build secure DELETE SQL
        if len(customer_ids) == 1:
            context.sql = f"DELETE FROM cacus WHERE zid = {context.business_id} AND xcus = '{customer_ids[0]}'"
        else:
            ids_str = "', '".join(customer_ids)
            context.sql = f"DELETE FROM cacus WHERE zid = {context.business_id} AND xcus IN ('{ids_str}')"
        
        logger.info(f"[🛡️DynamicDeletion] Executing confirmed deletion: {context.sql}")
        
        # Clear state and proceed to execution
        context.delete_phase = None
        context.pause_reason = None
        context.next = "ExecuteDeleteSQL"
        return context.model_dump()
        
    except Exception as e:
        logger.error(f"[🛡️DynamicDeletion] Error executing deletion: {e}")
        context.response = f"Error preparing deletion: {str(e)}"
        context.next = "CustomerResponse"
        return context.model_dump()

async def _cancel_deletion(context, deletion_type):
    """🚫 Cancel deletion with appropriate messaging"""
    try:
        context = _clear_delete_flow_state(context)
        
        if deletion_type == "bulk":
            customers_count = len(getattr(context, 'customers_to_delete', []))
            context.response = f"✅ Bulk customer deletion cancelled. No customers were deleted. All {customers_count} customers remain safe."
        else:
            context.response = "✅ Customer deletion cancelled. No customers were deleted."
        
        context.next = "CustomerResponse"
        return context.model_dump()
        
    except Exception as e:
        logger.error(f"[🚫DynamicCancellation] Error: {e}")
        context.response = "Deletion cancelled."
        context.next = "CustomerResponse"
        return context.model_dump()

async def _generate_confirmation_retry_prompt(context, deletion_type):
    """Generate retry prompt for unclear confirmations"""
    try:
        customers_count = len(getattr(context, 'customers_to_delete', []))
        
        if deletion_type == "bulk":
            return (
                f"⚠️ **Please confirm clearly for deleting {customers_count} customers:**\n\n"
                f"📝 **To proceed with deleting ALL {customers_count} customers, type exactly**: `YES DELETE ALL`\n"
                f"🚫 **To cancel, type**: `no` or `cancel`\n\n"
                f"❗ This action is permanent and cannot be undone!"
            )
        else:
            return (
                "⚠️ **Please confirm clearly for customer deletion:**\n\n"
                "📝 **To proceed with deletion, type exactly**: `YES DELETE`\n"
                "🚫 **To cancel, type**: `no` or `cancel`\n\n"
                "❗ This action is permanent and cannot be undone!"
            )
        
    except Exception as e:
        logger.error(f"[🚀DynamicDeleteFlow] Error generating retry prompt: {e}")
        return "Please confirm deletion clearly. Type 'YES DELETE' to confirm or 'no' to cancel."

async def validate_delete_customer_exists_node(context):
    """Validate that customers exist before deletion with enhanced preview and confirmation."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    logger.info(f"[ReactiveDeleteValidation] Validating customers exist for: {context.sql}")
    
    try:
        # Check for flow interruption during validation
        interruption_check = await _check_delete_flow_interruption(context)
        if interruption_check['is_interrupted']:
            return interruption_check['response']
        
        # Convert DELETE to SELECT to see what would be deleted
        select_sql = context.sql.replace("DELETE FROM", "SELECT * FROM", 1)
        select_sql = re.sub(r'\s+WHERE\s+', ' WHERE ', select_sql, flags=re.IGNORECASE)
        
        result = await mcp_client.execute_query(select_sql, context.business_id)
        
        if isinstance(result, dict) and 'content' in result:
            try:
                parsed = json.loads(result['content'][0]['text'])
                customers = parsed.get('results', [])
                
                if customers:
                    # Store customers to be deleted for confirmation
                    context.customers_to_delete = customers
                    
                    # Enhanced preview with customer details
                    preview_message = await _generate_delete_preview_message(customers)
                    context.delete_preview_message = preview_message
                    
                    context.next = "ConfirmDeleteOperation"
                    logger.info(f"[ReactiveDeleteValidation] Found {len(customers)} customer(s) for deletion")
                else:
                    context.response = "No customers found matching your deletion criteria. Please check your request and try again."
                    context.next = "CustomerResponse"
                    
            except (json.JSONDecodeError, KeyError, IndexError) as e:
                logger.error(f"[ReactiveDeleteValidation] Error parsing result: {e}")
                context.response = "Unable to validate customers for deletion. Please try again."
                context.next = "CustomerResponse"
        else:
            context.response = "Unable to validate customers for deletion. Please try again."
            context.next = "CustomerResponse"
            
    except Exception as e:
        logger.error(f"[ReactiveDeleteValidation] Error: {e}")
        context.response = f"Error validating customers for deletion: {str(e)}"
        context.next = "CustomerResponse"
    
    return context.model_dump()

async def process_delete_confirmation_node(context):
    """Process user confirmation for DELETE operations with enhanced validation."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    logger.info(f"[ReactiveDeleteConfirmProcess] Processing confirmation: {context.message}")
    
    try:
        user_response = context.message.lower().strip()
        
        # Check for negative vibe or cancellation first
        negative_vibe = await negative_vibe_detector.detect_negative_vibe(
            context.message, context.conversation_history
        )
        
        if negative_vibe['is_negative']:
            logger.info("[ReactiveDeleteConfirmProcess] Negative vibe detected, canceling deletion")
            context = _clear_delete_flow_state(context)
            context.response = "Customer deletion cancelled. " + negative_vibe['suggested_response']
            context.next = "CustomerResponse"
            return context.model_dump()
        
        # Enhanced confirmation validation
        if len(context.customers_to_delete) == 1:
            # Single customer deletion - require "YES DELETE"
            if "yes delete" in user_response or user_response == "yes delete":
                context.next = "ExecuteDeleteSQL"
                context.pause_reason = None
                logger.info("[ReactiveDeleteConfirmProcess] Single customer deletion confirmed")
            elif any(word in user_response for word in ['no', 'cancel', 'abort', 'stop']):
                context = _clear_delete_flow_state(context)
                context.response = "✅ Customer deletion cancelled. No customers were deleted."
                context.next = "CustomerResponse"
                logger.info("[ReactiveDeleteConfirmProcess] Single customer deletion cancelled")
            else:
                context.response = (
                    "⚠️ **Please confirm clearly for customer deletion:**\n\n"
                    "• Type **'YES DELETE'** to proceed with deletion\n"
                    "• Type **'no'** or **'cancel'** to abort\n\n"
                    "This action is permanent and cannot be undone!"
                )
                context.next = "PauseNode"
        else:
            # Multiple customers deletion - require "YES DELETE ALL"
            if "yes delete all" in user_response or user_response == "yes delete all":
                context.next = "ExecuteDeleteSQL"
                context.pause_reason = None
                logger.info(f"[ReactiveDeleteConfirmProcess] Bulk deletion of {len(context.customers_to_delete)} customers confirmed")
            elif any(word in user_response for word in ['no', 'cancel', 'abort', 'stop']):
                context = _clear_delete_flow_state(context)
                context.response = f"✅ Bulk customer deletion cancelled. No customers were deleted."
                context.next = "CustomerResponse"
                logger.info("[ReactiveDeleteConfirmProcess] Bulk customer deletion cancelled")
            else:
                context.response = (
                    f"⚠️ **Please confirm clearly for deleting {len(context.customers_to_delete)} customers:**\n\n"
                    f"• Type **'YES DELETE ALL'** to proceed with deleting all {len(context.customers_to_delete)} customers\n"
                    f"• Type **'no'** or **'cancel'** to abort\n\n"
                    f"This action is permanent and cannot be undone!"
                )
                context.next = "PauseNode"
            
    except Exception as e:
        logger.error(f"[ReactiveDeleteConfirmProcess] Error: {e}")
        context.response = "Error processing confirmation. Please try again."
        context.next = "CustomerResponse"
        context.pause_reason = None
    
    return context.model_dump()

async def confirm_delete_operation_node(context):
    """Confirm DELETE operations with enhanced customer details and safety warnings."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    logger.info("[ReactiveDeleteConfirm] Preparing confirmation")
    
    try:
        # Check for flow interruption during confirmation
        interruption_check = await _check_delete_flow_interruption(context)
        if interruption_check['is_interrupted']:
            return interruption_check['response']
        
        if hasattr(context, 'customers_to_delete') and context.customers_to_delete:
            customers = context.customers_to_delete
            
            # Use enhanced preview message if available
            if hasattr(context, 'delete_preview_message') and context.delete_preview_message:
                preview_display = context.delete_preview_message
            else:
                preview_display = await _generate_delete_preview_message(customers)
            
            # Generate confirmation message with safety warnings
            if len(customers) == 1:
                context.pause_message = (
                    f"🚨 **CUSTOMER DELETION CONFIRMATION** 🚨\n\n"
                    f"{preview_display}\n\n"
                    f"⚠️ **WARNING: This action is PERMANENT and cannot be undone!**\n\n"
                    f"📋 **What will be deleted:**\n"
                    f"• All customer data and information\n"
                    f"• Customer history and records\n"
                    f"• Associated relationships\n\n"
                    f"❓ **Are you absolutely sure you want to delete this customer?**\n"
                    f"Type 'YES DELETE' to confirm or 'no' to cancel."
                )
            else:
                context.pause_message = (
                    f"🚨 **BULK CUSTOMER DELETION CONFIRMATION** 🚨\n\n"
                    f"{preview_display}\n\n"
                    f"⚠️ **CRITICAL WARNING: This will PERMANENTLY delete {len(customers)} customers!**\n\n"
                    f"📋 **What will be deleted:**\n"
                    f"• All data for {len(customers)} customers\n"
                    f"• Complete customer histories and records\n"
                    f"• All associated relationships\n\n"
                    f"❓ **Are you absolutely sure you want to delete ALL these customers?**\n"
                    f"Type 'YES DELETE ALL' to confirm or 'no' to cancel."
                )
            
            context.pause_reason = "confirm_delete"
            context.next = "PauseNode"
        else:
            # No customers to delete
            context.response = "No customers found to delete. Please check your criteria."
            context.next = "CustomerResponse"
            
    except Exception as e:
        logger.error(f"[ReactiveDeleteConfirm] Error: {e}")
        context.response = "Error preparing deletion confirmation. Please try again."
        context.next = "CustomerResponse"
    
    return context.model_dump()

async def execute_delete_sql_node(context):
    """Execute customer DELETE SQL operations via MCP."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    logger.info(f"[CustomerDeleteSQL] Executing: {context.sql}")
    
    try:
        # Execute SQL via MCP
        result = await mcp_client.execute_query(context.sql, context.business_id)
        
        if isinstance(result, dict) and 'content' in result:
            try:
                # Parse MCP response
                parsed = json.loads(result['content'][0]['text'])
                
                if parsed.get('success'):
                    affected_rows = parsed.get('affected_rows', 0)
                    
                    if affected_rows > 0:
                        if affected_rows == 1:
                            context.response = f"✅ Customer has been successfully deleted! (1 record removed)"
                        else:
                            context.response = f"✅ {affected_rows} customers have been successfully deleted!"
                        
                        # Log the deletion for audit purposes
                        logger.info(f"[CustomerDeleteSQL] Successfully deleted {affected_rows} customer(s)")
                    else:
                        context.response = "No customers were deleted. The specified customers may have already been removed or the criteria didn't match any records."
                else:
                    error_msg = parsed.get('error', 'Unknown error occurred')
                    
                    # Handle specific database errors
                    if 'foreign key' in error_msg.lower() or 'constraint' in error_msg.lower():
                        context.response = (
                            "❌ Cannot delete customer(s) because they are referenced by other records "
                            "(orders, transactions, etc.). Please remove related records first or contact support."
                        )
                    else:
                        context.response = f"Failed to delete customer(s): {error_msg}"
                    
            except (json.JSONDecodeError, KeyError, IndexError) as e:
                logger.error(f"[CustomerDeleteSQL] Error parsing result: {e}")
                context.response = "Customer deletion completed but I had trouble confirming the details."
        else:
            context.response = "Customer deletion request was processed."
            
    except Exception as e:
        logger.error(f"[CustomerDeleteSQL] Execution error: {e}")
        
        # Handle specific error types
        error_str = str(e).lower()
        if 'foreign key' in error_str or 'constraint' in error_str:
            context.response = (
                "❌ Cannot delete customer(s) because they are referenced by other records. "
                "Please remove related records first or contact support."
            )
        else:
            context.response = f"I encountered an error while deleting the customer(s): {str(e)}"
    
    context.next = "CustomerResponse"
    return context.model_dump()

# --- DYNAMIC HELPER FUNCTIONS FOR OPTIMIZED DELETE FLOW ---

def _format_response(response_dict):
    """Format response dictionary for consistent output"""
    return response_dict

def _parse_json_response(response: str) -> dict:
    """Parse JSON response from LLM, handling markdown code blocks."""
    response = response.strip()
    
    # Remove markdown code blocks
    if response.startswith('```json'):
        response = response[7:]
    elif response.startswith('```'):
        response = response[3:]
    
    if response.endswith('```'):
        response = response[:-3]
    
    response = response.strip()
    
    # Try to extract JSON if embedded in other text
    json_match = re.search(r'\{.*\}', response, re.DOTALL)
    if json_match:
        response = json_match.group(0)
    
    try:
        return json.loads(response)
    except json.JSONDecodeError as e:
        logger.error(f"[JSONParser] Failed to parse JSON: {e}, cleaned response: {response[:200]}...")
        raise json.JSONDecodeError(f"Could not parse LLM JSON response: {e}", response, 0)

async def _check_delete_flow_control(context):
    """Enhanced LLM-powered flow control with context awareness"""
    try:
        # Build richer context for better LLM understanding
        conversation_context = _build_conversation_context(context)
        
        flow_control_prompt = f"""You are an expert at understanding user intent in customer deletion operations.

CONVERSATION CONTEXT:
{conversation_context}

CURRENT USER MESSAGE: "{context.message}"
CURRENT OPERATION: Customer DELETE flow

Analyze the user's message for:
1. **NEGATIVE SENTIMENT**: Wants to cancel, stop, or abort ("cancel", "stop", "nevermind", "quit")
2. **INTENT SWITCHING**: Wants to switch to different operation:
   - INSERT: "add customer", "create new customer"
   - UPDATE: "update customer", "modify customer"
   - SELECT: "show customers", "list customers" (standalone, not for deletion reference)
3. **CONTINUATION**: Providing information for current deletion (customer ID, confirmations)

IMPORTANT: Distinguish between:
- "show customers" (intent switch) vs "show me which customers" (help for deletion)
- "update info" (intent switch) vs "update this selection" (correction in deletion)

Respond with JSON:
{{
    "should_exit": boolean,
    "exit_reason": "negative_sentiment|intent_switch|none",
    "new_intent": "insert|update|select|none",
    "confidence": 0.0-1.0,
    "reasoning": "clear explanation",
    "suggested_response": "appropriate response if exiting"
}}

Examples:
- "cancel this" → {{"should_exit": true, "exit_reason": "negative_sentiment"}}
- "add customer instead" → {{"should_exit": true, "exit_reason": "intent_switch", "new_intent": "insert"}}
- "delete customer CUS-123" → {{"should_exit": false}} (providing deletion target)
- "yes delete" → {{"should_exit": false}} (confirming deletion)"""
        
        response = await llm_service.chat([
            {"role": "system", "content": "You are an intent analysis expert. Always respond with valid JSON."},
            {"role": "user", "content": flow_control_prompt}
        ])
        
        try:
            result = _parse_json_response(response)
            logger.info(f"[🚀DynamicDeleteFlow] Flow control analysis: {result}")
            
            if result.get('should_exit', False) and result.get('confidence', 0) > 0.7:
                exit_reason = result.get('exit_reason', 'unknown')
                new_intent = result.get('new_intent', 'none')
                
                # Clear delete flow state
                context = _clear_delete_flow_state(context)
                
                # Use LLM-suggested response or generate dynamic one
                if result.get('suggested_response'):
                    response_content = result['suggested_response']
                else:
                    response_content = await _generate_dynamic_response(
                        context, "flow_exit", 
                        {"exit_reason": exit_reason, "new_intent": new_intent, "reasoning": result.get('reasoning')}
                    )
                
                if exit_reason == 'negative_sentiment':
                    context.response = response_content
                    context.next = "CustomerResponse"
                elif exit_reason == 'intent_switch':
                    context = await _handle_intent_switch(context, new_intent, response_content)
                
                return {'should_exit': True, 'response': context.model_dump()}
            
            return {'should_exit': False}
            
        except json.JSONDecodeError as e:
            logger.error(f"[🚀DynamicDeleteFlow] JSON parsing error: {e}, response: {response}")
            return {'should_exit': False}
            
    except Exception as e:
        logger.error(f"[🚀DynamicDeleteFlow] Flow control error: {e}")
        return {'should_exit': False}

def _build_conversation_context(context):
    """Build rich conversation context for LLM analysis"""
    conversation_context = ""
    if hasattr(context, 'conversation_history') and context.conversation_history:
        recent_messages = context.conversation_history[-4:]
        for i, msg in enumerate(recent_messages):
            role = msg.role if hasattr(msg, 'role') else msg.get('role', 'user')
            content = msg.content if hasattr(msg, 'content') else msg.get('content', '')
            conversation_context += f"{i+1}. {role.upper()}: {content}\n"
    return conversation_context

async def _check_immediate_customer_identification(context):
    """Check if the user message contains clear customer identification for deletion"""
    try:
        # Build intelligent customer identification detection prompt
        identification_prompt = f"""You are an expert at identifying customers for deletion operations.

USER MESSAGE: "{context.message}"
BUSINESS CONTEXT: Customer deletion request

Analyze if this message contains CLEAR customer identification with these methods:
1. **Direct Customer ID**: Explicit customer ID (CUS-123456, CUS-000001)
2. **Email Address**: Valid email for identification (john@example.com)
3. **Phone Number**: Phone number for identification (123-456-7890, 1234567890)
4. **Contextual Reference**: "last customer", "recent customer", "that customer", "the one with"
5. **Organization Reference**: "customer from ABC Corp", "TechCorp customer"
6. **Name Reference**: "customer John Smith", "delete Jane Doe"

📝 EXAMPLES OF CLEAR IDENTIFICATION:
- "delete customer CUS-123456" → CLEAR (direct ID)
- "delete john@example.com" → CLEAR (email identification)
- "remove customer from TechCorp" → CLEAR (organization)
- "delete last customer" → CLEAR (contextual reference)
- "remove customer 1234567890" → CLEAR (phone identification)

❌ EXAMPLES NEEDING CLARIFICATION:
- "delete customer" → NOT CLEAR (which customer?)
- "remove some customers" → NOT CLEAR (which ones?)
- "delete the bad one" → NOT CLEAR (need specific criteria)

Respond with JSON:
{{
    "is_clear": boolean,
    "identification_method": "direct_id|email|phone|contextual|organization|name|vague",
    "confidence": 0.0-1.0,
    "reasoning": "explanation of analysis",
    "extracted_criteria": "specific criteria found",
    "suggested_sql_criteria": "SQL WHERE clause criteria"
}}

EXAMPLE:
- "delete customer CUS-123456" → {{"is_clear": true, "identification_method": "direct_id", "confidence": 0.95, "extracted_criteria": "CUS-123456", "suggested_sql_criteria": "xcus = 'CUS-123456'"}}"""
        
        response = await llm_service.chat([
            {"role": "system", "content": "You are an expert customer identification detector. Always respond with valid JSON."},
            {"role": "user", "content": identification_prompt}
        ])
        
        try:
            result = _parse_json_response(response)
            logger.info(f"[🚀DynamicDeleteFlow] Immediate customer identification analysis: {result}")
            return result
            
        except json.JSONDecodeError as e:
            logger.error(f"[🚀DynamicDeleteFlow] JSON parsing error in identification check: {e}")
            return {'is_clear': False, 'identification_method': 'vague', 'confidence': 0.0}
            
    except Exception as e:
        logger.error(f"[🚀DynamicDeleteFlow] Error in immediate customer identification check: {e}")
        return {'is_clear': False, 'identification_method': 'vague', 'confidence': 0.0}

async def _fetch_customers_for_deletion_enhanced(context, identification_result):
    """Enhanced customer fetching using dynamic LLM-generated SQL"""
    try:
        # Build dynamic SQL based on identification analysis
        sql_criteria = identification_result.get('suggested_sql_criteria')
        identification_method = identification_result.get('identification_method', 'unknown')
        
        if not sql_criteria:
            # Fallback to building SQL based on method
            if identification_method == 'direct_id':
                # Extract customer ID from message
                cus_match = re.search(r'CUS-\d+', context.message)
                if cus_match:
                    sql_criteria = f"xcus = '{cus_match.group()}'"
            elif identification_method == 'email':
                # Extract email from message
                email_match = re.search(r'\b[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}\b', context.message)
                if email_match:
                    sql_criteria = f"xemail = '{email_match.group()}'"
            elif identification_method == 'contextual':
                if 'last customer' in context.message.lower() or 'recent customer' in context.message.lower():
                    sql_criteria = "1=1 ORDER BY xcus DESC LIMIT 1"
        
        if not sql_criteria:
            logger.warning(f"[🚀DynamicDeleteFlow] No SQL criteria generated for: {context.message}")
            return None
        
        # Build and execute SELECT query
        if "ORDER BY" in sql_criteria:
            sql_query = f"SELECT * FROM cacus WHERE zid = {context.business_id} AND {sql_criteria}"
        else:
            sql_query = f"SELECT * FROM cacus WHERE zid = {context.business_id} AND {sql_criteria}"
        
        logger.info(f"[🚀DynamicDeleteFlow] Executing customer fetch SQL: {sql_query}")
        
        result = await mcp_client.execute_query(sql_query, context.business_id)
        
        if isinstance(result, dict) and 'content' in result:
            parsed = json.loads(result['content'][0]['text'])
            customers = parsed.get('results', [])
            return customers if customers else None
        
        return None
            
    except Exception as e:
        logger.error(f"[🚀DynamicDeleteFlow] Error fetching customers for deletion: {e}")
        return None

async def _proceed_to_dynamic_confirmation(context, identification_result):
    """Proceed to dynamic confirmation with intelligent safety checks"""
    try:
        customers = context.customers_to_delete
        
        if not customers:
            context.response = "No customers found for deletion."
            context.next = "CustomerResponse"
            return context.model_dump()
        
        # Generate intelligent confirmation prompt based on identification method
        confirmation_content = await _generate_intelligent_confirmation_prompt(context, customers, identification_result)
        
        context.response = confirmation_content
        context.pause_reason = "intelligent_deletion_confirmation"
        context.delete_phase = "final_confirmation"
        context.next = "PauseNode"
        return context.model_dump()
        
    except Exception as e:
        logger.error(f"[🚀DynamicDeleteFlow] Error proceeding to confirmation: {e}")
        context.response = "Error preparing deletion confirmation. Please try again."
        context.next = "CustomerResponse"
        return context.model_dump()

async def _generate_dynamic_customer_selection_prompt(context, identification_result):
    """Generate intelligent customer selection prompt with helpful examples"""
    try:
        # Get recent customers for examples
        recent_customers = await _get_recent_customers_for_examples(context.business_id)
        
        identification_method = identification_result.get('identification_method', 'vague')
        reasoning = identification_result.get('reasoning', 'unclear identification')
        
        prompt_parts = [
            "🗑️ **Dynamic Customer Deletion - Smart Customer Selection**",
            "",
            f"🚨 **Analysis**: {reasoning}",
            "",
            "🎯 **I need to know which specific customer you want to delete.**",
            "",
            "**You can identify the customer using any of these methods:**",
            "• **Customer ID**: `delete customer CUS-000001`",
            "• **Email address**: `delete john@example.com`",
            "• **Phone number**: `remove customer 1234567890`",
            "• **Organization**: `delete customer from TechCorp`",
            "• **Contextual reference**: `delete last customer`, `remove recent customer`",
            "• **Customer name**: `delete John Smith`",
            ""
        ]
        
        if recent_customers:
            prompt_parts.extend([
                "📊 **Recent Customers (for reference):**"
            ])
            for i, customer in enumerate(recent_customers[:4]):
                cus_id = customer.get('xcus', 'Unknown')
                email = customer.get('xemail', 'No email')
                org = customer.get('xorg', '')
                name_parts = [customer.get('xfirst', ''), customer.get('xlast', '')]
                name = ' '.join(filter(None, name_parts)) or 'No name'
                
                example = f"• **{cus_id}** - {name} ({email})"
                if org:
                    example += f" from {org}"
                prompt_parts.append(example)
            prompt_parts.append("")
        
        prompt_parts.extend([
            "⚠️ **CRITICAL WARNING**: Customer deletion is permanent and cannot be undone!",
            "",
            "📝 **Please specify which customer you want to delete:**"
        ])
        
        return "\n".join(prompt_parts)
        
    except Exception as e:
        logger.error(f"[🚀DynamicDeleteFlow] Error generating selection prompt: {e}")
        return "Which customer would you like to delete? Please provide specific identification."

async def _get_recent_customers_for_examples(business_id, limit=5):
    """Get recent customers for helpful examples in prompts"""
    try:
        sql = f"SELECT xcus, xemail, xphone, xorg, xfirst, xlast FROM cacus WHERE zid = {business_id} ORDER BY xcus DESC LIMIT {limit}"
        result = await mcp_client.execute_query(sql, business_id)
        
        if isinstance(result, dict) and 'content' in result:
            parsed = json.loads(result['content'][0]['text'])
            return parsed.get('results', [])
        return []
        
    except Exception as e:
        logger.error(f"[🚀DynamicDeleteFlow] Error getting recent customers: {e}")
        return []

async def _generate_intelligent_confirmation_prompt(context, customers, identification_result):
    """Generate intelligent confirmation prompt with enhanced safety warnings"""
    try:
        identification_method = identification_result.get('identification_method', 'unknown')
        
        if len(customers) == 1:
            customer = customers[0]
            
            # Build detailed customer information
            customer_details = []
            if customer.get('xcus'):
                customer_details.append(f"🆔 **Customer ID**: {customer['xcus']}")
            
            name_parts = [customer.get('xfirst', ''), customer.get('xlast', '')]
            name = ' '.join(filter(None, name_parts))
            if name:
                customer_details.append(f"👤 **Name**: {name}")
            
            if customer.get('xemail'):
                customer_details.append(f"📧 **Email**: {customer['xemail']}")
            if customer.get('xphone'):
                customer_details.append(f"📞 **Phone**: {customer['xphone']}")
            if customer.get('xorg'):
                customer_details.append(f"🏢 **Organization**: {customer['xorg']}")
            
            confirmation_prompt = (
                f"🚨 **CRITICAL: Customer Deletion Confirmation** 🚨\n\n"
                f"**Customer to be PERMANENTLY deleted:**\n"
                f"{''.join([f'{detail}\n' for detail in customer_details])}\n"
                f"⚠️ **DANGER**: This action is **IRREVERSIBLE** and will:\n"
                f"• Permanently delete all customer data\n"
                f"• Remove customer history and records\n"
                f"• Break any existing relationships\n"
                f"• Cannot be undone or recovered\n\n"
                f"❓ **Are you absolutely certain you want to delete this customer?**\n\n"
                f"📝 **To confirm deletion, type exactly**: `YES DELETE`\n"
                f"🚫 **To cancel, type**: `no` or `cancel`"
            )
        else:
            # Multiple customers
            customer_list = []
            for i, customer in enumerate(customers[:5], 1):
                cus_id = customer.get('xcus', 'Unknown')
                email = customer.get('xemail', 'No email')
                name_parts = [customer.get('xfirst', ''), customer.get('xlast', '')]
                name = ' '.join(filter(None, name_parts)) or 'No name'
                customer_list.append(f"{i}. **{cus_id}** - {name} ({email})")
            
            if len(customers) > 5:
                customer_list.append(f"... and **{len(customers) - 5} more customers**")
            
            confirmation_prompt = (
                f"🚨 **CRITICAL: Bulk Customer Deletion Confirmation** 🚨\n\n"
                f"**{len(customers)} Customers to be PERMANENTLY deleted:**\n"
                f"{''.join([f'{item}\n' for item in customer_list])}\n"
                f"⚠️ **EXTREME DANGER**: This action will **IRREVERSIBLY**:\n"
                f"• Permanently delete ALL {len(customers)} customer records\n"
                f"• Remove complete customer histories\n"
                f"• Break all existing relationships\n"
                f"• Cannot be undone or recovered\n\n"
                f"❓ **Are you absolutely certain you want to delete ALL {len(customers)} customers?**\n\n"
                f"📝 **To confirm bulk deletion, type exactly**: `YES DELETE ALL`\n"
                f"🚫 **To cancel, type**: `no` or `cancel`"
            )
        
        return confirmation_prompt
        
    except Exception as e:
        logger.error(f"[🚀DynamicDeleteFlow] Error generating confirmation prompt: {e}")
        return f"Confirm deletion of {len(customers)} customer(s). This action is permanent. Type 'YES DELETE' to confirm or 'no' to cancel."

async def _generate_dynamic_response(context, response_type, response_data):
    """Generate dynamic responses using intelligent analysis"""
    try:
        if response_type == "flow_exit":
            exit_reason = response_data.get('exit_reason', 'unknown')
            if exit_reason == 'negative_sentiment':
                return "Customer deletion cancelled. How can I help you instead?"
            elif exit_reason == 'intent_switch':
                new_intent = response_data.get('new_intent', 'unknown')
                return f"Switching to {new_intent} operation. How can I help you?"
        elif response_type == "no_customers_found":
            criteria = response_data.get('criteria', 'your criteria')
            identification_attempt = response_data.get('identification_attempt', {})
            method = identification_attempt.get('identification_method', 'unknown')
            
            if method == 'direct_id':
                return f"🔍 No customer found with the specified ID in '{criteria}'. Please check the customer ID and try again."
            elif method == 'email':
                return f"🔍 No customer found with the email address in '{criteria}'. Please verify the email and try again."
            elif method == 'contextual':
                return f"🔍 No customers found for '{criteria}'. There might not be any recent customers or the reference is unclear."
            else:
                return f"🔍 No customers found matching '{criteria}'. Please provide more specific identification."
        
        return "How can I help you with customer management?"
        
    except Exception as e:
        logger.error(f"[🚀DynamicDeleteFlow] Error generating dynamic response: {e}")
        return "How can I help you?"

async def _handle_intent_switch(context, new_intent, response_content):
    """Handle intent switching to other operations"""
    try:
        if new_intent == 'insert':
            context.query_classification = "CREATE_CUSTOMER"
            context.next = "GenerateInsertSQL"
        elif new_intent == 'update':
            context.query_classification = "UPDATE_CUSTOMER"
            context.next = "GenerateUpdateSQL"
        elif new_intent == 'select':
            context.query_classification = "SEARCH_CUSTOMER"
            context.next = "GenerateSelectSQL"
        else:
            context.next = "GeneralCustomerChat"
        
        context.response = response_content
        return context
        
    except Exception as e:
        logger.error(f"[🚀DynamicDeleteFlow] Error handling intent switch: {e}")
        context.response = "How can I help you?"
        context.next = "CustomerResponse"
        return context

async def _analyze_delete_customer_identification(context):
    """Analyze if customer identification is clear enough for deletion."""
    try:
        message = context.message.lower()
        
        # Check for specific customer identifiers
        clear_indicators = [
            r'cus-\d+',  # Customer ID pattern
            r'\b[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}\b',  # Email pattern
            r'\+?[1-9]\d{1,14}',  # Phone pattern
            'last customer', 'latest customer', 'most recent customer'
        ]
        
        has_clear_identifier = any(re.search(pattern, message) for pattern in clear_indicators)
        
        # Use LLM for deeper analysis
        analysis_prompt = f"""
Analyze this customer deletion request for clarity:

User Message: "{context.message}"

Determine:
1. Is the customer identification clear and specific?
2. Can we uniquely identify which customer(s) to delete?
3. What clarification is needed if unclear?

Return JSON:
{{
    "is_clear": boolean,
    "confidence": float (0-1),
    "missing_info": ["list of missing information"],
    "suggested_questions": ["list of clarifying questions"]
}}
"""
        
        analysis_response = await llm_service.chat([
            {"role": "system", "content": analysis_prompt},
            {"role": "user", "content": context.message}
        ])
        
        try:
            analysis = json.loads(analysis_response)
            # Combine rule-based and LLM analysis
            analysis['is_clear'] = has_clear_identifier and analysis.get('is_clear', False)
            return analysis
        except json.JSONDecodeError:
            return {
                'is_clear': has_clear_identifier,
                'confidence': 0.7 if has_clear_identifier else 0.3,
                'missing_info': ['customer identification'],
                'suggested_questions': ['Which specific customer would you like to delete?']
            }
            
    except Exception as e:
        logger.error(f"[DeleteFlow] Error analyzing customer identification: {e}")
        return {
            'is_clear': False,
            'confidence': 0.0,
            'missing_info': ['customer identification'],
            'suggested_questions': ['Which customer would you like to delete?']
        }

async def _generate_delete_customer_selection_prompt(context, clarity_analysis):
    """Generate customer selection prompt for delete operations."""
    try:
        # Get recent customers for examples
        recent_customers_sql = f"""
        SELECT xcus, xemail, xphone, xorg, xfirst, xlast 
        FROM cacus 
        WHERE zid = {context.business_id} 
        ORDER BY xcus DESC 
        LIMIT 5
        """
        
        recent_result = await mcp_client.execute_query(recent_customers_sql, context.business_id)
        customer_examples = []
        
        if isinstance(recent_result, dict) and 'content' in recent_result:
            try:
                parsed = json.loads(recent_result['content'][0]['text'])
                customers = parsed.get('results', [])
                
                for customer in customers:
                    cid = customer.get('xcus', 'Unknown')
                    email = customer.get('xemail', 'No email')
                    org = customer.get('xorg', '')
                    name_parts = [customer.get('xfirst', ''), customer.get('xlast', '')]
                    name = ' '.join(filter(None, name_parts)) or 'No name'
                    
                    example = f"• {cid} - {name} ({email})"
                    if org:
                        example += f" from {org}"
                    customer_examples.append(example)
                        
            except (json.JSONDecodeError, KeyError, IndexError):
                pass
        
        # Build customer selection prompt
        questions = [
            "🗑️ **Customer Deletion - Customer Selection**",
            "",
            "I need to know which specific customer you want to delete.",
            "",
            "**You can identify the customer by:**",
            "• Customer ID (e.g., CUS-000001)",
            "• Email address (e.g., john@example.com)",
            "• Phone number (e.g., +1234567890)",
            "• Organization name (e.g., Acme Corp)",
            "• First/Last name (e.g., John Smith)",
            "• Say 'last customer' for the most recent customer",
            ""
        ]
        
        if customer_examples:
            questions.extend([
                "**Recent Customers:**",
                *customer_examples[:3],  # Show top 3
                ""
            ])
        
        # Add specific clarification based on analysis
        if clarity_analysis.get('suggested_questions'):
            questions.extend([
                "**Clarification needed:**",
                *[f"• {q}" for q in clarity_analysis['suggested_questions'][:2]],
                ""
            ])
        
        questions.extend([
            "⚠️ **Warning: Customer deletion is permanent and cannot be undone!**",
            "",
            "Please specify which customer you want to delete:"
        ])
        
        return "\n".join(questions)
        
    except Exception as e:
        logger.error(f"[DeleteFlow] Error generating customer selection prompt: {e}")
        return "Which customer would you like to delete? Please provide the customer ID or describe the customer."

async def _fetch_customers_for_deletion(context, customer_clarity):
    """Fetch customers for deletion using dynamic LLM-generated SQL with vector DB context."""
    try:
        # Get vector search context for customer schema
        vector_results = await vector_search_service.search_schemas(
            business_id=context.business_id,
            query=context.message,
            top_k=3
        )
        
        # Build dynamic SQL prompt using vector context
        sql_prompt = await build_customer_sql_prompt(
            context.message, 
            context.business_id, 
            vector_results, 
            context.conversation_history,
            operation_type="select_for_delete"
        )
        
        # Generate SQL using LLM
        sql_response = await llm_service.chat([
            {"role": "system", "content": sql_prompt},
            {"role": "user", "content": f"Generate a SELECT query to find customers for deletion based on: {context.message}"}
        ])
        
        # Clean and validate SQL
        sql = clean_sql_from_llm(sql_response)
        
        if not sql or not sql.strip().lower().startswith('select'):
            logger.warning(f"[DeleteFlow] Invalid SQL generated: {sql}")
            return None
        
        # Execute the dynamically generated query
        result = await mcp_client.execute_query(sql, context.business_id)
        
        if isinstance(result, dict) and 'content' in result:
            parsed = json.loads(result['content'][0]['text'])
            customers = parsed.get('results', [])
            return customers if customers else None
            
    except Exception as e:
        logger.error(f"[DeleteFlow] Error fetching customers for deletion: {e}")
        return None

async def _build_dynamic_delete_sql_prompt(context):
    """Build dynamic SQL prompt for delete operations with enhanced context."""
    
    # Get schema context
    schema_info = "\n".join(context.schema_context) if context.schema_context else "Customer table: cacus"
    
    sql_prompt = f"""
You are a SQL expert generating DELETE queries for customer data.

Database Schema:
{schema_info}

Business Context:
- Business ID (zid): {context.business_id} (ALWAYS include in WHERE clause)
- Customer table: cacus
- Customer ID format: CUS-XXXXXX

User Request: "{context.message}"

Conversation Context:
{' '.join([msg.content for msg in context.conversation_history[-3:]])}

Generate a DELETE SQL query that:
1. ALWAYS includes WHERE zid = {context.business_id}
2. Safely identifies the customer(s) to delete
3. Uses proper SQL syntax for PostgreSQL
4. Handles customer identification (ID, email, phone, name, organization)

Examples:
- "delete customer CUS-000123" → DELETE FROM cacus WHERE zid = {context.business_id} AND xcus = 'CUS-000123';
- "delete customer with email john@example.com" → DELETE FROM cacus WHERE zid = {context.business_id} AND xemail = 'john@example.com';
- "delete last customer" → DELETE FROM cacus WHERE zid = {context.business_id} AND xcus = (SELECT xcus FROM cacus WHERE zid = {context.business_id} ORDER BY xcus DESC LIMIT 1);

Return only the SQL query, no explanations.
"""
    
    return sql_prompt

async def _generate_delete_preview_message(customers):
    """Generate enhanced preview message for customers to be deleted."""
    try:
        if len(customers) == 1:
            customer = customers[0]
            preview_lines = ["**Customer to be deleted:**", ""]
            
            # Format customer details
            details = []
            if customer.get('xcus'):
                details.append(f"🆔 **Customer ID:** {customer['xcus']}")
            if customer.get('xfirst') or customer.get('xlast'):
                name = f"{customer.get('xfirst', '')} {customer.get('xlast', '')}".strip()
                details.append(f"👤 **Name:** {name}")
            if customer.get('xemail'):
                details.append(f"📧 **Email:** {customer['xemail']}")
            if customer.get('xphone'):
                details.append(f"📞 **Phone:** {customer['xphone']}")
            if customer.get('xorg'):
                details.append(f"🏢 **Organization:** {customer['xorg']}")
            
            preview_lines.extend(details)
            
        else:
            preview_lines = [f"**{len(customers)} Customers to be deleted:**", ""]
            
            for i, customer in enumerate(customers[:5], 1):
                cid = customer.get('xcus', 'Unknown')
                email = customer.get('xemail', 'No email')
                name_parts = [customer.get('xfirst', ''), customer.get('xlast', '')]
                name = ' '.join(filter(None, name_parts))
                
                if name:
                    preview_lines.append(f"{i}. **{cid}** - {name} ({email})")
                else:
                    preview_lines.append(f"{i}. **{cid}** - {email}")
            
            if len(customers) > 5:
                preview_lines.append(f"... and **{len(customers) - 5} more customers**")
        
        return "\n".join(preview_lines)
        
    except Exception as e:
        logger.error(f"[DeleteFlow] Error generating preview message: {e}")
        return f"Preview: {len(customers)} customer(s) selected for deletion"

async def _check_delete_flow_interruption(context):
    """Check for flow interruption during delete operations."""
    try:
        interruption = await flow_interruption_handler.check_interruption(
            context.message, 
            context.conversation_history,
            current_flow="delete"
        )
        
        if interruption['is_interrupted']:
            logger.info(f"[DeleteFlow] Flow interrupted: {interruption['new_intent']}")
            
            # Clear delete flow state
            context = _clear_delete_flow_state(context)
            
            # Handle the interruption
            if interruption['new_intent'] in ['select', 'search', 'list']:
                context.query_classification = "SEARCH_CUSTOMER"
                context.next = "GenerateSelectSQL"
            elif interruption['new_intent'] == 'update':
                context.query_classification = "UPDATE_CUSTOMER"
                context.next = "GenerateUpdateSQL"
            elif interruption['new_intent'] == 'insert':
                context.query_classification = "CREATE_CUSTOMER"
                context.next = "GenerateCustomerSQL"
            else:
                context.next = "GeneralCustomerChat"
            
            return {
                'is_interrupted': True,
                'response': context.model_dump()
            }
        
        return {'is_interrupted': False}
        
    except Exception as e:
        logger.error(f"[DeleteFlow] Error checking interruption: {e}")
        return {'is_interrupted': False}

def _clear_delete_flow_state(context):
    """Clear delete flow specific state."""
    # Clear delete-specific fields
    if hasattr(context, 'customers_to_delete'):
        delattr(context, 'customers_to_delete')
    if hasattr(context, 'delete_preview_message'):
        delattr(context, 'delete_preview_message')
    if hasattr(context, 'delete_phase'):
        delattr(context, 'delete_phase')
    
    # Clear general flow state
    context.pause_reason = None
    context.pause_message = None
    context.current_flow = None
    
    return context
