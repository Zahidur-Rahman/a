"""
Streamlined Customer Chat Graph using separated flows
"""
from langgraph.graph import StateGraph
from backend.app.services.mistral_llm_service import MistralLLMService
from backend.app.services.vector_search import FaissVectorSearchService
from backend.app.mcp.mcp_client import MCPClient
from backend.app.agents.customer_agent.customer_query_classifier import CustomerQueryClassifier
from backend.app.agents.customer_agent.secure_customer_helpers import (
    format_customer_result_secure
)
from backend.app.agents.customer_agent.customer_chat_helpers import (
    get_customer_schema_context, build_customer_system_prompt
)
from backend.app.agents.customer_agent.negative_vibe_detector import negative_vibe_detector
from backend.app.agents.customer_agent.flow_interruption_handler import flow_interruption_handler
from backend.app.models.chat_graph_state import ChatGraphState
from backend.app.models.conversation import ChatMessage

# Import flow modules
from backend.app.agents.customer_agent.flows.select_flow import (
    vector_search_node, generate_select_sql_node, select_dependency_check_node, execute_select_sql_node, 
    reactive_questioning_node, handle_clarification_response_node
)
from backend.app.agents.customer_agent.flows.insert_flow import (
    generate_insert_sql_node, validate_insert_fields_node, collect_missing_fields_node,
    generate_customer_id_node, execute_insert_sql_node
)
# Update flow now handled by perfect_update_flow
from backend.app.agents.customer_agent.flows.perfect_update_flow import PerfectUpdateFlow

async def perfect_update_flow_node(context):
    """Dedicated node for perfect update flow"""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    print(f"[PerfectUpdateFlowNode] PRINT TEST - Entering perfect update flow node")
    logger.error(f"[PerfectUpdateFlowNode] ERROR TEST - Entering perfect update flow node")
    logger.info(f"[PerfectUpdateFlow] Entering perfect update flow node")
    
    # Call the perfect update flow
    perfect_update_flow = PerfectUpdateFlow()
    result = await perfect_update_flow.execute_perfect_update_flow(context)
    
    # Ensure the result has proper routing and is a dict
    if isinstance(result, dict):
        if 'next' not in result or not result['next']:
            result['next'] = "PauseNode" if result.get('pause_reason') else "CustomerResponse"
        return result
    else:
        # If it returns a context object, convert to dict
        if not hasattr(result, 'next') or not result.next:
            result.next = "PauseNode" if getattr(result, 'pause_reason', None) else "CustomerResponse"
        return result.model_dump()

async def perfect_update_flow_handler_node(context):
    """Handle responses for perfect update flow"""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    print(f"[PerfectUpdateFlowHandler] PRINT TEST - Handling update response for pause_reason: {getattr(context, 'pause_reason', None)}")
    logger.error(f"[PerfectUpdateFlowHandler] ERROR TEST - Handling update response for pause_reason: {getattr(context, 'pause_reason', None)}")
    logger.info(f"[PerfectUpdateFlowHandler] Handling update response for pause_reason: {getattr(context, 'pause_reason', None)}")
    
    # Call the perfect update flow response handler
    perfect_update_flow = PerfectUpdateFlow()
    result = await perfect_update_flow.handle_update_response(context)
    
    # Ensure proper routing and dict return
    if isinstance(result, dict):
        if 'next' not in result or not result['next']:
            result['next'] = "PauseNode" if result.get('pause_reason') else "CustomerResponse"
        return result
    else:
        # If it returns a context object, convert to dict
        if not hasattr(result, 'next') or not result.next:
            result.next = "PauseNode" if getattr(result, 'pause_reason', None) else "CustomerResponse"
        return result.model_dump()

from backend.app.agents.customer_agent.flows.delete_flow import (
    generate_delete_sql_node, validate_delete_customer_exists_node,
    confirm_delete_operation_node, execute_delete_sql_node,
    process_customer_selection_for_delete_node, process_delete_confirmation_node
)

import logging
import json
import re

logger = logging.getLogger(__name__)

# Initialize services
llm_service = MistralLLMService()
customer_classifier = CustomerQueryClassifier()
vector_search_service = FaissVectorSearchService()
mcp_client = MCPClient(script_path="backend/app/mcp/server_enhanced.py")

def ensure_chat_messages(messages):
    """Convert messages to ChatMessage objects if needed."""
    if not messages:
        return []
    return [msg if isinstance(msg, ChatMessage) else ChatMessage.model_validate(msg) for msg in messages]

# --- Core Routing and Classification Nodes ---

async def classify_customer_query(context):
    """Enhanced LLM-powered customer query classification with reduced complexity."""
    print(f"[CustomerClassify] PRINT TEST - Starting enhanced classification for: {context.message}")
    logger.error(f"[CustomerClassify] ERROR TEST - Starting enhanced classification for: {context.message}")
    logger.info(f"[CustomerClassify] Enhanced classification for: {context.message}")
    
    try:
        # Build richer context for better classification
        conversation_context = ""
        if context.conversation_history:
            recent_messages = context.conversation_history[-4:]
            conversation_context = "\n".join([
                f"{msg.role}: {msg.content[:100]}..." if len(msg.content) > 100 else f"{msg.role}: {msg.content}"
                for msg in recent_messages
            ])
        
        # Enhanced classification prompt
        classification_prompt = f"""You are an expert at understanding customer management requests with business context awareness.

CONVERSATION CONTEXT:
{conversation_context}

CURRENT MESSAGE: "{context.message}"

Classify the user's intent for customer operations:

**OPERATION TYPES:**
1. **CREATE_CUSTOMER**: Add new customer ("add customer", "create customer", "new customer", "register customer")
2. **SEARCH_CUSTOMER**: Find/view customers ("show customers", "find customer", "list customers", "give me customers", "get customers", "display customers", "see customers")
3. **UPDATE_CUSTOMER**: Modify customer data ("update customer", "change phone", "modify email")
4. **DELETE_CUSTOMER**: Remove customer ("delete customer", "remove customer")
5. **GENERAL_CUSTOMER**: General customer discussion or unclear intent

**IMPORTANT CLASSIFICATION RULES:**
- "give me" + customer = SEARCH_CUSTOMER (showing/retrieving existing customers)
- "get me" + customer = SEARCH_CUSTOMER (showing/retrieving existing customers)
- "show me" + customer = SEARCH_CUSTOMER (displaying existing customers)
- "add" + customer = CREATE_CUSTOMER (creating new customer)
- "create" + customer = CREATE_CUSTOMER (creating new customer)
- "new" + customer = CREATE_CUSTOMER (creating new customer)

**CONTEXT UNDERSTANDING:**
- "his phone" after customer discussion = UPDATE_CUSTOMER
- "last customer" = positional reference for any operation
- "delete this" in customer context = DELETE_CUSTOMER
- "show me details" = SEARCH_CUSTOMER
- Providing data (phone, email) in update context = continuing UPDATE_CUSTOMER

**CLARITY ASSESSMENT:**
- Clear: Specific operation with sufficient information
- Unclear: Vague request needing clarification

Respond with JSON:
{{
    "action": "CREATE_CUSTOMER|SEARCH_CUSTOMER|UPDATE_CUSTOMER|DELETE_CUSTOMER|GENERAL_CUSTOMER",
    "is_clear": boolean,
    "confidence": 0.0-1.0,
    "reasoning": "explanation of classification",
    "context_used": "how conversation context influenced decision",
    "needs_clarification": boolean
}}

Examples:
- "give me a customer" → {{"action": "SEARCH_CUSTOMER", "is_clear": false}} (needs search criteria)
- "give me customers" → {{"action": "SEARCH_CUSTOMER", "is_clear": false}} (needs search criteria)
- "add a customer" → {{"action": "CREATE_CUSTOMER", "is_clear": false}} (needs customer data)
- "update CUS-123456 email" → {{"action": "UPDATE_CUSTOMER", "is_clear": true}}
- "show recent customers" → {{"action": "SEARCH_CUSTOMER", "is_clear": true}}
- "update customer" → {{"action": "UPDATE_CUSTOMER", "is_clear": false}} (needs which customer)
- "his phone is 123456789" (in update context) → {{"action": "UPDATE_CUSTOMER", "is_clear": true}}"""
        
        response = await llm_service.chat([
            {"role": "system", "content": "You are a customer operation classifier. Always respond with valid JSON."},
            {"role": "user", "content": classification_prompt}
        ])
        
        try:
            import json
            # Enhanced JSON parsing to handle markdown code blocks
            classification = _parse_llm_json_response(response)
            
            # Extract the action and validate
            valid_actions = ["CREATE_CUSTOMER", "SEARCH_CUSTOMER", "UPDATE_CUSTOMER", "DELETE_CUSTOMER", "GENERAL_CUSTOMER"]
            action = classification.get('action', 'GENERAL_CUSTOMER')
            
            if action not in valid_actions:
                logger.warning(f"[CustomerClassify] Invalid action '{action}', defaulting to GENERAL_CUSTOMER")
                action = 'GENERAL_CUSTOMER'
            
            context.query_classification = action
            context.is_query_clear = classification.get('is_clear', False)
            context.classification_confidence = classification.get('confidence', 0.5)
            context.classification_reasoning = classification.get('reasoning', '')
            
            logger.info(f"[CustomerClassify] Enhanced classification result: {action} (clear: {context.is_query_clear}, confidence: {context.classification_confidence})")
            return context.model_dump()
            
        except json.JSONDecodeError as e:
            logger.error(f"[CustomerClassify] JSON parsing error: {e}, response: {response}")
            # Fallback to simple keyword classification
            context.query_classification = await _fallback_classification(context.message)
            context.is_query_clear = True
            return context.model_dump()
            
    except Exception as e:
        logger.error(f"[CustomerClassify] Error in enhanced classification: {e}")
        context.query_classification = "GENERAL_CUSTOMER"
        context.is_query_clear = False
        return context.model_dump()

async def _fallback_classification(message: str) -> str:
    """Simple fallback classification for when LLM fails"""
    message_lower = message.lower()
    
    # Check for search/retrieval patterns first (including "give me", "get me")
    if any(word in message_lower for word in ['find', 'search', 'show', 'list', 'display', 'give me', 'get me', 'see']):
        return 'SEARCH_CUSTOMER'
    elif any(word in message_lower for word in ['add', 'create', 'new customer', 'register']):
        return 'CREATE_CUSTOMER'
    elif any(word in message_lower for word in ['update', 'modify', 'change', 'edit']):
        return 'UPDATE_CUSTOMER'
    elif any(word in message_lower for word in ['delete', 'remove']):
        return 'DELETE_CUSTOMER'
    else:
        return 'GENERAL_CUSTOMER'

async def route_customer_action(context):
    """Route to appropriate customer action based on classification and state with enhanced logic."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    logger.info(f"[CustomerRoute] Routing for classification: {context.query_classification}")
    
    # Enhanced negative vibe detection using LLM with current flow context
    current_flow = getattr(context, 'current_flow', None) or context.query_classification.lower()
    negative_vibe = await negative_vibe_detector.detect_negative_vibe(
        context.message, context.conversation_history, current_flow
    )
    
    if negative_vibe['is_negative']:
        # Clear all state and respond appropriately
        context.pause_reason = None
        context.pause_message = None
        context.confirm = None
        context.resume_from_pause = None
        context.sql = None
        context.incomplete_sql = None
        context.missing_mandatory_fields = None
        context.collected_field_values = None
        context.customer_action = None
        context.reactive_questioning_active = False
        context.current_flow = None
        context.negative_vibe_detected = True
        
        context.response = negative_vibe['suggested_response']
        context.next = "CustomerResponse"
        return context.model_dump()
    
    # Check for pause/resume state - include perfect update flow pause reasons
    if hasattr(context, 'pause_reason') and context.pause_reason:
        update_flow_pause_reasons = ['confirm_delete', 'confirm_update', 'missing_mandatory_fields', 'clarification_needed', 
                                    'customer_selection_needed', 'field_selection_needed', 'customer_identification_needed',
                                    'multiple_customers_selection', 'update_confirmation', 'bulk_update_confirmation']
        
        # CRITICAL FIX: Check if this is actually a NEW query that should override the pause
        # Check if user is asking for a completely different operation
        message_lower = context.message.lower().strip()
        
        # If user is asking for SELECT operations, clear pause and route to SELECT
        select_keywords = ['give me', 'show me', 'get me', 'find', 'search', 'list', 'display']
        is_select_request = any(keyword in message_lower for keyword in select_keywords) and 'customer' in message_lower
        
        # Enhanced contextual reference detection for updates
        contextual_update_patterns = ['his ', 'her ', 'this customer', 'that customer', 'their ', 'its ']
        is_contextual_update = any(pattern in message_lower for pattern in contextual_update_patterns)
        
        # Field update patterns (status, phone, email, etc.)
        field_update_keywords = ['status', 'phone', 'email', 'name', 'organization', 'address']
        has_field_reference = any(field in message_lower for field in field_update_keywords)
        
        if is_select_request and not any(word in message_lower for word in ['update', 'change', 'modify', 'status', 'field']):
            logger.info(f"[CustomerRoute] NEW SELECT REQUEST detected, clearing pause state: {context.pause_reason}")
            # Clear pause state for new SELECT operation
            context.pause_reason = None
            context.pause_message = None
            context.current_flow = None
            context.query_classification = 'SEARCH_CUSTOMER'
            context.next = "VectorSearch"
            return context.model_dump()
        
        # Handle contextual update references (like "his status to Open")
        elif is_contextual_update and has_field_reference and context.pause_reason in update_flow_pause_reasons:
            logger.info(f"[CustomerRoute] CONTEXTUAL UPDATE detected, continuing with update flow: {context.message}")
            # This is a contextual update, continue with the update flow
            context.next = "ResumeOrClassify"
            return context.model_dump()
        
        if context.pause_reason in update_flow_pause_reasons:
            print(f"[CustomerRoute] PRINT TEST - Resuming from pause: {context.pause_reason}")
            logger.error(f"[CustomerRoute] ERROR TEST - Resuming from pause: {context.pause_reason}")
            logger.info(f"[CustomerRoute] Resuming from pause: {context.pause_reason}")
            context.next = "ResumeOrClassify"
            return context.model_dump()
    
    # Route based on classification
    classification = context.query_classification
    
    if classification in ["SEARCH_CUSTOMER", "LIST_CUSTOMERS", "VECTOR_SEARCH", "DATABASE_QUERY"]:
        if getattr(context, 'is_query_clear', True):
            context.next = "GenerateSelectSQL"
        else:
            context.next = "VectorSearch"
    elif classification == "CREATE_CUSTOMER":
        context.next = "GenerateCustomerSQL"
    elif classification == "UPDATE_CUSTOMER":
        # FIX: Route to a dedicated update node instead of calling the flow directly
        print(f"[CustomerRoute] PRINT TEST - Routing UPDATE_CUSTOMER to PerfectUpdateFlow")
        logger.error(f"[CustomerRoute] ERROR TEST - Routing UPDATE_CUSTOMER to PerfectUpdateFlow")
        context.current_flow = "update"
        context.next = "PerfectUpdateFlow"  # Route to dedicated node
    elif classification == "DELETE_CUSTOMER":
        context.next = "GenerateCustomerSQL"
    elif classification == "GENERAL_CUSTOMER":
        context.next = "GeneralCustomerChat"
    elif classification == "UNCLEAR_QUERY":
        context.next = "VectorSearch"
    else:
        context.next = "VectorSearch"
    
    logger.info(f"[CustomerRoute] Routed to: {context.next}")
    return context.model_dump()

async def customer_dependency_check_node(context):
    """Route to appropriate flow based on SQL operation type."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    sql = context.sql.strip().lower()
    
    if sql.startswith("select"):
        context.next = "SelectDependencyCheck"
    elif sql.startswith("insert"):
        context.next = "ValidateInsertFields"
    elif sql.startswith("update"):
        # Update operations handled by perfect_update_flow
        context.next = "ExecuteCustomerSQL"
    elif sql.startswith("delete"):
        context.next = "ValidateDeleteCustomerExists"
    else:
        # Default to execution for unknown operations
        context.next = "ExecuteCustomerSQL"
    
    logger.info(f"[CustomerDependencyCheck] SQL type detected, routing to: {context.next}")
    return context.model_dump()

async def generate_customer_sql_node(context):
    """Route SQL generation to appropriate flow based on detected operation."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    # Analyze message to determine operation type
    message_lower = context.message.lower()
    
    if any(word in message_lower for word in ['add', 'create', 'insert', 'new customer']):
        return await generate_insert_sql_node(context)
    elif any(word in message_lower for word in ['update', 'modify', 'change', 'edit']):
        # Route to perfect update flow through proper graph routing
        context.next = "PerfectUpdateFlow"
        return context.model_dump()
    elif any(word in message_lower for word in ['delete', 'remove', 'drop']):
        return await generate_delete_sql_node(context)
    else:
        # Default to select for queries
        result = await generate_select_sql_node(context)
        # Ensure routing continues
        if isinstance(result, dict):
            result['next'] = 'SelectDependencyCheck'
            return result
        else:
            result.next = 'SelectDependencyCheck'
            return result.model_dump()

async def execute_customer_sql_node(context):
    """Route SQL execution to appropriate flow based on SQL type."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    sql = context.sql.strip().lower()
    
    if sql.startswith("select"):
        return await execute_select_sql_node(context)
    elif sql.startswith("insert"):
        return await execute_insert_sql_node(context)
    elif sql.startswith("update"):
        # Update operations now handled by perfect_update_flow
        return await perfect_update_flow.execute_confirmed_update(context)
    elif sql.startswith("delete"):
        return await execute_delete_sql_node(context)
    else:
        # Fallback to select execution
        return await execute_select_sql_node(context)

# --- Pause and Resume Logic ---

async def pause_node(context):
    """Handle pause state for confirmations with dynamic messaging."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    logger.info(f"[CustomerPause] Pausing for: {context.pause_reason}")
    
    # Use specific pause message if available, otherwise generate generic one
    if hasattr(context, 'pause_message') and context.pause_message:
        context.response = context.pause_message
    else:
        # Generate appropriate pause message based on reason
        if context.pause_reason == "missing_mandatory_fields":
            # Import and use the enhanced field collection prompt
            from backend.app.agents.customer_agent.flows.insert_flow import _analyze_customer_data_completeness_enhanced, _generate_progressive_data_collection_prompt
            try:
                # Generate enhanced prompt with current field status
                data_analysis = await _analyze_customer_data_completeness_enhanced(context)
                context.response = await _generate_progressive_data_collection_prompt(context, data_analysis)
            except Exception as e:
                logger.error(f"[CustomerPause] Error generating enhanced prompt: {e}")
                context.response = "Please provide the missing mandatory fields to complete the customer creation."
        
        # Enhanced confirmation messages with clear instructions
        elif context.pause_reason == "confirm_delete":
            context.response = """🗑️ **Delete Confirmation**
            
You are about to delete a customer record. This action cannot be undone.

• Type **'confirm'** to proceed with the deletion
• Type **'cancel'** to abort this operation

Are you sure you want to delete this customer?"""
            
        elif context.pause_reason == "confirm_update":
            # Get the list of fields being updated for better context
            updates = getattr(context, 'pending_updates', {})
            update_summary = "\n".join([f"• {field}: {value}" for field, value in updates.items()])
            
            context.response = f"""📝 **Update Confirmation**
            
You are about to update the following fields:

{update_summary}

• Type **'confirm'** to proceed with the update
• Type **'cancel'** to abort this operation

Are you sure you want to update this customer?"""
        
        elif context.pause_reason in ["customer_identification_needed", "customer_selection_needed"]:
            context.response = getattr(context, 'response', """🔍 **Customer Selection Needed**
            
Please specify which customer you'd like to update. You can use:
• Customer ID (e.g., CUS-12345)
• Email address
• Phone number
• Organization name
• Or describe the customer (e.g., 'the one with email xyz@example.com')""")
            
        elif context.pause_reason in ["field_selection_needed", "multiple_customers_selection"]:
            context.response = getattr(context, 'response', """📋 **Additional Information Needed**
            
Please provide the requested information to continue. You can say things like:
• "Update the email to new@example.com"
• "Change the phone number to 123-456-7890"
• "Set the status to Active"

What changes would you like to make?""")
            
        elif context.pause_reason == "update_confirmation":
            context.response = getattr(context, 'response', """✅ **Ready to Update**
            
Your changes are ready to be saved. Please confirm to proceed with the update:
• Type **'confirm'** to save changes
• Type **'cancel'** to discard changes""")
            
        else:
            context.response = """ℹ️ **Action Required**
            
Please provide the necessary information to continue. You can:
• Answer the question above
• Type 'cancel' to stop the current operation
• Or ask for help if you're not sure what to do"""
    
    return context.model_dump()

async def resume_or_classify_node(context):
    """Handle resume logic and user intent analysis with enhanced pause handling."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    logger.info(f"[CustomerResume] Resuming from: {context.pause_reason}")
    logger.info(f"[CustomerResume] User message: '{context.message}'")
    
    # Check for confirmation responses first
    confirmation_triggers = ["yes", "confirm", "proceed", "continue", "ok", "okay"]
    is_confirmation = any(trigger in context.message.lower() for trigger in confirmation_triggers)
    
    # Check for cancellation triggers
    cancel_triggers = ["no", "cancel", "abort", "stop", "nevermind", "never mind", "quit", "exit"]
    is_cancellation = any(trigger in context.message.lower() for trigger in cancel_triggers)
    
    # Handle confirmation flow
    if context.pause_reason == "confirm_update" and is_confirmation:
        logger.info("[CustomerResume] User confirmed update operation")
        context.confirm = True
        context.pause_reason = None
        context.pause_message = None
        context.resume_from_pause = True
        
        # Route to the appropriate flow based on current operation
        if hasattr(context, 'current_flow'):
            if context.current_flow == 'update':
                context.next = "PerfectUpdateFlow"
            else:
                context.next = "GenerateCustomerSQL"
        else:
            context.next = "GenerateCustomerSQL"
            
        return context.model_dump()
    
    # Handle cancellation
    if is_cancellation:
        logger.info("[CustomerResume] User cancelled the operation")
        # Clear all pause-related fields
        context.pause_reason = None
        context.pause_message = None
        context.confirm = None
        context.resume_from_pause = None
        context.sql = None
        context.incomplete_sql = None
        context.missing_mandatory_fields = None
        context.collected_field_values = None
        context.customer_action = None
        context.reactive_questioning_active = False
        context.current_flow = None
        
        context.response = "Operation cancelled. How can I assist you?"
        context.next = "CustomerResponse"
        return context.model_dump()
    
    # If a negative vibe is detected at resume time, cancel immediately
    if getattr(context, 'negative_vibe_detected', False):
        logger.warning("[CustomerResume] Negative vibe detected, cancelling operation")
        context.pause_reason = None
        context.pause_message = None
        context.confirm = None
        context.resume_from_pause = None
        context.sql = None
        context.incomplete_sql = None
        context.missing_mandatory_fields = None
        context.collected_field_values = None
        context.customer_action = None
        context.reactive_questioning_active = False
        context.current_flow = None
        
        context.response = "I noticed some hesitation. Let's start over. How can I help you?"
        context.next = "CustomerResponse"
        return context.model_dump()
        
        context.response = "Operation canceled. How can I help you?"
        context.next = "CustomerResponse"
        return context.model_dump()
    
    # Handle different pause reasons
    if context.pause_reason == "missing_mandatory_fields":
        # Route to field collection
        context.next = "CollectMissingFields"
    elif context.pause_reason in ["confirm_delete", "confirm_update"]:
        # Check for confirmation
        confirm_triggers = ["yes", "y", "confirm", "proceed", "ok", "okay"]
        if any(trigger in context.message.lower() for trigger in confirm_triggers):
            context.next = "ExecuteCustomerSQL"
        else:
            # Treat as cancellation
            context.response = "Operation canceled. How can I help you?"
            context.next = "CustomerResponse"
    elif context.pause_reason == "clarification_needed":
        # Handle clarification response
        context.next = "HandleClarificationResponse"
    elif context.pause_reason in ["customer_identification_needed", "customer_selection_needed", "field_selection_needed", "multiple_customers_selection", "update_confirmation", "bulk_update_confirmation"]:
        # Route to perfect update flow handler node
        print(f"[CustomerResume] PRINT TEST - Routing to PerfectUpdateFlowHandler for pause_reason: {context.pause_reason}")
        logger.error(f"[CustomerResume] ERROR TEST - Routing to PerfectUpdateFlowHandler for pause_reason: {context.pause_reason}")
        logger.info(f"[CustomerResume] Routing to PerfectUpdateFlowHandler for pause_reason: {context.pause_reason}")
        context.next = "PerfectUpdateFlowHandler"
    else:
        # Unknown pause reason, classify as new query
        context.next = "ClassifyCustomerQuery"
    
    return context.model_dump()

async def flow_interruption_check_node(context):
    """Check for flow interruptions and handle dynamic flow switching."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    logger.info(f"[FlowInterruptionCheck] Checking for interruptions in flow: {getattr(context, 'current_flow', 'none')}")
    
    # Get current flow
    current_flow = getattr(context, 'current_flow', 'none')
    
    # Skip interruption check if no current flow or if already in a terminal state
    if current_flow == 'none' or getattr(context, 'pause_reason', None) in ['confirm_delete', 'confirm_update']:
        context.next = "GeneralCustomerChat"
        return context.model_dump()
    
    # Check for flow interruption
    interruption_result = await flow_interruption_handler.detect_flow_interruption(
        context.message, 
        current_flow, 
        context.conversation_history
    )
    
    logger.info(f"[FlowInterruptionCheck] Interruption result: {interruption_result}")
    
    if interruption_result['is_interruption']:
        # Handle flow interruption
        target_flow = interruption_result['target_flow']
        
        if target_flow == 'none':
            # Negative vibe or cancellation
            context.response = interruption_result['suggested_response']
            context.next = "CustomerResponse"
            return context.model_dump()
        
        # Clear state if needed
        if flow_interruption_handler.should_clear_state(current_flow, target_flow):
            context.pause_reason = None
            context.pause_message = None
            context.confirm = None
            context.resume_from_pause = None
            context.sql = None
            context.incomplete_sql = None
            context.missing_mandatory_fields = None
            context.collected_field_values = None
            context.customer_action = None
            context.reactive_questioning_active = False
            context.current_flow = target_flow
        
        # Set response and route to appropriate flow
        context.response = interruption_result['suggested_response'] or f"Switching to {target_flow} operation."
        context.next = "GenerateCustomerSQL"
        return context.model_dump()
    
    # No interruption, continue with current flow
    context.next = "GeneralCustomerChat"
    return context.model_dump()

async def general_customer_chat_node(context):
    """Handle general customer-related conversations."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    logger.info(f"[CustomerGeneralChat] Processing: {context.message}")
    
    # Build system prompt for general customer chat
    system_prompt = build_customer_system_prompt(context.message, context.conversation_history, context.schema_context)
    
    # Generate response using LLM
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": context.message}
    ]
    
    # Add conversation history for context
    for msg in context.conversation_history[-6:]:  # Last 6 messages for context
        messages.insert(-1, {"role": msg.role, "content": msg.content})
    
    context.response = await llm_service.chat(messages)
    
    return context.model_dump()

async def customer_response_node(context):
    """Final response node for customer interactions."""
    if isinstance(context, ChatGraphState):
        context = context.model_dump()
    
    logger.info(f"[CustomerResponse] Final response: {context.get('response', 'No response')[:100]}...")
    return context

# --- Build the Graph ---

def get_fresh_customer_graph():
    """Create a fresh customer chat graph with all nodes and edges."""
    
    builder = StateGraph(ChatGraphState)
    
    # Add core nodes
    builder.add_node("ClassifyCustomerQuery", classify_customer_query)
    builder.add_node("RouteCustomerAction", route_customer_action)
    builder.add_node("FlowInterruptionCheck", flow_interruption_check_node)
    builder.add_node("GeneralCustomerChat", general_customer_chat_node)
    builder.add_node("CustomerResponse", customer_response_node)
    builder.add_node("ResumeOrClassify", resume_or_classify_node)
    builder.add_node("PauseNode", pause_node)
    builder.add_node("PerfectUpdateFlow", perfect_update_flow_node)
    builder.add_node("PerfectUpdateFlowHandler", perfect_update_flow_handler_node)
    
    # Add flow nodes
    builder.add_node("VectorSearch", vector_search_node)
    builder.add_node("ReactiveQuestioning", reactive_questioning_node)
    builder.add_node("HandleClarificationResponse", handle_clarification_response_node)
    builder.add_node("GenerateCustomerSQL", generate_customer_sql_node)
    builder.add_node("CustomerDependencyCheck", customer_dependency_check_node)
    builder.add_node("ExecuteCustomerSQL", execute_customer_sql_node)
    
    # Select flow nodes
    builder.add_node("GenerateSelectSQL", generate_select_sql_node)
    builder.add_node("SelectDependencyCheck", select_dependency_check_node)
    builder.add_node("ExecuteSelectSQL", execute_select_sql_node)
    
    # Insert flow nodes
    builder.add_node("ValidateInsertFields", validate_insert_fields_node)
    builder.add_node("CollectMissingFields", collect_missing_fields_node)
    builder.add_node("GenerateCustomerID", generate_customer_id_node)
    builder.add_node("ExecuteInsertSQL", execute_insert_sql_node)
    
    # Update flow now handled by perfect_update_flow - no separate nodes needed
    
    # Delete flow nodes
    builder.add_node("ValidateDeleteCustomerExists", validate_delete_customer_exists_node)
    builder.add_node("ProcessCustomerSelectionForDelete", process_customer_selection_for_delete_node)
    builder.add_node("ProcessDeleteConfirmation", process_delete_confirmation_node)
    builder.add_node("ConfirmDeleteOperation", confirm_delete_operation_node)
    builder.add_node("ExecuteDeleteSQL", execute_delete_sql_node)
    
    # Add edges - ensure single path execution
    builder.add_edge("ClassifyCustomerQuery", "RouteCustomerAction")
    
    # Main routing
    builder.add_conditional_edges(
        "RouteCustomerAction",
        lambda x: x.get("next") if isinstance(x, dict) else getattr(x, "next", None),
        {
            "VectorSearch": "VectorSearch",
            "GenerateSelectSQL": "GenerateSelectSQL",
            "GenerateCustomerSQL": "GenerateCustomerSQL",
            "GeneralCustomerChat": "FlowInterruptionCheck",
            "ResumeOrClassify": "ResumeOrClassify",
            "PauseNode": "PauseNode",
            "CustomerResponse": "CustomerResponse",
            "PerfectUpdateFlow": "PerfectUpdateFlow",
            "PerfectUpdateFlowHandler": "PerfectUpdateFlowHandler"
        }
    )
    
    # Flow interruption check routing
    builder.add_conditional_edges(
        "FlowInterruptionCheck",
        lambda x: x.get("next") if isinstance(x, dict) else getattr(x, "next", None),
        {
            "GenerateCustomerSQL": "GenerateCustomerSQL",
            "GeneralCustomerChat": "GeneralCustomerChat",
            "CustomerResponse": "CustomerResponse"
        }
    )
    
    # Vector search routing
    builder.add_conditional_edges(
        "VectorSearch",
        lambda x: x.get("next") if isinstance(x, dict) else getattr(x, "next", None),
        {
            "ReactiveQuestioning": "ReactiveQuestioning",
            "GenerateSelectSQL": "GenerateSelectSQL",
            "CustomerResponse": "CustomerResponse"
        }
    )
    
    # Reactive questioning flow
    builder.add_conditional_edges(
        "ReactiveQuestioning",
        lambda x: x.get("next") if isinstance(x, dict) else getattr(x, "next", None),
        {
            "PauseNode": "PauseNode",
            "GenerateSelectSQL": "GenerateSelectSQL",
            "CustomerResponse": "CustomerResponse"
        }
    )
    
    # Handle clarification response
    builder.add_conditional_edges(
        "HandleClarificationResponse",
        lambda x: x.get("next") if isinstance(x, dict) else getattr(x, "next", None),
        {
            "ReactiveQuestioning": "ReactiveQuestioning",
            "GenerateSelectSQL": "GenerateSelectSQL",
            "CustomerResponse": "CustomerResponse"
        }
    )
    
    # SQL generation routing
    builder.add_conditional_edges(
        "GenerateCustomerSQL",
        lambda x: x.get("next") if isinstance(x, dict) else getattr(x, "next", None),
        {
            "CustomerDependencyCheck": "CustomerDependencyCheck",
            "SelectDependencyCheck": "SelectDependencyCheck",
            "PauseNode": "PauseNode",
            "CustomerResponse": "CustomerResponse"
        }
    )
    
    builder.add_edge("GenerateSelectSQL", "SelectDependencyCheck")
    builder.add_edge("SelectDependencyCheck", "ExecuteSelectSQL")
    
    # Dependency check routing
    builder.add_conditional_edges(
        "CustomerDependencyCheck",
        lambda x: x.get("next") if isinstance(x, dict) else getattr(x, "next", None),
        {
            "SelectDependencyCheck": "SelectDependencyCheck",
            "ValidateInsertFields": "ValidateInsertFields",
            "ValidateDeleteCustomerExists": "ValidateDeleteCustomerExists",
            "ExecuteCustomerSQL": "ExecuteCustomerSQL",
            "CustomerResponse": "CustomerResponse"
        }
    )
    
    # Select flow
    builder.add_conditional_edges(
        "SelectDependencyCheck",
        lambda x: x.get("next") if isinstance(x, dict) else getattr(x, "next", None),
        {
            "ExecuteSelectSQL": "ExecuteSelectSQL",
            "CustomerResponse": "CustomerResponse"
        }
    )
    
    # Insert flow
    builder.add_conditional_edges(
        "ValidateInsertFields",
        lambda x: x.get("next") if isinstance(x, dict) else getattr(x, "next", None),
        {
            "PauseNode": "PauseNode",
            "CollectMissingFields": "CollectMissingFields",
            "GenerateCustomerID": "GenerateCustomerID",
            "CustomerResponse": "CustomerResponse"
        }
    )
    
    builder.add_conditional_edges(
        "CollectMissingFields",
        lambda x: x.get("next") if isinstance(x, dict) else getattr(x, "next", None),
        {
            "ValidateInsertFields": "ValidateInsertFields",
            "PauseNode": "PauseNode",
            "CustomerResponse": "CustomerResponse"
        }
    )
    
    builder.add_conditional_edges(
        "GenerateCustomerID",
        lambda x: x.get("next") if isinstance(x, dict) else getattr(x, "next", None),
        {
            "ExecuteInsertSQL": "ExecuteInsertSQL",
            "CustomerResponse": "CustomerResponse"
        }
    )
    
    # Perfect Update Flow routing
    builder.add_conditional_edges(
        "PerfectUpdateFlow",
        lambda x: x.get("next") if isinstance(x, dict) else getattr(x, "next", None),
        {
            "PauseNode": "PauseNode",
            "CustomerResponse": "CustomerResponse",
            "PerfectUpdateFlowHandler": "PerfectUpdateFlowHandler"
        }
    )
    
    builder.add_conditional_edges(
        "PerfectUpdateFlowHandler",
        lambda x: x.get("next") if isinstance(x, dict) else getattr(x, "next", None),
        {
            "PauseNode": "PauseNode",
            "CustomerResponse": "CustomerResponse",
            "PerfectUpdateFlow": "PerfectUpdateFlow"
        }
    )
    
    # Delete flow
    builder.add_conditional_edges(
        "ValidateDeleteCustomerExists",
        lambda x: x.get("next") if isinstance(x, dict) else getattr(x, "next", None),
        {
            "ProcessCustomerSelectionForDelete": "ProcessCustomerSelectionForDelete",
            "ConfirmDeleteOperation": "ConfirmDeleteOperation",
            "PauseNode": "PauseNode",
            "CustomerResponse": "CustomerResponse"
        }
    )
    
    builder.add_conditional_edges(
        "ProcessCustomerSelectionForDelete",
        lambda x: x.get("next") if isinstance(x, dict) else getattr(x, "next", None),
        {
            "ConfirmDeleteOperation": "ConfirmDeleteOperation",
            "PauseNode": "PauseNode",
            "CustomerResponse": "CustomerResponse"
        }
    )
    
    builder.add_conditional_edges(
        "ProcessDeleteConfirmation",
        lambda x: x.get("next") if isinstance(x, dict) else getattr(x, "next", None),
        {
            "ExecuteDeleteSQL": "ExecuteDeleteSQL",
            "PauseNode": "PauseNode",
            "CustomerResponse": "CustomerResponse"
        }
    )
    
    builder.add_conditional_edges(
        "ConfirmDeleteOperation",
        lambda x: x.get("next") if isinstance(x, dict) else getattr(x, "next", None),
        {
            "ProcessDeleteConfirmation": "ProcessDeleteConfirmation",
            "PauseNode": "PauseNode",
            "ExecuteDeleteSQL": "ExecuteDeleteSQL",
            "CustomerResponse": "CustomerResponse"
        }
    )
    
    
    # Resume logic
    builder.add_conditional_edges(
        "ResumeOrClassify",
        lambda x: x.get("next") if isinstance(x, dict) else getattr(x, "next", None),
        {
            "ClassifyCustomerQuery": "ClassifyCustomerQuery",
            "ExecuteCustomerSQL": "ExecuteCustomerSQL",
            "CollectMissingFields": "CollectMissingFields",
            "HandleClarificationResponse": "HandleClarificationResponse",
            "GenerateCustomerSQL": "GenerateCustomerSQL",
            "PauseNode": "PauseNode",
            "CustomerResponse": "CustomerResponse",
            "PerfectUpdateFlowHandler": "PerfectUpdateFlowHandler",
        }
    )
    
    # All terminal nodes lead to response
    builder.add_edge("ExecuteCustomerSQL", "CustomerResponse")
    builder.add_edge("ExecuteSelectSQL", "CustomerResponse")
    builder.add_edge("ExecuteInsertSQL", "CustomerResponse")
    builder.add_edge("ExecuteDeleteSQL", "CustomerResponse")
    builder.add_edge("GeneralCustomerChat", "CustomerResponse")
    builder.add_edge("PauseNode", "CustomerResponse")
    
    # Set entry and exit points
    builder.set_entry_point("ClassifyCustomerQuery")
    builder.set_finish_point("CustomerResponse")
    
    # Compile without debug mode to avoid channel conflicts
    return builder.compile()

def _parse_llm_json_response(response: str) -> dict:
    """Parse JSON response from LLM, handling markdown code blocks and other formatting issues."""
    import json
    import re
    
    # Clean the response
    response = response.strip()
    
    # Remove markdown code blocks
    if response.startswith('```json'):
        response = response[7:]  # Remove ```json
    elif response.startswith('```'):
        response = response[3:]   # Remove ```
    
    if response.endswith('```'):
        response = response[:-3]  # Remove ending ```
    
    # Remove any extra whitespace
    response = response.strip()
    
    # Try to extract JSON if it's embedded in other text
    json_match = re.search(r'\{.*\}', response, re.DOTALL)
    if json_match:
        response = json_match.group(0)
    
    try:
        return json.loads(response)
    except json.JSONDecodeError as e:
        logger.error(f"[JSONParser] Failed to parse JSON: {e}, cleaned response: {response[:200]}...")
        # Return a default fallback structure
        return {
            'action': 'GENERAL_CUSTOMER',
            'is_clear': False,
            'confidence': 0.3,
            'reasoning': 'JSON parsing failed, using fallback',
            'context_used': 'none',
            'needs_clarification': True
        }

# Create the graph instance
print("[CustomerChatGraph] PRINT TEST - Creating customer_chat_graph instance")
customer_chat_graph = get_fresh_customer_graph()
print("[CustomerChatGraph] PRINT TEST - customer_chat_graph created successfully")
