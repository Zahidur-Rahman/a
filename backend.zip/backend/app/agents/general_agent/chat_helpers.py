def build_system_prompt(context, conversation_history, schema_context):
    schema_text = ""
    if schema_context:
        for schema in schema_context:
            schema_text += f"\nTable: {schema.get('table_name', 'Unknown')}\n"
            schema_text += f"Description: {schema.get('schema_description', 'No description')}\n"
            schema_text += "Columns:\n"
            for col in schema.get('columns', []):
                col_name = col.get('name', 'Unknown')
                col_type = col.get('type', 'Unknown')
                col_desc = col.get('description', 'No description')
                schema_text += f"  - {col_name}: {col_type} ({col_desc})\n"
            
            # Highlight primary keys and foreign keys
            primary_keys = []
            foreign_keys = []
            if schema.get('relationships'):
                schema_text += "Relationships:\n"
                for rel in schema.get('relationships', []):
                    rel_type = rel.get('relationship_type', 'unknown')
                    if rel_type == 'primary_key':
                        primary_keys.append(rel.get('from_column', 'Unknown'))
                        schema_text += f"  - PRIMARY KEY: {rel.get('from_column', 'Unknown')}\n"
                    elif rel_type == 'foreign_key':
                        foreign_keys.append(rel.get('from_column', 'Unknown'))
                        schema_text += f"  - FOREIGN KEY: {rel.get('from_column', 'Unknown')} -> {rel.get('referenced_table', 'Unknown')}.{rel.get('referenced_column', 'Unknown')}\n"
                    else:
                        schema_text += f"  - {rel.get('from_table', 'Unknown')}.{rel.get('from_column', 'Unknown')} -> {rel.get('to_table', 'Unknown')}.{rel.get('to_column', 'Unknown')}\n"
            
            if primary_keys:
                schema_text += f"PRIMARY KEYS: {', '.join(primary_keys)}\n"
            if foreign_keys:
                schema_text += f"FOREIGN KEYS: {', '.join(foreign_keys)}\n"
            schema_text += "\n"
    else:
        schema_text = "No relevant schema context found."

    system_prompt = (
        "You are a friendly AI assistant for business users. Help with questions and data.\n\n"
        f"DATA:\n{schema_text}\n\n"
        "CONVERSATION:\n"
    )
    for msg in conversation_history:
        role = msg.get('role', 'unknown') if isinstance(msg, dict) else getattr(msg, 'role', 'unknown')
        content = msg.get('content', '') if isinstance(msg, dict) else getattr(msg, 'content', '')
        system_prompt += f"{role.upper()}: {content}\n"
    system_prompt += (
        f"\nREQUEST: {context.message}\n\n"
        "GUIDELINES:\n"
        "- Be friendly and concise\n"
        "- Ask for clarification if needed\n"
        "- Use schema and conversation context\n"
        "- Confirm before data changes\n"
        "- Provide helpful guidance\n"
        "- Maintain professional tone\n"
    )
    return system_prompt

def build_sql_prompt(context, conversation_history, schema_context):
    schema_text = ""
    if schema_context:
        for schema in schema_context:
            schema_text += f"\nTable: {schema.get('table_name', 'Unknown')}\n"
            schema_text += f"Description: {schema.get('schema_description', 'No description')}\n"
            schema_text += "Columns:\n"
            for col in schema.get('columns', []):
                col_name = col.get('name', 'Unknown')
                col_type = col.get('type', 'Unknown')
                col_desc = col.get('description', 'No description')
                schema_text += f"  - {col_name}: {col_type} ({col_desc})\n"
            
            # Highlight primary keys and foreign keys
            primary_keys = []
            foreign_keys = []
            if schema.get('relationships'):
                schema_text += "Relationships:\n"
                for rel in schema.get('relationships', []):
                    rel_type = rel.get('relationship_type', 'unknown')
                    if rel_type == 'primary_key':
                        primary_keys.append(rel.get('from_column', 'Unknown'))
                        schema_text += f"  - PRIMARY KEY: {rel.get('from_column', 'Unknown')}\n"
                    elif rel_type == 'foreign_key':
                        foreign_keys.append(rel.get('from_column', 'Unknown'))
                        schema_text += f"  - FOREIGN KEY: {rel.get('from_column', 'Unknown')} -> {rel.get('referenced_table', 'Unknown')}.{rel.get('referenced_column', 'Unknown')}\n"
                    else:
                        schema_text += f"  - {rel.get('from_table', 'Unknown')}.{rel.get('from_column', 'Unknown')} -> {rel.get('to_table', 'Unknown')}.{rel.get('to_column', 'Unknown')}\n"
            
            if primary_keys:
                schema_text += f"PRIMARY KEYS: {', '.join(primary_keys)}\n"
            if foreign_keys:
                schema_text += f"FOREIGN KEYS: {', '.join(foreign_keys)}\n"
            schema_text += "\n"
    else:
        schema_text = "No relevant schema context found."

    sql_prompt = (
        "You are an expert SQL assistant for PostgreSQL. Convert natural language to safe SQL queries.\n\n"
        f"SCHEMAS:\n{schema_text}\n"
        "CONVERSATION:\n"
    )
    for msg in conversation_history:
        role = msg.get('role', 'unknown') if isinstance(msg, dict) else getattr(msg, 'role', 'unknown')
        content = msg.get('content', '') if isinstance(msg, dict) else getattr(msg, 'content', '')
        sql_prompt += f"{role.upper()}: {content}\n"
    sql_prompt += (
        f"\nREQUEST: {context.message}\n"
        "RULES:\n"
        "- NO dummy data (use '' for empty values)\n"
        "- Use SELECT/INSERT/UPDATE/DELETE only\n"
        "- Always use WHERE for UPDATE/DELETE\n"
        "- For INSERT: VALUES (business_id, 'CUS-000040', '', '', '', '', '', '', '', '', '')\n"
        "- For customer tables: ORDER BY xcus\n"
        "- Output SQL only, no explanations\n"
        "- Handle NULLs gracefully\n"
        "- Use primary keys in WHERE clauses\n"
    )
    return sql_prompt

def get_primary_keys_from_schema(schema_context):
    """Extract primary keys from schema context for validation"""
    primary_keys = {}
    for schema in schema_context:
        table_name = schema.get('table_name', 'Unknown')
        table_primary_keys = []
        
        if schema.get('relationships'):
            for rel in schema.get('relationships', []):
                if rel.get('relationship_type') == 'primary_key':
                    table_primary_keys.append(rel.get('from_column', 'Unknown'))
        
        if table_primary_keys:
            primary_keys[table_name] = table_primary_keys
    
    return primary_keys

def get_foreign_keys_from_schema(schema_context):
    """Extract foreign keys from schema context for validation"""
    foreign_keys = {}
    for schema in schema_context:
        table_name = schema.get('table_name', 'Unknown')
        table_foreign_keys = []
        
        if schema.get('relationships'):
            for rel in schema.get('relationships', []):
                if rel.get('relationship_type') == 'foreign_key':
                    table_foreign_keys.append({
                        'column': rel.get('from_column', 'Unknown'),
                        'referenced_table': rel.get('referenced_table', 'Unknown'),
                        'referenced_column': rel.get('referenced_column', 'Unknown')
                    })
        
        if table_foreign_keys:
            foreign_keys[table_name] = table_foreign_keys
    
    return foreign_keys

def clean_sql_from_llm(sql_response):
    # Remove markdown/code block and common prefixes, as in your main.py
    sql_query = sql_response.strip()
    if sql_query.startswith('```'):
        lines = sql_query.split('\n')
        if len(lines) > 1:
            sql_lines = []
            for line in lines[1:]:
                if line.strip() == '```':
                    break
                sql_lines.append(line)
            sql_query = '\n'.join(sql_lines).strip()
    lines = sql_query.split('\n')
    if lines:
        first_line = lines[0].strip()
        prefixes_to_remove = ['sql query:', 'sql:', 'query:']
        for prefix in prefixes_to_remove:
            if first_line.lower().startswith(prefix):
                first_line = first_line[len(prefix):].strip()
                break
        lines[0] = first_line
        sql_query = '\n'.join(lines).strip()
    sql_query = sql_query.rstrip(';').strip()
    return sql_query

def format_db_result(mcp_result):
    # User-friendly formatting for DB results
    if isinstance(mcp_result, dict):
        if mcp_result.get('success') and mcp_result.get('results'):
            rows = mcp_result['results']
            if not rows:
                return "No results found."
            headers = list(rows[0].keys())
            if len(rows) == 1:
                # Single row: return as a summary sentence
                row = rows[0]
                summary = ", ".join(f"{h}: {row.get(h, '')}" for h in headers)
                return f"Result: {summary}"
            # Multi-row: Build a table
            lines = [" | ".join(headers)]
            lines.append("-|-".join(["---"] * len(headers)))
            for row in rows:
                lines.append(" | ".join(str(row.get(h, '')) for h in headers))
            return "\n".join(lines)
        elif mcp_result.get('success'):
            return "Query executed successfully, but no results found."
        elif mcp_result.get('error'):
            return f"Error: {mcp_result['error']}"
        else:
            # Fallback: pretty-print JSON
            import json
            return json.dumps(mcp_result, indent=2)
    # Try to parse as JSON string
    try:
        import json
        parsed = json.loads(mcp_result)
        return format_db_result(parsed)
    except Exception:
        pass
    # Fallback: return as-is
    return str(mcp_result) 