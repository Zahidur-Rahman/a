"""
Comprehensive Test Cases for Enhanced Customer Agent
Tests the reactive questioning, negative vibe detection, and enhanced flows.
"""
import asyncio
import json
from backend.app.agents.customer_agent.customer_agent import CustomerAgent
from backend.app.models.chat_graph_state import ChatGraphState
from backend.app.models.conversation import ChatMessage

class TestEnhancedCustomerAgent:
    """Test suite for the enhanced customer agent with reactive features."""
    
    def __init__(self):
        self.agent = CustomerAgent()
        self.business_id = "123"
        self.user_id = "test_user"
    
    async def test_clear_select_query(self):
        """Test 1: Clear select query should work directly."""
        print("\n=== Test 1: Clear Select Query ===")
        
        state = ChatGraphState(
            message="show me all customers",
            business_id=self.business_id,
            user_id=self.user_id,
            conversation_history=[]
        )
        
        result = await self.agent.ainvoke(state.model_dump())
        print(f"Query: {state.message}")
        print(f"Response: {result.get('response', 'No response')[:200]}...")
        print(f"SQL Generated: {result.get('sql', 'No SQL')}")
        print(f"Flow: {result.get('current_flow', 'Unknown')}")
        print(f"Clear: {result.get('is_query_clear', 'Unknown')}")
        
        return result
    
    async def test_unclear_select_query(self):
        """Test 2: Unclear select query should trigger reactive questioning."""
        print("\n=== Test 2: Unclear Select Query ===")
        
        state = ChatGraphState(
            message="customer",
            business_id=self.business_id,
            user_id=self.user_id,
            conversation_history=[]
        )
        
        result = await self.agent.ainvoke(state.model_dump())
        print(f"Query: {state.message}")
        print(f"Response: {result.get('response', 'No response')[:200]}...")
        print(f"Reactive Questioning Active: {result.get('reactive_questioning_active', False)}")
        print(f"Clarification Questions: {result.get('clarification_questions', [])}")
        
        return result
    
    async def test_negative_vibe_detection(self):
        """Test 3: Negative vibe should be detected and handled."""
        print("\n=== Test 3: Negative Vibe Detection ===")
        
        state = ChatGraphState(
            message="no, cancel that",
            business_id=self.business_id,
            user_id=self.user_id,
            conversation_history=[]
        )
        
        result = await self.agent.ainvoke(state.model_dump())
        print(f"Query: {state.message}")
        print(f"Response: {result.get('response', 'No response')}")
        print(f"Negative Vibe Detected: {result.get('negative_vibe_detected', False)}")
        
        return result
    
    async def test_update_customer_selection(self):
        """Test 4: Update query without clear customer should ask for selection."""
        print("\n=== Test 4: Update Customer Selection ===")
        
        state = ChatGraphState(
            message="update customer",
            business_id=self.business_id,
            user_id=self.user_id,
            conversation_history=[]
        )
        
        result = await self.agent.ainvoke(state.model_dump())
        print(f"Query: {state.message}")
        print(f"Response: {result.get('response', 'No response')[:200]}...")
        print(f"Pause Reason: {result.get('pause_reason', 'None')}")
        print(f"Current Flow: {result.get('current_flow', 'Unknown')}")
        
        return result
    
    async def test_update_with_customer_id(self):
        """Test 5: Update query with specific customer ID should proceed."""
        print("\n=== Test 5: Update with Customer ID ===")
        
        state = ChatGraphState(
            message="update customer CUS-000001 phone to 1234567890",
            business_id=self.business_id,
            user_id=self.user_id,
            conversation_history=[]
        )
        
        result = await self.agent.ainvoke(state.model_dump())
        print(f"Query: {state.message}")
        print(f"Response: {result.get('response', 'No response')[:200]}...")
        print(f"SQL Generated: {result.get('sql', 'No SQL')}")
        print(f"Current Flow: {result.get('current_flow', 'Unknown')}")
        
        return result
    
    async def test_reactive_questioning_flow(self):
        """Test 6: Complete reactive questioning flow."""
        print("\n=== Test 6: Reactive Questioning Flow ===")
        
        # First unclear query
        state1 = ChatGraphState(
            message="find customer",
            business_id=self.business_id,
            user_id=self.user_id,
            conversation_history=[]
        )
        
        result1 = await self.agent.ainvoke(state1.model_dump())
        print(f"Initial Query: {state1.message}")
        print(f"Response: {result1.get('response', 'No response')[:200]}...")
        
        # Follow-up with clarification
        if result1.get('reactive_questioning_active'):
            state2 = ChatGraphState(
                message="find customer with email john@example.com",
                business_id=self.business_id,
                user_id=self.user_id,
                conversation_history=[ChatMessage(role="user", content=state1.message),
                                   ChatMessage(role="assistant", content=result1.get('response', ''))]
            )
            
            result2 = await self.agent.ainvoke(state2.model_dump())
            print(f"Clarification: {state2.message}")
            print(f"Response: {result2.get('response', 'No response')[:200]}...")
            print(f"SQL Generated: {result2.get('sql', 'No SQL')}")
        
        return result1, result2 if 'result2' in locals() else None
    
    async def test_conversation_context_preservation(self):
        """Test 7: Conversation context should be preserved across interactions."""
        print("\n=== Test 7: Conversation Context Preservation ===")
        
        # First query
        state1 = ChatGraphState(
            message="show me recent customers",
            business_id=self.business_id,
            user_id=self.user_id,
            conversation_history=[]
        )
        
        result1 = await self.agent.ainvoke(state1.model_dump())
        print(f"Query 1: {state1.message}")
        print(f"Response 1: {result1.get('response', 'No response')[:100]}...")
        
        # Follow-up query that should use context
        conversation_history = [
            ChatMessage(role="user", content=state1.message),
            ChatMessage(role="assistant", content=result1.get('response', ''))
        ]
        
        state2 = ChatGraphState(
            message="update his phone to 9876543210",
            business_id=self.business_id,
            user_id=self.user_id,
            conversation_history=conversation_history
        )
        
        result2 = await self.agent.ainvoke(state2.model_dump())
        print(f"Query 2: {state2.message}")
        print(f"Response 2: {result2.get('response', 'No response')[:200]}...")
        print(f"SQL Generated: {result2.get('sql', 'No SQL')}")
        
        return result1, result2
    
    async def test_flow_interruption_handling(self):
        """Test 8: Flow interruption should be handled gracefully."""
        print("\n=== Test 8: Flow Interruption Handling ===")
        
        # Start an update flow
        state1 = ChatGraphState(
            message="update customer",
            business_id=self.business_id,
            user_id=self.user_id,
            conversation_history=[]
        )
        
        result1 = await self.agent.ainvoke(state1.model_dump())
        print(f"Initial Query: {state1.message}")
        print(f"Response: {result1.get('response', 'No response')[:200]}...")
        
        # Interrupt with negative response
        conversation_history = [
            ChatMessage(role="user", content=state1.message),
            ChatMessage(role="assistant", content=result1.get('response', ''))
        ]
        
        state2 = ChatGraphState(
            message="no, cancel that",
            business_id=self.business_id,
            user_id=self.user_id,
            conversation_history=conversation_history
        )
        
        result2 = await self.agent.ainvoke(state2.model_dump())
        print(f"Interruption: {state2.message}")
        print(f"Response: {result2.get('response', 'No response')}")
        print(f"Negative Vibe Detected: {result2.get('negative_vibe_detected', False)}")
        
        return result1, result2
    
    async def run_all_tests(self):
        """Run all test cases."""
        print("Starting Enhanced Customer Agent Tests...")
        print("=" * 50)
        
        try:
            await self.test_clear_select_query()
            await self.test_unclear_select_query()
            await self.test_negative_vibe_detection()
            await self.test_update_customer_selection()
            await self.test_update_with_customer_id()
            await self.test_reactive_questioning_flow()
            await self.test_conversation_context_preservation()
            await self.test_flow_interruption_handling()
            
            print("\n" + "=" * 50)
            print("All tests completed!")
            
        except Exception as e:
            print(f"\nTest failed with error: {e}")
            import traceback
            traceback.print_exc()

async def main():
    """Main test runner."""
    tester = TestEnhancedCustomerAgent()
    await tester.run_all_tests()

if __name__ == "__main__":
    asyncio.run(main())
