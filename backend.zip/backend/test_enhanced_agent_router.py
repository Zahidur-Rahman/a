"""
Comprehensive Test Suite for Enhanced Agent Router
Tests dynamic routing, context awareness, and compatibility with enhanced customer agent.
"""
import asyncio
import json
from backend.app.services.agent_router import DynamicAgentRouter
from backend.app.services.agent_registry import AgentRegistry
from backend.app.models.chat_graph_state import ChatGraphState
from backend.app.models.conversation import ChatMessage

class TestEnhancedAgentRouter:
    """Test suite for the enhanced dynamic agent router."""
    
    def __init__(self):
        self.agent_registry = AgentRegistry()
        self.router = DynamicAgentRouter(self.agent_registry)
        self.business_id = "123"
        self.user_id = "test_user"
    
    async def test_explicit_customer_keywords(self):
        """Test 1: Explicit customer keywords should route to customer agent."""
        print("\n=== Test 1: Explicit Customer Keywords ===")
        
        test_cases = [
            "add customer",
            "create customer",
            "find customer",
            "update customer",
            "delete customer",
            "show customers",
            "customer data",
            "his details",
            "this customer"
        ]
        
        for message in test_cases:
            state = ChatGraphState(
                message=message,
                business_id=self.business_id,
                user_id=self.user_id,
                conversation_history=[]
            )
            
            result = await self.router.classify_and_route(state.model_dump())
            print(f"'{message}' → {result.get('routed_agent', 'unknown')} (confidence: {result.get('routing_confidence', 'unknown')})")
            
            # Should route to customer agent
            assert result.get('routed_agent') == 'customer', f"Expected 'customer', got '{result.get('routed_agent')}' for '{message}'"
    
    async def test_conversation_context_continuity(self):
        """Test 2: Conversation context should maintain customer agent routing."""
        print("\n=== Test 2: Conversation Context Continuity ===")
        
        # First message - explicit customer operation
        state1 = ChatGraphState(
            message="add customer",
            business_id=self.business_id,
            user_id=self.user_id,
            conversation_history=[]
        )
        
        result1 = await self.router.classify_and_route(state1.model_dump())
        print(f"Initial: '{state1.message}' → {result1.get('routed_agent', 'unknown')}")
        
        # Follow-up message - should maintain customer context
        conversation_history = [
            ChatMessage(role="user", content=state1.message),
            ChatMessage(role="assistant", content=result1.get('response', ''))
        ]
        
        state2 = ChatGraphState(
            message="yes, proceed",
            business_id=self.business_id,
            user_id=self.user_id,
            conversation_history=conversation_history
        )
        
        result2 = await self.router.classify_and_route(state2.model_dump())
        print(f"Follow-up: '{state2.message}' → {result2.get('routed_agent', 'unknown')} (reasoning: {result2.get('routing_reasoning', 'none')})")
        
        # Should route to customer agent due to context
        assert result2.get('routed_agent') == 'customer', f"Expected 'customer', got '{result2.get('routed_agent')}' for follow-up"
    
    async def test_data_provision_patterns(self):
        """Test 3: Data provision patterns should route to customer agent."""
        print("\n=== Test 3: Data Provision Patterns ===")
        
        test_cases = [
            "phone number is 1234567890",
            "email is john@example.com",
            "organization is TechCorp",
            "address is 123 Main St",
            "his phone is 9876543210"
        ]
        
        for message in test_cases:
            state = ChatGraphState(
                message=message,
                business_id=self.business_id,
                user_id=self.user_id,
                conversation_history=[]
            )
            
            result = await self.router.classify_and_route(state.model_dump())
            print(f"'{message}' → {result.get('routed_agent', 'unknown')} (reasoning: {result.get('routing_reasoning', 'none')})")
            
            # Should route to customer agent
            assert result.get('routed_agent') == 'customer', f"Expected 'customer', got '{result.get('routed_agent')}' for '{message}'"
    
    async def test_general_conversation(self):
        """Test 4: General conversation should route to general agent."""
        print("\n=== Test 4: General Conversation ===")
        
        test_cases = [
            "hello",
            "hi there",
            "thanks for your help",
            "show me sales report",
            "what's the weather like",
            "help me with something"
        ]
        
        for message in test_cases:
            state = ChatGraphState(
                message=message,
                business_id=self.business_id,
                user_id=self.user_id,
                conversation_history=[]
            )
            
            result = await self.router.classify_and_route(state.model_dump())
            print(f"'{message}' → {result.get('routed_agent', 'unknown')} (confidence: {result.get('routing_confidence', 'unknown')})")
            
            # Should route to general agent
            assert result.get('routed_agent') == 'general', f"Expected 'general', got '{result.get('routed_agent')}' for '{message}'"
    
    async def test_pause_state_handling(self):
        """Test 5: Pause states should route to customer agent."""
        print("\n=== Test 5: Pause State Handling ===")
        
        pause_reasons = [
            'confirm_update',
            'confirm_delete',
            'missing_mandatory_fields',
            'clarification_needed',
            'customer_selection_needed',
            'field_selection_needed'
        ]
        
        for pause_reason in pause_reasons:
            state = ChatGraphState(
                message="yes, proceed",
                business_id=self.business_id,
                user_id=self.user_id,
                conversation_history=[],
                pause_reason=pause_reason
            )
            
            result = await self.router.classify_and_route(state.model_dump())
            print(f"Pause reason '{pause_reason}' → {result.get('routed_agent', 'unknown')} (reason: {result.get('routing_reason', 'none')})")
            
            # Should route to customer agent
            assert result.get('routed_agent') == 'customer', f"Expected 'customer', got '{result.get('routed_agent')}' for pause reason '{pause_reason}'"
    
    async def test_multi_dimensional_analysis(self):
        """Test 6: Multi-dimensional analysis should work correctly."""
        print("\n=== Test 6: Multi-dimensional Analysis ===")
        
        # Test case with mixed signals
        state = ChatGraphState(
            message="update his phone",
            business_id=self.business_id,
            user_id=self.user_id,
            conversation_history=[
                ChatMessage(role="user", content="show me customers"),
                ChatMessage(role="assistant", content="Here are the customers...")
            ]
        )
        
        result = await self.router.classify_and_route(state.model_dump())
        print(f"Mixed signals: '{state.message}' → {result.get('routed_agent', 'unknown')}")
        print(f"Reasoning: {result.get('routing_reasoning', 'none')}")
        print(f"Context analysis: {result.get('context_analysis', {})}")
        
        # Should route to customer agent due to action + reference + context
        assert result.get('routed_agent') == 'customer', f"Expected 'customer', got '{result.get('routed_agent')}' for mixed signals"
    
    async def test_confidence_scoring(self):
        """Test 7: Confidence scoring should be accurate."""
        print("\n=== Test 7: Confidence Scoring ===")
        
        test_cases = [
            ("add customer", 0.9),  # High confidence
            ("customer", 0.8),      # Medium-high confidence
            ("hello", 0.7),         # Medium confidence
            ("xyz", 0.3)            # Low confidence
        ]
        
        for message, expected_min_confidence in test_cases:
            state = ChatGraphState(
                message=message,
                business_id=self.business_id,
                user_id=self.user_id,
                conversation_history=[]
            )
            
            result = await self.router.classify_and_route(state.model_dump())
            confidence = result.get('routing_confidence', 0)
            
            print(f"'{message}' → confidence: {confidence}")
            
            # Check if confidence meets minimum threshold
            if isinstance(confidence, (int, float)):
                assert confidence >= expected_min_confidence, f"Confidence {confidence} below expected {expected_min_confidence} for '{message}'"
    
    async def test_performance_metrics(self):
        """Test 8: Performance metrics should be tracked."""
        print("\n=== Test 8: Performance Metrics ===")
        
        # Make several requests
        test_messages = [
            "add customer",
            "hello",
            "update customer",
            "hi there",
            "find customer"
        ]
        
        for message in test_messages:
            state = ChatGraphState(
                message=message,
                business_id=self.business_id,
                user_id=self.user_id,
                conversation_history=[]
            )
            
            await self.router.classify_and_route(state.model_dump())
        
        # Check performance metrics
        stats = self.router.get_classification_stats()
        print(f"Classification stats: {stats}")
        
        assert stats['total'] == len(test_messages), f"Expected {len(test_messages)} total requests, got {stats['total']}"
        assert stats['customer'] > 0, "Expected at least one customer routing"
        assert stats['general'] > 0, "Expected at least one general routing"
        
        # Check performance metrics
        perf_metrics = self.router.get_agent_performance_metrics()
        print(f"Performance metrics: {perf_metrics}")
        
        assert 'customer' in perf_metrics['agent_performance'], "Customer agent performance should be tracked"
        assert 'general' in perf_metrics['agent_performance'], "General agent performance should be tracked"
    
    async def test_routing_insights(self):
        """Test 9: Routing insights should provide useful information."""
        print("\n=== Test 9: Routing Insights ===")
        
        # Make some requests first
        test_messages = ["add customer", "hello", "update customer", "hi", "find customer"]
        for message in test_messages:
            state = ChatGraphState(
                message=message,
                business_id=self.business_id,
                user_id=self.user_id,
                conversation_history=[]
            )
            await self.router.classify_and_route(state.model_dump())
        
        # Get insights
        insights = self.router.get_routing_insights()
        print(f"Routing insights: {json.dumps(insights, indent=2)}")
        
        assert 'total_requests' in insights, "Insights should include total requests"
        assert 'routing_distribution' in insights, "Insights should include routing distribution"
        assert 'average_confidence' in insights, "Insights should include average confidence"
        assert 'recommendations' in insights, "Insights should include recommendations"
    
    async def test_context_preservation(self):
        """Test 10: Context should be preserved across interactions."""
        print("\n=== Test 10: Context Preservation ===")
        
        # First interaction
        state1 = ChatGraphState(
            message="add customer",
            business_id=self.business_id,
            user_id=self.user_id,
            conversation_history=[]
        )
        
        result1 = await self.router.classify_and_route(state1.model_dump())
        print(f"First: '{state1.message}' → {result1.get('routed_agent', 'unknown')}")
        
        # Second interaction with same user
        state2 = ChatGraphState(
            message="yes",
            business_id=self.business_id,
            user_id=self.user_id,
            conversation_history=[
                ChatMessage(role="user", content=state1.message),
                ChatMessage(role="assistant", content=result1.get('response', ''))
            ]
        )
        
        result2 = await self.router.classify_and_route(state2.model_dump())
        print(f"Second: '{state2.message}' → {result2.get('routed_agent', 'unknown')}")
        
        # Check conversation flows
        perf_metrics = self.router.get_agent_performance_metrics()
        conversation_flows = perf_metrics['conversation_flows']
        
        assert self.user_id in conversation_flows, f"User {self.user_id} should be in conversation flows"
        assert conversation_flows[self.user_id]['conversation_count'] >= 2, "Conversation count should be at least 2"
    
    async def run_all_tests(self):
        """Run all test cases."""
        print("Starting Enhanced Agent Router Tests...")
        print("=" * 60)
        
        try:
            await self.test_explicit_customer_keywords()
            await self.test_conversation_context_continuity()
            await self.test_data_provision_patterns()
            await self.test_general_conversation()
            await self.test_pause_state_handling()
            await self.test_multi_dimensional_analysis()
            await self.test_confidence_scoring()
            await self.test_performance_metrics()
            await self.test_routing_insights()
            await self.test_context_preservation()
            
            print("\n" + "=" * 60)
            print("✅ All tests passed! Enhanced Agent Router is working correctly.")
            
        except Exception as e:
            print(f"\n❌ Test failed with error: {e}")
            import traceback
            traceback.print_exc()

async def main():
    """Main test runner."""
    tester = TestEnhancedAgentRouter()
    await tester.run_all_tests()

if __name__ == "__main__":
    asyncio.run(main())
