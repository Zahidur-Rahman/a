from backend.app.services.general_agent import GeneralAgent
from backend.app.services.customer_agent import CustomerAgent
from backend.app.services.master_agent import MasterAgent

class AgentRegistry:
    def __init__(self):
        self._agents = {}

    def register_agent(self, name, agent_instance):
        self._agents[name] = agent_instance

    def get_agent(self, name):
        return self._agents.get(name)

# Instantiate and pre-register agents
agent_registry = AgentRegistry()
agent_registry.register_agent('general', GeneralAgent())
agent_registry.register_agent('customer', CustomerAgent())
agent_registry.register_agent('master', MasterAgent(agent_registry))  # Pass registry to master agent 