from langgraph.graph import StateGraph
from backend.app.services.mistral_llm_service import MistralLLMService
from backend.app.services.vector_search import FaissVectorSearchService
from backend.app.mcp.mcp_client import MCPClient
from backend.app.utils.customer_query_classifier import CustomerQueryClassifier
import importlib
from backend.app.utils import customer_chat_helpers
importlib.reload(customer_chat_helpers)
from backend.app.utils.customer_chat_helpers import (
    get_next_customer_id, get_customer_schema_context, build_customer_sql_prompt,
    build_customer_system_prompt, clean_sql_from_llm, extract_customer_fields_from_message,
    format_customer_result
)
from backend.app.models.chat_graph_state import ChatGraphState
from backend.app.models.conversation import ChatMessage
import logging
import time
import json
import re
import string

logger = logging.getLogger(__name__)

# Initialize services
llm_service = MistralLLMService()
customer_classifier = CustomerQueryClassifier()
vector_search_service = FaissVectorSearchService()
mcp_client = MCPClient(script_path="backend/app/mcp/server_enhanced.py")

def ensure_chat_messages(messages):
    """Convert messages to ChatMessage objects if needed."""
    if not messages:
        return []
    return [msg if isinstance(msg, ChatMessage) else ChatMessage.model_validate(msg) for msg in messages]

# --- Insert Validation Helper Functions ---

def is_valid_email(email):
    """Validate email format."""
    import re
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None

def is_valid_phone(phone):
    """Validate phone number (10 or 11 digits)."""
    if not phone or not phone.isdigit():
        return False
    return len(phone) in [10, 11]

def extract_insert_fields_from_sql(sql):
    """Extract field names and values from INSERT SQL statement."""
    import re
    
    # Pattern to match INSERT INTO table (columns) VALUES (values)
    pattern = r'INSERT\s+INTO\s+\w+\s*\(([^)]+)\)\s*VALUES\s*\(([^)]+)\)'
    match = re.search(pattern, sql, re.IGNORECASE | re.DOTALL)
    
    if not match:
        return {}
    
    columns_str = match.group(1).strip()
    values_str = match.group(2).strip()
    
    # Split columns and values, handling commas inside quotes
    columns = parse_sql_list(columns_str)
    values = parse_sql_list(values_str)
    
    # Create field dictionary
    fields = {}
    for i, col in enumerate(columns):
        if i < len(values):
            fields[col.strip()] = values[i].strip()
    
    return fields

def parse_sql_list(sql_list_str):
    """Parse SQL list handling commas inside quotes."""
    parts = []
    current = ""
    in_quotes = False
    quote_char = None
    
    for char in sql_list_str:
        if char in ["'", '"'] and not in_quotes:
            in_quotes = True
            quote_char = char
            current += char
        elif char == quote_char and in_quotes:
            in_quotes = False
            quote_char = None
            current += char
        elif char == ',' and not in_quotes:
            parts.append(current.strip())
            current = ""
        else:
            current += char
    
    if current.strip():
        parts.append(current.strip())
    
    return parts

def extract_fields_from_message(message):
    """Extract field values from user message using various patterns."""
    import re
    
    fields = {}
    message_lower = message.lower()
    
    # Phone number extraction (10 or 11 digits)
    phone_patterns = [
        r'phone[:\s]*(\d{10,11})',
        r'phone number[:\s]*(\d{10,11})',
        r'contact[:\s]*(\d{10,11})',
        r'mobile[:\s]*(\d{10,11})',
        r'\b(\d{11})\b',  # Exactly 11 digits with word boundaries
        r'\b(\d{10})\b',  # Exactly 10 digits with word boundaries
    ]
    
    for pattern in phone_patterns:
        match = re.search(pattern, message_lower)
        if match:
            phone = match.group(1)
            if len(phone) in [10, 11] and phone.isdigit():
                fields['xphone'] = phone  # Store as integer, no quotes
                break
    
    # Email extraction
    email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
    email_match = re.search(email_pattern, message)
    if email_match:
        fields['xemail'] = f"'{email_match.group()}'"
    
    # Enhanced customer type extraction with variations
    customer_type_mapping = {
        'corporate': 'Corporate',
        'business': 'Corporate', 
        'company': 'Corporate',
        'dealer': 'Dealer',
        'reseller': 'Dealer',
        'distributor': 'Dealer',
        'retail': 'Retail',
        'individual': 'Retail',
        'personal': 'Retail',
        'inter company': 'Inter Company',
        'internal': 'Inter Company',
        'subsidiary': 'Inter Company'
    }
    
    for variant, standard in customer_type_mapping.items():
        if variant in message_lower:
            fields['xgcus'] = f"'{standard}'"
            break
    
    # Enhanced tax scope extraction with variations
    tax_scope_mapping = {
        'local': 'Local-Registered',
        'registered': 'Local-Registered',
        'local registered': 'Local-Registered',
        'domestic': 'Local-Registered',
        'zero': 'Zero-Registered',
        'zero rated': 'Zero-Registered',
        'export': 'Zero-Registered',
        'foreign': 'Zero-Registered'
    }
    
    for variant, standard in tax_scope_mapping.items():
        if variant in message_lower:
            fields['xtaxscope'] = f"'{standard}'"
            break
    
    # Organization extraction - comprehensive patterns
    org_patterns = [
        r'organization[:\s]+(.+?)(?:\s+and\s|$)',  
        r'org[:\s]+(.+?)(?:\s+and\s|$)',          
        r'company[:\s]+(.+?)(?:\s+and\s|$)',      
        r'business[:\s]+(.+?)(?:\s+and\s|$)',     
    ]
    
    for pattern in org_patterns:
        match = re.search(pattern, message_lower)
        if match:
            org_name = match.group(1).strip()
            # Remove common words that might be captured
            org_name = re.sub(r'\s+(is|are|was|were)\s+', ' ', org_name).strip()
            if org_name and len(org_name) > 0:
                fields['xorg'] = f"'{org_name}'"
                break
    
    logger.info(f"[ExtractFields] Enhanced extraction from '{message}': {fields}")
    return fields

async def extract_update_fields_from_message(message):
    """Extract update field information from user message for UPDATE operations."""
    try:
        from .mistral_llm_service import MistralLLMService
        llm_service = MistralLLMService()
        
        extraction_prompt = f"""You are analyzing a user message to extract what customer fields they want to UPDATE.

User Message: "{message}"

Extract update information for these fields if mentioned:

1. PHONE (xphone): Extract new phone number
   - Look for: "phone", "contact", "mobile", "number"
   - Format as just the digits: 1234567890

2. EMAIL (xemail): Extract new email address  
   - Look for: "email", "mail", "@"
   - Format with quotes: 'newemail@domain.com'

3. ORGANIZATION (xorg): Extract new organization/company name
   - Look for: "organization", "company", "org", "business"
   - Format with quotes: 'New Company Name'

4. CUSTOMER TYPE (xgcus): Extract new customer type
   - Look for: "corporate", "dealer", "retail", "type"
   - Normalize to: 'Corporate', 'Dealer', 'Retail', 'Inter Company'

5. TAX SCOPE (xtaxscope): Extract new tax classification
   - Look for: "tax", "local", "zero", "registered", "domestic", "export"
   - Normalize to: 'Local-Registered' or 'Zero-Registered'

IMPORTANT: Only extract fields that are clearly being updated. Look for action words like:
- "update phone to...", "change email to...", "set organization to..."
- "his phone is now...", "new email is...", "organization should be..."

If no clear update fields are found, return: {{"no_fields": true}}

Respond in JSON format:
{{
  "xphone": "1234567890",
  "xemail": "'newemail@example.com'",
  "xorg": "'New Company Name'",
  "xgcus": "'Corporate'",
  "xtaxscope": "'Local-Registered'"
}}"""

        response = await llm_service.chat([
            {"role": "system", "content": "You are a customer data update extractor. Respond with valid JSON only."},
            {"role": "user", "content": extraction_prompt}
        ])
        
        # Parse the JSON response
        import json
        import re
        
        # Clean the response to extract JSON
        json_match = re.search(r'\{.*\}', response, re.DOTALL)
        if json_match:
            json_str = json_match.group()
            extracted_data = json.loads(json_str)
            
            # Check if no fields were found
            if extracted_data.get('no_fields'):
                logger.info(f"[UpdateFieldExtraction] No update fields found in: '{message}'")
                return None
            
            # Remove empty fields
            update_fields = {k: v for k, v in extracted_data.items() if v and k != 'no_fields'}
            
            if update_fields:
                logger.info(f"[UpdateFieldExtraction] Extracted update fields: {update_fields}")
                return update_fields
            else:
                logger.info(f"[UpdateFieldExtraction] No valid update fields extracted from: '{message}'")
                return None
        else:
            logger.warning(f"[UpdateFieldExtraction] Could not parse JSON from LLM response: {response}")
            return None
            
    except Exception as e:
        logger.error(f"[UpdateFieldExtraction] Error: {e}")
        return None

async def extract_fields_dynamic(message):
    """
    Dynamic field extraction using LLM for natural language understanding.
    Handles variations like 'local' → 'Local-Registered', 'corporate' → 'Corporate', etc.
    """
    try:
        from .mistral_llm_service import MistralLLMService
        llm_service = MistralLLMService()
        
        extraction_prompt = f"""You are a customer data extractor. Extract customer information from natural language text and normalize it to standard business formats.

User Message: "{message}"

Extract and normalize the following fields if present:

1. PHONE (xphone): Extract 10-11 digit phone numbers
   - Format as just the digits (no quotes): 1234567890
   
2. EMAIL (xemail): Extract valid email addresses
   - Keep exact format with quotes: 'email@domain.com'
   
3. CUSTOMER TYPE (xgcus): Normalize to standard business types
   - "corporate", "business", "company" → 'Corporate'
   - "dealer", "reseller", "distributor" → 'Dealer'  
   - "retail", "individual", "personal" → 'Retail'
   - "inter company", "internal", "subsidiary" → 'Inter Company'
   - Format with quotes: 'Corporate'
   
4. TAX SCOPE (xtaxscope): Normalize tax classification
   - "local", "registered", "local registered", "domestic" → 'Local-Registered'
   - "zero", "zero rated", "export", "foreign" → 'Zero-Registered'
   - Format with quotes: 'Local-Registered'
   
5. ORGANIZATION (xorg): Extract company/organization names
   - Clean format, proper capitalization
   - Format with quotes: 'Company Name'

IMPORTANT: Only extract fields that are clearly present. Don't guess or infer.

Respond in JSON format:
{{
  "xphone": "1234567890",
  "xemail": "'user@example.com'", 
  "xgcus": "'Corporate'",
  "xtaxscope": "'Local-Registered'",
  "xorg": "'Company Name'"
}}

If no fields are found, return: {{"no_fields": true}}"""

        response = await llm_service.chat([
            {"role": "system", "content": "You are a data extraction specialist. Always respond with valid JSON."},
            {"role": "user", "content": extraction_prompt}
        ])
        
        # Parse JSON response
        import json
        try:
            extracted = json.loads(response.strip())
            if extracted.get('no_fields'):
                logger.info(f"[DynamicExtraction] No fields found in: '{message}'")
                return {}
            
            # Clean up the extracted fields
            fields = {}
            for key, value in extracted.items():
                if value and value != 'null' and key != 'no_fields':
                    fields[key] = value
            
            logger.info(f"[DynamicExtraction] Extracted from '{message}': {fields}")
            return fields
            
        except json.JSONDecodeError as e:
            logger.error(f"[DynamicExtraction] JSON parse error: {e}, response: {response}")
            return extract_fields_from_message(message)
            
    except Exception as e:
        logger.error(f"[DynamicExtraction] Error in LLM extraction: {e}")
        return extract_fields_from_message(message)

def update_sql_with_fields(sql, new_fields):
    """Update INSERT SQL with new field values."""
    import re
    
    if not new_fields:
        return sql
    
    # Pattern to match INSERT INTO table (columns) VALUES (values)
    pattern = r'INSERT\s+INTO\s+(\w+)\s*\(([^)]+)\)\s*VALUES\s*\(([^)]+)\)'
    match = re.search(pattern, sql, re.IGNORECASE | re.DOTALL)
    
    if not match:
        return sql
    
    table_name = match.group(1).strip()
    columns_str = match.group(2).strip()
    values_str = match.group(3).strip()
    
    # Parse columns and values
    columns = parse_sql_list(columns_str)
    values = parse_sql_list(values_str)
    
    # Update existing fields or add new ones
    for field, value in new_fields.items():
        field = field.strip()
        if field in [col.strip() for col in columns]:
            # Update existing field
            index = [col.strip() for col in columns].index(field)
            values[index] = str(value)
        else:
            # Add new field
            columns.append(field)
            values.append(str(value))
    
    # Reconstruct SQL
    new_columns = ', '.join(columns)
    new_values = ', '.join(values)
    
    return f"INSERT INTO {table_name} ({new_columns}) VALUES ({new_values})"

def validate_business_access(sql, user_business_id):
    """
    Enhanced business access control validation.
    Validates that SQL query only accesses data for the user's business.
    Returns error message if access violation detected, None if valid.
    """
    import re
    
    if not sql or not user_business_id:
        return "Invalid query or business ID"
    
    sql_lower = sql.lower().strip()
    
    try:
        user_business_id_int = int(user_business_id)
    except (ValueError, TypeError):
        return f"Invalid business ID format: {user_business_id}"
    
    # Enhanced patterns to catch various SQL formats
    where_patterns = [
        r'where\s+.*?zid\s*=\s*(\d+)',
        r'where\s+.*?zid\s*=\s*\'(\d+)\'',
        r'where\s+.*?zid\s*=\s*\"(\d+)\"',
        r'and\s+.*?zid\s*=\s*(\d+)',
        r'and\s+.*?zid\s*=\s*\'(\d+)\'',
        r'and\s+.*?zid\s*=\s*\"(\d+)\"',
        r'or\s+.*?zid\s*=\s*(\d+)',
        r'or\s+.*?zid\s*=\s*\'(\d+)\'',
        r'or\s+.*?zid\s*=\s*\"(\d+)\"'
    ]
    
    # Check for zid in INSERT VALUES - more comprehensive patterns
    insert_patterns = [
        r'values\s*\(\s*(\d+)',  # First value in INSERT is typically zid
        r'values\s*\(\s*\'(\d+)\'',
        r'values\s*\(\s*\"(\d+)\"',
        r'\(\s*zid[^)]*\)\s*values\s*\([^,]*?(\d+)',  # Explicit zid column
        r'insert\s+into\s+\w+\s*\([^)]*zid[^)]*\)\s*values\s*\([^,]*?(\d+)'
    ]
    
    # Check for zid in UPDATE SET
    update_patterns = [
        r'set\s+.*?zid\s*=\s*(\d+)',
        r'set\s+.*?zid\s*=\s*\'(\d+)\'',
        r'set\s+.*?zid\s*=\s*\"(\d+)\"'
    ]
    
    all_patterns = where_patterns + insert_patterns + update_patterns
    
    # Check all patterns for business ID violations
    for pattern in all_patterns:
        matches = re.findall(pattern, sql_lower, re.DOTALL)
        for match in matches:
            try:
                found_business_id = int(match)
                if found_business_id != user_business_id_int:
                    return f"🚫 Access denied: You cannot access data from business ID {found_business_id}. You can only access your own business data."
            except (ValueError, TypeError):
                continue
    
    # Enhanced checks for different SQL operations
    if 'select' in sql_lower:
        # Ensure SELECT has proper WHERE clause with zid filter
        if 'where' not in sql_lower:
            return "🚫 Access denied: SELECT queries must include WHERE clause with business ID filter for security."
        if 'zid' not in sql_lower:
            return "🚫 Access denied: SELECT queries must filter by business ID (zid) for data access control."
    
    elif 'update' in sql_lower:
        # Ensure UPDATE has proper WHERE clause with zid filter
        if 'where' not in sql_lower:
            return "🚫 Access denied: UPDATE queries must include WHERE clause with business ID filter for security."
        if 'zid' not in sql_lower:
            return "🚫 Access denied: UPDATE queries must filter by business ID (zid) for data access control."
    
    elif 'delete' in sql_lower:
        # Ensure DELETE has proper WHERE clause with zid filter
        if 'where' not in sql_lower:
            return "🚫 Access denied: DELETE queries must include WHERE clause with business ID filter for security."
        if 'zid' not in sql_lower:
            return "🚫 Access denied: DELETE queries must filter by business ID (zid) for data access control."
    
    elif 'insert' in sql_lower:
        # Ensure INSERT uses correct business ID
        if str(user_business_id_int) not in sql:
            return f"🚫 Access denied: INSERT operations must use your business ID ({user_business_id_int})."
    
    # Additional security check: look for attempts to bypass filters
    bypass_patterns = [
        r'or\s+1\s*=\s*1',  # SQL injection attempt
        r'or\s+true',       # Boolean bypass
        r'union\s+select',  # Union injection
        r'drop\s+table',    # Destructive operations
        r'truncate\s+table',
        r'alter\s+table'
    ]
    
    for pattern in bypass_patterns:
        if re.search(pattern, sql_lower):
            return "🚫 Access denied: Potentially malicious SQL detected."
    
    return None  # No access violation detected

# --- Node Functions ---

async def classify_customer_query(context):
    """Classify the customer query and get schema context."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    context.conversation_history = ensure_chat_messages(context.conversation_history or [])
    
    # Clean state to prevent contamination from previous operations
    # BUT preserve pause context if we're resuming from a pause
    current_pause_reason = getattr(context, 'pause_reason', None)
    
    # Only clear state if we're NOT resuming from a pause
    if current_pause_reason not in {'confirm_update', 'confirm_delete', 'missing_mandatory_fields'}:
        context.incomplete_sql = None
        context.missing_mandatory_fields = None
        context.collected_field_values = None
        context.validation_attempts = None
        context.pause_reason = None
        context.pause_message = None
        context.confirm = None
        context.resume_from_pause = None
        context.sql = None
        context.response = None
    
    # Classify the customer query
    context.customer_action = await customer_classifier.classify_query(context.message)
    
    # Get customer schema context from vector DB
    context.schema_context = await get_customer_schema_context(context.business_id, context.message)
    
    logger.info(f"[CustomerGraph] Query classified as: {context.customer_action}")
    return context.model_dump()

async def route_customer_action(context):
    """Route to appropriate customer action handler."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    # Check for pause/resume logic first
    current_pause_reason = getattr(context, 'pause_reason', None)
    if current_pause_reason in {'confirm_update', 'confirm_delete', 'missing_mandatory_fields', 'specify_update_fields'}:
        logger.info(f"[CustomerRouting] Detected pause_reason: {current_pause_reason}, routing to ResumeOrClassify")
        context.next = "ResumeOrClassify"
        return context.model_dump()
    
    action = getattr(context, 'customer_action', 'GENERAL_CUSTOMER')
    
    if action == 'CREATE_CUSTOMER':
        context.next = "VectorSearch"
    elif action in ['SEARCH_CUSTOMER', 'LIST_CUSTOMERS']:
        context.next = "VectorSearch"
    elif action in ['UPDATE_CUSTOMER', 'DELETE_CUSTOMER']:
        context.next = "VectorSearch"
    else:
        context.next = "GeneralCustomerChat"
    
    return context.model_dump()

async def vector_search_node(context):
    """Get customer schema context for database operations."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    # Get enhanced schema context for customer operations
    if not context.schema_context:
        context.schema_context = await get_customer_schema_context(context.business_id, context.message)
    
    return context.model_dump()

async def generate_customer_sql_node(context):
    """Generate SQL for customer operations."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    context.conversation_history = ensure_chat_messages(context.conversation_history or [])
    
    # Build SQL prompt for customer operations
    context.sql_prompt = build_customer_sql_prompt(
        context, context.conversation_history, context.schema_context or []
    )
    
    # Generate SQL using LLM
    messages = [
        {"role": "system", "content": context.sql_prompt},
        {"role": "user", "content": context.message}
    ]
    
    sql_response = await llm_service.chat(messages)
    context.sql = clean_sql_from_llm(sql_response)
    
    logger.info(f"[CustomerSQL] Generated: {context.sql}")
    return context.model_dump()

async def customer_dependency_check_node(context):
    """Check for dependencies and handle pause/resume logic for customer operations."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    sql = context.sql or ""
    
    # Validate SQL for UPDATE/DELETE operations
    update_pattern = re.compile(r"^update\s+\w+\s+set\s+.+where\s+.+", re.IGNORECASE | re.DOTALL)
    delete_pattern = re.compile(r"^delete\s+from\s+\w+\s+where\s+.+", re.IGNORECASE | re.DOTALL)
    
    # Check for invalid SQL structure OR dummy data in UPDATE/DELETE operations
    has_invalid_structure = ("update" in sql.lower() and not update_pattern.match(sql)) or ("delete" in sql.lower() and not delete_pattern.match(sql))
    
    # Check for vague DELETE operations (using specific customer IDs from conversation history)
    has_vague_delete = False
    if "delete" in sql.lower() and "cacus" in sql.lower():
        # Check if using specific customer ID without user explicitly mentioning it
        import re
        customer_id_match = re.search(r"CUS-\d{6}", sql)
        if customer_id_match:
            # Check if this customer ID was mentioned in the current user message
            current_message = getattr(context, 'message', '').lower()
            customer_id = customer_id_match.group()
            if customer_id.lower() not in current_message:
                has_vague_delete = True
                logger.warning(f"[CustomerDepCheck] Vague DELETE detected - using {customer_id} without user explicitly mentioning it")
    
    # Check for dummy data patterns in UPDATE operations
    dummy_data_patterns = [
        'new_email@example.com', 'customer@example.com', 'example.com', 
        'ptech solutions', 'pTech Solutions', 'ABC Corp', 'test@test.com',
        '1234567890', '123456789', 'newphone', 'newemail', 'neworg',
        'Corporate', 'Local-Registered', 'Zero-Registered',
        'new_phone', 'new_email', 'new_customer_type', 'new_tax_scope', 'new_organization_name',
        "'new_", '"new_', '= new_', '= \'new_', '= "new_'
    ]
    has_dummy_data = any(pattern.lower() in sql.lower() for pattern in dummy_data_patterns)
    
    if has_invalid_structure or has_dummy_data or has_vague_delete:
        if has_dummy_data:
            logger.warning(f"[CustomerDepCheck] Dummy data detected in SQL: {sql}")
        elif has_vague_delete:
            logger.warning(f"[CustomerDepCheck] Vague DELETE operation detected: {sql}")
        else:
            logger.warning(f"[CustomerDepCheck] Invalid UPDATE/DELETE SQL structure: {sql}")
        
        # Provide specific guidance based on the operation type
        if "update" in sql.lower():
            # Check if this is a customer identification issue or field specification issue
            if has_invalid_structure and not has_dummy_data:
                # Customer not properly identified
                context.response = "📝 To update a customer, I need to know which customer to update. Please specify:\n\n• A specific customer ID (e.g., 'update CUS-000105')\n• Or say 'update last customer'\n• Or say 'show me customers' to see the list first\n\nWhich customer would you like to update?"
            else:
                # Customer identified but unclear what to update (dummy data detected)
                target_info = getattr(context, 'target_customer_info', None)
                customer_name = target_info.get('name', 'the customer') if target_info else 'the customer'
                context.response = f"""📝 I found {customer_name}, but I need to know what information to update. You can update:

🔹 **Contact Information:**
   • Phone: "update phone to 01234567890"
   • Email: "change email to john@newcompany.com"

🔹 **Business Details:**
   • Organization: "update organization to New Company Ltd"
   • Customer Type: "change to corporate" (Corporate/Dealer/Retail)
   • Tax Scope: "update tax scope to local registered"

💡 **Examples:**
   • "update his phone to 01798695259"
   • "change email to zahid@newcompany.com"
   • "update organization to pTech Solutions"

What would you like to update for {customer_name}?"""
                
                context.pause_reason = "specify_update_fields"
                context.pause_message = context.response
                context.next = "PauseNode"
                return context.model_dump()
                
        elif "delete" in sql.lower():
            if has_vague_delete:
                context.response = "🗑️ I cannot delete a customer without you explicitly specifying which one. Please specify:\n\n• A specific customer ID (e.g., 'delete CUS-000105')\n• Or say 'delete last customer'\n• Or say 'show me customers' to see the list first\n\n⚠️ Which customer would you like to delete?"
            else:
                context.response = "🗑️ To delete a customer, I need to know which customer to delete. Please specify:\n\n• A specific customer ID (e.g., 'delete CUS-000105')\n• Or say 'delete last customer'\n• Or say 'show me customers' to see the list first\n\n⚠️ Which customer would you like to delete?"
        else:
            context.response = "I need more specific information to update or delete a customer. Please provide the customer ID or more details."
        
        # Clear state to prepare for new query
        clear_all_operation_state(context)
        context.next = "CustomerResponse"
        return context.model_dump()
    
    # For INSERT operations, validate mandatory fields first
    if "insert" in sql.lower():
        context.next = "ValidateInsertFields"
        return context.model_dump()
    
    # For UPDATE/DELETE operations, validate customer existence first
    if "update" in sql.lower() or "delete" in sql.lower():
        context.next = "ValidateCustomerExists"
        return context.model_dump()
    
    # For other operations (SELECT), proceed directly
    context.next = "ExecuteCustomerSQL"
    return context.model_dump()

async def validate_customer_exists_node(context):
    """Validate that the customer exists before performing UPDATE/DELETE operations."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    sql = context.sql or ""
    business_id = context.business_id
    
    logger.info(f"[ValidateCustomerExists] Checking customer existence for SQL: {sql}")
    
    # Extract customer ID from WHERE clause
    customer_id = None
    customer_id_patterns = [
        r"xcus\s*=\s*'([^']+)'",  # xcus = 'CUS-123456'
        r"xcus\s*=\s*\"([^\"]+)\"",  # xcus = "CUS-123456"
        r"xcus\s*=\s*([A-Z]{3}-\d{6})",  # xcus = CUS-123456 (without quotes)
    ]
    
    for pattern in customer_id_patterns:
        match = re.search(pattern, sql, re.IGNORECASE)
        if match:
            customer_id = match.group(1)
            break
    
    # Handle subquery cases (like "delete last customer")
    if not customer_id and "order by xcus desc limit" in sql.lower():
        # This is a "delete/update last customer" type query
        # We need to execute a SELECT first to see if any customers exist
        try:
            check_sql = f"SELECT xcus FROM cacus WHERE zid = {business_id} ORDER BY xcus DESC LIMIT 1"
            logger.info(f"[ValidateCustomerExists] Checking for last customer: {check_sql}")
            
            check_result = await mcp_client.execute_query(check_sql, business_id)
            
            if isinstance(check_result, dict) and 'content' in check_result:
                try:
                    import json
                    parsed = json.loads(check_result['content'][0]['text'])
                    rows = parsed.get('results', [])
                    
                    if not rows:
                        logger.warning("[ValidateCustomerExists] No customers found for 'last customer' operation")
                        context.response = "❌ No customers found in the system. There are no customers to update or delete."
                        # Clear state and prepare for new query
                        context.pause_reason = None
                        context.pause_message = None
                        context.confirm = None
                        context.resume_from_pause = None
                        context.sql = None
                        context.next = "CustomerResponse"
                        return context.model_dump()
                    else:
                        customer_id = rows[0].get('xcus')
                        logger.info(f"[ValidateCustomerExists] Found last customer: {customer_id}")
                        
                except Exception as e:
                    logger.error(f"[ValidateCustomerExists] Error parsing check result: {e}")
                    context.response = "❌ Unable to verify customer existence. Please try again or provide a specific customer ID."
                    # Clear state and prepare for new query
                    context.pause_reason = None
                    context.pause_message = None
                    context.confirm = None
                    context.resume_from_pause = None
                    context.sql = None
                    context.next = "CustomerResponse"
                    return context.model_dump()
                    
        except Exception as e:
            logger.error(f"[ValidateCustomerExists] Error checking for last customer: {e}")
            context.response = "❌ Unable to verify customer existence. Please try again or provide a specific customer ID."
            # Clear state and prepare for new query
            context.pause_reason = None
            context.pause_message = None
            context.confirm = None
            context.resume_from_pause = None
            context.sql = None
            context.next = "CustomerResponse"
            return context.model_dump()
    
    # If we still don't have a customer ID, it might be a complex query
    if not customer_id:
        logger.warning("[ValidateCustomerExists] Could not extract customer ID from SQL")
        context.response = "❌ I need a specific customer ID to perform this operation. Please provide the customer ID (like CUS-123456) or say 'show me customers' to see available customers."
        # Clear state and prepare for new query
        context.pause_reason = None
        context.pause_message = None
        context.confirm = None
        context.resume_from_pause = None
        context.sql = None
        context.next = "CustomerResponse"
        return context.model_dump()
    
    # Now validate that this specific customer exists
    try:
        validation_sql = f"SELECT xcus, xorg, xemail FROM cacus WHERE zid = {business_id} AND xcus = '{customer_id}'"
        logger.info(f"[ValidateCustomerExists] Validating customer: {validation_sql}")
        
        validation_result = await mcp_client.execute_query(validation_sql, business_id)
        
        if isinstance(validation_result, dict) and 'content' in validation_result:
            try:
                import json
                parsed = json.loads(validation_result['content'][0]['text'])
                rows = parsed.get('results', [])
                
                if not rows:
                    logger.warning(f"[ValidateCustomerExists] Customer {customer_id} not found")
                    context.response = f"❌ Customer {customer_id} is not a valid customer in your system. Please check the customer ID or use 'show me customers' to see available customers."
                    # Clear state and prepare for new query
                    clear_all_operation_state(context)
                    context.next = "CustomerResponse"
                    return context.model_dump()
                else:
                    # Customer exists, store customer info for confirmation message
                    customer_info = rows[0]
                    logger.info(f"[ValidateCustomerExists] Found customer data: {customer_info}")
                    context.target_customer_info = customer_info
                    logger.info(f"[ValidateCustomerExists] Customer {customer_id} validated successfully")
                    
                    # Proceed to confirmation step
                    context.next = "ConfirmCustomerOperation"
                    return context.model_dump()
                    
            except Exception as e:
                logger.error(f"[ValidateCustomerExists] Error parsing validation result: {e}")
                context.response = "❌ Unable to verify customer existence. Please try again."
                # Clear state and prepare for new query
                context.pause_reason = None
                context.pause_message = None
                context.confirm = None
                context.resume_from_pause = None
                context.sql = None
                context.next = "CustomerResponse"
                return context.model_dump()
                
    except Exception as e:
        logger.error(f"[ValidateCustomerExists] Error validating customer existence: {e}")
        context.response = "❌ Unable to verify customer existence. Please try again."
        # Clear state and prepare for new query
        context.pause_reason = None
        context.pause_message = None
        context.confirm = None
        context.resume_from_pause = None
        context.sql = None
        context.next = "CustomerResponse"
        return context.model_dump()

async def confirm_customer_operation_node(context):
    """Confirm UPDATE/DELETE operations with customer details."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    sql = context.sql or ""
    target_info = getattr(context, 'target_customer_info', None)
    customer_info = target_info if target_info is not None else {}
    
    # Check if already confirmed
    if getattr(context, "confirm", False):
        context.next = "ExecuteCustomerSQL"
        return context.model_dump()
    
    # Build confirmation message with customer details
    customer_id = customer_info.get('xcus', 'Unknown')
    customer_org = customer_info.get('xorg', 'N/A')
    customer_email = customer_info.get('xemail', 'N/A')
    
    customer_display = f"Customer ID: {customer_id}"
    if customer_org and customer_org != 'N/A':
        customer_display += f"\nOrganization: {customer_org}"
    if customer_email and customer_email != 'N/A':
        customer_display += f"\nEmail: {customer_email}"
    
    if "delete" in sql.lower():
        logger.info("[ConfirmCustomerOperation] Pausing for delete confirmation")
        context.response = f"⚠️ You are about to permanently DELETE the following customer:\n\n{customer_display}\n\n🚨 This action cannot be undone and will remove all customer data. Please confirm by replying 'confirm delete'."
        context.pause_reason = "confirm_delete"
        context.pause_message = context.response
        context.next = "PauseNode"
        return context.model_dump()
    elif "update" in sql.lower():
        logger.info("[ConfirmCustomerOperation] Pausing for update confirmation")
        context.response = f"📝 You are about to UPDATE the following customer:\n\n{customer_display}\n\nPlease confirm by replying 'confirm update'."
        context.pause_reason = "confirm_update"
        context.pause_message = context.response
        context.next = "PauseNode"
        return context.model_dump()
    else:
        # Should not reach here, but handle gracefully
        context.next = "ExecuteCustomerSQL"
    return context.model_dump()

async def validate_insert_fields_node(context):
    """
    Validate mandatory fields for customer insert operations with progress tracking.
    Mandatory fields: xphone (11 digits), xemail (valid email), xgcus, xtaxscope, xorg
    """
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    sql = context.sql or ""
    logger.info(f"[ValidateInsertFields] Validating SQL: {sql}")
    
    # Extract fields from INSERT SQL
    insert_fields = extract_insert_fields_from_sql(sql)
    logger.info(f"[ValidateInsertFields] Extracted fields: {insert_fields}")
    
    # Define mandatory fields with their validation requirements
    mandatory_fields = {
        'xphone': {
            'name': 'Phone number',
            'description': '10 or 11 digits',
            'validator': lambda v: is_valid_phone(v.strip().strip("'\"")) if v else False,
            'example': 'Phone: 01798695259'
        },
        'xemail': {
            'name': 'Email address',
            'description': 'valid email format',
            'validator': lambda v: is_valid_email(v.strip().strip("'\"")) if v else False,
            'example': 'Email: customer@example.com'
        },
        'xgcus': {
            'name': 'Customer type',
            'description': 'Corporate, Dealer, Retail, or Inter Company',
            'validator': lambda v: v.strip().strip("'\"") in ['Corporate', 'Dealer', 'Retail', 'Inter Company'] if v else False,
            'example': 'Customer Type: Corporate/Dealer/Retail/Inter Company'
        },
        'xtaxscope': {
            'name': 'Tax scope',
            'description': 'Local-Registered or Zero-Registered',
            'validator': lambda v: v.strip().strip("'\"") in ['Local-Registered', 'Zero-Registered'] if v else False,
            'example': 'Tax Scope: Local-Registered/Zero-Registered'
        },
        'xorg': {
            'name': 'Organization',
            'description': 'company or organization name',
            'validator': lambda v: len(v.strip().strip("'\"")) > 0 if v else False,
            'example': 'Organization Name: pTech Solutions'
        }
    }
    
    # Track provided and missing fields
    provided_fields = []
    missing_fields = []
    invalid_fields = []
    
    # Check each mandatory field
    for field_name, field_config in mandatory_fields.items():
        value = insert_fields.get(field_name)
        
        if not value or value.strip() in ['NULL', 'null', '']:
            missing_fields.append({
                'name': field_config['name'],
                'description': field_config['description'],
                'example': field_config['example']
            })
        else:
            # Validate field format
            if field_config['validator'](value):
                provided_fields.append({
                    'name': field_config['name'],
                    'value': value.strip().strip("'\"")
                })
            else:
                current_value = value.strip().strip("'\"")
                invalid_fields.append({
                    'name': field_config['name'],
                    'description': field_config['description'],
                    'current_value': current_value,
                    'example': field_config['example']
                })
    
    # If there are missing or invalid fields, store incomplete SQL and ask for missing data
    if missing_fields or invalid_fields:
        logger.info(f"[ValidateInsertFields] Missing: {len(missing_fields)}, Invalid: {len(invalid_fields)}, Provided: {len(provided_fields)}")
        
        # Store the incomplete SQL and track attempts
        context.incomplete_sql = sql
        context.validation_attempts = (context.validation_attempts or 0) + 1
        context.pause_reason = "missing_mandatory_fields"
        
        # Build user-friendly response with progress tracking
        response_parts = []
        
        # Show progress if any fields are provided
        if provided_fields:
            response_parts.append("✅ **Information received till now.Please provide remaining fields:**")
            for field in provided_fields:
                response_parts.append(f"   • {field['name']}: {field['value']}")
            response_parts.append("")
        
        # Show what's still needed
        if missing_fields:
            response_parts.append("📝 **Still needed for customer creation:**")
            for field in missing_fields:
                response_parts.append(f"   • {field['example']}")
        
        if invalid_fields:
            response_parts.append("\n❌ **Please correct:**")
            for field in invalid_fields:
                response_parts.append(f"   • {field['name']} must be {field['description']} (you provided: {field['current_value']})")
                response_parts.append(f"     Example: {field['example']}")
        
        if missing_fields or invalid_fields:
            response_parts.append("\n💡 **Natural language examples:**")
            response_parts.append("'Phone 01798695259, email john@ptech.com, corporate, local registered, pTech Solutions'")
            response_parts.append("'Business customer, domestic tax, organization ABC Corp, phone 01234567890, email info@abc.com'")
        
        context.response = "\n".join(response_parts)
        context.pause_message = context.response
        context.next = "PauseNode"
        return context.model_dump()
    
    # All mandatory fields are present and valid, proceed to ID generation
    logger.info("[ValidateInsertFields] All mandatory fields validated successfully")
    context.next = "GenerateCustomerID"
    return context.model_dump()

async def collect_missing_fields_node(context):
    """
    Collect missing mandatory fields from user input and update the incomplete SQL.
    """
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    user_message = context.message
    incomplete_sql = getattr(context, 'incomplete_sql', '')
    
    logger.info(f"[CollectMissingFields] Processing user input: {user_message}")
    logger.info(f"[CollectMissingFields] Incomplete SQL: {incomplete_sql}")
    
    # Extract field values from user message using dynamic LLM extraction
    extracted_fields = await extract_fields_dynamic(user_message)
    logger.info(f"[CollectMissingFields] Dynamic extracted fields: {extracted_fields}")
    
    if not extracted_fields:
        # No fields extracted, ask for clarification
        attempts = context.validation_attempts or 0
        if attempts > 3:
            # Too many attempts, reset and ask to start over
            context.incomplete_sql = None
            context.missing_mandatory_fields = None
            context.collected_field_values = None
            context.validation_attempts = None
            context.pause_reason = None
            context.response = "I'm having trouble understanding the field values. Let's start over. Please say 'add a customer' and I'll guide you through it step by step."
            context.next = "CustomerResponse"
        else:
            context.response = """I couldn't extract the required information from your message. Please provide the missing fields using natural language:

📞 **Phone**: Just mention the 10-11 digit number
   Example: "Phone is 01798695259" or "01798695259"

📧 **Email**: Your email address  
   Example: "Email: john@company.com" or "john@company.com"

🏢 **Customer Type**: Use natural terms
   • "Corporate", "Business", "Company" → Corporate
   • "Dealer", "Reseller", "Distributor" → Dealer  
   • "Retail", "Individual", "Personal" → Retail

💰 **Tax Classification**: Use simple terms
   • "Local", "Registered", "Domestic" → Local-Registered
   • "Zero", "Export", "Foreign" → Zero-Registered

🏛️ **Organization**: Company/organization name
   Example: "Organization: pTech Solutions" or "pTech Solutions"

💡 **You can provide multiple fields at once**: "Phone 01798695259, email john@ptech.com, corporate, local registered, pTech Solutions" """
            context.next = "CustomerResponse"
        return context.model_dump()
    
    # Update the incomplete SQL with new field values
    updated_sql = update_sql_with_fields(incomplete_sql, extracted_fields)
    context.sql = updated_sql
    
    logger.info(f"[CollectMissingFields] Updated SQL: {updated_sql}")
    
    # Re-validate the updated SQL
    context.next = "ValidateInsertFields"
    return context.model_dump()

async def generate_customer_id_node(context):
    """
    Enhanced customer ID generation node with better error handling.
    """
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    try:
        # Generate the next customer ID
        logger.info(f"[GenerateCustomerID] Starting for business_id: {context.business_id}")
        next_customer_id = await get_next_customer_id(context.business_id)
        logger.info(f"[GenerateCustomerID] Generated: {next_customer_id}")
        
        # Get the current SQL
        sql = context.sql or ""
        
        if "insert" in sql.lower() and "cacus" in sql.lower():
            # Parse the INSERT statement more robustly
            import re
            
            # Pattern to match INSERT INTO table (columns) VALUES (values)
            pattern = r"INSERT\s+INTO\s+(\w+)\s*\(([^)]+)\)\s*VALUES\s*\(([^)]+)\)"
            match = re.search(pattern, sql, re.IGNORECASE | re.DOTALL)
            
            if match:
                table_name = match.group(1).strip()
                columns_str = match.group(2).strip()
                values_str = match.group(3).strip()
                
                # Split columns and values, handling potential whitespace
                columns = [col.strip() for col in columns_str.split(',')]
                values = [val.strip() for val in values_str.split(',')]
                
                logger.info(f"[GenerateCustomerID] Original columns: {columns}")
                logger.info(f"[GenerateCustomerID] Original values: {values}")
                
                # Find where to insert xcus (after zid)
                insert_position = 1  # Default after first column
                
                for i, col in enumerate(columns):
                    if 'zid' in col.lower():
                        insert_position = i + 1
                        break
                
                # Insert xcus column and value
                columns.insert(insert_position, 'xcus')
                values.insert(insert_position, f"'{next_customer_id}'")
                
                # Reconstruct the SQL
                new_columns = ', '.join(columns)
                new_values = ', '.join(values)
                context.sql = f"INSERT INTO {table_name} ({new_columns}) VALUES ({new_values})"
                
                logger.info(f"[GenerateCustomerID] Updated SQL: {context.sql}")
                
            else:
                logger.error(f"[GenerateCustomerID] Could not parse INSERT statement: {sql}")
                context.response = "Error: Could not generate customer ID due to SQL parsing issue."
                context.next = "CustomerResponse"
                return context.model_dump()
        
        context.next = "ExecuteCustomerSQL"
        return context.model_dump()
        
    except Exception as e:
        logger.error(f"[GenerateCustomerID] Error: {e}")
        context.response = f"Error generating customer ID: {e}"
        context.next = "CustomerResponse"
        return context.model_dump()

async def execute_customer_sql_node(context):
    """Execute customer SQL operations via MCP."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    sql = getattr(context, 'sql', None)
    business_id = getattr(context, 'business_id', None)
    
    # Business access control check - validate SQL only accesses user's business data
    access_violation = validate_business_access(sql, business_id)
    if access_violation:
        logger.warning(f"[CustomerSQL_ACCESS_DENIED] {access_violation}")
        context.response = access_violation
        return context.model_dump()
    
    logger.info(f"[CustomerSQL_EXECUTED] {sql}")
    start_time = time.time()
    
    try:
        mcp_result = await mcp_client.execute_query(sql, business_id)
        
        # Parse MCP result
        rows = []
        error_message = None
        
        if isinstance(mcp_result, dict):
            if mcp_result.get('error'):
                error_message = mcp_result['error']
            
            if 'content' in mcp_result and isinstance(mcp_result['content'], list):
                for item in mcp_result['content']:
                    if 'text' in item and 'error' in item['text'].lower():
                        error_message = item['text']
                        break
                
                try:
                    import json
                    parsed = json.loads(mcp_result['content'][0]['text'])
                    rows = parsed.get('results', [])
                except Exception as e:
                    logger.error(f"Error parsing customer MCP result: {e}")
                    rows = []
        
        elapsed = time.time() - start_time
        
        # Handle errors
        if error_message:
            logger.error(f"[CustomerSQL_ERROR] {error_message}")
            if 'foreign key constraint' in error_message.lower():
                # Extract customer ID from the error message for cascade deletion
                import re
                customer_id_match = re.search(r'CUS-\d{6}', error_message)
                if customer_id_match and 'delete' in sql.lower():
                    customer_id = customer_id_match.group()
                    logger.info(f"[CustomerSQL_CASCADE] Attempting cascade deletion for {customer_id}")
                    
                    # Try cascade deletion - delete dependent records first
                    cascade_sql = f"""
                    DELETE FROM cacuscon WHERE zid = {business_id} AND xcus = '{customer_id}';
                    DELETE FROM cacus WHERE zid = {business_id} AND xcus = '{customer_id}';
                    """
                    
                    try:
                        cascade_result = await mcp_client.execute_query(cascade_sql, business_id)
                        if isinstance(cascade_result, dict) and not cascade_result.get('error'):
                            context.response = "✅ Customer and all related records have been successfully deleted from the system."
                            # Clear pause fields
                            context.pause_reason = None
                            context.pause_message = None
                            context.confirm = None
                            context.resume_from_pause = None
                            return context.model_dump()
                    except Exception as cascade_error:
                        logger.error(f"[CustomerSQL_CASCADE_ERROR] {cascade_error}")
                
                context.response = "Unable to delete the customer because there are related records (such as contacts or orders). The system attempted to remove related records but encountered an issue. Please contact support for manual deletion."
            else:
                context.response = f"Sorry, I couldn't complete your request due to a database error: {error_message}"
            
            # Clear all operation state after error
            clear_all_operation_state(context)
            return context.model_dump()
        
        # Handle successful operations
        is_select = sql.strip().lower().startswith("select")
        is_insert = sql.strip().lower().startswith("insert")
        is_update = sql.strip().lower().startswith("update")
        is_delete = sql.strip().lower().startswith("delete")
        
        if is_select:
            if not rows:
                context.response = "No customers found matching your criteria. Would you like to try a different search or add a new customer?"
            else:
                from backend.app.utils.customer_chat_helpers import format_customer_result
                context.response = format_customer_result(rows)
        
        elif is_insert:
            # Fetch the newly created customer to show details
            try:
                # Extract the generated customer ID from the INSERT SQL
                import re
                customer_id_match = re.search(r"'(CUS-\d{6})'", sql)
                if customer_id_match:
                    new_customer_id = customer_id_match.group(1)
                    
                    # Query to get the newly created customer details
                    fetch_sql = f"SELECT * FROM cacus WHERE zid = {business_id} AND xcus = '{new_customer_id}'"
                    fetch_result = await mcp_client.execute_query(fetch_sql, business_id)
                    
                    if isinstance(fetch_result, dict) and 'content' in fetch_result:
                        try:
                            import json
                            parsed = json.loads(fetch_result['content'][0]['text'])
                            customer_data = parsed.get('results', [])
                            
                            if customer_data:
                                from backend.app.utils.customer_chat_helpers import format_customer_result
                                customer_details = format_customer_result(customer_data)
                                context.response = f"✅ Customer has been successfully added to the system!\n\n{customer_details}"
                            else:
                                context.response = f"✅ Customer has been successfully added to the system! Customer ID: {new_customer_id}"
                        except Exception as format_error:
                            logger.error(f"[CustomerSQL_FORMAT] Error formatting new customer: {format_error}")
                            context.response = f"✅ Customer has been successfully added to the system! Customer ID: {new_customer_id}"
                else:
                    context.response = "✅ Customer has been successfully added to the system! The customer ID has been automatically generated."
            except Exception as fetch_error:
                logger.error(f"[CustomerSQL_FETCH] Error fetching new customer: {fetch_error}")
                context.response = "✅ Customer has been successfully added to the system! The customer ID has been automatically generated."
            
            # Clear pause fields
            context.pause_reason = None
            context.pause_message = None
            context.confirm = None
            context.resume_from_pause = None
        
        elif is_update:
            context.response = "✅ Customer information has been successfully updated!"
            # Clear all operation state after successful completion
            clear_all_operation_state(context)
        
        elif is_delete:
            context.response = "✅ Customer has been successfully deleted from the system."
            # Clear all operation state after successful completion
            clear_all_operation_state(context)
        
        else:
            context.response = "Operation completed successfully."
    
    except Exception as e:
        logger.error(f"[CustomerSQL_EXCEPTION] {e}")
        context.response = f"Sorry, there was an error executing your request: {e}"
    
    return context.model_dump()

async def pause_node(context):
    """Handle pause state for confirmations with dynamic messaging."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    # Generate dynamic confirmation messages based on operation context
    if getattr(context, "pause_reason", None) == "confirm_update":
        # Extract operation details from SQL for more specific messaging
        sql = getattr(context, 'sql', '')
        operation_details = ""
        if 'SET' in sql.upper():
            # Try to extract what's being updated
            import re
            set_match = re.search(r'SET\s+(.+?)\s+WHERE', sql, re.IGNORECASE)
            if set_match:
                operation_details = f" ({set_match.group(1).strip()})"
        
        context.response = f"📝 You are about to update customer information{operation_details}. Do you want to proceed? Reply 'yes' to confirm or 'no' to cancel."
        context.pause_message = context.response
        
    elif getattr(context, "pause_reason", None) == "confirm_delete":
        # Extract customer ID if available for more specific messaging
        sql = getattr(context, 'sql', '')
        customer_info = ""
        if 'xcus' in sql:
            import re
            cus_match = re.search(r"xcus\s*=\s*'(CUS-\d{6})'", sql, re.IGNORECASE)
            if cus_match:
                customer_info = f" (Customer ID: {cus_match.group(1)})"
        
        context.response = f"⚠️ You are about to permanently delete a customer record{customer_info}. This action cannot be undone. Reply 'yes' to confirm or 'no' to cancel."
        context.pause_message = context.response
        
    elif getattr(context, "pause_reason", None) == "missing_mandatory_fields":
        # Use the detailed field collection message already set in validation node
        if hasattr(context, 'pause_message') and context.pause_message:
            context.response = context.pause_message
        else:
            context.response = "🔍 **I need some additional information to create the customer.** Please provide the missing mandatory fields."
    else:
        context.response = "Confirmation required for this action. Reply 'yes' to proceed or 'no' to cancel."
        context.pause_message = context.response
    
    return context.model_dump()

async def detect_dynamic_intent(message: str, conversation_history=None, operation_context=None) -> str:
    """
    Dynamic LLM-based intent detection for natural language confirmations.
    Returns: POSITIVE, NEGATIVE, or UNCLEAR
    """
    try:
        from backend.app.services.mistral_llm_service import MistralLLMService
        llm_service = MistralLLMService()
        
        # Build conversation context
        context_text = "No previous conversation"
        if conversation_history:
            context_parts = []
            # Get last 4 messages for context
            recent_messages = conversation_history[-4:]
            for msg in recent_messages:
                if hasattr(msg, 'role') and hasattr(msg, 'content'):
                    role, content = msg.role, msg.content
                elif isinstance(msg, dict):
                    role = msg.get('role', 'user')
                    content = msg.get('content', '')
                else:
                    continue
                context_parts.append(f"{role}: {content}")
            context_text = "\n".join(context_parts)
        
        operation_info = ""
        if operation_context:
            operation_info = f"\nOperation Context: {operation_context}"
        
        intent_prompt = f"""You are analyzing user intent for a confirmation system. The user was asked to confirm an operation and you need to understand their response.

CONVERSATION CONTEXT:
{context_text}

CURRENT USER MESSAGE: "{message}"{operation_info}

Analyze the user's response and classify their intent:

POSITIVE - User wants to proceed/confirm the operation:
- Direct confirmations: "yes", "sure", "ok", "do it", "go ahead", "proceed"
- Enthusiastic: "absolutely", "definitely", "of course", "let's do it"
- Conditional agreements: "yes please", "that's fine", "sounds good"
- Informal agreements: "yep", "yeah", "alright", "fine by me"

NEGATIVE - User wants to cancel/reject the operation:
- Direct rejections: "no", "cancel", "stop", "abort", "don't do it"
- Polite refusals: "no thanks", "never mind", "forget it", "skip this"
- Strong rejections: "absolutely not", "definitely not", "I don't want to"
- Cancellation requests: "cancel this", "stop the operation", "back out"

UNCLEAR - Intent is ambiguous, unrelated, or asking questions:
- Questions: "what will happen?", "are you sure?", "can you explain?"
- Unrelated responses: talking about something else entirely
- Ambiguous: "maybe", "I'm not sure", "let me think"
- Requests for more info: "show me details", "what exactly will change?"

IMPORTANT: Consider natural language variations, typos, and conversational context. People don't always say exactly "yes" or "no".

Respond with EXACTLY ONE WORD: POSITIVE, NEGATIVE, or UNCLEAR"""

        response = await llm_service.chat([
            {"role": "system", "content": "You are an expert intent classifier that understands natural language nuances. Always respond with exactly one word."},
            {"role": "user", "content": intent_prompt}
        ])
        
        intent = response.strip().upper()
        logger.info(f"[DynamicIntentDetection] Message: '{message}' → Intent: '{intent}'")
        
        if intent in ["POSITIVE", "NEGATIVE", "UNCLEAR"]:
            return intent
        else:
            # Fallback to simple pattern matching if LLM gives unexpected response
            logger.warning(f"[DynamicIntentDetection] Unexpected LLM response: '{response}', falling back to simple detection")
            return detect_fallback_intent(message)
            
    except Exception as e:
        logger.error(f"[DynamicIntentDetection] Error in LLM analysis: {e}")
        # Fallback to simple pattern matching
        return detect_fallback_intent(message)

def detect_fallback_intent(message: str) -> str:
    """
    Fallback intent detection using enhanced pattern matching.
    Returns: POSITIVE, NEGATIVE, or UNCLEAR
    """
    message_clean = message.lower().strip()
    
    # Remove punctuation for cleaner matching
    import string
    message_clean = message_clean.translate(str.maketrans('', '', string.punctuation))
    
    # Enhanced positive patterns with natural language variations
    positive_patterns = [
        'yes', 'yeah', 'yep', 'yup', 'sure', 'ok', 'okay', 'alright', 'confirm', 
        'proceed', 'go ahead', 'do it', 'continue', 'absolutely', 'definitely',
        'confirm delete', 'confirm update', 'yes delete', 'yes update',
        'sounds good', 'that works', 'fine by me', 'lets do it', 'of course',
        'please do', 'go for it', 'make it happen', 'thats fine'
    ]
    
    # Enhanced negative patterns with natural language variations
    negative_patterns = [
        'no', 'nope', 'cancel', 'stop', 'abort', 'dont', 'never mind', 
        'nevermind', 'forget it', 'skip', 'back', 'exit', 'quit',
        'no thanks', 'not now', 'i dont want', 'dont do it', 'cancel this',
        'stop this', 'abort this', 'back out', 'forget about it', 'skip this'
    ]
    
    # Check for positive intent
    if any(pattern in message_clean for pattern in positive_patterns):
        return "POSITIVE"
    
    # Check for negative intent
    if any(pattern in message_clean for pattern in negative_patterns):
        return "NEGATIVE"
    
    # If unclear, return UNCLEAR
    return "UNCLEAR"

# --- Reactive State Management System ---

class OperationContext:
    """Represents the current operation context for reactive behavior."""
    def __init__(self, operation_type=None, operation_stage=None, required_info=None, collected_info=None):
        self.operation_type = operation_type  # 'CREATE', 'UPDATE', 'DELETE', 'SEARCH'
        self.operation_stage = operation_stage  # 'INITIATED', 'COLLECTING_INFO', 'CONFIRMING', 'EXECUTING'
        self.required_info = required_info or {}  # What info is needed
        self.collected_info = collected_info or {}  # What info has been collected
        self.interruption_count = 0
        self.last_interruption = None

def get_operation_context(context) -> OperationContext:
    """Extract current operation context from state."""
    pause_reason = getattr(context, 'pause_reason', None)
    customer_action = getattr(context, 'customer_action', None)
    
    if pause_reason == 'missing_mandatory_fields':
        return OperationContext(
            operation_type='CREATE',
            operation_stage='COLLECTING_INFO',
            required_info={'phone': None, 'email': None, 'organization': None, 'customer_type': None, 'tax_scope': None},
            collected_info=getattr(context, 'collected_field_values', {}) or {}
        )
    elif pause_reason in ['confirm_update', 'confirm_delete']:
        op_type = 'UPDATE' if 'update' in pause_reason else 'DELETE'
        return OperationContext(
            operation_type=op_type,
            operation_stage='CONFIRMING',
            required_info={'customer_id': getattr(context, 'target_customer_info', {}).get('xcus', None) if getattr(context, 'target_customer_info', None) else None},
            collected_info={}
        )
    elif customer_action in ['UPDATE_CUSTOMER', 'DELETE_CUSTOMER']:
        op_type = customer_action.split('_')[0]
        return OperationContext(
            operation_type=op_type,
            operation_stage='INITIATED',
            required_info={'customer_id': None, 'update_fields': None},
            collected_info={}
        )
    
    return OperationContext()

async def analyze_query_relationship(user_message: str, current_operation: OperationContext, conversation_history=None) -> dict:
    """
    Analyze if the user's query is related to the current operation or is an interruption.
    Returns: {
        'relationship': 'RELATED' | 'UNRELATED' | 'CANCELLATION',
        'intent': 'CONTINUE' | 'INTERRUPT' | 'CANCEL',
        'confidence': float,
        'reasoning': str
    }
    """
    try:
        from .mistral_llm_service import MistralLLMService
        llm_service = MistralLLMService()
        
        # Build context for analysis
        operation_desc = f"{current_operation.operation_type} operation in {current_operation.operation_stage} stage"
        if current_operation.required_info:
            operation_desc += f", needs: {list(current_operation.required_info.keys())}"
        
        analysis_prompt = f"""You are analyzing user intent in a conversational customer management system.

CURRENT OPERATION: {operation_desc}

USER MESSAGE: "{user_message}"

ANALYSIS TASK: Determine the relationship between the user's message and the current operation.

RELATIONSHIP TYPES:
1. RELATED - Message continues/contributes to current operation
   Examples: 
   - Providing requested data ("phone is 123456789")
   - Asking clarifying questions ("what customer type options are there?")
   - Confirming/denying current operation ("yes, update it", "no, don't delete")
   
2. UNRELATED - Message starts a completely different operation
   Examples:
   - New customer operation while in middle of another ("show me all customers")
   - Different business query ("what's the weather?", "show sales report")
   - System queries ("help", "what can you do?")
   
3. CANCELLATION - Message explicitly cancels current operation
   Examples: "cancel", "stop", "never mind", "forget it", "abort", "quit"

INTENT TYPES:
- CONTINUE: User wants to proceed with current operation
- INTERRUPT: User wants to start something else (pause current operation)
- CANCEL: User wants to cancel current operation entirely

Respond with JSON:
{{
    "relationship": "RELATED|UNRELATED|CANCELLATION",
    "intent": "CONTINUE|INTERRUPT|CANCEL", 
    "confidence": 0.0-1.0,
    "reasoning": "brief explanation"
}}"""

        response = await llm_service.chat([
            {"role": "system", "content": "You are an expert conversation analyst. Always respond with valid JSON."},
            {"role": "user", "content": analysis_prompt}
        ])
        
        import json
        analysis = json.loads(response.strip())
        logger.info(f"[QueryRelationship] '{user_message}' → {analysis}")
        return analysis
        
    except Exception as e:
        logger.error(f"[QueryRelationship] Error: {e}")
        # Fallback analysis
        message_lower = user_message.lower().strip()
        
        # Check for cancellation
        cancel_words = ['cancel', 'stop', 'abort', 'quit', 'never mind', 'forget it', 'exit']
        if any(word in message_lower for word in cancel_words):
            return {"relationship": "CANCELLATION", "intent": "CANCEL", "confidence": 0.9, "reasoning": "cancellation keywords detected"}
        
        # Check for customer operations
        customer_words = ['customer', 'client', 'update', 'delete', 'add', 'create', 'search', 'find', 'show']
        if any(word in message_lower for word in customer_words):
            return {"relationship": "UNRELATED", "intent": "INTERRUPT", "confidence": 0.7, "reasoning": "new customer operation detected"}
        
        # Default to related for data-like responses
        return {"relationship": "RELATED", "intent": "CONTINUE", "confidence": 0.5, "reasoning": "fallback classification"}

def clear_all_operation_state(context):
    """
    Comprehensive state cleanup function to ensure no residual state remains
    after cancellation or completion of operations.
    """
    # Core pause/resume state
    context.pause_reason = None
    context.pause_message = None
    context.confirm = None
    context.resume_from_pause = None
    
    # SQL and query state
    context.sql = None
    context.incomplete_sql = None
    context.is_db_query = None
    context.sql_prompt = None
    context.db_result = None
    
    # Customer-specific state
    context.customer_action = None
    context.missing_mandatory_fields = None
    context.collected_field_values = None
    context.validation_attempts = None
    context.target_customer_info = None
    
    # System state
    context.system_prompt = None
    context.schema_context = None
    
    # Conversation flow state
    context.next = None
    
    logger.info("[StateCleanup] All operation state cleared successfully")

def preserve_operation_context(context, operation_context: OperationContext):
    """
    Preserve current operation context while handling interruptions.
    This allows resuming operations after interruptions are handled.
    """
    # Store operation context in a way that can be resumed
    context.preserved_operation = {
        'type': operation_context.operation_type,
        'stage': operation_context.operation_stage,
        'required_info': operation_context.required_info,
        'collected_info': operation_context.collected_info,
        'pause_reason': getattr(context, 'pause_reason', None),
        'pause_message': getattr(context, 'pause_message', None),
        'sql': getattr(context, 'sql', None),
        'incomplete_sql': getattr(context, 'incomplete_sql', None),
        'target_customer_info': getattr(context, 'target_customer_info', None)
    }
    logger.info(f"[OperationPreserved] {operation_context.operation_type} operation context saved")

async def analyze_user_intent(message: str, conversation_history=None, operation_context=None) -> str:
    """Analyze user intent using LLM with full conversation context for confirmation/cancellation detection."""
    try:
        # Build conversation context for better understanding
        context_text = ""
        if conversation_history:
            recent_messages = conversation_history[-8:] if len(conversation_history) > 8 else conversation_history
            logger.info(f"[IntentAnalysis] Processing {len(recent_messages)} conversation messages")
            for msg in recent_messages:
                role = msg.get('role', 'unknown') if isinstance(msg, dict) else getattr(msg, 'role', 'unknown')
                content = msg.get('content', '') if isinstance(msg, dict) else getattr(msg, 'content', '')
                context_text += f"{role.upper()}: {content}\n"
                logger.info(f"[IntentAnalysis] Added message: {role}: {content[:50]}...")
        else:
            logger.info(f"[IntentAnalysis] No conversation history available")
        
        # Add operation context if available
        operation_info = ""
        if operation_context:
            operation_info = f"\nPending Operation: {operation_context}"
        
        intent_prompt = f"""You are analyzing user intent in a conversation where the system asked for confirmation of an operation.

CONVERSATION CONTEXT:
{context_text}
CURRENT USER MESSAGE: "{message}"{operation_info}

CRITICAL CONTEXT ANALYSIS:
- Look at the LAST assistant message in the conversation
- If the last assistant message contains words like "canceled", "cancelled", "start fresh", then the operation was already cancelled
- If user says "yes" AFTER a cancellation message, they are NOT confirming the old operation - they are just acknowledging or starting fresh

The user was asked to confirm an operation. Analyze their response and classify their intent:

- POSITIVE: User agrees to proceed with the CURRENT pending operation (not a cancelled one)
  Examples: "yes", "sure", "go ahead", "do it", "confirm", "proceed", "okay", "alright", "fine"
  BUT ONLY if there's no recent cancellation message from assistant
  
- NEGATIVE: User disagrees, wants to cancel, rejects the action  
  Examples: "no", "cancel", "stop", "abort", "don't", "nevermind", "forget it", "skip", "nope", "forget", "i dont want", "dont want", "cancle it"
  
- UNCLEAR: Intent is ambiguous, unrelated, or user is responding to a cancellation message
  Examples: unclear responses, questions, unrelated topics, "yes" after cancellation

SPECIAL RULE: If the last assistant message mentioned cancellation/cancelled and user says "yes", classify as UNCLEAR (they're not confirming an operation)

Respond with ONLY one word: POSITIVE, NEGATIVE, or UNCLEAR"""

        response = await llm_service.chat([
            {"role": "system", "content": "You are an expert intent classifier that understands natural language nuances and conversation context. Always respond with exactly one word."},
            {"role": "user", "content": intent_prompt}
        ])
        
        intent = response.strip().upper()
        logger.info(f"[IntentAnalysis] Raw LLM response: '{response}'")
        logger.info(f"[IntentAnalysis] Processed intent: '{intent}'")
        logger.info(f"[IntentAnalysis] Message analyzed: '{message}'")
        logger.info(f"[IntentAnalysis] Operation context: '{operation_context}'")
        
        if intent in ["POSITIVE", "NEGATIVE", "UNCLEAR"]:
            return intent
        
        # If LLM returns unexpected format, try to extract intent
        if "positive" in response.lower():
            logger.info(f"[IntentAnalysis] Extracted POSITIVE from: '{response}'")
            return "POSITIVE"
        elif "negative" in response.lower():
            logger.info(f"[IntentAnalysis] Extracted NEGATIVE from: '{response}'")
            return "NEGATIVE"
        else:
            logger.info(f"[IntentAnalysis] Defaulting to UNCLEAR for: '{response}'")
            return "UNCLEAR"
        
    except Exception as e:
        logger.error(f"[IntentAnalysis] LLM Error: {e}")
        # Emergency fallback - return UNCLEAR to ask for clarification
        return "UNCLEAR"

async def analyze_confirmation_intent(message: str, conversation_history=None, operation_context=None) -> str:
    """Analyze if user message is a confirmation response or new query using LLM."""
    try:
        # Build conversation context
        context_text = ""
        if conversation_history:
            recent_messages = conversation_history[-4:] if len(conversation_history) > 4 else conversation_history
            for msg in recent_messages:
                role = msg.get('role', 'unknown') if isinstance(msg, dict) else getattr(msg, 'role', 'unknown')
                content = msg.get('content', '') if isinstance(msg, dict) else getattr(msg, 'content', '')
                context_text += f"{role.upper()}: {content}\n"
        
        confirmation_prompt = f"""You are analyzing user intent in a conversation where the system asked for confirmation.

CONVERSATION CONTEXT:
{context_text}
CURRENT USER MESSAGE: "{message}"
OPERATION CONTEXT: {operation_context}

Analyze the user's message and classify their intent:

- CONFIRMATION: User is responding to the field collection request by providing field values for the current customer creation
  Examples: "yes", "no", "email is john@example.com", "phone: 123456789", "organization pTech", "corporate", "local registered", "567" (when asked for phone), "ptech solutions" (when asked for organization)
  
- NEW_QUERY: User is asking something completely different, ignoring the field collection request, OR wants to cancel/stop the current operation, OR wants to perform operations on OTHER customers
  Examples: "update customer phone", "update last customer phone", "delete last customer", "show me customers", "last 5 customers", "search customer", "add new customer", "find customer", "cancel", "cancle", "cansel", "stop", "quit", "exit", "no thanks", "never mind", "forget it"

CRITICAL DISTINCTION:
- CONFIRMATION = providing data FOR THE CURRENT customer being created
- NEW_QUERY = operations on OTHER/EXISTING customers OR completely different requests OR cancellations

IMPORTANT: Any mention of "last customer", "existing customer", "update customer", "delete customer" is ALWAYS NEW_QUERY because it refers to operations on other customers, not the current creation process.

CANCELLATION KEYWORDS: "cancel", "cancle", "cansel", "stop", "quit", "exit", "no thanks", "never mind", "forget it", "abort", "end", "nevermind"

IMPORTANT: Look for cancellation intent even with typos or misspellings. Common misspellings: "cancle", "cansel", "nevermind"

Respond with ONLY: CONFIRMATION or NEW_QUERY"""

        response = await llm_service.chat([
            {"role": "system", "content": "You are an expert intent classifier. Respond with exactly one word."},
            {"role": "user", "content": confirmation_prompt}
        ])
        
        intent = response.strip().upper()
        logger.info(f"[ConfirmationIntent] Message: '{message}' → Intent: '{intent}'")
        
        if intent in ["CONFIRMATION", "NEW_QUERY"]:
            return intent
        
        # Fallback parsing
        if "confirmation" in response.lower():
            return "CONFIRMATION"
        elif "new_query" in response.lower() or "new query" in response.lower():
            return "NEW_QUERY"
        else:
            # Default to CONFIRMATION to be safe (continue with existing flow)
            return "CONFIRMATION"
        
    except Exception as e:
        logger.error(f"[ConfirmationIntent] Error: {e}")
        # Safe fallback - assume confirmation to avoid breaking existing flow
        return "CONFIRMATION"

async def resume_or_classify_node(context):
    """
    Reactive node that handles interruptions intelligently.
    Distinguishes between related queries, unrelated interruptions, and cancellations.
    """
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    user_message = getattr(context, 'message', '').strip()
    current_pause_reason = getattr(context, 'pause_reason', None)
    
    logger.info(f"[ReactiveResumeOrClassify] user_message: '{user_message}', pause_reason: '{current_pause_reason}'")
    
    # If no active operation, proceed with classification
    if not current_pause_reason:
        context.next = "ClassifyCustomerQuery"
        return context.model_dump()
    
    # Get current operation context
    current_operation = get_operation_context(context)
    
    # Analyze query relationship to current operation
    relationship_analysis = await analyze_query_relationship(
        user_message, current_operation, getattr(context, 'conversation_history', [])
    )
    
    relationship = relationship_analysis.get('relationship', 'UNRELATED')
    intent = relationship_analysis.get('intent', 'INTERRUPT')
    confidence = relationship_analysis.get('confidence', 0.5)
    reasoning = relationship_analysis.get('reasoning', 'Unknown')
    
    logger.info(f"[ReactiveAnalysis] Relationship: {relationship}, Intent: {intent}, Confidence: {confidence:.2f}")
    logger.info(f"[ReactiveAnalysis] Reasoning: {reasoning}")
    
    # Handle based on relationship and intent
    if relationship == "CANCELLATION" or intent == "CANCEL":
        # User wants to cancel current operation
        logger.info(f"[ReactiveCancel] Cancelling {current_operation.operation_type} operation")
        clear_all_operation_state(context)
        context.response = f"✅ {current_operation.operation_type.title()} operation cancelled. How can I help you?"
        context.next = "CustomerResponse"
        return context.model_dump()
    
    elif relationship == "UNRELATED" and intent == "INTERRUPT":
        # User wants to do something else - preserve current operation and handle interruption
        logger.info(f"[ReactiveInterrupt] Handling interruption while preserving {current_operation.operation_type} operation")
        
        # Preserve current operation context
        preserve_operation_context(context, current_operation)
        
        # Clear current state to handle interruption
        clear_all_operation_state(context)
        
        # Inform user about interruption handling
        context.response = f"I'll help you with that. Your {current_operation.operation_type.lower()} operation is paused and can be resumed later."
        
        # Classify the interrupting query
        context.next = "ClassifyCustomerQuery"
        return context.model_dump()
        
    elif relationship == "RELATED" and intent == "CONTINUE":
        # User is continuing with current operation
        logger.info(f"[ReactiveContinue] Continuing {current_operation.operation_type} operation")
        
        if current_pause_reason == "missing_mandatory_fields":
            # Continue with field collection
            context.next = "CollectMissingFields"
            return context.model_dump()
        
        elif current_pause_reason in ['confirm_update', 'confirm_delete']:
            # Handle confirmation
            user_intent = await detect_dynamic_intent(
                user_message, 
                getattr(context, 'conversation_history', []), 
                f"{current_pause_reason}: {getattr(context, 'sql', 'Unknown operation')}"
            )
            
            if user_intent == "POSITIVE":
                logger.info(f"[ReactiveConfirm] Confirmation received for {current_pause_reason}")
                context.resume_from_pause = True
                context.confirm = True
                context.next = "ExecuteCustomerSQL"
                return context.model_dump()
        
            elif user_intent == "NEGATIVE":
                logger.info(f"[ReactiveConfirm] Operation declined for {current_pause_reason}")
                clear_all_operation_state(context)
                context.response = "✅ Operation cancelled. What would you like to do instead?"
                context.next = "CustomerResponse"
                return context.model_dump()
            
            else:
                # Ask for clarification
                action_type = "update" if "update" in current_pause_reason else "delete"
                context.response = f"Please confirm: Do you want to proceed with the {action_type}? Reply 'yes' to confirm or 'no' to cancel."
                context.next = "CustomerResponse"
                return context.model_dump()
        
        elif current_pause_reason == "specify_update_fields":
            # Handle unclear responses during UPDATE field specification
            logger.info(f"[ReactiveUpdateFields] Handling unclear response for update field specification: '{user_message}'")
            
            # Try to extract update information from the user message
            update_fields = await extract_update_fields_from_message(user_message)
            
            if update_fields:
                # User provided specific update information
                logger.info(f"[ReactiveUpdateFields] Extracted update fields: {update_fields}")
                # Continue with the update process
                context.next = "GenerateCustomerSQL"
                return context.model_dump()
            else:
                # Still unclear, provide helpful guidance
                target_info = getattr(context, 'target_customer_info', None)
                customer_name = target_info.get('name', 'the customer') if target_info else 'the customer'
                context.response = f"""📝 I need to know what information you'd like to update for {customer_name}. You can update:

🔹 **Contact Information:**
   • Phone: "update phone to 01234567890"
   • Email: "change email to john@newcompany.com"

🔹 **Business Details:**
   • Organization: "update organization to New Company Ltd"
   • Customer Type: "change to corporate" (Corporate/Dealer/Retail)
   • Tax Scope: "update tax scope to local registered"

🔹 **Multiple Fields:**
   • "update phone to 01234567890 and email to john@company.com"

💡 **Examples:**
   • "update his phone to 01798695259"
   • "change email to zahid@newcompany.com"  
   • "update organization to pTech Solutions"

What would you like to update?"""
                
                context.validation_attempts = (getattr(context, 'validation_attempts', 0) or 0) + 1
                
                # If too many unclear attempts, offer to start over
                if context.validation_attempts > 2:
                    context.response += "\n\n❓ If you're not sure what to update, you can:\n• Say 'show customer details' to see current information\n• Say 'cancel' to stop the update\n• Say 'list customers' to see all customers"
                
                context.next = "CustomerResponse"
                return context.model_dump()
    
    # Default fallback - treat as continuation
    logger.info(f"[ReactiveFallback] Defaulting to continuation for {current_operation.operation_type} operation")
    
    if current_pause_reason == "missing_mandatory_fields":
        context.next = "CollectMissingFields"
    else:
        context.next = "ExecuteCustomerSQL"
    
    return context.model_dump()


async def general_customer_chat_node(context):
    """Handle general customer-related conversations."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    context.conversation_history = ensure_chat_messages(context.conversation_history or [])
    
    # Build system prompt for general customer conversation
    system_prompt = build_customer_system_prompt(context, context.conversation_history, context.schema_context or [])
    
    messages = [{"role": "system", "content": system_prompt}]
    
    # Add conversation history
    if context.conversation_history:
        recent_history = context.conversation_history[-8:]
        for msg in recent_history:
            messages.append(msg.model_dump())
    
    # Add current message
    messages.append({"role": "user", "content": context.message})
    
    # Generate response
    response = await llm_service.chat(messages)
    context.response = response
    
    return context.model_dump()


async def customer_response_node(context):
    """Final response node for customer interactions."""
    if isinstance(context, ChatGraphState):
        context = context.model_dump()
    
    # Ensure context is not None
    if context is None:
        logger.error("[CustomerResponse] Context is None!")
        return {
            'response': 'Internal error: context is None',
            'routed_agent': 'customer',
            'routing_confidence': 'error'
        }
    
    output = {
        'message': context.get('message'),
        'business_id': context.get('business_id'),
        'user_id': context.get('user_id'),
        'conversation_history': context.get('conversation_history'),
        'response': context.get('response'),
        'schema_context': context.get('schema_context'),
        'is_db_query': context.get('is_db_query'),
        'sql_prompt': context.get('sql_prompt'),
        'sql': context.get('sql'),
        'db_result': context.get('db_result'),
        'next': None,  # Terminal node
        'pause_reason': context.get('pause_reason'),
        'pause_message': context.get('pause_message'),
        'confirm': context.get('confirm'),
        'resume_from_pause': context.get('resume_from_pause'),
        'routed_agent': 'customer',
        'customer_action': context.get('customer_action'),
        'missing_mandatory_fields': context.get('missing_mandatory_fields'),
        'collected_field_values': context.get('collected_field_values'),
        'validation_attempts': context.get('validation_attempts'),
    }
    
    logger.info(f"[CustomerGraph] Response: {output.get('response', '')[:100]}...")
    return output


# --- Build the Customer LangGraph Workflow ---
builder = StateGraph(ChatGraphState)

# Add nodes
builder.add_node("ClassifyCustomerQuery", classify_customer_query)
builder.add_node("RouteCustomerAction", route_customer_action)
builder.add_node("VectorSearch", vector_search_node)
builder.add_node("GenerateCustomerSQL", generate_customer_sql_node)
builder.add_node("CustomerDependencyCheck", customer_dependency_check_node)
builder.add_node("ValidateCustomerExists", validate_customer_exists_node)
builder.add_node("ConfirmCustomerOperation", confirm_customer_operation_node)
builder.add_node("ValidateInsertFields", validate_insert_fields_node)
builder.add_node("CollectMissingFields", collect_missing_fields_node)
builder.add_node("GenerateCustomerID", generate_customer_id_node)
builder.add_node("ExecuteCustomerSQL", execute_customer_sql_node)
builder.add_node("GeneralCustomerChat", general_customer_chat_node)
builder.add_node("PauseNode", pause_node)
builder.add_node("ResumeOrClassify", resume_or_classify_node)
builder.add_node("CustomerResponse", customer_response_node)

# Add edges
builder.add_edge("ClassifyCustomerQuery", "RouteCustomerAction")

# Conditional routing based on customer action
builder.add_conditional_edges(
    "RouteCustomerAction",
    lambda x: x.get("next") if isinstance(x, dict) else getattr(x, "next", None),
    {
        "VectorSearch": "VectorSearch",
        "GeneralCustomerChat": "GeneralCustomerChat",
        "ResumeOrClassify": "ResumeOrClassify"
    }
)

# Vector search leads to SQL generation
builder.add_edge("VectorSearch", "GenerateCustomerSQL")

# SQL generation leads to dependency check
builder.add_edge("GenerateCustomerSQL", "CustomerDependencyCheck")

# Dependency check routing
builder.add_conditional_edges(
    "CustomerDependencyCheck",
    lambda x: x.get("next") if isinstance(x, dict) else getattr(x, "next", None),
    {
        "ValidateCustomerExists": "ValidateCustomerExists",
        "ValidateInsertFields": "ValidateInsertFields",
        "ExecuteCustomerSQL": "ExecuteCustomerSQL",
        "PauseNode": "PauseNode",
        "CustomerResponse": "CustomerResponse"
    }
)

# Customer existence validation routing
builder.add_conditional_edges(
    "ValidateCustomerExists",
    lambda x: x.get("next") if isinstance(x, dict) else getattr(x, "next", None),
    {
        "ConfirmCustomerOperation": "ConfirmCustomerOperation",
        "CustomerResponse": "CustomerResponse"
    }
)

# Confirmation routing
builder.add_conditional_edges(
    "ConfirmCustomerOperation",
    lambda x: x.get("next") if isinstance(x, dict) else getattr(x, "next", None),
    {
        "PauseNode": "PauseNode",
        "ExecuteCustomerSQL": "ExecuteCustomerSQL",
        "CustomerResponse": "CustomerResponse"
    }
)

# Insert field validation routing
builder.add_conditional_edges(
    "ValidateInsertFields",
    lambda x: x.get("next") if isinstance(x, dict) else getattr(x, "next", None),
    {
        "PauseNode": "PauseNode",
        "CollectMissingFields": "CollectMissingFields", 
        "GenerateCustomerID": "GenerateCustomerID",
        "CustomerResponse": "CustomerResponse"
    }
)

# Field collection routing
builder.add_conditional_edges(
    "CollectMissingFields",
    lambda x: x.get("next") if isinstance(x, dict) else getattr(x, "next", None),
    {
        "PauseNode": "PauseNode",
        "GenerateCustomerID": "GenerateCustomerID",
        "CustomerResponse": "CustomerResponse"
    }
)

# Customer ID generation leads to SQL execution
builder.add_edge("GenerateCustomerID", "ExecuteCustomerSQL")

# Resume or classify routing
builder.add_conditional_edges(
    "ResumeOrClassify",
    lambda x: x.get("next") if isinstance(x, dict) else getattr(x, "next", None),
    {
        "ClassifyCustomerQuery": "ClassifyCustomerQuery",
        "ExecuteCustomerSQL": "ExecuteCustomerSQL",
        "CollectMissingFields": "CollectMissingFields",
        "CustomerResponse": "CustomerResponse"
    }
)

# All terminal nodes lead to response
builder.add_edge("ExecuteCustomerSQL", "CustomerResponse")
builder.add_edge("GeneralCustomerChat", "CustomerResponse")
builder.add_edge("PauseNode", "CustomerResponse")

# Set entry and exit points
builder.set_entry_point("ClassifyCustomerQuery")
builder.set_finish_point("CustomerResponse")


# Compile the graph (for backward compatibility)
customer_chat_graph = builder.compile()
