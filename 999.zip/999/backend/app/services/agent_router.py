from .mistral_llm_service import MistralLLMService
from ..models.chat_graph_state import ChatGraphState
import logging
import re
import time
import hashlib
import json
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass
from collections import defaultdict

logger = logging.getLogger(__name__)

@dataclass
class RoutingDecision:
    """Represents a routing decision with confidence and reasoning."""
    agent_type: str
    confidence: float
    reasoning: str
    fallback_agents: List[str]
    metadata: Dict[str, Any]

@dataclass
class AgentCapability:
    """Represents an agent's capabilities and constraints."""
    name: str
    description: str
    keywords: List[str]
    complexity_score: int  # 1-10, higher means more complex queries
    priority: int  # Higher priority agents get preference in ties
    constraints: Dict[str, Any]

class DynamicAgentRouter:
    def __init__(self, agent_registry=None):
        self.llm_service = MistralLLMService()
        self.agent_registry = agent_registry
        self.classification_history = []  # Track classification decisions for learning
        self.classification_cache = {}  # Cache for similar queries (performance optimization)
        self.cache_ttl = 300  # Cache TTL in seconds (5 minutes)
        
        # Enhanced routing capabilities
        self.agent_capabilities = self._initialize_agent_capabilities()
        self.routing_patterns = defaultdict(list)  # Learn routing patterns
        self.confidence_threshold = 0.7  # Minimum confidence for routing
        self.learning_enabled = True  # Enable adaptive learning
        self.context_memory = {}  # Remember context between interactions
    
    def _initialize_agent_capabilities(self) -> Dict[str, AgentCapability]:
        """Initialize agent capabilities for dynamic routing."""
        return {
            'customer': AgentCapability(
                name='customer',
                description='Customer and client management operations',
                keywords=[
                    'customer', 'client', 'add customer', 'create customer', 'new customer',
                    'find customer', 'search customer', 'update customer', 'delete customer',
                    'list customer', 'show customer', 'customer data', 'customer info',
                    'phone', 'email', 'organization', 'contact', 'his details', 'her details'
                ],
                complexity_score=7,
                priority=2,
                constraints={
                    'requires_database': True,
                    'data_sensitive': True,
                    'confirmation_required': ['update', 'delete']
                }
            ),
            'general': AgentCapability(
                name='general',
                description='General business operations and conversations',
                keywords=[
                    'hello', 'hi', 'hey', 'thanks', 'thank you', 'help', 'support',
                    'sales', 'orders', 'inventory', 'products', 'reports', 'analytics',
                    'business', 'operations', 'system', 'information'
                ],
                complexity_score=5,
                priority=1,
                constraints={
                    'fallback_agent': True,
                    'general_purpose': True
                }
            ),
            # Extensible for future agents
            'analytics': AgentCapability(
                name='analytics',
                description='Data analysis and reporting operations',
                keywords=[
                    'report', 'analytics', 'dashboard', 'metrics', 'statistics',
                    'analysis', 'chart', 'graph', 'data', 'trends'
                ],
                complexity_score=8,
                priority=3,
                constraints={
                    'requires_database': True,
                    'compute_intensive': True
                }
            ),
            'inventory': AgentCapability(
                name='inventory',
                description='Inventory and product management',
                keywords=[
                    'inventory', 'stock', 'products', 'items', 'warehouse',
                    'supply', 'goods', 'catalog', 'sku', 'quantity'
                ],
                complexity_score=6,
                priority=2,
                constraints={
                    'requires_database': True,
                    'real_time_data': True
                }
            )
        }
        
    async def classify_and_route(self, state: Dict[str, Any]) -> Dict[str, Any]:
        """
        Enhanced dynamic classification and routing with improved context awareness.
        Returns the result from the selected agent.
        """
        try:
            # Convert state to ChatGraphState for consistency
            if isinstance(state, dict):
                context = ChatGraphState(**state)
            else:
                context = state
                
            # Enhanced pause state handling - route ALL pause reasons to customer agent
            pause_reasons = {'confirm_update', 'confirm_delete', 'missing_mandatory_fields', 'specify_update_fields'}
            current_pause_reason = getattr(context, 'pause_reason', None)
            logger.info(f"[AgentRouter] Checking pause_reason: {current_pause_reason}")
            
            if current_pause_reason in pause_reasons:
                try:
                    logger.info(f"[AgentRouter] Routing to customer agent due to pause_reason: {current_pause_reason}")
                    agent = self.agent_registry.get_agent('customer')
                    result = await agent.ainvoke(state)
                    if isinstance(result, dict):
                        result['routed_agent'] = 'customer'
                        result['routing_confidence'] = 'forced_pause_resume'
                        result['routing_reason'] = f'pause_reason: {current_pause_reason}'
                    logger.info(f"[AgentRouter] Customer agent result: {result.get('response', '')[:100] if isinstance(result, dict) else str(result)[:100]}")
                    return result
                except Exception as pause_error:
                    logger.error(f"[AgentRouter] Error handling pause state: {pause_error}")
                    # Clear ALL pause state and proceed with normal routing
                    if hasattr(context, 'pause_reason'):
                        context.pause_reason = None
                        context.pause_message = None
                        context.confirm = None
                        context.resume_from_pause = None
                        context.target_customer_info = None
                        context.missing_mandatory_fields = None
                        context.collected_field_values = None
                        context.validation_attempts = None

            # Check cache first for performance optimization
            cache_key = self._generate_cache_key(context)
            cached_result = self._get_cached_classification(cache_key)
            
            if cached_result:
                agent_type = cached_result
                logger.info(f"[AGENT_CACHED] {agent_type}")
            else:
                # Perform dynamic classification
                logger.info(f"[AgentRouter] Starting LLM classification for: '{context.message}'")
                agent_type = await self._classify_query_dynamically(context)
                logger.info(f"[AGENT_CLASSIFIED] {agent_type} for message: '{context.message}'")
                
                # Cache the result for similar future queries
                self._cache_classification(cache_key, agent_type)
            
            # Track the classification decision
            self._track_classification(context.message, agent_type)
            
            # Get the appropriate agent
            agent = self.agent_registry.get_agent(agent_type)
            if not agent:
                logger.error(f"[AgentRouter] Agent '{agent_type}' not found, falling back to general")
                agent = self.agent_registry.get_agent('general')
            
            # Execute with the selected agent
            result = await agent.ainvoke(state)
            
            # Add routing metadata to result
            if isinstance(result, dict):
                result['routed_agent'] = agent_type
                result['routing_confidence'] = 'high'
            
            return result
            
        except Exception as e:
            logger.error(f"[AgentRouter] Error in classification/routing: {e}")
            logger.error(f"[AgentRouter] Message was: '{context.message if hasattr(context, 'message') else 'unknown'}'")
            
            # Try fallback classification before defaulting to general
            try:
                fallback_classification = self._fallback_classification(context.message if hasattr(context, 'message') else "")
                logger.info(f"[AgentRouter] Fallback classification: {fallback_classification}")
                
                if fallback_classification == 'customer':
                    agent = self.agent_registry.get_agent('customer')
                else:
                    agent = self.agent_registry.get_agent('general')
                    
                result = await agent.ainvoke(state)
                
                if isinstance(result, dict):
                    result['routed_agent'] = fallback_classification
                    result['routing_confidence'] = 'fallback_after_error'
                    
                return result
                
            except Exception as fallback_error:
                logger.error(f"[AgentRouter] Even fallback failed: {fallback_error}")
                # Last resort: general agent
                fallback_agent = self.agent_registry.get_agent('general')
                result = await fallback_agent.ainvoke(state)
                
                if isinstance(result, dict):
                    result['routed_agent'] = 'general'
                    result['routing_confidence'] = 'emergency_fallback'
                
                return result
    
    async def _classify_query_dynamically(self, context: ChatGraphState) -> str:
        """
        Optimized dynamic LLM-based agent classification with conversation context.
        Uses conversation history and intent analysis for accurate routing.
        """
        try:
            # Build optimized conversation context (last 6 messages)
            conversation_context = self._build_optimized_context(context)
            
            # Enhanced dynamic classification prompt with improved conversation understanding
            system_prompt = """You are an expert agent router with advanced conversation understanding and context awareness. Make intelligent routing decisions based on conversation flow and user intent.

AVAILABLE AGENTS:
🔹 customer: Customer/Client data operations, relationship management, and customer workflows
🔹 general: All other business queries, greetings, and general conversation

CUSTOMER AGENT RESPONSIBILITIES:
✅ Creating/adding new customers or clients
✅ Searching/finding existing customer information  
✅ Updating customer details and records
✅ Deleting/removing customers from system
✅ Listing customers with various filters
✅ Customer relationship management tasks
✅ Customer data validation and collection
✅ Handling incomplete customer information
✅ Confirmations for customer operations (yes/no responses)
✅ Continuing ongoing customer workflows
✅ Collecting missing customer data fields
✅ Customer data corrections and updates

GENERAL AGENT RESPONSIBILITIES:
✅ Greetings and casual conversation
✅ Business operations (orders, sales, inventory, products)
✅ Reports and analytics (non-customer specific)
✅ System information and help requests
✅ General business inquiries
✅ Non-customer confirmations

CRITICAL ROUTING RULES:
🚨 **EXPLICIT CUSTOMER KEYWORDS OVERRIDE CONTEXT**: If user message contains "customer", "client", "add customer", "create customer", "find customer", "search customer", "update customer", "delete customer" → ALWAYS route to customer agent regardless of conversation history
🚨 **CANCELLATION RECOVERY**: After a cancelled operation, treat new explicit requests as fresh operations
🚨 **KEYWORD PRIORITY**: Direct customer operation keywords take precedence over conversational context

CONTEXT ANALYSIS RULES:
🎯 **Workflow Continuity**: If previous messages show active customer operations → route to customer
🎯 **Data Collection**: If user is providing customer data (phone, email, etc.) → route to customer
🎯 **Dynamic Confirmation Context**: Route natural language confirmations/rejections to the agent handling the pending operation
🎯 **Natural Language Understanding**: "sounds good", "let's do it", "forget it", "never mind" → route based on context
🎯 **Topic Switching**: Clear topic changes from customer to general → route to general
🎯 **Implicit References**: "his details", "update him", "delete this" in customer context → route to customer
🎯 **Keyword Equivalence**: "client" = "customer" (treat identically)

ENHANCED ROUTING LOGIC:
1. **Keywords First**: Check for explicit customer operation keywords before analyzing context
2. **Intent Recognition**: Understand user's actual goal beyond surface words
3. **Workflow Preservation**: Maintain active customer operations until completion
4. **Smart Confirmations**: Route confirmations based on what's being confirmed
5. **Fresh Start**: After cancellations, treat new requests as independent operations
6. **Explicit Customer Operations**: Always route customer keywords to customer agent

EXAMPLES:
- "add a customer" → customer (explicit keyword - ALWAYS customer regardless of context)
- "add customer" → customer (explicit keyword - ALWAYS customer regardless of context)
- "create customer" → customer (explicit keyword - ALWAYS customer regardless of context)
- "yes" (after customer delete confirmation) → customer (workflow context)
- "sounds good" (after customer update request) → customer (natural confirmation)
- "forget it" (during customer operation) → customer (natural cancellation)
- "let's do it" (after confirmation prompt) → customer (natural agreement)
- "never mind" (during any operation) → customer (natural cancellation)
- "his phone number is 123456789" → customer (data collection context)
- "hello" → general (greeting)
- "show me sales report" → general (non-customer operation)

Respond with EXACTLY ONE WORD: "customer" or "general" """

            user_prompt = f"""CONVERSATION CONTEXT:
{conversation_context}

CURRENT QUERY: "{context.message}"

Route to:"""
            
            # Single optimized LLM call
            logger.info(f"[AgentRouter] Sending to LLM: '{context.message}'")
            classification_response = await self.llm_service.chat([
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ])
            
            logger.info(f"[AgentRouter] LLM Raw Response: '{classification_response}'")
            
            # Fast parsing with fallback
            raw = classification_response.strip().lower()
            cleaned = re.sub(r"[^a-z]", "", raw)
            
            logger.info(f"[AgentRouter] Cleaned Response: '{cleaned}'")
            
            if cleaned in ["customer", "general"]:
                agent_type = cleaned
                logger.info(f"[AgentRouter] Direct match: {agent_type}")
            else:
                # Fallback: detect keywords in raw response
                if "customer" in raw:
                    agent_type = "customer"
                    logger.info(f"[AgentRouter] Keyword match: customer")
                elif "general" in raw:
                    agent_type = "general"
                    logger.info(f"[AgentRouter] Keyword match: general")
                else:
                    logger.warning(f"[AgentRouter] Invalid classification '{classification_response}', using fallback classification")
                    fallback_result = self._fallback_classification(context.message)
                    logger.info(f"[AgentRouter] Fallback result: {fallback_result}")
                    return fallback_result
                
            logger.info(f"[AgentRouter] Final LLM classification: {agent_type}")
            return agent_type
            
        except Exception as e:
            logger.error(f"[AgentRouter] Error in dynamic classification: {e}")
            # Fallback to rule-based classification
            return self._fallback_classification(context.message)
    
    def _build_optimized_context(self, context: ChatGraphState) -> str:
        """Build intelligent conversation context with workflow awareness."""
        if not context.conversation_history:
            return "No previous conversation"
        
        # Get last 8 messages for better context (increased from 6)
        recent_messages = context.conversation_history[-8:]
        context_parts = []
        
        # Track conversation themes
        customer_keywords = ['customer', 'client', 'add', 'create', 'update', 'delete', 'search', 'find', 'phone', 'email']
        customer_score = 0
        
        for msg in recent_messages:
            # Process message content
            if hasattr(msg, 'role') and hasattr(msg, 'content'):
                role, content = msg.role, msg.content
            elif isinstance(msg, dict):
                role = msg.get('role', 'user')
                content = msg.get('content', '')
            else:
                continue
            
            # Analyze content for customer-related themes
            content_lower = content.lower()
            for keyword in customer_keywords:
                if keyword in content_lower:
                    customer_score += 1
            
            # Preserve important context, truncate less important messages
            if any(word in content_lower for word in ['confirm', 'yes', 'no', 'cancel', 'phone', 'email']):
                # Keep confirmation and data messages full
                display_content = content[:200] + "..." if len(content) > 200 else content
            else:
                # Truncate general messages more aggressively
                display_content = content[:80] + "..." if len(content) > 80 else content
            
            context_parts.append(f"{role}: {display_content}")
        
        # Add context analysis
        context_analysis = ""
        if customer_score > 2:
            context_analysis = "[CONTEXT: Active customer conversation detected] "
        elif customer_score > 0:
            context_analysis = "[CONTEXT: Some customer references found] "
        
        context_str = "\n".join(context_parts) if context_parts else "No context"
        return context_analysis + context_str
    
    def _build_conversation_context(self, context: ChatGraphState) -> str:
        """Legacy method - redirects to optimized version."""
        return self._build_optimized_context(context)
    
    def _generate_cache_key(self, context: ChatGraphState) -> str:
        """Generate a cache key based on message and recent context."""
        # Use message + last 2 conversation turns for cache key
        cache_input = context.message.lower().strip()
        
        if context.conversation_history:
            recent = context.conversation_history[-2:]
            for msg in recent:
                if hasattr(msg, 'content'):
                    cache_input += msg.content[:50]  # First 50 chars only
                elif isinstance(msg, dict):
                    cache_input += msg.get('content', '')[:50]
        
        return hashlib.md5(cache_input.encode()).hexdigest()
    
    def _get_cached_classification(self, cache_key: str) -> str:
        """Get cached classification if valid and not expired."""
        if cache_key in self.classification_cache:
            cached_data = self.classification_cache[cache_key]
            if time.time() - cached_data['timestamp'] < self.cache_ttl:
                return cached_data['agent_type']
            else:
                # Remove expired cache entry
                del self.classification_cache[cache_key]
        return None
    
    def _cache_classification(self, cache_key: str, agent_type: str):
        """Cache the classification result."""
        self.classification_cache[cache_key] = {
            'agent_type': agent_type,
            'timestamp': time.time()
        }
        
        # Limit cache size to prevent memory bloat
        if len(self.classification_cache) > 1000:
            # Remove oldest 200 entries
            sorted_items = sorted(self.classification_cache.items(), 
                                key=lambda x: x[1]['timestamp'])
            for key, _ in sorted_items[:200]:
                del self.classification_cache[key]
    
    def _fallback_classification(self, message: str) -> str:
        """
        Optimized fallback classification using fast pattern matching.
        This is used only when LLM classification fails.
        """
        message_lower = message.lower().strip()
        
        # PRIORITY: Customer operations - check first before greetings
        customer_keywords = [
            'customer', 'client', 'add customer', 'create customer', 'new customer',
            'find customer', 'search customer', 'update customer', 'delete customer',
            'list customer', 'show customer', 'customer data', 'customer info',
            'last customer', 'latest customer', 'recent customer', 'last 5 customer',
            'last 10 customer', 'top customer', 'all customer', 'customer count'
        ]
        
        # Quick keyword check for performance - PRIORITY CHECK
        if any(keyword in message_lower for keyword in customer_keywords):
            return 'customer'
        
        # Greetings and general conversation - only after customer check
        greeting_patterns = ['hi', 'hello', 'hey', 'good morning', 'good afternoon', 'good evening', 'how are you', 'thanks', 'thank you']
        if any(pattern in message_lower for pattern in greeting_patterns):
            return 'general'
        
        # Default to general for everything else
        return 'general'

    def _track_classification(self, query: str, agent_type: str, confidence: str = 'high'):
        """
        Track classification decisions for potential learning and improvement.
        """
        classification_record = {
            'query': query,
            'agent_type': agent_type,
            'confidence': confidence,
            'timestamp': time.time()
        }
        self.classification_history.append(classification_record)
        
        # Keep only last 1000 classifications to prevent memory bloat
        if len(self.classification_history) > 1000:
            self.classification_history = self.classification_history[-1000:]
    
    def get_classification_stats(self):
        """
        Get statistics about classification decisions for monitoring and improvement.
        """
        if not self.classification_history:
            return {'total': 0, 'customer': 0, 'general': 0}
        
        total = len(self.classification_history)
        customer_count = sum(1 for record in self.classification_history if record['agent_type'] == 'customer')
        general_count = sum(1 for record in self.classification_history if record['agent_type'] == 'general')
        
        return {
            'total': total,
            'customer': customer_count,
            'general': general_count,
            'customer_percentage': (customer_count / total) * 100 if total > 0 else 0,
            'general_percentage': (general_count / total) * 100 if total > 0 else 0
        }

 