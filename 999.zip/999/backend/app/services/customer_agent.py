from backend.app.services.base_agent import BaseAgent
from backend.app.services.customer_chat_graph import customer_chat_graph
import logging

logger = logging.getLogger(__name__)

class CustomerAgent(BaseAgent):
    """
    Customer Agent that uses LangGraph workflow for customer-related queries and operations.
    """
    
    async def ainvoke(self, state):
        """
        Process customer-related queries using LangGraph workflow.
        """
        if not isinstance(state, dict):
            raise ValueError(f"Expected state to be a dictionary, got {type(state)}")
        
        try:
            result = await customer_chat_graph.ainvoke(state)
            return result
        except Exception as e:
            logger.error(f"[CustomerAgent] Error in LangGraph execution: {e}")
            import traceback
            logger.error(f"[CustomerAgent] Traceback: {traceback.format_exc()}")
            
            # Return a safe fallback response
            return {
                'message': state.get('message', ''),
                'business_id': state.get('business_id', ''),
                'user_id': state.get('user_id', ''),
                'conversation_history': state.get('conversation_history', []),
                'response': f"I encountered an error while processing your customer request. Please try again or contact support. Error: {str(e)}",
                'routed_agent': 'customer',
                'routing_confidence': 'error_fallback'
            }
