"""
Schema models for table and column definitions.
"""

from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel, Field
from bson import ObjectId
from backend.app.models.business import PyObjectId

class ColumnSchema(BaseModel):
    """Column schema model"""
    name: str
    type: str
    description: Optional[str] = ""
    is_nullable: bool = True
    is_primary_key: bool = False
    max_length: Optional[int] = None
    default_value: Optional[str] = None

class TableSchema(BaseModel):
    """Table schema model"""
    id: Optional[PyObjectId] = Field(default_factory=PyObjectId, alias="_id")
    business_id: str = Field(index=True)
    table_name: str
    schema_description: str
    columns: List[ColumnSchema]
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    
    class Config:
        validate_by_name = True
        arbitrary_types_allowed = True
        json_encoders = {ObjectId: str}

class TableSchemaCreate(BaseModel):
    """Model for creating table schema"""
    table_name: str
    schema_description: str
    columns: List[ColumnSchema]

class TableSchemaUpdate(BaseModel):
    """Model for updating table schema"""
    schema_description: Optional[str] = None
    columns: Optional[List[ColumnSchema]] = None
