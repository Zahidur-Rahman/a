from backend.app.services.mistral_llm_service import MistralLLMService
import logging

logger = logging.getLogger(__name__)

class CustomerQueryClassifier:
    """
    Classifies customer-related queries to determine the appropriate action.
    """
    
    def __init__(self):
        self.llm_service = MistralLLMService()
    
    async def classify_query(self, query: str) -> str:
        """
        Classify a customer query into one of the following categories:
        - CREATE_CUSTOMER: User wants to add a new customer
        - SEARCH_CUSTOMER: User wants to find existing customers
        - UPDATE_CUSTOMER: User wants to modify customer information
        - DELETE_CUSTOMER: User wants to remove a customer
        - LIST_CUSTOMERS: User wants to see all/recent customers
        - GENERAL_CUSTOMER: General customer-related conversation
        """
        try:
            classification_prompt = f"""
You are a query classifier for a customer management system. Classify the following query into one of these categories:

1. CREATE_CUSTOMER - User wants to add/create a new customer
   Examples: "add a new customer", "create customer", "register new client", "I want to add customer John"

2. SEARCH_CUSTOMER - User wants to find/search for existing customers
   Examples: "find customer John", "search for customers", "look up client", "show me customer with email", "his details", "show his info", "this customer details"

3. UPDATE_CUSTOMER - User wants to modify existing customer information
   Examples: "update customer info", "change customer details", "edit customer", "modify client data", "update his phone", "change his email", "his details", "update this customer"

4. DELETE_CUSTOMER - User wants to remove/delete a customer
   Examples: "delete customer", "remove client", "cancel customer account"

5. LIST_CUSTOMERS - User wants to see all customers or recent customers
   Examples: "show all customers", "list customers", "recent customers", "last 10 customers"

6. GENERAL_CUSTOMER - General customer-related questions or conversation
   Examples: "what is a customer?", "how do customers work?", "customer management help"

Query: "{query}"

Respond with only the category name (e.g., CREATE_CUSTOMER, SEARCH_CUSTOMER, etc.).
"""

            messages = [
                {"role": "system", "content": "You are a precise query classifier. Respond only with the exact category name."},
                {"role": "user", "content": classification_prompt}
            ]
            
            response = await self.llm_service.chat(messages)
            classification = response.strip().upper()
            
            # Validate classification
            valid_classifications = [
                'CREATE_CUSTOMER', 'SEARCH_CUSTOMER', 'UPDATE_CUSTOMER', 
                'DELETE_CUSTOMER', 'LIST_CUSTOMERS', 'GENERAL_CUSTOMER'
            ]
            
            if classification in valid_classifications:
                logger.info(f"[CustomerQueryClassifier] Query '{query}' classified as: {classification}")
                return classification
            else:
                logger.warning(f"[CustomerQueryClassifier] Invalid classification '{classification}', defaulting to GENERAL_CUSTOMER")
                return 'GENERAL_CUSTOMER'
                
        except Exception as e:
            logger.error(f"[CustomerQueryClassifier] Error classifying query: {e}")
            return 'GENERAL_CUSTOMER'
    
    def is_customer_related(self, query: str) -> bool:
        """
        Simple check to determine if a query is customer-related.
        """
        customer_keywords = [
            'customer', 'client', 'customers', 'clients',
            'add customer', 'create customer', 'new customer',
            'find customer', 'search customer', 'list customer',
            'update customer', 'edit customer', 'modify customer',
            'delete customer', 'remove customer', 'his details',
            'his info', 'his phone', 'his email', 'this customer',
            'that customer', 'these customers'
        ]
        
        query_lower = query.lower()
        return any(keyword in query_lower for keyword in customer_keywords)
