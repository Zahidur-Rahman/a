from backend.app.services.base_agent import BaseAgent
from backend.app.agents.general_agent.chat_graph import get_chat_graph

class GeneralAgent(BaseAgent):
    async def ainvoke(self, state):
        if not isinstance(state, dict):
            raise ValueError(f"Expected state to be a dictionary, got {type(state)}")
        # Get fresh compiled graph to avoid caching issues
        graph = get_chat_graph()
        return await graph.ainvoke(state)
