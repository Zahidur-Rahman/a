"""
Reactive Customer Insert Flow - Handles customer creation with enhanced validation and error handling
"""
from backend.app.models.chat_graph_state import ChatGraphState
from backend.app.services.mistral_llm_service import MistralLLMService
from backend.app.services.vector_search import FaissVectorSearchService
from backend.app.mcp.mcp_client import MCPClient
from backend.app.agents.customer_agent.customer_chat_helpers import (
    get_next_customer_id, build_customer_sql_prompt, clean_sql_from_llm, 
    extract_customer_fields_from_message, format_customer_result,
    get_customer_schema_context_for_flow
)
from backend.app.agents.customer_agent.negative_vibe_detector import negative_vibe_detector
from backend.app.agents.customer_agent.flow_interruption_handler import flow_interruption_handler
import logging
import json
import re
import importlib

logger = logging.getLogger(__name__)

# Initialize services
llm_service = MistralLLMService()
vector_search_service = FaissVectorSearchService()
mcp_client = MCPClient(script_path="backend/app/mcp/server_enhanced.py")

def is_valid_email(email):
    """Validate email format."""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None

def is_valid_phone(phone):
    """Validate phone number (10 or 11 digits)."""
    if not phone or not phone.isdigit():
        return False
    return len(phone) in [10, 11]

def extract_insert_fields_from_sql(sql):
    """Extract field names and values from INSERT SQL statement."""
    # Pattern to match INSERT INTO table (columns) VALUES (values)
    pattern = r'INSERT\s+INTO\s+\w+\s*\(([^)]+)\)\s*VALUES\s*\(([^)]+)\)'
    match = re.search(pattern, sql, re.IGNORECASE | re.DOTALL)
    
    if not match:
        return {}
    
    columns_str = match.group(1).strip()
    values_str = match.group(2).strip()
    
    # Split columns and values, handling commas inside quotes
    columns = parse_sql_list(columns_str)
    values = parse_sql_list(values_str)
    
    # Create field dictionary
    fields = {}
    for i, col in enumerate(columns):
        if i < len(values):
            fields[col.strip()] = values[i].strip()
    
    return fields

def parse_sql_list(sql_list_str):
    """Parse SQL list handling commas inside quotes."""
    parts = []
    current = ""
    in_quotes = False
    quote_char = None
    
    for char in sql_list_str:
        if char in ["'", '"'] and not in_quotes:
            in_quotes = True
            quote_char = char
            current += char
        elif char == quote_char and in_quotes:
            in_quotes = False
            quote_char = None
            current += char
        elif char == ',' and not in_quotes:
            parts.append(current.strip())
            current = ""
        else:
            current += char
    
    if current.strip():
        parts.append(current.strip())
    
    return parts

async def generate_insert_sql_node(context):
    """Generate SQL for customer INSERT operations with reactive validation and error handling."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    logger.info(f"[ReactiveInsertFlow] Starting INSERT flow for: {context.message}")
    
    # Set current flow
    context.current_flow = "insert"
    
    # Check for negative vibe first
    negative_vibe = await negative_vibe_detector.detect_negative_vibe(
        context.message, context.conversation_history
    )
    
    if negative_vibe['is_negative']:
        logger.info("[ReactiveInsertFlow] Negative vibe detected, canceling flow")
        context = _clear_insert_flow_state(context)
        context.response = negative_vibe['suggested_response']
        context.next = "CustomerResponse"
        return context.model_dump()
    
    # Check for flow interruption
    interruption_check = await _check_insert_flow_interruption(context)
    if interruption_check['is_interrupted']:
        return interruption_check['response']
    
    # Get schema context for insert operations
    if not hasattr(context, 'schema_context') or not context.schema_context:
        context.schema_context = await get_customer_schema_context_for_flow(context.business_id, "insert")
    
    # PHASE 1: Data Collection - Check if we have all required information
    if not hasattr(context, 'collected_field_values') or not context.collected_field_values:
        context.collected_field_values = {}
    
    # Analyze completeness of customer data from current message + collected data
    data_analysis = await _analyze_customer_data_completeness_enhanced(context)
    
    if not data_analysis['is_complete']:
        logger.info("[ReactiveInsertFlow] Customer data incomplete, requesting missing information")
        
        # Update collected field values with any new data from current message
        new_fields = await _extract_fields_from_current_message(context)
        context.collected_field_values.update(new_fields)
        
        # Generate progressive data collection prompt
        context.pause_message = await _generate_progressive_data_collection_prompt(context, data_analysis)
        context.pause_reason = "missing_mandatory_fields"
        context.insert_phase = "data_collection"
        context.next = "PauseNode"
        return context.model_dump()
    
    # PHASE 2: Duplicate Check - All data collected, check for duplicates
    if not hasattr(context, 'duplicate_check_done') or not context.duplicate_check_done:
        logger.info("[ReactiveInsertFlow] Performing duplicate check")
        duplicate_result = await _check_for_duplicate_customers(context)
        
        if duplicate_result['has_duplicates']:
            context.response = await _generate_duplicate_handling_prompt(context, duplicate_result)
            context.pause_reason = "duplicate_customer_found"
            context.insert_phase = "duplicate_handling"
            context.next = "PauseNode"
            return context.model_dump()
        
        context.duplicate_check_done = True
    
    # PHASE 3: Final SQL Generation - All data collected and validated
    logger.info("[ReactiveInsertFlow] Generating final INSERT SQL")
    return await _generate_final_insert_sql(context)

async def validate_insert_fields_node(context):
    """
    Enhanced validation for customer insert operations with reactive error handling.
    Mandatory fields: xphone (10-11 digits), xemail (valid email), xgcus, xorg
    """
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    logger.info(f"[ReactiveInsertValidation] Validating fields for SQL: {context.sql}")
    
    try:
        # Check for flow interruption during validation
        interruption_check = await _check_insert_flow_interruption(context)
        if interruption_check['is_interrupted']:
            return interruption_check['response']
        
        # Check for negative vibe
        negative_vibe = await negative_vibe_detector.detect_negative_vibe(
            context.message, context.conversation_history
        )
        
        if negative_vibe['is_negative']:
            logger.info("[ReactiveInsertValidation] Negative vibe detected, canceling flow")
            context = _clear_insert_flow_state(context)
            context.response = negative_vibe['suggested_response']
            context.next = "CustomerResponse"
            return context.model_dump()
        
        # Required fields for customer insertion
        required_fields = ['xemail', 'xphone', 'xgcus', 'xorg']
        
        # Extract fields from SQL
        sql_fields = extract_insert_fields_from_sql(context.sql)
        logger.info(f"[ReactiveInsertValidation] Extracted fields: {sql_fields}")
        
        # Enhanced validation with detailed error reporting
        validation_result = await _validate_customer_fields(sql_fields, required_fields)
        
        # Initialize collected field values if not present
        if not hasattr(context, 'collected_field_values') or context.collected_field_values is None:
            context.collected_field_values = {}
        
        # Store valid fields in collected values
        for field, value in sql_fields.items():
            if field in required_fields:
                clean_value = value.strip("'\"")
                if clean_value:  # Only store non-empty values
                    context.collected_field_values[field] = clean_value
        
        if validation_result['missing_fields'] or validation_result['validation_errors']:
            # Store incomplete SQL for later completion
            context.incomplete_sql = context.sql
            context.missing_mandatory_fields = validation_result['missing_fields']
            
            # Generate enhanced progress and error message
            progress_message = await _generate_validation_progress_message(
                context, required_fields, validation_result
            )
            
            context.pause_message = progress_message
            context.pause_reason = "missing_mandatory_fields"
            context.next = "PauseNode"
            
            logger.info(f"[ReactiveInsertValidation] Missing fields: {validation_result['missing_fields']}, Errors: {validation_result['validation_errors']}")
            return context.model_dump()
        
        # All fields are valid, proceed to duplicate check
        logger.info("[ReactiveInsertValidation] All mandatory fields validated successfully")
        context.next = "CheckDuplicateCustomer"
        return context.model_dump()
        
    except Exception as e:
        logger.error(f"[ReactiveInsertValidation] Error during validation: {e}")
        context.response = "Error validating customer information. Please try again."
        context.next = "CustomerResponse"
        return context.model_dump()

async def collect_missing_fields_node(context):
    """
    Enhanced collection of missing mandatory fields with proper dictionary accumulation.
    """
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    logger.info(f"[ReactiveFieldCollection] Processing: {context.message}")
    
    try:
        # Check for negative vibe or cancellation first
        negative_vibe = await negative_vibe_detector.detect_negative_vibe(
            context.message, context.conversation_history
        )
        
        if negative_vibe['is_negative']:
            logger.info("[ReactiveFieldCollection] Negative vibe detected, canceling flow")
            context = _clear_insert_flow_state(context)
            context.response = negative_vibe['suggested_response']
            context.next = "CustomerResponse"
            return context.model_dump()
        
        # Check for flow interruption
        interruption_check = await _check_insert_flow_interruption(context)
        if interruption_check['is_interrupted']:
            return interruption_check['response']
        
        # Initialize collected_field_values dictionary if not present
        if not hasattr(context, 'collected_field_values') or context.collected_field_values is None:
            context.collected_field_values = {}
        
        # Extract fields from current message using enhanced extraction
        extracted_fields = await _extract_fields_from_current_message(context)
        logger.info(f"[ReactiveFieldCollection] Extracted from message: {extracted_fields}")
        
        # Accumulate fields in dictionary - preserve existing values, add new ones
        fields_updated = False
        for field, value in extracted_fields.items():
            if value and value.strip():  # Only update with non-empty values
                old_value = context.collected_field_values.get(field)
                context.collected_field_values[field] = value.strip()
                if old_value != value.strip():
                    fields_updated = True
                    logger.info(f"[ReactiveFieldCollection] Updated {field}: {old_value} -> {value.strip()}")
        
        # Re-analyze completeness with updated field dictionary
        data_analysis = await _analyze_customer_data_completeness_enhanced(context)
        
        if data_analysis['is_complete']:
            # All mandatory fields collected, proceed to final SQL generation
            logger.info("[ReactiveFieldCollection] All mandatory fields collected, generating final SQL")
            context.duplicate_check_done = False  # Reset for duplicate check
            context.insert_phase = "final_sql_generation"
            context.next = "GenerateInsertSQL"  # Go back to generate final SQL
            return context.model_dump()
        else:
            # Still missing fields, show updated progress and continue collection
            logger.info(f"[ReactiveFieldCollection] Still missing fields: {data_analysis['missing_fields']}")
            
            if fields_updated:
                # Show progress if fields were updated
                context.pause_message = await _generate_progressive_data_collection_prompt(context, data_analysis)
            else:
                # No new fields extracted, ask for clarification
                context.pause_message = await _generate_field_clarification_prompt(context, data_analysis)
            
            context.pause_reason = "missing_mandatory_fields"
            context.insert_phase = "data_collection"
            context.next = "PauseNode"
            return context.model_dump()
        
    except Exception as e:
        logger.error(f"[ReactiveFieldCollection] Error: {e}")
        context.response = "Error processing the information. Please try again with the required customer details."
        context.next = "CustomerResponse"
        return context.model_dump()

async def generate_customer_id_node(context):
    """
    Enhanced customer ID generation node with better error handling.
    """
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    logger.info("[CustomerIDGeneration] Starting customer ID generation")
    
    try:
        # Force reload and get fresh function reference
        from backend.app.agents.customer_agent import customer_chat_helpers
        importlib.reload(customer_chat_helpers)
        
        # Generate next customer ID with fresh function
        next_customer_id = await customer_chat_helpers.get_next_customer_id(context.business_id)
        logger.info(f"[CustomerIDGeneration] Generated ID: {next_customer_id}")
        
        # Inject customer ID into SQL
        if context.sql and next_customer_id:
            # Add xcus field to INSERT statement
            if 'xcus' not in context.sql.lower():
                # Find INSERT INTO pattern and add xcus
                insert_pattern = r'INSERT\s+INTO\s+(\w+)\s*\(([^)]+)\)\s*VALUES\s*\(([^)]+)\)'
                match = re.search(insert_pattern, context.sql, re.IGNORECASE)
                
                if match:
                    table_name = match.group(1)
                    columns = match.group(2).strip()
                    values = match.group(3).strip()
                    
                    # Add xcus to columns and values
                    new_columns = f"{columns}, xcus"
                    new_values = f"{values}, '{next_customer_id}'"
                    
                    context.sql = f"INSERT INTO {table_name} ({new_columns}) VALUES ({new_values})"
                    logger.info(f"[CustomerIDGeneration] Updated SQL with ID: {context.sql}")
        
        context.next = "ExecuteInsertSQL"
        return context.model_dump()
        
    except Exception as e:
        logger.error(f"[CustomerIDGeneration] Error: {e}")
        context.response = f"Error generating customer ID: {str(e)}"
        context.next = "CustomerResponse"
        return context.model_dump()

async def execute_insert_sql_node(context):
    """Execute customer INSERT SQL operations with enhanced error handling and success reporting."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    logger.info(f"[ReactiveInsertExecution] Executing: {context.sql}")
    
    try:
        # Final validation before execution
        if not context.sql or 'INSERT' not in context.sql.upper():
            context.response = "Invalid SQL statement for customer creation. Please try again."
            context.next = "CustomerResponse"
            return context.model_dump()
        
        # Execute SQL via MCP
        result = await mcp_client.execute_query(context.sql, context.business_id)
        
        if isinstance(result, dict) and 'content' in result:
            try:
                # Parse MCP response
                parsed = json.loads(result['content'][0]['text'])
                
                if parsed.get('success'):
                    # Enhanced success handling with customer details
                    success_message = await _generate_success_message(context, parsed)
                    context.response = success_message
                    
                    # Clear insert flow state on success
                    context = _clear_insert_flow_state(context)
                    
                    logger.info("[ReactiveInsertExecution] Customer created successfully")
                else:
                    # Enhanced error handling
                    error_msg = parsed.get('error', 'Unknown error occurred')
                    context.response = await _handle_insert_error(error_msg)
                    
            except (json.JSONDecodeError, KeyError, IndexError) as e:
                logger.error(f"[ReactiveInsertExecution] Error parsing result: {e}")
                context.response = "Customer creation completed but I had trouble confirming the details. The customer may have been created successfully."
        else:
            context.response = "Customer creation request was processed, but I couldn't confirm the result."
            
    except Exception as e:
        logger.error(f"[ReactiveInsertExecution] Execution error: {e}")
        
        # Enhanced error categorization
        error_str = str(e).lower()
        if 'duplicate' in error_str or 'unique' in error_str:
            context.response = (
                "❌ A customer with this email or phone number already exists. "
                "Please check the information and try again with different details."
            )
        elif 'constraint' in error_str or 'foreign key' in error_str:
            context.response = (
                "❌ Invalid customer group or organization specified. "
                "Please check the customer group and organization values."
            )
        else:
            context.response = f"❌ Error creating customer: {str(e)}"
    
    context.next = "CustomerResponse"
    return context.model_dump()

# Helper Functions for Reactive Insert Flow

async def _analyze_customer_data_completeness_enhanced(context):
    """Enhanced analysis of customer data completeness with collected field values."""
    try:
        # Initialize collected field values if not present
        if not hasattr(context, 'collected_field_values') or not context.collected_field_values:
            context.collected_field_values = {}
        
        # Extract fields from current message
        current_fields = await _extract_fields_from_current_message(context)
        
        # Combine with previously collected fields
        all_fields = {**context.collected_field_values, **current_fields}
        
        # Update mandatory fields list to include all schema-required fields  
        required_fields = ['xemail', 'xphone', 'xorg', 'xgcus', 'xstatuscus', 'xtaxscope']
        
        # Check completeness
        missing_fields = []
        for field in required_fields:
            if field not in all_fields or not all_fields[field] or not all_fields[field].strip():
                missing_fields.append(field)
        
        # Field name mapping for user-friendly messages
        field_names = {
            'xemail': 'Email Address',
            'xphone': 'Phone Number', 
            'xorg': 'Organization',
            'xgcus': 'Customer Group',
            'xstatuscus': 'Customer Status',
            'xtaxscope': 'Tax Scope'
        }
        
        # Generate suggested questions for missing fields
        suggested_questions = []
        for field in missing_fields:
            field_name = field_names.get(field, field)
            if field == 'xemail':
                suggested_questions.append(f"What is the customer's email address?")
            elif field == 'xphone':
                suggested_questions.append(f"What is their phone number?")
            elif field == 'xorg':
                suggested_questions.append(f"What organization/company do they belong to?")
            elif field == 'xgcus':
                suggested_questions.append(f"What customer group/type should they be assigned to?")
            elif field == 'xstatuscus':
                suggested_questions.append(f"What is the customer's status?")
            elif field == 'xtaxscope':
                suggested_questions.append(f"What is their tax scope?")
        
        return {
            'is_complete': len(missing_fields) == 0,
            'missing_fields': missing_fields,
            'suggested_questions': suggested_questions,
            'collected_fields': all_fields,
            'confidence': 1.0 - (len(missing_fields) / len(required_fields))
        }
        
    except Exception as e:
        logger.error(f"[InsertFlow] Error in enhanced data completeness analysis: {e}")
        return {
            'is_complete': False,
            'missing_fields': ['xemail', 'xphone', 'xorg', 'xgcus', 'xstatuscus', 'xtaxscope'],
            'suggested_questions': ['Please provide complete customer information'],
            'collected_fields': {},
            'confidence': 0.0
        }

async def _extract_fields_from_current_message(context):
    """Extract customer fields from the current message."""
    try:
        # Use existing helper function
        extracted_fields = extract_customer_fields_from_message(context.message)
        
        # Enhanced extraction with regex patterns
        email_pattern = r'\b[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}\b'
        phone_pattern = r'\b\d{10,11}\b'
        
        email_match = re.search(email_pattern, context.message)
        phone_match = re.search(phone_pattern, context.message)
        
        if email_match and 'xemail' not in extracted_fields:
            extracted_fields['xemail'] = email_match.group()
            
        if phone_match and 'xphone' not in extracted_fields:
            extracted_fields['xphone'] = phone_match.group()
        
        # Clean extracted fields
        cleaned_fields = {}
        for field, value in extracted_fields.items():
            clean_value = str(value).strip().strip("'\"")
            if clean_value:
                cleaned_fields[field] = clean_value
        
        return cleaned_fields
        
    except Exception as e:
        logger.error(f"[InsertFlow] Error extracting fields from message: {e}")
        return {}

async def _extract_fields_with_llm(message):
    """Use LLM to extract customer fields from natural language."""
    try:
        extraction_prompt = f"""Extract customer information from this message and return as JSON.

Message: "{message}"

Extract these fields if present:
- email: Email address (must contain @ and .)
- phone: Phone number (10-11 digits only)
- organization: Company/organization name
- customer_group: Customer type/group/category

Return JSON format:
{{
    "xemail": "email_if_found",
    "xphone": "phone_if_found", 
    "xorg": "organization_if_found",
    "xgcus": "customer_group_if_found"
}}

Only include fields that are clearly present. Return empty JSON {{}} if no fields found."""
        
        response = await llm_service.chat([
            {"role": "system", "content": "You are a data extraction expert. Extract customer information and return valid JSON only."},
            {"role": "user", "content": extraction_prompt}
        ])
        
        # Clean response and parse JSON
        clean_response = response.strip()
        if clean_response.startswith('```json'):
            clean_response = clean_response[7:-3].strip()
        elif clean_response.startswith('```'):
            clean_response = clean_response[3:-3].strip()
        
        extracted = json.loads(clean_response)
        
        # Validate extracted data
        validated_fields = {}
        for field, value in extracted.items():
            if field in ['xemail', 'xphone', 'xorg', 'xgcus'] and value and str(value).strip():
                validated_fields[field] = str(value).strip()
        
        return validated_fields
        
    except Exception as e:
        logger.debug(f"[InsertFlow] LLM field extraction failed: {e}")
        return {}

async def _generate_field_clarification_prompt(context, data_analysis):
    """Generate clarification prompt when no new fields were extracted."""
    try:
        missing_fields = data_analysis.get('missing_fields', [])
        field_names = {
            'xemail': 'Email Address',
            'xphone': 'Phone Number',
            'xorg': 'Organization',
            'xgcus': 'Customer Group'
        }
        
        missing_names = [field_names.get(field, field) for field in missing_fields]
        
        prompt_parts = [
            "🔍 **I need more specific information**",
            "",
            f"I couldn't extract the required fields from your message. Still missing: **{', '.join(missing_names)}**",
            "",
            "**Please provide in one of these formats:**",
            "• `Email: john@company.com`",
            "• `Phone: 1234567890`", 
            "• `Organization: ABC Corporation`",
            "• `Customer Group: Premium`",
            "",
            "**Or all together:**",
            "• `Email: john@company.com, Phone: 1234567890, Organization: ABC Corp, Group: Premium`"
        ]
        
        return "\n".join(prompt_parts)
        
    except Exception as e:
        logger.error(f"[InsertFlow] Error generating clarification prompt: {e}")
        return "Please provide the missing customer information in a clear format."

async def _generate_progressive_data_collection_prompt(context, data_analysis):
    """Generate structured data collection prompt with examples and clear field requirements."""
    try:
        # Field name mapping with examples
        field_info = {
            'xemail': {
                'name': 'Email Address',
                'example': 'john.doe@company.com',
                'description': 'Valid email address'
            },
            'xphone': {
                'name': 'Phone Number',
                'example': '1234567890 or 01798695259',
                'description': '5-15 digit phone number'
            },
            'xorg': {
                'name': 'Organization',
                'example': 'ABC Corporation, Tech Solutions Ltd',
                'description': 'Company or organization name'
            },
            'xgcus': {
                'name': 'Customer Group',
                'example': 'Premium, Standard, VIP, Corporate',
                'description': 'Customer type or category'
            },
            'xstatuscus': {
                'name': 'Customer Status',
                'example': 'Active, Inactive, Pending, Suspended',
                'description': 'Current status of the customer'
            },
            'xtaxscope': {
                'name': 'Tax Scope',
                'example': 'Domestic, International, Exempt, Standard',
                'description': 'Tax classification scope'
            }
        }
        
        # Show current progress
        progress_items = []
        collected_fields = data_analysis.get('collected_fields', {})
        
        for field in ['xemail', 'xphone', 'xorg', 'xgcus', 'xstatuscus', 'xtaxscope']:
            field_data = field_info[field]
            if field in collected_fields and collected_fields[field]:
                progress_items.append(f"✅ **{field_data['name']}**: {collected_fields[field]}")
            else:
                progress_items.append(f"❌ **{field_data['name']}**: Missing")
        
        # Generate prompt
        prompt_parts = [
            "📝 **Customer Creation - Mandatory Information Required**",
            "",
            "**Current Progress:**"
        ]
        prompt_parts.extend(progress_items)
        
        # Add detailed field requirements for missing fields
        missing_fields = data_analysis.get('missing_fields', [])
        if missing_fields:
            prompt_parts.extend([
                "",
                "**📋 Required Fields (with examples):**",
                ""
            ])
            
            for field in missing_fields:
                field_data = field_info[field]
                prompt_parts.extend([
                    f"**{field_data['name']}** ({field_data['description']})",
                    f"   Example: `{field_data['example']}`",
                    ""
                ])
            
            prompt_parts.extend([
                "**💡 How to provide information:**",
                "• You can provide one field at a time: `Email: john@company.com`",
                "• Or multiple fields together: `Email: john@company.com, Phone: 1234567890, Organization: ABC Corp, Group: Premium`",
                "• Or in natural language: `The customer's email is john@company.com and phone is 1234567890`",
                "",
                "Please provide the missing information:"
            ])
        
        return "\n".join(prompt_parts)
        
    except Exception as e:
        logger.error(f"[InsertFlow] Error generating progressive prompt: {e}")
        return "Please provide the remaining customer information to continue."

async def _generate_final_insert_sql(context):
    """Generate final INSERT SQL only after all mandatory fields are collected."""
    try:
        # Get all collected field values
        collected_fields = getattr(context, 'collected_field_values', {})
        
        if not collected_fields:
            context.response = "No customer data collected. Please provide customer information."
            context.next = "CustomerResponse"
            return context.model_dump()
        
        # Verify all mandatory fields are present before generating SQL
        required_fields = ['xemail', 'xphone', 'xorg', 'xgcus', 'xstatuscus', 'xtaxscope']
        missing_fields = []
        
        for field in required_fields:
            if field not in collected_fields or not collected_fields[field] or not collected_fields[field].strip():
                missing_fields.append(field)
        
        if missing_fields:
            # Still missing mandatory fields - should not happen but safety check
            logger.warning(f"[ReactiveInsertFlow] Attempted to generate SQL with missing fields: {missing_fields}")
            data_analysis = await _analyze_customer_data_completeness_enhanced(context)
            context.response = await _generate_progressive_data_collection_prompt(context, data_analysis)
            context.pause_reason = "missing_mandatory_fields"
            context.insert_phase = "data_collection"
            context.next = "PauseNode"
            return context.model_dump()
        
        # All mandatory fields present - generate final INSERT SQL
        columns = ['zid']  # Always include business ID
        values = [str(context.business_id)]
        
        # Add collected fields in consistent order
        for field in required_fields:
            if field in collected_fields:
                columns.append(field)
                escaped_value = collected_fields[field].replace("'", "''")  # Escape quotes
                values.append(f"'{escaped_value}'")
        
        # Add any additional fields that were collected
        for field, value in collected_fields.items():
            if field not in required_fields and field not in columns:
                columns.append(field)
                escaped_value = value.replace("'", "''")  # Escape quotes
                values.append(f"'{escaped_value}'")
        
        # Generate final SQL
        columns_str = ', '.join(columns)
        values_str = ', '.join(values)
        context.sql = f"INSERT INTO cacus ({columns_str}) VALUES ({values_str})"
        
        logger.info(f"[ReactiveInsertFlow] Generated final SQL with all mandatory fields: {context.sql}")
        
        # Clear collection state and proceed to validation
        context.insert_phase = None
        context.pause_reason = None
        context.next = "ValidateInsertFields"
        return context.model_dump()
        
    except Exception as e:
        logger.error(f"[InsertFlow] Error generating final SQL: {e}")
        context.response = f"Error generating customer creation SQL: {str(e)}"
        context.next = "CustomerResponse"
        return context.model_dump()

async def _check_for_duplicate_customers(context):
    """Check for duplicate customers based on collected data."""
    try:
        collected_fields = getattr(context, 'collected_field_values', {})
        email = collected_fields.get('xemail')
        phone = collected_fields.get('xphone')
        
        if not email and not phone:
            return {'has_duplicates': False, 'duplicates': []}
        
        # Build duplicate check query
        conditions = []
        if email:
            conditions.append(f"xemail = '{email}'")
        if phone:
            conditions.append(f"xphone = '{phone}'")
        
        duplicate_check_sql = f"""
        SELECT xcus, xemail, xphone, xorg 
        FROM cacus 
        WHERE zid = {context.business_id} 
        AND ({' OR '.join(conditions)})
        """
        
        result = await mcp_client.execute_query(duplicate_check_sql, context.business_id)
        
        if isinstance(result, dict) and 'content' in result:
            try:
                parsed = json.loads(result['content'][0]['text'])
                duplicates = parsed.get('results', [])
                
                return {
                    'has_duplicates': len(duplicates) > 0,
                    'duplicates': duplicates
                }
            except (json.JSONDecodeError, KeyError, IndexError):
                pass
        
        return {'has_duplicates': False, 'duplicates': []}
        
    except Exception as e:
        logger.error(f"[InsertFlow] Error checking duplicates: {e}")
        return {'has_duplicates': False, 'duplicates': []}

async def _generate_duplicate_handling_prompt(context, duplicate_result):
    """Generate prompt for handling duplicate customers."""
    try:
        duplicates = duplicate_result.get('duplicates', [])
        
        duplicate_info = []
        for dup in duplicates[:3]:  # Show max 3 duplicates
            info = f"• {dup.get('xcus', 'Unknown')} - {dup.get('xemail', 'No email')}"
            if dup.get('xorg'):
                info += f" ({dup['xorg']})"
            duplicate_info.append(info)
        
        prompt = (
            f"⚠️ **Duplicate Customer Found**\n\n"
            f"A customer with this contact information already exists:\n\n"
            f"{''.join(duplicate_info)}\n\n"
            f"Would you like to:\n"
            f"• Update the existing customer instead?\n"
            f"• Create a new customer with different contact information?\n"
            f"• Cancel the operation?"
        )
        
        return prompt
        
    except Exception as e:
        logger.error(f"[InsertFlow] Error generating duplicate prompt: {e}")
        return "Duplicate customer detected. Please choose how to proceed."

async def _analyze_customer_data_completeness(context):
    """Analyze if customer data is complete enough for insertion."""
    try:
        message = context.message.lower()
        
        # Required fields
        required_fields = ['email', 'phone', 'organization', 'customer group']
        
        # Strategy 3: Key-value pair extraction
        kv_patterns = {
            'xemail': [r'email[:\s]+([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})', 
                      r'e-?mail[:\s]+([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})'],
            'xphone': [r'phone[:\s]+(\d{5,15})', r'number[:\s]+(\d{5,15})', 
                      r'contact[:\s]+(\d{5,15})', r'mobile[:\s]+(\d{5,15})'],
            'xorg': [r'org(?:anization)?[:\s]+([^,\n]+)', r'company[:\s]+([^,\n]+)', 
                    r'business[:\s]+([^,\n]+)', r'firm[:\s]+([^,\n]+)',
                    r'org\s+is\s+([^,\n]+)', r'organization\s+is\s+([^,\n]+)'],
            'xgcus': [r'group[:\s]+([^,\n]+)', r'type[:\s]+([^,\n]+)', 
                     r'category[:\s]+([^,\n]+)', r'class[:\s]+([^,\n]+)',
                     r'customer\s+group[:\s]+([^,\n]+)', r'group\s+is\s+([^,\n]+)'],
            'xstatuscus': [r'status[:\s]+([^,\n]+)', r'customer\s+status[:\s]+([^,\n]+)',
                          r'status\s+is\s+([^,\n]+)'],
            'xtaxscope': [r'tax\s+scope[:\s]+([^,\n]+)', r'taxscope[:\s]+([^,\n]+)',
                         r'tax[:\s]+([^,\n]+)', r'scope[:\s]+([^,\n]+)']
        }
        
        found_fields = []
        for field, patterns in kv_patterns.items():
            for pattern in patterns:
                match = re.search(pattern, message)
                if match:
                    found_fields.append(field)
                    break
        
        # Use LLM for deeper analysis
        analysis_prompt = f"""
Analyze this customer creation request for data completeness:

User Message: "{context.message}"

Required Information:
1. Email address (valid format)
2. Phone number (10-11 digits)
3. Organization/Company name
4. Customer group/type

Determine:
1. Is all required information present?
2. What specific information is missing?
3. What clarification questions should be asked?

Return JSON:
{{
    "is_complete": boolean,
    "missing_fields": ["list of missing required fields"],
    "suggested_questions": ["list of clarifying questions"],
    "confidence": float (0-1)
}}
"""
        
        analysis_response = await llm_service.chat([
            {"role": "system", "content": analysis_prompt},
            {"role": "user", "content": context.message}
        ])
        
        try:
            analysis = json.loads(analysis_response)
            # Combine rule-based and LLM analysis
            analysis['is_complete'] = len(found_fields) >= 3 and analysis.get('is_complete', False)
            return analysis
        except json.JSONDecodeError:
            return {
                'is_complete': len(found_fields) >= 3,
                'missing_fields': [field for field in required_fields if field not in found_fields],
                'suggested_questions': ['What is the customer\'s email address?', 'What is their phone number?'],
                'confidence': 0.6
            }
            
    except Exception as e:
        logger.error(f"[InsertFlow] Error analyzing data completeness: {e}")
        return {
            'is_complete': False,
            'missing_fields': ['email', 'phone', 'organization', 'customer_group'],
            'suggested_questions': ['Please provide the customer\'s complete information'],
            'confidence': 0.0
        }

async def _generate_data_collection_prompt(context, data_analysis):
    """Generate data collection prompt for insert operations."""
    try:
        questions = [
            "📝 **Customer Creation - Information Collection**",
            "",
            "I need some additional information to create the customer record.",
            ""
        ]
        
        # Add specific missing field requests
        if data_analysis.get('missing_fields'):
            questions.extend([
                "**Missing Information:**",
                *[f"• {field.replace('_', ' ').title()}" for field in data_analysis['missing_fields']],
                ""
            ])
        
        # Add clarification questions
        if data_analysis.get('suggested_questions'):
            questions.extend([
                "**Please provide:**",
                *[f"• {q}" for q in data_analysis['suggested_questions'][:3]],
                ""
            ])
        
        questions.extend([
            "**Required Fields:**",
            "• Email address (valid format)",
            "• Phone number (10-11 digits)",
            "• Organization/Company name",
            "• Customer group/type",
            "",
            "Please provide the missing information:"
        ])
        
        return "\n".join(questions)
        
    except Exception as e:
        logger.error(f"[InsertFlow] Error generating data collection prompt: {e}")
        return "Please provide the customer's email, phone number, organization, and customer group."

async def _build_dynamic_insert_sql_prompt(context):
    """Build dynamic SQL prompt for insert operations with enhanced context."""
    
    # Get schema context
    schema_info = "\n".join(context.schema_context) if context.schema_context else "Customer table: cacus"
    
    sql_prompt = f"""
You are a SQL expert generating INSERT queries for customer data.

Database Schema:
{schema_info}

Business Context:
- Business ID (zid): {context.business_id} (ALWAYS include in INSERT)
- Customer table: cacus
- Customer ID will be auto-generated (do not include xcus in INSERT)

User Request: "{context.message}"

Conversation Context:
{' '.join([msg.content for msg in context.conversation_history[-3:]])}

Generate an INSERT SQL query that:
1. ALWAYS includes zid = {context.business_id}
2. Extracts customer information from the user message
3. Uses proper SQL syntax for PostgreSQL
4. Maps user input to correct database fields:
   - Email → xemail
   - Phone → xphone
   - Organization → xorg
   - Customer Group → xgcus
   - First Name → xfirst
   - Last Name → xlast

Examples:
- "create customer john@example.com, phone 1234567890, Acme Corp, VIP" → INSERT INTO cacus (zid, xemail, xphone, xorg, xgcus) VALUES ({context.business_id}, 'john@example.com', '1234567890', 'Acme Corp', 'VIP');
- "add customer Jane Smith, jane@test.com, 9876543210, Test Inc, Standard" → INSERT INTO cacus (zid, xfirst, xlast, xemail, xphone, xorg, xgcus) VALUES ({context.business_id}, 'Jane', 'Smith', 'jane@test.com', '9876543210', 'Test Inc', 'Standard');

Return only the SQL query, no explanations.
"""
    
    return sql_prompt

async def _validate_customer_fields(sql_fields, required_fields):
    """Enhanced validation of customer fields with detailed error reporting."""
    try:
        missing_fields = []
        validation_errors = []
        
        # Check for missing required fields
        for field in required_fields:
            if field not in sql_fields or not sql_fields[field] or sql_fields[field].strip("'\"") == '':
                missing_fields.append(field)
        
        # Validate existing fields with enhanced checks
        for field, value in sql_fields.items():
            clean_value = value.strip("'\"")
            
            if field == 'xemail' and clean_value:
                if not is_valid_email(clean_value):
                    validation_errors.append(f"Email format is invalid: {clean_value}")
                elif len(clean_value) > 100:
                    validation_errors.append(f"Email is too long (max 100 characters): {clean_value}")
                    
            elif field == 'xphone' and clean_value:
                if not is_valid_phone(clean_value):
                    validation_errors.append(f"Phone number must be 10 or 11 digits: {clean_value}")
                elif not clean_value.isdigit():
                    validation_errors.append(f"Phone number should contain only digits: {clean_value}")
                if clean_value.isdigit() and len(clean_value) >= 5:
                    cleaned_fields[field] = clean_value
            elif field == 'xorg' and clean_value:
                if len(clean_value) > 200:
                    validation_errors.append(f"Organization name is too long (max 200 characters): {clean_value}")
                if len(clean_value.strip()) >= 1:
                    cleaned_fields[field] = clean_value.strip()
            elif field == 'xgcus' and clean_value:
                if len(clean_value) > 50:
                    validation_errors.append(f"Customer group is too long (max 50 characters): {clean_value}")
                if len(clean_value.strip()) >= 1:
                    cleaned_fields[field] = clean_value.strip()
            elif field in ['xstatuscus', 'xtaxscope'] and clean_value:
                if len(clean_value.strip()) >= 1:
                    cleaned_fields[field] = clean_value.strip()
        
        return {
            'missing_fields': missing_fields,
            'validation_errors': validation_errors,
            'is_valid': len(missing_fields) == 0 and len(validation_errors) == 0,
            'cleaned_fields': cleaned_fields
        }
        
    except Exception as e:
        logger.error(f"[InsertFlow] Error validating fields: {e}")
        return {
            'missing_fields': required_fields,
            'validation_errors': ['Error during validation'],
            'is_valid': False
        }

async def _generate_validation_progress_message(context, required_fields, validation_result):
    """Generate enhanced progress message for validation."""
    try:
        progress_items = []
        
        # Field mapping for display
        field_names = {
            'xemail': 'Email Address',
            'xphone': 'Phone Number',
            'xgcus': 'Customer Group',
            'xorg': 'Organization'
        }
        
        # Show progress for each required field
        for field in required_fields:
            field_name = field_names.get(field, field)
            
            if hasattr(context, 'collected_field_values') and field in context.collected_field_values:
                progress_items.append(f"✅ {field_name}: {context.collected_field_values[field]}")
            else:
                progress_items.append(f"❌ {field_name}: Missing")
        
        progress_message = "**Customer Creation Progress:**\n" + "\n".join(progress_items)
        
        # Add validation errors if any
        if validation_result.get('validation_errors'):
            error_message = "\n\n**Validation Errors:**\n" + "\n".join([f"• {error}" for error in validation_result['validation_errors']])
            progress_message += error_message
        
        # Add missing field requests
        if validation_result.get('missing_fields'):
            missing_field_names = [field_names.get(field, field) for field in validation_result['missing_fields']]
            progress_message += f"\n\nPlease provide the missing information: {', '.join(missing_field_names)}"
        
        return progress_message
        
    except Exception as e:
        logger.error(f"[InsertFlow] Error generating progress message: {e}")
        return "Please provide the required customer information to continue."

async def _extract_and_validate_fields(message):
    """Enhanced field extraction with validation."""
    try:
        # Use existing helper function as base
        extracted_fields = extract_customer_fields_from_message(message)
        
        # Enhanced extraction with regex patterns
        email_pattern = r'\b[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}\b'
        phone_pattern = r'\b\d{10,11}\b'
        
        email_match = re.search(email_pattern, message)
        phone_match = re.search(phone_pattern, message)
        
        if email_match and 'xemail' not in extracted_fields:
            extracted_fields['xemail'] = email_match.group()
            
        if phone_match and 'xphone' not in extracted_fields:
            extracted_fields['xphone'] = phone_match.group()
        
        # Clean and validate extracted fields
        validated_fields = {}
        for field, value in extracted_fields.items():
            clean_value = str(value).strip()
            if clean_value:
                validated_fields[field] = clean_value
        
        return validated_fields
        
    except Exception as e:
        logger.error(f"[InsertFlow] Error extracting fields: {e}")
        return {}

async def _update_sql_with_collected_fields(incomplete_sql, collected_fields):
    """Update incomplete SQL with collected field values."""
    try:
        updated_sql = incomplete_sql
        
        # Replace or add field values in SQL
        for field, value in collected_fields.items():
            # Escape single quotes in values
            escaped_value = value.replace("'", "''")
            
            # Check if field already exists in SQL
            field_pattern = rf"{field}\s*=\s*'[^']*'"
            if re.search(field_pattern, updated_sql, re.IGNORECASE):
                # Replace existing value
                updated_sql = re.sub(field_pattern, f"{field} = '{escaped_value}'", updated_sql, flags=re.IGNORECASE)
            else:
                # Add new field to INSERT statement
                values_match = re.search(r'VALUES\s*\(([^)]+)\)', updated_sql, re.IGNORECASE)
                columns_match = re.search(r'INSERT\s+INTO\s+\w+\s*\(([^)]+)\)', updated_sql, re.IGNORECASE)
                
                if values_match and columns_match:
                    columns = columns_match.group(1)
                    values = values_match.group(1)
                    
                    # Add field to columns and values
                    new_columns = f"{columns}, {field}"
                    new_values = f"{values}, '{escaped_value}'"
                    
                    # Replace in SQL
                    updated_sql = re.sub(r'INSERT\s+INTO\s+(\w+)\s*\([^)]+\)', 
                                       f'INSERT INTO \\1 ({new_columns})', updated_sql, flags=re.IGNORECASE)
                    updated_sql = re.sub(r'VALUES\s*\([^)]+\)', 
                                       f'VALUES ({new_values})', updated_sql, flags=re.IGNORECASE)
        
        return updated_sql
        
    except Exception as e:
        logger.error(f"[InsertFlow] Error updating SQL: {e}")
        return incomplete_sql

async def _generate_success_message(context, parsed_result):
    """Generate enhanced success message with customer details."""
    try:
        # Extract customer ID from SQL
        customer_id_match = re.search(r"'(CUS-\d{6})'", context.sql)
        if customer_id_match:
            new_customer_id = customer_id_match.group(1)
            
            # Fetch the newly created customer details
            fetch_sql = f"SELECT * FROM cacus WHERE zid = {context.business_id} AND xcus = '{new_customer_id}'"
            fetch_result = await mcp_client.execute_query(fetch_sql, context.business_id)
            
            if isinstance(fetch_result, dict) and 'content' in fetch_result:
                try:
                    parsed_fetch = json.loads(fetch_result['content'][0]['text'])
                    customer_data = parsed_fetch.get('results', [])
                    
                    if customer_data:
                        customer_details = format_customer_result(customer_data)
                        return f"🎉 **Customer Successfully Created!**\n\n{customer_details}"
                    else:
                        return f"✅ Customer successfully created! Customer ID: **{new_customer_id}**"
                except Exception:
                    return f"✅ Customer successfully created! Customer ID: **{new_customer_id}**"
        
        return "✅ Customer has been successfully created! The customer ID has been automatically generated."
        
    except Exception as e:
        logger.error(f"[InsertFlow] Error generating success message: {e}")
        return "✅ Customer has been successfully created!"

async def _handle_insert_error(error_msg):
    """Enhanced error handling for insert operations."""
    try:
        error_lower = error_msg.lower()
        
        if 'duplicate' in error_lower or 'unique' in error_lower:
            return (
                "❌ **Duplicate Customer Detected**\n\n"
                "A customer with this email or phone number already exists. "
                "Please check the information and try again with different details."
            )
        elif 'constraint' in error_lower or 'foreign key' in error_lower:
            return (
                "❌ **Invalid Reference Data**\n\n"
                "The customer group or organization specified is invalid. "
                "Please check these values and try again."
            )
        elif 'not null' in error_lower:
            return (
                "❌ **Missing Required Information**\n\n"
                "Some required fields are missing. Please provide all mandatory customer information."
            )
        else:
            return f"❌ **Customer Creation Failed**\n\nError: {error_msg}"
            
    except Exception as e:
        logger.error(f"[InsertFlow] Error handling insert error: {e}")
        return f"❌ Failed to create customer: {error_msg}"

async def _check_insert_flow_interruption(context):
    """Check for flow interruption during insert operations."""
    try:
        interruption = await flow_interruption_handler.check_interruption(
            context.message, 
            context.conversation_history,
            current_flow="insert"
        )
        
        if interruption['is_interrupted']:
            logger.info(f"[InsertFlow] Flow interrupted: {interruption['new_intent']}")
            
            # Clear insert flow state
            context = _clear_insert_flow_state(context)
            
            # Handle the interruption
            if interruption['new_intent'] in ['select', 'search', 'list']:
                context.query_classification = "SEARCH_CUSTOMER"
                context.next = "GenerateSelectSQL"
            elif interruption['new_intent'] == 'update':
                context.query_classification = "UPDATE_CUSTOMER"
                context.next = "GenerateUpdateSQL"
            elif interruption['new_intent'] == 'delete':
                context.query_classification = "DELETE_CUSTOMER"
                context.next = "GenerateDeleteSQL"
            else:
                context.next = "GeneralCustomerChat"
            
            return {
                'is_interrupted': True,
                'response': context.model_dump()
            }
        
        return {'is_interrupted': False}
        
    except Exception as e:
        logger.error(f"[InsertFlow] Error checking interruption: {e}")
        return {'is_interrupted': False}

def _clear_insert_flow_state(context):
    """Clear insert flow specific state."""
    # Clear insert-specific fields
    if hasattr(context, 'collected_field_values'):
        delattr(context, 'collected_field_values')
    if hasattr(context, 'incomplete_sql'):
        delattr(context, 'incomplete_sql')
    if hasattr(context, 'missing_mandatory_fields'):
        delattr(context, 'missing_mandatory_fields')
    if hasattr(context, 'insert_phase'):
        delattr(context, 'insert_phase')
    
    # Clear general flow state
    context.pause_reason = None
    context.pause_message = None
    context.current_flow = None
    
    return context

# New node for duplicate checking
async def check_duplicate_customer_node(context):
    """Check for duplicate customers before insertion."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    logger.info("[ReactiveInsertDuplicateCheck] Checking for duplicate customers")
    
    try:
        # Extract email and phone from SQL
        sql_fields = extract_insert_fields_from_sql(context.sql)
        email = sql_fields.get('xemail', '').strip("'\"")
        phone = sql_fields.get('xphone', '').strip("'\"")
        
        if email or phone:
            # Build duplicate check query
            conditions = []
            if email:
                conditions.append(f"xemail = '{email}'")
            if phone:
                conditions.append(f"xphone = '{phone}'")
            
            duplicate_check_sql = f"""
            SELECT xcus, xemail, xphone, xorg 
            FROM cacus 
            WHERE zid = {context.business_id} 
            AND ({' OR '.join(conditions)})
            """
            
            result = await mcp_client.execute_query(duplicate_check_sql, context.business_id)
            
            if isinstance(result, dict) and 'content' in result:
                try:
                    parsed = json.loads(result['content'][0]['text'])
                    duplicates = parsed.get('results', [])
                    
                    if duplicates:
                        # Found duplicates, show them to user
                        duplicate_info = []
                        for dup in duplicates[:3]:  # Show max 3 duplicates
                            info = f"• {dup.get('xcus', 'Unknown')} - {dup.get('xemail', 'No email')}"
                            if dup.get('xorg'):
                                info += f" ({dup['xorg']})"
                            duplicate_info.append(info)
                        
                        context.response = (
                            f"⚠️ **Duplicate Customer Found**\n\n"
                            f"A customer with this {'email' if email in str(duplicates) else 'phone number'} already exists:\n\n"
                            f"{''.join(duplicate_info)}\n\n"
                            f"Would you like to:\n"
                            f"• Update the existing customer instead?\n"
                            f"• Create a new customer with different contact information?\n"
                            f"• Cancel the operation?"
                        )
                        context.next = "CustomerResponse"
                        return context.model_dump()
                        
                except (json.JSONDecodeError, KeyError, IndexError):
                    pass
        
        # No duplicates found, proceed to customer ID generation
        context.next = "GenerateCustomerID"
        return context.model_dump()
        
    except Exception as e:
        logger.error(f"[ReactiveInsertDuplicateCheck] Error: {e}")
        # Continue with insertion on error
        context.next = "GenerateCustomerID"
        return context.model_dump()
