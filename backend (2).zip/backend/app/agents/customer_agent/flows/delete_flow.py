"""
Reactive Customer Delete Flow - Handles customer deletion with dynamic customer selection and confirmation
"""
from backend.app.models.chat_graph_state import ChatGraphState
from backend.app.services.mistral_llm_service import MistralLLMService
from backend.app.services.vector_search import FaissVectorSearchService
from backend.app.mcp.mcp_client import MCPClient
from backend.app.agents.customer_agent.customer_chat_helpers import (
    build_customer_sql_prompt, clean_sql_from_llm, format_customer_result,
    get_customer_schema_context_for_flow
)
from backend.app.agents.customer_agent.negative_vibe_detector import negative_vibe_detector
from backend.app.agents.customer_agent.flow_interruption_handler import flow_interruption_handler
import logging
import json
import re

logger = logging.getLogger(__name__)

# Initialize services
llm_service = MistralLLMService()
vector_search_service = FaissVectorSearchService()
mcp_client = MCPClient(script_path="backend/app/mcp/server_enhanced.py")

async def generate_delete_sql_node(context):
    """Generate SQL for customer DELETE operations with reactive customer selection and confirmation."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    logger.info(f"[ReactiveDeleteFlow] Starting DELETE flow for: {context.message}")
    
    # Set current flow
    context.current_flow = "delete"
    
    # Check for negative vibe first
    negative_vibe = await negative_vibe_detector.detect_negative_vibe(
        context.message, context.conversation_history
    )
    
    if negative_vibe['is_negative']:
        logger.info("[ReactiveDeleteFlow] Negative vibe detected, canceling flow")
        context = _clear_delete_flow_state(context)
        context.response = negative_vibe['suggested_response']
        context.next = "CustomerResponse"
        return context.model_dump()
    
    # Check for flow interruption
    interruption_check = await _check_delete_flow_interruption(context)
    if interruption_check['is_interrupted']:
        return interruption_check['response']
    
    # Get schema context for delete operations
    if not hasattr(context, 'schema_context') or not context.schema_context:
        context.schema_context = await get_customer_schema_context_for_flow(context.business_id, "delete")
    
    # PHASE 1: Customer Selection - Always start here if not already selected
    if not hasattr(context, 'customers_to_delete') or not context.customers_to_delete:
        logger.info("[ReactiveDeleteFlow] Phase 1: Customer selection needed")
        
        # Analyze customer identification clarity for deletion
        customer_clarity = await _analyze_delete_customer_identification(context)
        
        if customer_clarity['is_clear']:
            # Customer is clearly identified, fetch and show for confirmation
            customers_data = await _fetch_customers_for_deletion(context, customer_clarity)
            if customers_data:
                context.customers_to_delete = customers_data
                context.delete_phase = "confirmation"
                # Proceed to confirmation
                return await _proceed_to_delete_confirmation(context)
            else:
                context.response = "No customers found matching your criteria. Please check your request and try again."
                context.next = "CustomerResponse"
                return context.model_dump()
        else:
            # Customer identification unclear - need reactive questioning
            context.response = await _generate_delete_customer_selection_prompt(context, customer_clarity)
            context.pause_reason = "customer_selection_needed"
            context.delete_phase = "customer_selection"
            context.next = "PauseNode"
            return context.model_dump()
    
    # PHASE 2: Confirmation - Customers already selected
    elif hasattr(context, 'delete_phase') and context.delete_phase == "confirmation":
        logger.info("[ReactiveDeleteFlow] Phase 2: Delete confirmation")
        return await _handle_delete_confirmation_phase(context)
    
    # PHASE 3: Final DELETE SQL Generation - Confirmed
    else:
        logger.info("[ReactiveDeleteFlow] Phase 3: Generating final DELETE SQL")
        return await _generate_final_delete_sql(context)

async def process_customer_selection_for_delete_node(context):
    """Process customer selection input for delete operations with enhanced validation."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    logger.info(f"[ReactiveDeleteSelection] Processing selection: {context.message}")
    
    try:
        # Check for negative vibe or cancellation first
        negative_vibe = await negative_vibe_detector.detect_negative_vibe(
            context.message, context.conversation_history
        )
        
        if negative_vibe['is_negative']:
            logger.info("[ReactiveDeleteSelection] Negative vibe detected, canceling")
            context = _clear_delete_flow_state(context)
            context.response = negative_vibe['suggested_response']
            context.next = "CustomerResponse"
            return context.model_dump()
        
        # Check for flow interruption
        interruption_check = await _check_delete_flow_interruption(context)
        if interruption_check['is_interrupted']:
            return interruption_check['response']
        
        # Re-analyze customer identification clarity
        customer_clarity = await _analyze_delete_customer_identification(context)
        
        if not customer_clarity['is_clear']:
            logger.info("[ReactiveDeleteSelection] Customer identification still unclear")
            context.response = await _generate_delete_customer_selection_prompt(context, customer_clarity)
            context.next = "PauseNode"
            return context.model_dump()
        
        # Generate SQL based on customer selection
        sql_prompt = await _build_dynamic_delete_sql_prompt(context)
        
        # Generate SQL using LLM with conversation context
        messages = [
            {"role": "system", "content": sql_prompt},
            {"role": "user", "content": context.message}
        ]
        
        # Add recent conversation for context
        for msg in context.conversation_history[-3:]:
            messages.insert(-1, {"role": msg.role, "content": msg.content})
        
        sql_response = await llm_service.chat(messages)
        context.sql = clean_sql_from_llm(sql_response)
        
        # Clear selection phase and proceed to validation
        context.delete_phase = None
        context.next = "ValidateDeleteCustomerExists"
        context.pause_reason = None
        
        logger.info(f"[ReactiveDeleteSelection] Generated SQL: {context.sql}")
        
    except Exception as e:
        logger.error(f"[ReactiveDeleteSelection] Error: {e}")
        context.response = "Error processing customer selection. Please try again."
        context.next = "CustomerResponse"
        context.pause_reason = None
    
    return context.model_dump()

async def validate_delete_customer_exists_node(context):
    """Validate that customers exist before deletion with enhanced preview and confirmation."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    logger.info(f"[ReactiveDeleteValidation] Validating customers exist for: {context.sql}")
    
    try:
        # Check for flow interruption during validation
        interruption_check = await _check_delete_flow_interruption(context)
        if interruption_check['is_interrupted']:
            return interruption_check['response']
        
        # Convert DELETE to SELECT to see what would be deleted
        select_sql = context.sql.replace("DELETE FROM", "SELECT * FROM", 1)
        select_sql = re.sub(r'\s+WHERE\s+', ' WHERE ', select_sql, flags=re.IGNORECASE)
        
        result = await mcp_client.execute_query(select_sql, context.business_id)
        
        if isinstance(result, dict) and 'content' in result:
            try:
                parsed = json.loads(result['content'][0]['text'])
                customers = parsed.get('results', [])
                
                if customers:
                    # Store customers to be deleted for confirmation
                    context.customers_to_delete = customers
                    
                    # Enhanced preview with customer details
                    preview_message = await _generate_delete_preview_message(customers)
                    context.delete_preview_message = preview_message
                    
                    context.next = "ConfirmDeleteOperation"
                    logger.info(f"[ReactiveDeleteValidation] Found {len(customers)} customer(s) for deletion")
                else:
                    context.response = "No customers found matching your deletion criteria. Please check your request and try again."
                    context.next = "CustomerResponse"
                    
            except (json.JSONDecodeError, KeyError, IndexError) as e:
                logger.error(f"[ReactiveDeleteValidation] Error parsing result: {e}")
                context.response = "Unable to validate customers for deletion. Please try again."
                context.next = "CustomerResponse"
        else:
            context.response = "Unable to validate customers for deletion. Please try again."
            context.next = "CustomerResponse"
            
    except Exception as e:
        logger.error(f"[ReactiveDeleteValidation] Error: {e}")
        context.response = f"Error validating customers for deletion: {str(e)}"
        context.next = "CustomerResponse"
    
    return context.model_dump()

async def process_delete_confirmation_node(context):
    """Process user confirmation for DELETE operations with enhanced validation."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    logger.info(f"[ReactiveDeleteConfirmProcess] Processing confirmation: {context.message}")
    
    try:
        user_response = context.message.lower().strip()
        
        # Check for negative vibe or cancellation first
        negative_vibe = await negative_vibe_detector.detect_negative_vibe(
            context.message, context.conversation_history
        )
        
        if negative_vibe['is_negative']:
            logger.info("[ReactiveDeleteConfirmProcess] Negative vibe detected, canceling deletion")
            context = _clear_delete_flow_state(context)
            context.response = "Customer deletion cancelled. " + negative_vibe['suggested_response']
            context.next = "CustomerResponse"
            return context.model_dump()
        
        # Enhanced confirmation validation
        if len(context.customers_to_delete) == 1:
            # Single customer deletion - require "YES DELETE"
            if "yes delete" in user_response or user_response == "yes delete":
                context.next = "ExecuteDeleteSQL"
                context.pause_reason = None
                logger.info("[ReactiveDeleteConfirmProcess] Single customer deletion confirmed")
            elif any(word in user_response for word in ['no', 'cancel', 'abort', 'stop']):
                context = _clear_delete_flow_state(context)
                context.response = "✅ Customer deletion cancelled. No customers were deleted."
                context.next = "CustomerResponse"
                logger.info("[ReactiveDeleteConfirmProcess] Single customer deletion cancelled")
            else:
                context.response = (
                    "⚠️ **Please confirm clearly for customer deletion:**\n\n"
                    "• Type **'YES DELETE'** to proceed with deletion\n"
                    "• Type **'no'** or **'cancel'** to abort\n\n"
                    "This action is permanent and cannot be undone!"
                )
                context.next = "PauseNode"
        else:
            # Multiple customers deletion - require "YES DELETE ALL"
            if "yes delete all" in user_response or user_response == "yes delete all":
                context.next = "ExecuteDeleteSQL"
                context.pause_reason = None
                logger.info(f"[ReactiveDeleteConfirmProcess] Bulk deletion of {len(context.customers_to_delete)} customers confirmed")
            elif any(word in user_response for word in ['no', 'cancel', 'abort', 'stop']):
                context = _clear_delete_flow_state(context)
                context.response = f"✅ Bulk customer deletion cancelled. No customers were deleted."
                context.next = "CustomerResponse"
                logger.info("[ReactiveDeleteConfirmProcess] Bulk customer deletion cancelled")
            else:
                context.response = (
                    f"⚠️ **Please confirm clearly for deleting {len(context.customers_to_delete)} customers:**\n\n"
                    f"• Type **'YES DELETE ALL'** to proceed with deleting all {len(context.customers_to_delete)} customers\n"
                    f"• Type **'no'** or **'cancel'** to abort\n\n"
                    f"This action is permanent and cannot be undone!"
                )
                context.next = "PauseNode"
            
    except Exception as e:
        logger.error(f"[ReactiveDeleteConfirmProcess] Error: {e}")
        context.response = "Error processing confirmation. Please try again."
        context.next = "CustomerResponse"
        context.pause_reason = None
    
    return context.model_dump()

async def confirm_delete_operation_node(context):
    """Confirm DELETE operations with enhanced customer details and safety warnings."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    logger.info("[ReactiveDeleteConfirm] Preparing confirmation")
    
    try:
        # Check for flow interruption during confirmation
        interruption_check = await _check_delete_flow_interruption(context)
        if interruption_check['is_interrupted']:
            return interruption_check['response']
        
        if hasattr(context, 'customers_to_delete') and context.customers_to_delete:
            customers = context.customers_to_delete
            
            # Use enhanced preview message if available
            if hasattr(context, 'delete_preview_message') and context.delete_preview_message:
                preview_display = context.delete_preview_message
            else:
                preview_display = await _generate_delete_preview_message(customers)
            
            # Generate confirmation message with safety warnings
            if len(customers) == 1:
                context.pause_message = (
                    f"🚨 **CUSTOMER DELETION CONFIRMATION** 🚨\n\n"
                    f"{preview_display}\n\n"
                    f"⚠️ **WARNING: This action is PERMANENT and cannot be undone!**\n\n"
                    f"📋 **What will be deleted:**\n"
                    f"• All customer data and information\n"
                    f"• Customer history and records\n"
                    f"• Associated relationships\n\n"
                    f"❓ **Are you absolutely sure you want to delete this customer?**\n"
                    f"Type 'YES DELETE' to confirm or 'no' to cancel."
                )
            else:
                context.pause_message = (
                    f"🚨 **BULK CUSTOMER DELETION CONFIRMATION** 🚨\n\n"
                    f"{preview_display}\n\n"
                    f"⚠️ **CRITICAL WARNING: This will PERMANENTLY delete {len(customers)} customers!**\n\n"
                    f"📋 **What will be deleted:**\n"
                    f"• All data for {len(customers)} customers\n"
                    f"• Complete customer histories and records\n"
                    f"• All associated relationships\n\n"
                    f"❓ **Are you absolutely sure you want to delete ALL these customers?**\n"
                    f"Type 'YES DELETE ALL' to confirm or 'no' to cancel."
                )
            
            context.pause_reason = "confirm_delete"
            context.next = "PauseNode"
        else:
            # No customers to delete
            context.response = "No customers found to delete. Please check your criteria."
            context.next = "CustomerResponse"
            
    except Exception as e:
        logger.error(f"[ReactiveDeleteConfirm] Error: {e}")
        context.response = "Error preparing deletion confirmation. Please try again."
        context.next = "CustomerResponse"
    
    return context.model_dump()

async def execute_delete_sql_node(context):
    """Execute customer DELETE SQL operations via MCP."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    logger.info(f"[CustomerDeleteSQL] Executing: {context.sql}")
    
    try:
        # Execute SQL via MCP
        result = await mcp_client.execute_query(context.sql, context.business_id)
        
        if isinstance(result, dict) and 'content' in result:
            try:
                # Parse MCP response
                parsed = json.loads(result['content'][0]['text'])
                
                if parsed.get('success'):
                    affected_rows = parsed.get('affected_rows', 0)
                    
                    if affected_rows > 0:
                        if affected_rows == 1:
                            context.response = f"✅ Customer has been successfully deleted! (1 record removed)"
                        else:
                            context.response = f"✅ {affected_rows} customers have been successfully deleted!"
                        
                        # Log the deletion for audit purposes
                        logger.info(f"[CustomerDeleteSQL] Successfully deleted {affected_rows} customer(s)")
                    else:
                        context.response = "No customers were deleted. The specified customers may have already been removed or the criteria didn't match any records."
                else:
                    error_msg = parsed.get('error', 'Unknown error occurred')
                    
                    # Handle specific database errors
                    if 'foreign key' in error_msg.lower() or 'constraint' in error_msg.lower():
                        context.response = (
                            "❌ Cannot delete customer(s) because they are referenced by other records "
                            "(orders, transactions, etc.). Please remove related records first or contact support."
                        )
                    else:
                        context.response = f"Failed to delete customer(s): {error_msg}"
                    
            except (json.JSONDecodeError, KeyError, IndexError) as e:
                logger.error(f"[CustomerDeleteSQL] Error parsing result: {e}")
                context.response = "Customer deletion completed but I had trouble confirming the details."
        else:
            context.response = "Customer deletion request was processed."
            
    except Exception as e:
        logger.error(f"[CustomerDeleteSQL] Execution error: {e}")
        
        # Handle specific error types
        error_str = str(e).lower()
        if 'foreign key' in error_str or 'constraint' in error_str:
            context.response = (
                "❌ Cannot delete customer(s) because they are referenced by other records. "
                "Please remove related records first or contact support."
            )
        else:
            context.response = f"I encountered an error while deleting the customer(s): {str(e)}"
    
    context.next = "CustomerResponse"
    return context.model_dump()

# Helper Functions for Reactive Delete Flow

async def _analyze_delete_customer_identification(context):
    """Analyze if customer identification is clear enough for deletion."""
    try:
        message = context.message.lower()
        
        # Check for specific customer identifiers
        clear_indicators = [
            r'cus-\d+',  # Customer ID pattern
            r'\b[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}\b',  # Email pattern
            r'\+?[1-9]\d{1,14}',  # Phone pattern
            'last customer', 'latest customer', 'most recent customer'
        ]
        
        has_clear_identifier = any(re.search(pattern, message) for pattern in clear_indicators)
        
        # Use LLM for deeper analysis
        analysis_prompt = f"""
Analyze this customer deletion request for clarity:

User Message: "{context.message}"

Determine:
1. Is the customer identification clear and specific?
2. Can we uniquely identify which customer(s) to delete?
3. What clarification is needed if unclear?

Return JSON:
{{
    "is_clear": boolean,
    "confidence": float (0-1),
    "missing_info": ["list of missing information"],
    "suggested_questions": ["list of clarifying questions"]
}}
"""
        
        analysis_response = await llm_service.chat([
            {"role": "system", "content": analysis_prompt},
            {"role": "user", "content": context.message}
        ])
        
        try:
            analysis = json.loads(analysis_response)
            # Combine rule-based and LLM analysis
            analysis['is_clear'] = has_clear_identifier and analysis.get('is_clear', False)
            return analysis
        except json.JSONDecodeError:
            return {
                'is_clear': has_clear_identifier,
                'confidence': 0.7 if has_clear_identifier else 0.3,
                'missing_info': ['customer identification'],
                'suggested_questions': ['Which specific customer would you like to delete?']
            }
            
    except Exception as e:
        logger.error(f"[DeleteFlow] Error analyzing customer identification: {e}")
        return {
            'is_clear': False,
            'confidence': 0.0,
            'missing_info': ['customer identification'],
            'suggested_questions': ['Which customer would you like to delete?']
        }

async def _generate_delete_customer_selection_prompt(context, clarity_analysis):
    """Generate customer selection prompt for delete operations."""
    try:
        # Get recent customers for examples
        recent_customers_sql = f"""
        SELECT xcus, xemail, xphone, xorg, xfirst, xlast 
        FROM cacus 
        WHERE zid = {context.business_id} 
        ORDER BY xcus DESC 
        LIMIT 5
        """
        
        recent_result = await mcp_client.execute_query(recent_customers_sql, context.business_id)
        customer_examples = []
        
        if isinstance(recent_result, dict) and 'content' in recent_result:
            try:
                parsed = json.loads(recent_result['content'][0]['text'])
                customers = parsed.get('results', [])
                
                for customer in customers:
                    cid = customer.get('xcus', 'Unknown')
                    email = customer.get('xemail', 'No email')
                    org = customer.get('xorg', '')
                    name_parts = [customer.get('xfirst', ''), customer.get('xlast', '')]
                    name = ' '.join(filter(None, name_parts)) or 'No name'
                    
                    example = f"• {cid} - {name} ({email})"
                    if org:
                        example += f" from {org}"
                    customer_examples.append(example)
                        
            except (json.JSONDecodeError, KeyError, IndexError):
                pass
        
        # Build customer selection prompt
        questions = [
            "🗑️ **Customer Deletion - Customer Selection**",
            "",
            "I need to know which specific customer you want to delete.",
            "",
            "**You can identify the customer by:**",
            "• Customer ID (e.g., CUS-000001)",
            "• Email address (e.g., john@example.com)",
            "• Phone number (e.g., +1234567890)",
            "• Organization name (e.g., Acme Corp)",
            "• First/Last name (e.g., John Smith)",
            "• Say 'last customer' for the most recent customer",
            ""
        ]
        
        if customer_examples:
            questions.extend([
                "**Recent Customers:**",
                *customer_examples[:3],  # Show top 3
                ""
            ])
        
        # Add specific clarification based on analysis
        if clarity_analysis.get('suggested_questions'):
            questions.extend([
                "**Clarification needed:**",
                *[f"• {q}" for q in clarity_analysis['suggested_questions'][:2]],
                ""
            ])
        
        questions.extend([
            "⚠️ **Warning: Customer deletion is permanent and cannot be undone!**",
            "",
            "Please specify which customer you want to delete:"
        ])
        
        return "\n".join(questions)
        
    except Exception as e:
        logger.error(f"[DeleteFlow] Error generating customer selection prompt: {e}")
        return "Which customer would you like to delete? Please provide the customer ID or describe the customer."

async def _fetch_customers_for_deletion(context, customer_clarity):
    """Fetch customers for deletion using dynamic LLM-generated SQL with vector DB context."""
    try:
        # Get vector search context for customer schema
        vector_results = await vector_search_service.search(
            query=context.message,
            business_id=context.business_id,
            top_k=3
        )
        
        # Build dynamic SQL prompt using vector context
        sql_prompt = await build_customer_sql_prompt(
            context.message, 
            context.business_id, 
            vector_results, 
            context.conversation_history,
            operation_type="select_for_delete"
        )
        
        # Generate SQL using LLM
        sql_response = await llm_service.chat([
            {"role": "system", "content": sql_prompt},
            {"role": "user", "content": f"Generate a SELECT query to find customers for deletion based on: {context.message}"}
        ])
        
        # Clean and validate SQL
        sql = clean_sql_from_llm(sql_response)
        
        if not sql or not sql.strip().lower().startswith('select'):
            logger.warning(f"[DeleteFlow] Invalid SQL generated: {sql}")
            return None
        
        # Execute the dynamically generated query
        result = await mcp_client.execute_query(sql, context.business_id)
        
        if isinstance(result, dict) and 'content' in result:
            parsed = json.loads(result['content'][0]['text'])
            customers = parsed.get('results', [])
            return customers if customers else None
            
    except Exception as e:
        logger.error(f"[DeleteFlow] Error fetching customers for deletion: {e}")
        return None

async def _build_dynamic_delete_sql_prompt(context):
    """Build dynamic SQL prompt for delete operations with enhanced context."""
    
    # Get schema context
    schema_info = "\n".join(context.schema_context) if context.schema_context else "Customer table: cacus"
    
    sql_prompt = f"""
You are a SQL expert generating DELETE queries for customer data.

Database Schema:
{schema_info}

Business Context:
- Business ID (zid): {context.business_id} (ALWAYS include in WHERE clause)
- Customer table: cacus
- Customer ID format: CUS-XXXXXX

User Request: "{context.message}"

Conversation Context:
{' '.join([msg.content for msg in context.conversation_history[-3:]])}

Generate a DELETE SQL query that:
1. ALWAYS includes WHERE zid = {context.business_id}
2. Safely identifies the customer(s) to delete
3. Uses proper SQL syntax for PostgreSQL
4. Handles customer identification (ID, email, phone, name, organization)

Examples:
- "delete customer CUS-000123" → DELETE FROM cacus WHERE zid = {context.business_id} AND xcus = 'CUS-000123';
- "delete customer with email john@example.com" → DELETE FROM cacus WHERE zid = {context.business_id} AND xemail = 'john@example.com';
- "delete last customer" → DELETE FROM cacus WHERE zid = {context.business_id} AND xcus = (SELECT xcus FROM cacus WHERE zid = {context.business_id} ORDER BY xcus DESC LIMIT 1);

Return only the SQL query, no explanations.
"""
    
    return sql_prompt

async def _generate_delete_preview_message(customers):
    """Generate enhanced preview message for customers to be deleted."""
    try:
        if len(customers) == 1:
            customer = customers[0]
            preview_lines = ["**Customer to be deleted:**", ""]
            
            # Format customer details
            details = []
            if customer.get('xcus'):
                details.append(f"🆔 **Customer ID:** {customer['xcus']}")
            if customer.get('xfirst') or customer.get('xlast'):
                name = f"{customer.get('xfirst', '')} {customer.get('xlast', '')}".strip()
                details.append(f"👤 **Name:** {name}")
            if customer.get('xemail'):
                details.append(f"📧 **Email:** {customer['xemail']}")
            if customer.get('xphone'):
                details.append(f"📞 **Phone:** {customer['xphone']}")
            if customer.get('xorg'):
                details.append(f"🏢 **Organization:** {customer['xorg']}")
            
            preview_lines.extend(details)
            
        else:
            preview_lines = [f"**{len(customers)} Customers to be deleted:**", ""]
            
            for i, customer in enumerate(customers[:5], 1):
                cid = customer.get('xcus', 'Unknown')
                email = customer.get('xemail', 'No email')
                name_parts = [customer.get('xfirst', ''), customer.get('xlast', '')]
                name = ' '.join(filter(None, name_parts))
                
                if name:
                    preview_lines.append(f"{i}. **{cid}** - {name} ({email})")
                else:
                    preview_lines.append(f"{i}. **{cid}** - {email}")
            
            if len(customers) > 5:
                preview_lines.append(f"... and **{len(customers) - 5} more customers**")
        
        return "\n".join(preview_lines)
        
    except Exception as e:
        logger.error(f"[DeleteFlow] Error generating preview message: {e}")
        return f"Preview: {len(customers)} customer(s) selected for deletion"

async def _check_delete_flow_interruption(context):
    """Check for flow interruption during delete operations."""
    try:
        interruption = await flow_interruption_handler.check_interruption(
            context.message, 
            context.conversation_history,
            current_flow="delete"
        )
        
        if interruption['is_interrupted']:
            logger.info(f"[DeleteFlow] Flow interrupted: {interruption['new_intent']}")
            
            # Clear delete flow state
            context = _clear_delete_flow_state(context)
            
            # Handle the interruption
            if interruption['new_intent'] in ['select', 'search', 'list']:
                context.query_classification = "SEARCH_CUSTOMER"
                context.next = "GenerateSelectSQL"
            elif interruption['new_intent'] == 'update':
                context.query_classification = "UPDATE_CUSTOMER"
                context.next = "GenerateUpdateSQL"
            elif interruption['new_intent'] == 'insert':
                context.query_classification = "CREATE_CUSTOMER"
                context.next = "GenerateCustomerSQL"
            else:
                context.next = "GeneralCustomerChat"
            
            return {
                'is_interrupted': True,
                'response': context.model_dump()
            }
        
        return {'is_interrupted': False}
        
    except Exception as e:
        logger.error(f"[DeleteFlow] Error checking interruption: {e}")
        return {'is_interrupted': False}

def _clear_delete_flow_state(context):
    """Clear delete flow specific state."""
    # Clear delete-specific fields
    if hasattr(context, 'customers_to_delete'):
        delattr(context, 'customers_to_delete')
    if hasattr(context, 'delete_preview_message'):
        delattr(context, 'delete_preview_message')
    if hasattr(context, 'delete_phase'):
        delattr(context, 'delete_phase')
    
    # Clear general flow state
    context.pause_reason = None
    context.pause_message = None
    context.current_flow = None
    
    return context
