"""Reactive Customer Select Flow - Handles customer data retrieval with dynamic SQL generation and clarification"""
from backend.app.models.chat_graph_state import ChatGraphState
from backend.app.services.mistral_llm_service import MistralLLMService
from backend.app.services.vector_search import FaissVectorSearchService
from backend.app.mcp.mcp_client import MCPClient
from backend.app.agents.customer_agent.customer_chat_helpers import (
    build_customer_sql_prompt, clean_sql_from_llm, format_customer_result,
    get_customer_schema_context_for_flow
)
from backend.app.agents.customer_agent.reactive_questioning import ReactiveQuestioningSystem
from backend.app.agents.customer_agent.negative_vibe_detector import negative_vibe_detector
import logging
import json
import re

logger = logging.getLogger(__name__)

# Initialize services
llm_service = MistralLLMService()
vector_search_service = FaissVectorSearchService()
mcp_client = MCPClient(script_path="backend/app/mcp/server_enhanced.py")
reactive_questioning = ReactiveQuestioningSystem()

async def vector_search_node(context):
    """Enhanced vector search with dynamic query clarity assessment and negative vibe detection."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    logger.info(f"[ReactiveSelectFlow] Starting vector search for: {context.message}")
    
    # Set current flow
    context.current_flow = "select"
    
    # Check for negative vibe first using dynamic LLM detection
    negative_vibe = await negative_vibe_detector.detect_negative_vibe(
        context.message, context.conversation_history
    )
    
    if negative_vibe['is_negative']:
        logger.info("[ReactiveSelectFlow] Negative vibe detected, canceling flow")
        context = _clear_select_flow_state(context)
        context.response = negative_vibe['suggested_response']
        context.next = "CustomerResponse"
        return context.model_dump()
    
    # Get schema context for customer operations using vector DB
    context.schema_context = await get_customer_schema_context_for_flow(context.business_id, "select")
    
    # Dynamic query clarity assessment using LLM + vector DB context
    clarity_result = await _assess_query_clarity_with_vectordb(context)
    
    context.is_query_clear = clarity_result['is_clear']
    context.clarification_questions = clarity_result.get('clarification_questions', [])
    context.missing_information = clarity_result.get('missing_information', [])
    
    logger.info(f"[ReactiveSelectFlow] Query clarity: {context.is_query_clear}")
    
    # Route based on clarity
    if context.is_query_clear:
        # Clear query - proceed directly to SQL generation
        context.next = "GenerateSelectSQL"
    else:
        # Unclear query - activate reactive questioning with state maintenance
        context.reactive_questioning_active = True
        context.clarification_attempts = getattr(context, 'clarification_attempts', 0)
        context.next = "ReactiveQuestioning"
    
    return context.model_dump()

async def generate_select_sql_node(context):
    """Generate SQL for customer SELECT operations using vector DB and conversation context."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    logger.info(f"[ReactiveSelectSQL] Generating SQL for: {context.message}")
    
    try:
        # Check for flow interruption before SQL generation
        interruption_check = await _check_select_flow_interruption(context)
        if interruption_check['is_interrupted']:
            return interruption_check['response']
        
        # Get schema context if not already available
        if not hasattr(context, 'schema_context') or not context.schema_context:
            context.schema_context = await get_customer_schema_context_for_flow(context.business_id, "select")
        
        # Build dynamic SQL prompt using vector DB context and conversation history
        sql_prompt = await _build_dynamic_select_sql_prompt(context)
        
        # Generate SQL using LLM with enhanced context
        messages = [
            {"role": "system", "content": sql_prompt},
            {"role": "user", "content": context.message}
        ]
        
        # Add recent conversation for context
        for msg in context.conversation_history[-4:]:
            messages.insert(-1, {"role": msg.role, "content": msg.content})
        
        sql_response = await llm_service.chat(messages)
        
        # Clean and validate SQL
        context.sql = clean_sql_from_llm(sql_response)
        context.customer_action = "select"
        context.next = "SelectDependencyCheck"
        
        logger.info(f"[ReactiveSelectSQL] Generated: {context.sql}")
        return context.model_dump()
        
    except Exception as e:
        logger.error(f"[ReactiveSelectSQL] Error: {e}")
        context.response = f"I encountered an error generating the query: {str(e)}"
        context.next = "CustomerResponse"
        return context.model_dump()

async def execute_select_sql_node(context):
    """Execute customer SELECT SQL operations via MCP."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    logger.info(f"[CustomerSelectSQL] Executing: {context.sql}")
    
    try:
        # Execute SQL via MCP
        result = await mcp_client.execute_query(context.sql, context.business_id)
        
        if isinstance(result, dict) and 'content' in result:
            try:
                # Parse MCP response
                parsed = json.loads(result['content'][0]['text'])
                rows = parsed.get('results', [])
                
                if not rows:
                    context.response = "No customers found matching your criteria. Would you like to try a different search or add a new customer?"
                else:
                    context.response = format_customer_result(rows)
                    
            except (json.JSONDecodeError, KeyError, IndexError) as e:
                logger.error(f"[CustomerSelectSQL] Error parsing result: {e}")
                context.response = "I found some data but had trouble formatting it. Please try rephrasing your request."
        else:
            context.response = "No results found for your customer query."
            
    except Exception as e:
        logger.error(f"[CustomerSelectSQL] Execution error: {e}")
        context.response = f"I encountered an error while searching for customers: {str(e)}"
    
    context.next = "CustomerResponse"
    return context.model_dump()

async def reactive_questioning_node(context):
    """Handle reactive questioning for unclear SELECT queries with state maintenance."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    logger.info(f"[ReactiveQuestioning] Handling unclear query: {context.message}")
    
    # Check for negative vibe during questioning
    negative_vibe = await negative_vibe_detector.detect_negative_vibe(
        context.message, context.conversation_history
    )
    
    if negative_vibe['is_negative']:
        logger.info("[ReactiveQuestioning] Negative vibe detected during questioning")
        context = _clear_select_flow_state(context)
        context.response = negative_vibe['suggested_response']
        context.next = "CustomerResponse"
        return context.model_dump()
    
    # Track clarification attempts
    context.clarification_attempts = getattr(context, 'clarification_attempts', 0) + 1
    
    # Check if we should continue questioning (max 3 attempts)
    if context.clarification_attempts > 3:
        logger.info("[ReactiveQuestioning] Max attempts reached, proceeding with best effort")
        context.response = "I'll try to help with the information provided so far."
        context.next = "GenerateSelectSQL"
        return context.model_dump()
    
    # Generate dynamic clarification questions using vector DB context
    questions = await _generate_dynamic_clarification_questions(context)
    
    if questions:
        # Present questions with context from vector DB
        context.response = _format_clarification_questions(questions, context.schema_context)
        context.pause_reason = "clarification_needed"
        context.next = "PauseNode"
    else:
        # No questions generated, proceed with best effort
        context.next = "GenerateSelectSQL"
    
    return context.model_dump()

async def handle_clarification_response_node(context):
    """Handle user's response to clarification questions with dynamic analysis."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    logger.info(f"[ClarificationResponse] Processing response: {context.message}")
    
    # Check for flow interruption during clarification
    interruption_check = await _check_select_flow_interruption(context)
    if interruption_check['is_interrupted']:
        return interruption_check['response']
    
    # Analyze the clarification response using LLM
    response_analysis = await _analyze_clarification_response(context)
    
    # Update context with extracted information
    if response_analysis.get('extracted_info'):
        context.clarification_provided = True
        context.extracted_criteria = response_analysis['extracted_info']
    
    if response_analysis.get('sufficient_info', False):
        # Enough information provided, proceed with SQL generation
        logger.info("[ClarificationResponse] Sufficient information provided")
        context.reactive_questioning_active = False
        context.pause_reason = None  # Clear pause state
        context.next = "GenerateSelectSQL"
    else:
        # Still need more information
        missing_info = response_analysis.get('still_missing', [])
        if missing_info and context.clarification_attempts < 3:
            context.missing_information = missing_info
            context.next = "ReactiveQuestioning"
        else:
            # Proceed with best effort after max attempts
            logger.info("[ClarificationResponse] Proceeding with available information")
            context.next = "GenerateSelectSQL"
    
    return context.model_dump()

async def select_dependency_check_node(context):
    """Check dependencies for SELECT operations (minimal checks needed)."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    # SELECT operations typically don't need dependency checks
    # Just proceed to execution
    context.next = "ExecuteSelectSQL"
    return context.model_dump()

# --- Helper Functions for Reactive SELECT Flow ---

def _clear_select_flow_state(context):
    """Clear all SELECT flow related state."""
    context.reactive_questioning_active = False
    context.clarification_attempts = 0
    context.pause_reason = None
    context.pause_message = None
    context.missing_information = []
    context.clarification_questions = []
    context.extracted_criteria = None
    context.clarification_provided = False
    context.current_flow = None
    return context

async def _assess_query_clarity_with_vectordb(context):
    """Assess query clarity using LLM with vector DB context."""
    try:
        # Get relevant schema information from vector DB
        vector_results = await vector_search_service.search(
            context.message, 
            top_k=5,
            business_id=context.business_id
        )
        
        schema_info = "\n".join([result.get('content', '') for result in vector_results])
        
        clarity_prompt = f"""
You are analyzing a customer query for clarity in generating SQL SELECT statements.

Available Customer Schema Information:
{schema_info}

User Query: "{context.message}"

Analyze if this query is clear enough to generate a specific SQL SELECT statement.

Consider:
1. Are specific customer identifiers mentioned (ID, name, email, phone)?
2. Are search criteria clear (specific field values, ranges, patterns)?
3. Is the intent unambiguous?

Respond with JSON:
{{
    "is_clear": boolean,
    "missing_information": ["list of missing info needed"],
    "clarification_questions": ["specific questions to ask user"],
    "confidence": "high/medium/low"
}}

Examples:
- "show me customer CUS-000123" → is_clear: true
- "find customers" → is_clear: false, missing: ["search criteria"]
- "customers with gmail" → is_clear: true (clear criteria)
- "get some customers" → is_clear: false, missing: ["specific criteria"]
"""
        
        response = await llm_service.chat([
            {"role": "system", "content": clarity_prompt},
            {"role": "user", "content": context.message}
        ])
        
        # Parse LLM response
        import json
        try:
            result = json.loads(response)
            return result
        except json.JSONDecodeError:
            # Fallback if JSON parsing fails
            return {
                "is_clear": "specific" in context.message.lower() or "CUS-" in context.message,
                "missing_information": ["search criteria"],
                "clarification_questions": ["What specific customer information are you looking for?"]
            }
            
    except Exception as e:
        logger.error(f"[QueryClarity] Error: {e}")
        return {
            "is_clear": True,  # Default to clear to avoid blocking
            "missing_information": [],
            "clarification_questions": []
        }

async def _check_select_flow_interruption(context):
    """Check for flow interruption during SELECT operations."""
    try:
        interruption_prompt = f"""
Analyze if this user message interrupts the current SELECT flow with a different operation.

Current Flow: SELECT (customer search/retrieval)
User Message: "{context.message}"
Conversation Context: {[msg.content for msg in context.conversation_history[-3:]]}

Check for:
1. UPDATE/MODIFY requests ("update customer", "change", "modify")
2. DELETE requests ("delete", "remove")
3. INSERT/CREATE requests ("add customer", "create new")
4. Negative intent ("cancel", "stop", "nevermind")

Respond with JSON:
{{
    "is_interrupted": boolean,
    "target_operation": "select/update/delete/insert/cancel/none",
    "confidence": "high/medium/low",
    "suggested_response": "response to user"
}}
"""
        
        response = await llm_service.chat([
            {"role": "system", "content": interruption_prompt},
            {"role": "user", "content": context.message}
        ])
        
        import json
        try:
            result = json.loads(response)
            
            if result.get('is_interrupted', False):
                target_op = result.get('target_operation', 'none')
                
                if target_op == 'cancel':
                    context = _clear_select_flow_state(context)
                    context.response = result.get('suggested_response', "Operation canceled. How can I help you?")
                    context.next = "CustomerResponse"
                    return {'is_interrupted': True, 'response': context.model_dump()}
                elif target_op in ['update', 'delete', 'insert']:
                    context = _clear_select_flow_state(context)
                    context.current_flow = target_op
                    context.response = result.get('suggested_response', f"Switching to {target_op} operation.")
                    context.next = "GenerateCustomerSQL"
                    return {'is_interrupted': True, 'response': context.model_dump()}
            
            return {'is_interrupted': False}
            
        except json.JSONDecodeError:
            return {'is_interrupted': False}
            
    except Exception as e:
        logger.error(f"[FlowInterruption] Error: {e}")
        return {'is_interrupted': False}

async def _build_dynamic_select_sql_prompt(context):
    """Build dynamic SQL prompt using vector DB context and conversation history."""
    # Get enhanced schema context
    schema_context = context.schema_context or ""
    
    # Build conversation context
    conversation_context = ""
    if context.conversation_history:
        recent_messages = context.conversation_history[-6:]
        conversation_context = "\n".join([
            f"{msg.role}: {msg.content}" for msg in recent_messages
        ])
    
    # Include clarification context if available
    clarification_context = ""
    if getattr(context, 'clarification_provided', False):
        clarification_context = f"\nClarification provided: {getattr(context, 'extracted_criteria', '')}"
    
    sql_prompt = f"""
You are a SQL expert generating SELECT queries for customer data retrieval.

Customer Table Schema and Context:
{schema_context}

Business ID (zid): {context.business_id} (ALWAYS include in WHERE clause as integer)

Recent Conversation:
{conversation_context}
{clarification_context}

Generate a precise SQL SELECT query based on the user's request.

Rules:
1. ALWAYS include WHERE zid = {context.business_id} (as integer, not string)
2. Use appropriate column names from the schema
3. Handle partial matches with ILIKE for text searches
4. Order results logically (usually by xcus DESC for latest customers)
5. Use LIMIT when appropriate for large result sets

Examples:
- "show me customer CUS-000123" → SELECT * FROM cacus WHERE zid = {context.business_id} AND xcus = 'CUS-000123';
- "customers with gmail" → SELECT * FROM cacus WHERE zid = {context.business_id} AND xemail ILIKE '%gmail%';
- "last 5 customers" → SELECT * FROM cacus WHERE zid = {context.business_id} ORDER BY xcus DESC LIMIT 5;
- "customers with phone numbers" → SELECT * FROM cacus WHERE zid = {context.business_id} AND xphone IS NOT NULL AND xphone != '';

Return only the SQL query, no explanations.
"""
    
    return sql_prompt

async def _generate_dynamic_clarification_questions(context):
    """Generate dynamic clarification questions using vector DB context."""
    try:
        # Get relevant schema fields
        vector_results = await vector_search_service.search(
            "customer fields columns", 
            top_k=10,
            business_id=context.business_id
        )
        
        available_fields = "\n".join([result.get('content', '') for result in vector_results])
        
        question_prompt = f"""
Generate clarification questions to help the user specify their customer search criteria.

User Query: "{context.message}"
Missing Information: {getattr(context, 'missing_information', [])}
Attempt: {getattr(context, 'clarification_attempts', 1)}

Available Customer Fields:
{available_fields}

Generate 2-3 specific, helpful questions that guide the user to provide searchable criteria.

Focus on:
1. Customer identification (ID, name, email, phone)
2. Specific field values or patterns
3. Date ranges or quantities if relevant

Return as JSON array: ["question1", "question2", "question3"]

Examples:
- For "find customers" → ["Are you looking for a specific customer by name or ID?", "Do you want customers with specific criteria like email domain or phone area code?"]
- For "some customers" → ["How many customers do you need?", "Any specific criteria like recent customers or customers from a particular group?"]
"""
        
        response = await llm_service.chat([
            {"role": "system", "content": question_prompt},
            {"role": "user", "content": context.message}
        ])
        
        import json
        try:
            questions = json.loads(response)
            return questions if isinstance(questions, list) else []
        except json.JSONDecodeError:
            # Fallback questions
            return [
                "What specific customer information are you looking for?",
                "Do you have a customer ID, name, email, or phone number to search by?"
            ]
            
    except Exception as e:
        logger.error(f"[ClarificationQuestions] Error: {e}")
        return [
            "Could you provide more specific search criteria?",
            "Are you looking for a particular customer or a group of customers?"
        ]

def _format_clarification_questions(questions, schema_context):
    """Format clarification questions with helpful context."""
    if not questions:
        return "Could you provide more specific information about what you're looking for?"
    
    formatted_response = "I need a bit more information to find the right customers:\n\n"
    
    for i, question in enumerate(questions, 1):
        formatted_response += f"{i}. {question}\n"
    
    # Add helpful examples based on schema
    formatted_response += "\n💡 **Examples of what I can search for:**\n"
    formatted_response += "• Customer ID: \"CUS-000123\"\n"
    formatted_response += "• Email domain: \"customers with gmail\"\n"
    formatted_response += "• Recent customers: \"last 10 customers\"\n"
    formatted_response += "• Phone numbers: \"customers with phone numbers\""
    
    return formatted_response

async def _analyze_clarification_response(context):
    """Analyze user's clarification response using LLM."""
    try:
        analysis_prompt = f"""
Analyze the user's clarification response to extract customer search criteria.

Original Query: "{getattr(context, 'original_message', context.message)}"
Clarification Response: "{context.message}"
Previous Missing Info: {getattr(context, 'missing_information', [])}

Extract:
1. Specific search criteria provided
2. Whether enough information is now available for SQL generation
3. What information is still missing (if any)

Respond with JSON:
{{
    "sufficient_info": boolean,
    "extracted_info": {{
        "customer_id": "if provided",
        "name_pattern": "if provided",
        "email_pattern": "if provided",
        "phone_pattern": "if provided",
        "quantity": "if specified",
        "other_criteria": "any other criteria"
    }},
    "still_missing": ["list of still missing info"],
    "confidence": "high/medium/low"
}}
"""
        
        response = await llm_service.chat([
            {"role": "system", "content": analysis_prompt},
            {"role": "user", "content": context.message}
        ])
        
        import json
        try:
            result = json.loads(response)
            return result
        except json.JSONDecodeError:
            # Fallback analysis
            return {
                "sufficient_info": len(context.message.split()) > 2,
                "extracted_info": {"general_criteria": context.message},
                "still_missing": [],
                "confidence": "low"
            }
            
    except Exception as e:
        logger.error(f"[ClarificationAnalysis] Error: {e}")
        return {
            "sufficient_info": True,  # Default to proceed
            "extracted_info": {},
            "still_missing": []
        }
