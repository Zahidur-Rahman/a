"""
Comprehensive State Management System for Reactive Customer Agent
Handles state clearing, context preservation, and flow transitions
"""
from backend.app.models.chat_graph_state import ChatGraphState
import logging

logger = logging.getLogger(__name__)

class CustomerAgentStateManager:
    """Manages state transitions and cleanup for customer agent flows."""
    
    def __init__(self):
        # Define flow-specific state fields
        self.flow_state_fields = {
            'select': [
                'query_classification', 'is_query_clear', 'clarification_questions',
                'schema_context', 'sql', 'select_phase'
            ],
            'update': [
                'sql', 'update_phase', 'customer_selection_needed', 'field_selection_needed',
                'selected_customer_id', 'field_updates', 'current_customer_values',
                'incomplete_sql', 'collected_field_values'
            ],
            'delete': [
                'sql', 'delete_phase', 'customers_to_delete', 'delete_preview_message'
            ],
            'insert': [
                'sql', 'insert_phase', 'collected_field_values', 'incomplete_sql',
                'missing_mandatory_fields'
            ]
        }
        
        # Common state fields across all flows
        self.common_state_fields = [
            'pause_reason', 'pause_message', 'current_flow', 'customer_action',
            'negative_vibe_detected', 'schema_context'
        ]
        
        # Persistent fields that should never be cleared
        self.persistent_fields = [
            'business_id', 'message', 'conversation_history', 'next'
        ]

    def clear_all_flow_state(self, context: ChatGraphState) -> ChatGraphState:
        """Clear all flow-specific state while preserving persistent fields."""
        try:
            logger.info("[StateManager] Clearing all flow state")
            
            # Clear all flow-specific fields
            for flow, fields in self.flow_state_fields.items():
                context = self._clear_flow_fields(context, fields)
            
            # Clear common state fields
            context = self._clear_flow_fields(context, self.common_state_fields)
            
            logger.info("[StateManager] All flow state cleared successfully")
            return context
            
        except Exception as e:
            logger.error(f"[StateManager] Error clearing all flow state: {e}")
            return context

    def clear_flow_state(self, context: ChatGraphState, flow: str) -> ChatGraphState:
        """Clear state for a specific flow."""
        try:
            logger.info(f"[StateManager] Clearing {flow} flow state")
            
            if flow in self.flow_state_fields:
                fields_to_clear = self.flow_state_fields[flow]
                context = self._clear_flow_fields(context, fields_to_clear)
            
            # Clear common state fields
            context = self._clear_flow_fields(context, self.common_state_fields)
            
            logger.info(f"[StateManager] {flow} flow state cleared successfully")
            return context
            
        except Exception as e:
            logger.error(f"[StateManager] Error clearing {flow} flow state: {e}")
            return context

    def transition_flow_state(self, context: ChatGraphState, from_flow: str, to_flow: str) -> ChatGraphState:
        """Handle state transition between flows with selective preservation."""
        try:
            logger.info(f"[StateManager] Transitioning from {from_flow} to {to_flow}")
            
            # Determine what to preserve based on flow transition
            preservation_strategy = self._get_preservation_strategy(from_flow, to_flow)
            
            if preservation_strategy['clear_all']:
                context = self.clear_all_flow_state(context)
            elif preservation_strategy['clear_source']:
                context = self.clear_flow_state(context, from_flow)
            
            # Preserve specific fields if needed
            if preservation_strategy.get('preserve_customer_context'):
                # Keep customer-related context for related operations
                logger.info("[StateManager] Preserving customer context for related operation")
            
            # Set new flow
            context.current_flow = to_flow
            
            logger.info(f"[StateManager] Flow transition completed: {from_flow} → {to_flow}")
            return context
            
        except Exception as e:
            logger.error(f"[StateManager] Error in flow transition: {e}")
            return context

    def preserve_customer_context(self, context: ChatGraphState) -> dict:
        """Extract and preserve customer context for flow transitions."""
        try:
            preserved_context = {}
            
            # Preserve customer identification info
            if hasattr(context, 'selected_customer_id') and context.selected_customer_id:
                preserved_context['customer_id'] = context.selected_customer_id
            
            if hasattr(context, 'customers_to_delete') and context.customers_to_delete:
                preserved_context['customer_data'] = context.customers_to_delete
            
            if hasattr(context, 'current_customer_values') and context.current_customer_values:
                preserved_context['customer_values'] = context.current_customer_values
            
            # Preserve schema context
            if hasattr(context, 'schema_context') and context.schema_context:
                preserved_context['schema_context'] = context.schema_context
            
            logger.info(f"[StateManager] Preserved customer context: {list(preserved_context.keys())}")
            return preserved_context
            
        except Exception as e:
            logger.error(f"[StateManager] Error preserving customer context: {e}")
            return {}

    def restore_customer_context(self, context: ChatGraphState, preserved_context: dict) -> ChatGraphState:
        """Restore preserved customer context after flow transition."""
        try:
            if not preserved_context:
                return context
            
            # Restore customer identification
            if 'customer_id' in preserved_context:
                context.selected_customer_id = preserved_context['customer_id']
            
            if 'customer_data' in preserved_context:
                context.customers_to_delete = preserved_context['customer_data']
            
            if 'customer_values' in preserved_context:
                context.current_customer_values = preserved_context['customer_values']
            
            # Restore schema context
            if 'schema_context' in preserved_context:
                context.schema_context = preserved_context['schema_context']
            
            logger.info(f"[StateManager] Restored customer context: {list(preserved_context.keys())}")
            return context
            
        except Exception as e:
            logger.error(f"[StateManager] Error restoring customer context: {e}")
            return context

    def get_state_summary(self, context: ChatGraphState) -> dict:
        """Get a summary of current state for debugging and monitoring."""
        try:
            summary = {
                'current_flow': getattr(context, 'current_flow', None),
                'pause_reason': getattr(context, 'pause_reason', None),
                'customer_action': getattr(context, 'customer_action', None),
                'has_sql': bool(getattr(context, 'sql', None)),
                'active_fields': []
            }
            
            # Check which flow-specific fields are active
            for flow, fields in self.flow_state_fields.items():
                active_fields = []
                for field in fields:
                    if hasattr(context, field) and getattr(context, field) is not None:
                        active_fields.append(field)
                if active_fields:
                    summary['active_fields'].extend([f"{flow}:{field}" for field in active_fields])
            
            return summary
            
        except Exception as e:
            logger.error(f"[StateManager] Error getting state summary: {e}")
            return {'error': str(e)}

    def validate_state_consistency(self, context: ChatGraphState) -> dict:
        """Validate state consistency and detect potential issues."""
        try:
            issues = []
            warnings = []
            
            # Check for orphaned state
            current_flow = getattr(context, 'current_flow', None)
            if current_flow:
                # Check if other flows have active state
                for flow, fields in self.flow_state_fields.items():
                    if flow != current_flow:
                        active_fields = [f for f in fields if hasattr(context, f) and getattr(context, f) is not None]
                        if active_fields:
                            warnings.append(f"Flow {flow} has active state while in {current_flow}: {active_fields}")
            
            # Check for missing required state
            if current_flow and current_flow in self.flow_state_fields:
                pause_reason = getattr(context, 'pause_reason', None)
                if pause_reason and not getattr(context, 'pause_message', None):
                    issues.append("Pause reason set but no pause message")
            
            # Check for SQL without customer action
            if getattr(context, 'sql', None) and not getattr(context, 'customer_action', None):
                warnings.append("SQL present but no customer action set")
            
            return {
                'is_consistent': len(issues) == 0,
                'issues': issues,
                'warnings': warnings
            }
            
        except Exception as e:
            logger.error(f"[StateManager] Error validating state consistency: {e}")
            return {'is_consistent': False, 'issues': [f"Validation error: {e}"], 'warnings': []}

    def _clear_flow_fields(self, context: ChatGraphState, fields: list) -> ChatGraphState:
        """Clear specific fields from context."""
        for field in fields:
            if hasattr(context, field):
                try:
                    delattr(context, field)
                except AttributeError:
                    # Field doesn't exist, continue
                    pass
        return context

    def _get_preservation_strategy(self, from_flow: str, to_flow: str) -> dict:
        """Determine what state to preserve during flow transitions."""
        
        # Same flow - preserve everything
        if from_flow == to_flow:
            return {
                'clear_all': False,
                'clear_source': False,
                'preserve_customer_context': True
            }
        
        # Related flows (update ↔ delete) - preserve customer context
        related_flows = [['update', 'delete'], ['delete', 'update']]
        if [from_flow, to_flow] in related_flows:
            return {
                'clear_all': False,
                'clear_source': True,
                'preserve_customer_context': True
            }
        
        # Unrelated flows - clear everything
        return {
            'clear_all': True,
            'clear_source': False,
            'preserve_customer_context': False
        }

    def emergency_state_reset(self, context: ChatGraphState) -> ChatGraphState:
        """Emergency reset of all state except persistent fields."""
        try:
            logger.warning("[StateManager] Performing emergency state reset")
            
            # Preserve only persistent fields
            preserved_values = {}
            for field in self.persistent_fields:
                if hasattr(context, field):
                    preserved_values[field] = getattr(context, field)
            
            # Clear all other attributes
            for attr in list(context.__dict__.keys()):
                if attr not in self.persistent_fields:
                    try:
                        delattr(context, attr)
                    except AttributeError:
                        pass
            
            # Restore persistent fields
            for field, value in preserved_values.items():
                setattr(context, field, value)
            
            logger.warning("[StateManager] Emergency state reset completed")
            return context
            
        except Exception as e:
            logger.error(f"[StateManager] Error in emergency state reset: {e}")
            return context

# Global instance
state_manager = CustomerAgentStateManager()
