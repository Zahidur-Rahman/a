"""
Reactive Questioning System for Customer Agent
Handles unclear queries and provides intelligent clarification questions.
"""
from backend.app.services.mistral_llm_service import MistralLLMService
from backend.app.services.vector_search import FaissVectorSearchService
from backend.app.models.chat_graph_state import ChatGraphState
from backend.app.agents.customer_agent.negative_vibe_detector import negative_vibe_detector
import logging
import json

logger = logging.getLogger(__name__)

class ReactiveQuestioningSystem:
    """
    Handles reactive questioning for unclear customer queries.
    """
    
    def __init__(self):
        self.llm_service = MistralLLMService()
        self.vector_search_service = FaissVectorSearchService()
    
    async def assess_query_clarity(self, context: ChatGraphState) -> dict:
        """
        Assess if a query is clear enough to proceed with SQL generation.
        Returns assessment with clarity status and missing information.
        """
        try:
            # First check for negative vibe
            negative_vibe = await negative_vibe_detector.detect_negative_vibe(
                context.message, context.conversation_history
            )
            
            if negative_vibe['is_negative']:
                return {
                    "is_clear": False,
                    "missing_information": [],
                    "clarification_questions": [],
                    "is_continuation": False,
                    "confidence_score": negative_vibe['confidence'],
                    "negative_vibe": True,
                    "vibe_type": negative_vibe['vibe_type'],
                    "suggested_response": negative_vibe['suggested_response']
                }
            assessment_prompt = f"""
You are a query clarity assessor for a customer management system. Analyze the query and determine if it's clear enough to generate SQL.

Query: "{context.message}"
Current Flow: {context.current_flow or 'Unknown'}
Conversation History: {self._get_recent_context(context.conversation_history)}

Assess:
1. Is the query clear enough to generate SQL directly? (yes/no)
2. What specific information is missing?
3. What clarification questions should be asked?
4. Is this a continuation of a previous unclear query?

Respond in JSON format:
{{
    "is_clear": true/false,
    "missing_information": ["list", "of", "missing", "info"],
    "clarification_questions": ["question1", "question2"],
    "is_continuation": true/false,
    "confidence_score": 0.0-1.0
}}
"""

            messages = [
                {"role": "system", "content": "You are a precise query assessor. Respond only with valid JSON."},
                {"role": "user", "content": assessment_prompt}
            ]
            
            response = await self.llm_service.chat(messages)
            
            try:
                result = json.loads(response.strip())
                logger.info(f"[ReactiveQuestioning] Query clarity assessment: {result}")
                return result
            except json.JSONDecodeError:
                return {
                    "is_clear": True,
                    "missing_information": [],
                    "clarification_questions": [],
                    "is_continuation": False,
                    "confidence_score": 0.5
                }
                
        except Exception as e:
            logger.error(f"[ReactiveQuestioning] Error assessing query clarity: {e}")
            return {
                "is_clear": True,
                "missing_information": [],
                "clarification_questions": [],
                "is_continuation": False,
                "confidence_score": 0.0
            }
    
    async def generate_clarification_questions(self, context: ChatGraphState, missing_info: list) -> list:
        """
        Generate specific clarification questions based on the flow and missing information.
        """
        try:
            flow = context.current_flow or 'unknown'
            
            if flow == 'select':
                return await self._generate_select_clarification_questions(context, missing_info)
            elif flow == 'update':
                return await self._generate_update_clarification_questions(context, missing_info)
            elif flow == 'delete':
                return await self._generate_delete_clarification_questions(context, missing_info)
            elif flow == 'insert':
                return await self._generate_insert_clarification_questions(context, missing_info)
            else:
                return await self._generate_general_clarification_questions(context, missing_info)
                
        except Exception as e:
            logger.error(f"[ReactiveQuestioning] Error generating clarification questions: {e}")
            return ["Could you please provide more details about what you'd like to do?"]
    
    async def _generate_select_clarification_questions(self, context: ChatGraphState, missing_info: list) -> list:
        """Generate clarification questions for SELECT operations."""
        questions = []
        
        if 'customer_identification' in missing_info:
            questions.append("Which customer are you looking for? Please provide the customer ID or describe the customer (name, email, phone).")
        
        if 'search_criteria' in missing_info:
            questions.append("What specific information are you looking for about the customer? (e.g., contact details, customer type, recent activity)")
        
        if 'filter_criteria' in missing_info:
            questions.append("Do you want to see all customers or filter by specific criteria? (e.g., customers with phone numbers, corporate customers)")
        
        if not questions:
            questions.append("What customer information would you like to see?")
        
        return questions
    
    async def _generate_update_clarification_questions(self, context: ChatGraphState, missing_info: list) -> list:
        """Generate clarification questions for UPDATE operations."""
        questions = []
        
        if 'customer_identification' in missing_info:
            questions.append("Which customer would you like to update? Please provide the customer ID or say 'show me customers' to see the list.")
        
        if 'field_to_update' in missing_info:
            questions.append("Which field would you like to update? (e.g., email, phone, organization, customer type)")
        
        if 'new_value' in missing_info:
            questions.append("What should be the new value for this field?")
        
        if not questions:
            questions.append("What customer information would you like to update?")
        
        return questions
    
    async def _generate_delete_clarification_questions(self, context: ChatGraphState, missing_info: list) -> list:
        """Generate clarification questions for DELETE operations."""
        questions = []
        
        if 'customer_identification' in missing_info:
            questions.append("Which customer would you like to delete? Please provide the customer ID or say 'show me customers' to see the list.")
        
        if 'confirmation' in missing_info:
            questions.append("Are you sure you want to delete this customer? This action cannot be undone.")
        
        if not questions:
            questions.append("Which customer would you like to delete?")
        
        return questions
    
    async def _generate_insert_clarification_questions(self, context: ChatGraphState, missing_info: list) -> list:
        """Generate clarification questions for INSERT operations."""
        questions = []
        
        if 'customer_name' in missing_info:
            questions.append("What is the customer's name or organization?")
        
        if 'contact_info' in missing_info:
            questions.append("What is the customer's email address and phone number?")
        
        if 'customer_type' in missing_info:
            questions.append("What type of customer is this? (Corporate, Dealer, Retail, Inter Company)")
        
        if not questions:
            questions.append("What customer information would you like to add?")
        
        return questions
    
    async def _generate_general_clarification_questions(self, context: ChatGraphState, missing_info: list) -> list:
        """Generate general clarification questions."""
        return [
            "Could you please provide more details about what you'd like to do?",
            "Are you looking to add, search, update, or delete customer information?",
            "What specific customer information are you working with?"
        ]
    
    async def handle_clarification_response(self, context: ChatGraphState) -> dict:
        """
        Handle user's response to clarification questions.
        Determines if enough information has been provided to proceed.
        """
        try:
            response_prompt = f"""
Analyze the user's response to clarification questions and determine if enough information has been provided.

Original Query: "{context.message}"
Current Flow: {context.current_flow}
Previous Context: {self._get_recent_context(context.conversation_history)}

Assess:
1. Has the user provided enough information to proceed? (yes/no)
2. What information is still missing?
3. Should we ask more questions or proceed with SQL generation?

Respond in JSON format:
{{
    "sufficient_info": true/false,
    "still_missing": ["remaining", "missing", "info"],
    "action": "proceed|ask_more|clarify_flow",
    "confidence": 0.0-1.0
}}
"""

            messages = [
                {"role": "system", "content": "You are a clarification response analyzer. Respond only with valid JSON."},
                {"role": "user", "content": response_prompt}
            ]
            
            response = await self.llm_service.chat(messages)
            
            try:
                result = json.loads(response.strip())
                logger.info(f"[ReactiveQuestioning] Clarification response analysis: {result}")
                return result
            except json.JSONDecodeError:
                return {
                    "sufficient_info": True,
                    "still_missing": [],
                    "action": "proceed",
                    "confidence": 0.5
                }
                
        except Exception as e:
            logger.error(f"[ReactiveQuestioning] Error handling clarification response: {e}")
            return {
                "sufficient_info": True,
                "still_missing": [],
                "action": "proceed",
                "confidence": 0.0
            }
    
    def _get_recent_context(self, conversation_history) -> str:
        """Extract recent conversation context for analysis."""
        if not conversation_history:
            return "No previous conversation"
        
        recent_messages = conversation_history[-3:]  # Last 3 messages
        context_parts = []
        
        for msg in recent_messages:
            role = msg.get('role', 'unknown') if isinstance(msg, dict) else getattr(msg, 'role', 'unknown')
            content = msg.get('content', '') if isinstance(msg, dict) else getattr(msg, 'content', '')
            context_parts.append(f"{role.upper()}: {content}")
        
        return "\n".join(context_parts)
    
    async def should_continue_questioning(self, context: ChatGraphState) -> bool:
        """
        Determine if we should continue asking clarification questions.
        Prevents infinite questioning loops.
        """
        if not hasattr(context, 'sql_generation_attempts'):
            context.sql_generation_attempts = 0
        
        # Limit to 3 attempts
        if context.sql_generation_attempts >= 3:
            return False
        
        # Check if we're in a questioning loop
        if hasattr(context, 'reactive_questioning_active') and context.reactive_questioning_active:
            # Check if user is providing meaningful responses
            if len(context.message.strip()) < 10:  # Very short responses
                return False
        
        return True
    
    async def generate_contextual_sql_prompt(self, context: ChatGraphState) -> str:
        """
        Generate a contextual SQL prompt that includes all conversation context.
        """
        try:
            context_prompt = f"""
You are generating SQL for a customer management system. Use ALL the conversation context to understand the user's intent.

CONVERSATION CONTEXT:
{self._get_recent_context(context.conversation_history)}

CURRENT QUERY: {context.message}
CURRENT FLOW: {context.current_flow}
BUSINESS ID: {context.business_id}

IMPORTANT:
- Use the ENTIRE conversation history to understand what the user wants
- If the user is responding to clarification questions, incorporate their answers
- Generate SQL that reflects the complete intent, not just the current message
- If context shows a specific customer ID or details, use them

Generate the appropriate SQL query based on the complete context.
"""

            return context_prompt
            
        except Exception as e:
            logger.error(f"[ReactiveQuestioning] Error generating contextual SQL prompt: {e}")
            return f"Generate SQL for: {context.message}"
