from backend.app.services.base_agent import BaseAgent
from backend.app.agents.customer_agent.customer_chat_graph import customer_chat_graph
import logging

logger = logging.getLogger(__name__)

class CustomerAgent(BaseAgent):
    """
    Customer Agent that uses LangGraph workflow for customer-related queries and operations.
    """
    
    async def ainvoke(self, state):
        """
        Process customer-related queries using LangGraph workflow.
        """
        if not isinstance(state, dict):
            raise ValueError(f"Expected state to be a dictionary, got {type(state)}")
        
        try:
            print(f"[CustomerAgent] PRINT TEST - Invoking customer_chat_graph with state keys: {list(state.keys())}")
            logger.error(f"[CustomerAgent] ERROR TEST - Invoking customer_chat_graph with state keys: {list(state.keys())}")
            logger.warning(f"[CustomerAgent] WARNING TEST - Invoking customer_chat_graph with state keys: {list(state.keys())}")
            logger.info(f"[CustomerAgent] Invoking customer_chat_graph with state keys: {list(state.keys())}")
            
            print(f"[CustomerAgent] ABOUT TO CALL customer_chat_graph.ainvoke()")
            logger.error(f"[CustomerAgent] ABOUT TO CALL customer_chat_graph.ainvoke()")
            
            import asyncio
            try:
                result = await asyncio.wait_for(customer_chat_graph.ainvoke(state), timeout=10.0)
                print(f"[CustomerAgent] Graph execution SUCCESS")
                logger.error(f"[CustomerAgent] Graph execution SUCCESS")
            except asyncio.TimeoutError:
                print(f"[CustomerAgent] Graph execution TIMEOUT after 10 seconds")
                logger.error(f"[CustomerAgent] Graph execution TIMEOUT after 10 seconds")
                raise Exception("Graph execution timeout")
            except Exception as graph_error:
                print(f"[CustomerAgent] Graph execution ERROR: {graph_error}")
                logger.error(f"[CustomerAgent] Graph execution ERROR: {graph_error}")
                raise
            
            logger.info(f"[CustomerAgent] Graph execution completed, result keys: {list(result.keys()) if isinstance(result, dict) else type(result)}")
            return result
        except Exception as e:
            logger.error(f"[CustomerAgent] Error in LangGraph execution: {e}")
            import traceback
            logger.error(f"[CustomerAgent] Traceback: {traceback.format_exc()}")
            
            # Return a safe fallback response
            return {
                'message': state.get('message', ''),
                'business_id': state.get('business_id', ''),
                'user_id': state.get('user_id', ''),
                'conversation_history': state.get('conversation_history', []),
                'response': f"I encountered an error while processing your customer request. Please try again or contact support. Error: {str(e)}",
                'routed_agent': 'customer',
                'routing_confidence': 'error_fallback'
            }
