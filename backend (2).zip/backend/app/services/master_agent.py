from backend.app.services.base_agent import BaseAgent
from backend.app.services.agent_router import DynamicAgentRouter
import logging

logger = logging.getLogger(__name__)

class MasterAgent(BaseAgent):
    """
    Master Agent that dynamically routes queries to appropriate specialized agents.
    Uses intelligent classification to determine whether to use Customer Agent or General Agent.
    """
    
    def __init__(self, agent_registry):
        self.agent_router = DynamicAgentRouter(agent_registry)
    
    async def ainvoke(self, state):
        """
        Route the query to the appropriate agent based on dynamic classification.
        """
        if not isinstance(state, dict):
            raise ValueError(f"Expected state to be a dictionary, got {type(state)}")
        
        print(f"[MasterAgent] PRINT TEST - About to call agent_router.classify_and_route()")
        logger.error(f"[MasterAgent] ERROR TEST - About to call agent_router.classify_and_route()")
        
        # Use the agent router to classify and route
        result = await self.agent_router.classify_and_route(state)
        
        logger.info(f"[AGENT_USED] {result.get('routed_agent', 'unknown')}")
        
        return result