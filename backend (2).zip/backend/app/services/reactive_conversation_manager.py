"""
Reactive Conversation Manager

Transforms static response templates into dynamic, context-aware conversations
that understand user intent and respond naturally.
"""

import json
import logging
from typing import Dict, Any, List, Optional
from ..services.groq_llm_service import GroqLLMService

logger = logging.getLogger(__name__)

class ReactiveConversationManager:
    """
    Manages dynamic, reactive conversations that adapt to user context and intent.
    Replaces static templates with intelligent, contextual responses.
    """
    
    def __init__(self):
        self.llm_service = GroqLLMService()
    
    async def generate_reactive_response(self, context: Dict[str, Any], 
                                       situation: str, data: Dict[str, Any] = None) -> str:
        """
        Generate a reactive, contextual response based on the situation and user context.
        """
        try:
            conversation_history = self._extract_conversation_history(context)
            user_message = context.get('message', '')
            
            # Build situation-specific prompt
            response_prompt = self._build_response_prompt(situation, user_message, 
                                                        conversation_history, data)
            
            response = await self.llm_service.chat([
                {"role": "system", "content": response_prompt},
                {"role": "user", "content": f"Generate response for: {user_message}"}
            ])
            
            return response.strip()
            
        except Exception as e:
            logger.error(f"[ReactiveConversation] Error generating response: {e}")
            return self._fallback_response(situation, data)
    
    def _build_response_prompt(self, situation: str, user_message: str, 
                              conversation_history: str, data: Dict[str, Any] = None) -> str:
        """Build situation-specific prompts for different conversation contexts."""
        
        base_instructions = """
You are a helpful, intelligent customer service assistant. Generate natural, conversational responses that:
1. Understand synonyms and natural language variations
2. Respond contextually based on conversation history
3. Are concise but informative
4. Use friendly, professional tone
5. Provide clear next steps when appropriate
"""
        
        if situation == "multiple_customers_clarification":
            return f"""{base_instructions}

SITUATION: User found multiple customers and needs to clarify their selection intent.

USER MESSAGE: "{user_message}"
CONVERSATION HISTORY: {conversation_history}
AVAILABLE CUSTOMERS: {json.dumps(data.get('customers', []), indent=2) if data else 'None'}

UNDERSTAND SYNONYMS:
- "both" = "all" when referring to 2 customers
- "update both" = "update all" = bulk update
- "everyone" = "all customers" = bulk update
- "first one" = "customer 1" = index 0
- "second one" = "customer 2" = index 1

RESPONSE GUIDELINES:
- If user says "both" or "all" → acknowledge bulk update intent
- If user selects specific customer → acknowledge selection
- If unclear → provide friendly clarification with options
- Always be conversational, not robotic
- Show understanding of their intent

Generate a helpful, natural response that shows you understand their intent."""

        elif situation == "field_selection_guidance":
            return f"""{base_instructions}

SITUATION: User needs to specify which fields to update for customer(s).

USER MESSAGE: "{user_message}"
CONVERSATION HISTORY: {conversation_history}
CUSTOMER DATA: {json.dumps(data.get('customer', {}), indent=2) if data else 'None'}

RESPONSE GUIDELINES:
- Be conversational and helpful
- Suggest common fields they might want to update
- Give examples in natural language
- Show current values if available
- Make it easy to understand what they can change

Generate a friendly response that guides them to specify update fields."""

        elif situation == "confirmation_request":
            return f"""{base_instructions}

SITUATION: Requesting user confirmation for an operation.

USER MESSAGE: "{user_message}"
CONVERSATION HISTORY: {conversation_history}
OPERATION: {data.get('operation', 'operation') if data else 'operation'}
DETAILS: {json.dumps(data.get('details', {}), indent=2) if data else 'None'}

RESPONSE GUIDELINES:
- Clearly explain what will happen
- Show what data will be changed
- Ask for clear confirmation
- Be conversational but ensure they understand the impact
- For bulk operations, emphasize the scope

Generate a clear confirmation request that helps user understand the operation."""

        elif situation == "error_recovery":
            return f"""{base_instructions}

SITUATION: An error occurred and we need to help user recover gracefully.

USER MESSAGE: "{user_message}"
CONVERSATION HISTORY: {conversation_history}
ERROR_TYPE: {data.get('error_type', 'unknown') if data else 'unknown'}

RESPONSE GUIDELINES:
- Acknowledge the issue without being technical
- Suggest clear next steps
- Be reassuring and helpful
- Offer alternative approaches
- Keep it conversational

Generate a helpful error recovery response."""

        else:
            return f"""{base_instructions}

SITUATION: {situation}
USER MESSAGE: "{user_message}"
CONVERSATION HISTORY: {conversation_history}
DATA: {json.dumps(data, indent=2) if data else 'None'}

Generate a natural, helpful response appropriate for this situation."""
    
    def _extract_conversation_history(self, context: Dict[str, Any]) -> str:
        """Extract and format conversation history."""
        history = context.get('conversation_history', [])
        if not history:
            return "No previous conversation"
        
        # Get last 4 messages
        recent = history[-4:] if len(history) > 4 else history
        formatted = []
        
        for msg in recent:
            if isinstance(msg, dict):
                role = msg.get('role', 'user')
                content = msg.get('content', '')
            else:
                role = getattr(msg, 'role', 'user')
                content = getattr(msg, 'content', str(msg))
            
            # Truncate long messages
            if len(content) > 100:
                content = content[:100] + "..."
            
            formatted.append(f"{role}: {content}")
        
        return "\n".join(formatted)
    
    def _fallback_response(self, situation: str, data: Dict[str, Any] = None) -> str:
        """Provide fallback responses when LLM fails."""
        fallback_responses = {
            "multiple_customers_clarification": "I found multiple customers. Could you clarify which one you'd like to work with?",
            "field_selection_guidance": "Which fields would you like to update? You can specify email, phone, organization, or other customer details.",
            "confirmation_request": "Please confirm if you'd like to proceed with this operation.",
            "error_recovery": "Something went wrong. Let's try again - could you please rephrase your request?"
        }
        
        return fallback_responses.get(situation, "I'm here to help. Could you please clarify what you'd like to do?")

# Global instance
reactive_conversation = ReactiveConversationManager()
