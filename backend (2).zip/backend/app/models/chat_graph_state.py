from pydantic import BaseModel
from typing import List, Optional, Any, Dict
from backend.app.models.conversation import ChatMessage

class ChatGraphState(BaseModel):
    # Use class_config to prevent field validation conflicts
    class Config:
        arbitrary_types_allowed = True
        
    message: str
    business_id: str
    user_id: str
    conversation_history: List[ChatMessage]
    schema_context: Optional[Any] = None
    is_db_query: Optional[bool] = None
    sql_prompt: Optional[str] = None
    system_prompt: Optional[str] = None
    sql: Optional[str] = None
    db_result: Optional[Any] = None
    response: Optional[str] = None
    next: Optional[str] = None  # For routing in LangGraph
    # --- Add these fields for pause/resume support ---
    pause_reason: Optional[str] = None
    pause_message: Optional[str] = None
    confirm: Optional[bool] = None
    resume_from_pause: Optional[bool] = None 
    # --- Customer agent support ---
    customer_action: Optional[str] = None
    # --- Insert slot-filling support ---
    operation: Optional[str] = None
    collect_fields: Optional[Any] = None
    required_fields: Optional[Any] = None
    optional_fields: Optional[Any] = None
    # --- Insert validation fields ---
    incomplete_sql: Optional[str] = None  # Store incomplete INSERT SQL during validation
    missing_mandatory_fields: Optional[List[str]] = None  # Track missing mandatory fields
    collected_field_values: Optional[Dict[str, str]] = None  # Store collected field values
    validation_attempts: Optional[int] = None  # Track validation attempts
    target_customer_info: Optional[Dict[str, Any]] = None  # Store target customer info for operations
    preserved_operation: Optional[Dict[str, Any]] = None  # Store preserved operation context for interruptions
    query_classification: Optional[str] = None  # Store query classification result
    
    # --- Enhanced reactive customer agent fields ---
    current_flow: Optional[str] = None  # Track current flow (select, update, delete, insert)
    flow_state: Optional[Dict[str, Any]] = None  # Store flow-specific state
    is_query_clear: Optional[bool] = None  # Whether the current query is clear enough
    clarification_questions: Optional[List[str]] = None  # Questions to ask for clarification
    conversation_context: Optional[Dict[str, Any]] = None  # Store conversation context
    negative_vibe_detected: Optional[bool] = None  # Whether negative vibe is detected
    interruption_reason: Optional[str] = None  # Reason for flow interruption
    reactive_questioning_active: Optional[bool] = None  # Whether in reactive questioning mode
    customer_selection_context: Optional[Dict[str, Any]] = None  # Context for customer selection
    field_validation_context: Optional[Dict[str, Any]] = None  # Context for field validation
    sql_generation_attempts: Optional[int] = None  # Track SQL generation attempts
    last_sql_generation_context: Optional[Dict[str, Any]] = None  # Context from last SQL generation
    
    # --- Flow phase tracking ---
    insert_phase: Optional[str] = None  # Track insert flow phase
    update_phase: Optional[str] = None  # Track update flow phase
    delete_phase: Optional[str] = None  # Track delete flow phase
    duplicate_check_done: Optional[bool] = None  # Track if duplicate check is completed
    
    # --- Perfect Update Flow fields ---
    selected_customer: Optional[Dict[str, Any]] = None  # Selected customer for update
    identified_customers: Optional[List[Dict[str, Any]]] = None  # List of identified customers
    multiple_customers_found: Optional[List[Dict[str, Any]]] = None  # Multiple customers found
    customer_field_descriptions: Optional[Dict[str, Any]] = None  # Field descriptions from VectorDB
    pending_update_sql: Optional[str] = None  # Pending UPDATE SQL for confirmation
    bulk_update_data: Optional[Dict[str, Any]] = None  # Bulk update data for multiple customers