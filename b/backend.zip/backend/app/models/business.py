"""
MongoDB models for business configurations and schemas.
Supports Pinecone, Weaviate, or Faiss for vector search.
"""
from datetime import datetime
from typing import Dict, List, Optional, Any
from pydantic import BaseModel, Field
from bson import ObjectId

class PyObjectId(ObjectId):
    @classmethod
    def __get_pydantic_core_schema__(cls, source, handler):
        import pydantic_core
        return pydantic_core.core_schema.no_info_after_validator_function(
            cls.validate,
            handler(ObjectId)
        )

    @classmethod
    def validate(cls, v):
        if not ObjectId.is_valid(v):
            raise ValueError("Invalid ObjectId")
        return ObjectId(v)

    @classmethod
    def __get_pydantic_json_schema__(cls, core_schema, handler):
        # This tells Pydantic/OpenAPI to treat it as a string in the schema
        return {'type': 'string', 'format': 'objectid'}

class DatabaseConfig(BaseModel):
    """Database configuration for a business"""
    host: str
    database: str
    user: str
    password: str
    port: int = 5432
    ssl_mode: str = "require"

class BusinessConfig(BaseModel):
    """Business configuration model"""
    id: Optional[PyObjectId] = Field(default_factory=PyObjectId, alias="_id")
    business_id: str = Field(unique=True, index=True)
    name: str
    description: Optional[str] = None  # Added description field for business
    db_config: DatabaseConfig
    status: str = "active"  # active, inactive, suspended
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    
    class Config:
        validate_by_name = True
        arbitrary_types_allowed = True
        json_encoders = {ObjectId: str}

class ColumnInfo(BaseModel):
    """Column information for schema"""
    name: str
    type: str
    max_length: Optional[int] = None
    nullable: bool = True
    default: Optional[str] = None
    position: Optional[int] = None  # Make position optional for backward compatibility
    business_meaning: Optional[str] = None
    description: Optional[str] = None  # Added description field for column
    constraints: Optional[List[str]] = []  # PRIMARY KEY, FOREIGN KEY, UNIQUE, INDEX, etc.

class TableRelationship(BaseModel):
    """Table relationship information"""
    relationship_type: str  
    referenced_table: str
    referenced_column: str
    description: Optional[str] = None

class BusinessSchema(BaseModel):
    """Business schema model for vector embeddings"""
    id: Optional[PyObjectId] = Field(default_factory=PyObjectId, alias="_id")
    business_id: str = Field(index=True)
    table_name: str
    schema_description: str
    columns: List[ColumnInfo]
    relationships: List[TableRelationship] = []
    embedding_text: Optional[str] = None  # Make optional for backward compatibility
    vector_id: Optional[str] = None  # ID in vector store (Pinecone/Weaviate/Faiss)
    indexed_at: Optional[datetime] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    
    class Config:
        validate_by_name = True
        arbitrary_types_allowed = True
        json_encoders = {ObjectId: str}

class BusinessConfigCreate(BaseModel):
    """Model for creating business configuration"""
    business_id: str
    name: str
    description: Optional[str] = None  # Added description field for business
    db_config: DatabaseConfig
    status: str = "active"

class BusinessConfigUpdate(BaseModel):
    """Model for updating business configuration"""
    name: Optional[str] = None
    description: Optional[str] = None  # Added description field for business
    db_config: Optional[DatabaseConfig] = None
    status: Optional[str] = None

class BusinessSchemaCreateUpdate(BaseModel):
    """Combined model for creating and updating business schema"""
    business_id: str
    table_name: str
    schema_description: str
    columns: List[ColumnInfo]
    relationships: List[TableRelationship] = []
    embedding_text: Optional[str] = None  # Auto-generated if not provided
    
    def generate_embedding_text(self) -> str:
        """Generate embedding text from schema components"""
        text_parts = [
            f"Table: {self.table_name}",
            f"Description: {self.schema_description}"
        ]
        
        # Add column information
        column_texts = []
        for col in self.columns:
            col_text = f"{col.name} ({col.type})"
            if col.description:
                col_text += f" - {col.description}"
            elif col.business_meaning:
                col_text += f" - {col.business_meaning}"
            column_texts.append(col_text)
        
        if column_texts:
            text_parts.append(f"Columns: {', '.join(column_texts)}")
        
        # Add relationship information
        if self.relationships:
            rel_texts = []
            for rel in self.relationships:
                rel_text = f"{rel.relationship_type} with {rel.referenced_table}.{rel.referenced_column}"
                if rel.description:
                    rel_text += f" - {rel.description}"
                rel_texts.append(rel_text)
            text_parts.append(f"Relationships: {', '.join(rel_texts)}")
        
        return ". ".join(text_parts)

# Keep backward compatibility
BusinessSchemaCreate = BusinessSchemaCreateUpdate

class BusinessSchemaUpdate(BaseModel):
    """Model for updating business schema"""
    schema_description: Optional[str] = None
    columns: Optional[List[ColumnInfo]] = None
    relationships: Optional[List[TableRelationship]] = None
    embedding_text: Optional[str] = None