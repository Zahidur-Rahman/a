"""
Advanced Negative Vibe Detection System for Customer Agent
Uses LLM to dynamically detect negative sentiments, cancellations, and interruptions
"""
from backend.app.services.mistral_llm_service import MistralLLMService
import logging
import re

logger = logging.getLogger(__name__)

class NegativeVibeDetector:
    """Advanced negative vibe detection using LLM and pattern matching."""
    
    def __init__(self):
        self.llm_service = MistralLLMService()
        
        # Static patterns for quick detection
        self.cancel_patterns = [
            r'\b(no|nope|nevermind|never mind|cancel|abort|stop|quit|exit)\b',
            r'\b(don\'t|dont|do not)\s+(want|need|like)\b',
            r'\b(not\s+interested|not\s+needed|not\s+required)\b',
            r'\b(ignore|skip|pass|forget)\b',
            r'\b(that\'s\s+ok|thats\s+ok|its\s+ok|it\'s\s+ok)\b',
            r'\b(no\s+thanks|no\s+thank\s+you)\b'
        ]
        
        self.negative_patterns = [
            r'\b(wrong|incorrect|error|mistake|bad|terrible|awful)\b',
            r'\b(hate|dislike|annoying|frustrating|confusing)\b',
            r'\b(useless|pointless|waste|stupid|dumb)\b',
            r'\b(not\s+working|broken|failed|error)\b'
        ]
        
        self.interruption_patterns = [
            r'\b(wait|hold|pause|stop|freeze)\b',
            r'\b(actually|instead|rather|prefer)\b',
            r'\b(change\s+mind|changed\s+my\s+mind)\b',
            r'\b(let\s+me|let\s+me\s+think)\b',
            r'\b(go\s+back|start\s+over|restart)\b'
        ]
        
        self.confusion_patterns = [
            r'\b(confused|confusing|unclear|understand|what)\b',
            r'\b(how\s+do|what\s+do|where\s+do)\b',
            r'\b(help|explain|clarify)\b'
        ]

    async def detect_negative_vibe(self, message: str, conversation_history: list = None, current_flow: str = None) -> dict:
        """
        Detect negative vibe using both pattern matching and LLM analysis.
        
        Returns:
            dict: {
                'is_negative': bool,
                'confidence': float,
                'vibe_type': str,  # 'cancel', 'negative', 'interruption', 'none'
                'reasoning': str,
                'suggested_response': str
            }
        """
        try:
            # First check pattern-based detection (includes CRUD operation check)
            pattern_result = self._pattern_based_detection(message)
            
            # If pattern detection found a legitimate CRUD operation, return immediately
            if not pattern_result['is_negative'] and pattern_result['reasoning'] == "Detected legitimate CRUD operation":
                return pattern_result
            
            # If pattern detection found high-confidence negative, but let's double-check with LLM for CRUD operations
            if pattern_result['is_negative'] and pattern_result['confidence'] > 0.8:
                # Use LLM to verify this isn't a legitimate CRUD operation
                llm_result = await self._llm_based_detection(message, conversation_history, current_flow)
                if not llm_result['is_negative']:
                    return llm_result  # LLM says it's not negative, trust it
                return pattern_result  # Both agree it's negative
            
            # Use LLM for more nuanced detection
            llm_result = await self._llm_based_detection(message, conversation_history, current_flow)
            
            # Combine results with LLM taking precedence for complex cases
            if llm_result['confidence'] > 0.6:
                return llm_result
            elif pattern_result['is_negative']:
                return pattern_result
            else:
                return llm_result
                
        except Exception as e:
            logger.error(f"[NegativeVibeDetector] Error in detection: {e}")
            # Fallback to pattern matching
            return self._pattern_based_detection(message)

    def _pattern_based_detection(self, message: str) -> dict:
        """Quick pattern-based negative vibe detection."""
        message_lower = message.lower().strip()
        
        # First check if this is a legitimate CRUD operation
        crud_patterns = [
            r'\b(add|insert|create)\s+(a\s+)?customer\b',
            r'\b(update|modify|change)\s+(a\s+)?customer\b',
            r'\b(delete|remove)\s+(a\s+)?customer\b',
            r'\b(show|list|find|get|select)\s+(a\s+)?customer\b',
            r'\b(add|insert|create)\s+new\s+customer\b',
            r'\b(delete|remove)\s+(last|first|third)\s+customer\b',
            r'\bcustomer\s+(with|whose|from)\b'
        ]
        
        for crud_pattern in crud_patterns:
            if re.search(crud_pattern, message_lower, re.IGNORECASE):
                return {
                    'is_negative': False,
                    'confidence': 0.1,
                    'vibe_type': 'none',
                    'reasoning': "Detected legitimate CRUD operation",
                    'suggested_response': None
                }
        
        # Check for cancellation patterns
        for pattern in self.cancel_patterns:
            if re.search(pattern, message_lower, re.IGNORECASE):
                return {
                    'is_negative': True,
                    'confidence': 0.9,
                    'vibe_type': 'cancel',
                    'reasoning': f"Detected cancellation pattern: '{pattern}'",
                    'suggested_response': "Operation canceled. How can I help you?"
                }
        
        # Check for negative sentiment patterns
        for pattern in self.negative_patterns:
            if re.search(pattern, message_lower, re.IGNORECASE):
                return {
                    'is_negative': True,
                    'confidence': 0.8,
                    'vibe_type': 'negative',
                    'reasoning': f"Detected negative sentiment pattern: '{pattern}'",
                    'suggested_response': "I understand your concern. Let me help you with something else."
                }
        
        # Check for interruption patterns
        for pattern in self.interruption_patterns:
            if re.search(pattern, message_lower, re.IGNORECASE):
                return {
                    'is_negative': True,
                    'confidence': 0.7,
                    'vibe_type': 'interruption',
                    'reasoning': f"Detected interruption pattern: '{pattern}'",
                    'suggested_response': "I'll pause here. What would you like to do instead?"
                }
        
        # Check for confusion patterns
        for pattern in self.confusion_patterns:
            if re.search(pattern, message_lower, re.IGNORECASE):
                return {
                    'is_negative': True,
                    'confidence': 0.6,
                    'vibe_type': 'confusion',
                    'reasoning': f"Detected confusion pattern: '{pattern}'",
                    'suggested_response': "I want to make sure I understand correctly. Could you clarify what you need?"
                }
        
        return {
            'is_negative': False,
            'confidence': 0.1,
            'vibe_type': 'none',
            'reasoning': "No negative patterns detected",
            'suggested_response': None
        }

    async def _llm_based_detection(self, message: str, conversation_history: list = None, current_flow: str = None) -> dict:
        """Advanced LLM-based negative vibe detection."""
        try:
            # Build context for LLM
            context = ""
            if conversation_history:
                recent_messages = conversation_history[-3:] if len(conversation_history) > 3 else conversation_history
                context = "Recent conversation:\n"
                for msg in recent_messages:
                    role = msg.get('role', 'unknown') if isinstance(msg, dict) else getattr(msg, 'role', 'unknown')
                    content = msg.get('content', '') if isinstance(msg, dict) else getattr(msg, 'content', '')
                    context += f"{role}: {content}\n"
            
            prompt = f"""You are an expert at detecting user sentiment and intent in customer service conversations.

IMPORTANT: This is a customer management system. Users frequently make legitimate requests to:
- INSERT/ADD customers ("add a customer", "insert customer", "create new customer")
- UPDATE customers ("update customer", "modify customer", "change customer details")
- DELETE customers ("delete customer", "remove customer", "delete last customer")
- SELECT/VIEW customers ("show customers", "list customers", "find customer")

These are NORMAL BUSINESS OPERATIONS and should NOT be flagged as negative unless the user shows clear frustration, cancellation intent, or confusion.

Current user message: "{message}"
Current operation: {current_flow or 'none'}

{context}

Analyze this message for:
1. Cancellation intent (user wants to stop current operation) - NOT legitimate CRUD requests
2. Negative sentiment (frustration, anger, dissatisfaction) - NOT normal business operations
3. Interruption intent (user wants to change direction) - NOT switching between CRUD operations
4. Confusion or misunderstanding
5. Context-specific negative patterns based on current flow

CRUD OPERATION EXAMPLES THAT ARE NOT NEGATIVE:
- "delete a customer" → LEGITIMATE DELETE REQUEST
- "add customer" → LEGITIMATE INSERT REQUEST  
- "update customer info" → LEGITIMATE UPDATE REQUEST
- "show me customers" → LEGITIMATE SELECT REQUEST
- "remove last customer" → LEGITIMATE DELETE REQUEST

ACTUAL NEGATIVE EXAMPLES:
- "no thanks, cancel this" → CANCELLATION
- "this is wrong, stop" → NEGATIVE + CANCELLATION
- "I don't want to do this anymore" → CANCELLATION
- "this system is terrible" → NEGATIVE SENTIMENT

Respond with ONLY a JSON object in this exact format:
{{
    "is_negative": true/false,
    "confidence": 0.0-1.0,
    "vibe_type": "cancel|negative|interruption|confusion|none",
    "reasoning": "brief explanation",
    "suggested_response": "appropriate response to user",
    "flow_specific_advice": "advice for handling in current flow context"
}}

Examples:
- "delete a customer" → {{"is_negative": false, "confidence": 0.1, "vibe_type": "none", "reasoning": "legitimate delete request", "suggested_response": null}}
- "no thanks" → {{"is_negative": true, "confidence": 0.9, "vibe_type": "cancel", "reasoning": "explicit decline", "suggested_response": "No problem! How can I help you?"}}
- "this is wrong" → {{"is_negative": true, "confidence": 0.8, "vibe_type": "negative", "reasoning": "expresses dissatisfaction", "suggested_response": "I understand your concern. Let me help fix this."}}
- "wait, actually..." → {{"is_negative": true, "confidence": 0.7, "vibe_type": "interruption", "reasoning": "wants to change direction", "suggested_response": "I'll pause here. What would you like to do instead?"}}
- "show me customers" → {{"is_negative": false, "confidence": 0.1, "vibe_type": "none", "reasoning": "clear request", "suggested_response": null}}"""

            response = await self.llm_service.chat([
                {"role": "system", "content": "You are a sentiment analysis expert. Respond with only valid JSON."},
                {"role": "user", "content": prompt}
            ])
            
            # Parse LLM response
            import json
            result = json.loads(response.strip())
            
            # Validate result structure
            required_keys = ['is_negative', 'confidence', 'vibe_type', 'reasoning', 'suggested_response']
            if all(key in result for key in required_keys):
                return result
            else:
                logger.warning(f"[NegativeVibeDetector] Invalid LLM response structure: {result}")
                return self._pattern_based_detection(message)
                
        except json.JSONDecodeError as e:
            logger.warning(f"[NegativeVibeDetector] Failed to parse LLM response as JSON: {e}")
            return self._pattern_based_detection(message)
        except Exception as e:
            logger.error(f"[NegativeVibeDetector] LLM detection error: {e}")
            return self._pattern_based_detection(message)

    def should_cancel_operation(self, message: str, current_flow: str = None) -> bool:
        """Quick check if operation should be cancelled based on message."""
        result = self._pattern_based_detection(message)
        return result['is_negative'] and result['vibe_type'] in ['cancel', 'interruption']

    def get_cancellation_response(self, vibe_type: str) -> str:
        """Get appropriate response based on vibe type."""
        responses = {
            'cancel': "Operation canceled. How can I help you?",
            'negative': "I understand your concern. Let me help you with something else.",
            'interruption': "I'll pause here. What would you like to do instead?",
            'confusion': "I want to make sure I understand correctly. Could you clarify what you need?",
            'none': "How can I help you?"
        }
        return responses.get(vibe_type, "How can I help you?")

# Global instance
negative_vibe_detector = NegativeVibeDetector()
