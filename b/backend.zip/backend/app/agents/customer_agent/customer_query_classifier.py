from backend.app.services.mistral_llm_service import MistralLLMService
import logging
import re
import json

logger = logging.getLogger(__name__)

# Universal JSON parser for LLM responses
def _parse_llm_json_response(response: str) -> dict:
    """Parse JSON response from LLM, handling markdown code blocks and other formatting issues."""
    # Clean the response
    response = response.strip()
    
    # Remove markdown code blocks
    if response.startswith('```json'):
        response = response[7:]  # Remove ```json
    elif response.startswith('```'):
        response = response[3:]   # Remove ```
    
    if response.endswith('```'):
        response = response[:-3]  # Remove ending ```
    
    # Remove any extra whitespace
    response = response.strip()
    
    # Try to extract JSON if it's embedded in other text
    json_match = re.search(r'\{.*\}', response, re.DOTALL)
    if json_match:
        response = json_match.group(0)
    
    try:
        return json.loads(response)
    except json.JSONDecodeError as e:
        logger.error(f"[JSONParser] Failed to parse JSON: {e}, cleaned response: {response[:200]}...")
        # Return a basic fallback structure
        raise json.JSONDecodeError(f"Could not parse LLM JSON response: {e}", response, 0)

class CustomerQueryClassifier:
    """
    Enhanced customer query classifier with negative vibe detection and reactive questioning support.
    """
    
    def __init__(self):
        self.llm_service = MistralLLMService()
    
    async def classify_query(self, query: str, conversation_history=None) -> dict:
        """
        Enhanced classification that returns both action and clarity assessment.
        Returns a dictionary with:
        - action: The primary action (CREATE_CUSTOMER, SEARCH_CUSTOMER, etc.)
        - is_clear: Whether the query is clear enough to proceed
        - needs_clarification: Whether clarification is needed
        - negative_vibe: Whether negative sentiment is detected
        - clarification_questions: Questions to ask for clarification
        """
        try:
            # First, check for negative vibes
            negative_vibe = await self._detect_negative_vibe(query, conversation_history)
            
            if negative_vibe:
                return {
                    'action': 'NEGATIVE_RESPONSE',
                    'is_clear': False,
                    'needs_clarification': False,
                    'negative_vibe': True,
                    'clarification_questions': []
                }
            
            # Then classify the main action
            classification_prompt = f"""
You are an advanced query classifier for a customer management system. Analyze the query and provide detailed classification.

Query: "{query}"

Classify into one of these categories:
1. CREATE_CUSTOMER - User wants to add/create a new customer
2. SEARCH_CUSTOMER - User wants to find/search for existing customers  
3. UPDATE_CUSTOMER - User wants to modify existing customer information
4. DELETE_CUSTOMER - User wants to remove/delete a customer
5. LIST_CUSTOMERS - User wants to see all customers or recent customers
6. GENERAL_CUSTOMER - General customer-related questions or conversation
7. UNCLEAR_QUERY - Query is too vague or unclear to determine intent

Also assess:
- Is the query clear enough to generate SQL directly? (yes/no)
- What specific information is missing for clarity?
- What clarification questions should be asked?

Respond in JSON format:
{{
    "action": "CATEGORY_NAME",
    "is_clear": true/false,
    "missing_information": ["list", "of", "missing", "info"],
    "clarification_questions": ["question1", "question2"]
}}
"""

            messages = [
                {"role": "system", "content": "You are a precise query classifier. Respond only with valid JSON."},
                {"role": "user", "content": classification_prompt}
            ]
            
            response = await self.llm_service.chat(messages)
            
            # Parse JSON response using enhanced parser
            try:
                result = _parse_llm_json_response(response)
                
                # Validate and set defaults
                valid_actions = [
                    'CREATE_CUSTOMER', 'SEARCH_CUSTOMER', 'UPDATE_CUSTOMER', 
                    'DELETE_CUSTOMER', 'LIST_CUSTOMERS', 'GENERAL_CUSTOMER', 'UNCLEAR_QUERY'
                ]
                
                if result.get('action') not in valid_actions:
                    result['action'] = 'GENERAL_CUSTOMER'
                
                result['negative_vibe'] = False
                result['needs_clarification'] = not result.get('is_clear', False)
                
                logger.info(f"[CustomerQueryClassifier] Query '{query}' classified as: {result['action']}, clear: {result['is_clear']}")
                return result
                
            except json.JSONDecodeError as e:
                logger.error(f"[CustomerQueryClassifier] JSON parsing failed: {e}, response: {response[:200]}...")
                # Fallback to simple classification
                return await self._fallback_classification(query)
                
        except Exception as e:
            logger.error(f"[CustomerQueryClassifier] Error classifying query: {e}")
            return await self._fallback_classification(query)
    
    async def _detect_negative_vibe(self, query: str, conversation_history=None) -> bool:
        """
        Detect negative sentiment or cancellation intent in the query.
        """
        try:
            negative_prompt = f"""
Analyze the following query for negative sentiment, cancellation intent, or refusal to proceed.

Query: "{query}"

Look for:
- Negative words (no, cancel, stop, abort, nevermind, etc.)
- Refusal to provide information
- Expression of frustration or dissatisfaction
- Intent to stop current operation
- Switching to different topic/operation

Respond with only "true" if negative sentiment is detected, "false" otherwise.
"""

            messages = [
                {"role": "system", "content": "You are a sentiment analyzer. Respond only with 'true' or 'false'."},
                {"role": "user", "content": negative_prompt}
            ]
            
            response = await self.llm_service.chat(messages)
            return response.strip().lower() == 'true'
            
        except Exception as e:
            logger.error(f"[CustomerQueryClassifier] Error detecting negative vibe: {e}")
            return False
    
    async def _fallback_classification(self, query: str) -> dict:
        """
        Fallback classification using simple keyword matching.
        """
        query_lower = query.lower()
        
        if any(word in query_lower for word in ['add', 'create', 'new customer', 'register']):
            action = 'CREATE_CUSTOMER'
        elif any(word in query_lower for word in ['find', 'search', 'look up', 'show me', 'his details', 'this customer']):
            action = 'SEARCH_CUSTOMER'
        elif any(word in query_lower for word in ['update', 'modify', 'change', 'edit', 'his phone', 'his email']):
            action = 'UPDATE_CUSTOMER'
        elif any(word in query_lower for word in ['delete', 'remove', 'cancel']):
            action = 'DELETE_CUSTOMER'
        elif any(word in query_lower for word in ['list', 'show all', 'recent', 'all customers']):
            action = 'LIST_CUSTOMERS'
        else:
            action = 'GENERAL_CUSTOMER'
        
        return {
            'action': action,
            'is_clear': True,
            'needs_clarification': False,
            'negative_vibe': False,
            'clarification_questions': []
        }
    
    def is_customer_related(self, query: str) -> bool:
        """
        Simple check to determine if a query is customer-related.
        """
        customer_keywords = [
            'customer', 'client', 'customers', 'clients',
            'add customer', 'create customer', 'new customer',
            'find customer', 'search customer', 'list customer',
            'update customer', 'edit customer', 'modify customer',
            'delete customer', 'remove customer', 'his details',
            'his info', 'his phone', 'his email', 'this customer',
            'that customer', 'these customers'
        ]
        
        query_lower = query.lower()
        return any(keyword in query_lower for keyword in customer_keywords)
    
    async def generate_clarification_questions(self, query: str, action: str, missing_info: list) -> list:
        """
        Generate specific clarification questions based on the action and missing information.
        """
        try:
            clarification_prompt = f"""
Generate 2-3 specific clarification questions for a customer management query.

Query: "{query}"
Action: {action}
Missing Information: {missing_info}

Generate questions that:
1. Are specific to the missing information
2. Help narrow down the customer or operation
3. Are easy to understand and answer
4. Don't overwhelm the user

Examples:
- For unclear customer identification: "Which customer would you like to update? Please provide the customer ID or say 'show me customers' to see the list."
- For missing field information: "What is the customer's email address?"
- For vague search: "What specific information are you looking for about the customer?"

Respond with a JSON array of questions: ["question1", "question2", "question3"]
"""

            messages = [
                {"role": "system", "content": "You are a helpful assistant. Respond only with a JSON array of questions."},
                {"role": "user", "content": clarification_prompt}
            ]
            
            response = await self.llm_service.chat(messages)
            
            try:
                questions = _parse_llm_json_response(response)
                return questions if isinstance(questions, list) else []
            except json.JSONDecodeError as e:
                logger.error(f"[CustomerQueryClassifier] Clarification questions JSON parsing failed: {e}")
                return []
                
        except Exception as e:
            logger.error(f"[CustomerQueryClassifier] Error generating clarification questions: {e}")
            return []
