"""
Flow Interruption Handler for Customer Agent
Handles dynamic switching between select/update/delete/insert flows based on user intent
"""
from backend.app.services.mistral_llm_service import MistralLLMService
from backend.app.agents.customer_agent.negative_vibe_detector import negative_vibe_detector
import logging
import re

logger = logging.getLogger(__name__)

class FlowInterruptionHandler:
    """Handles flow interruptions and intent disambiguation."""
    
    def __init__(self):
        self.llm_service = MistralLLMService()
        
        # Flow keywords for quick detection
        self.flow_keywords = {
            'select': ['show', 'find', 'search', 'list', 'get', 'display', 'view', 'see'],
            'update': ['update', 'modify', 'change', 'edit', 'alter', 'fix'],
            'delete': ['delete', 'remove', 'drop', 'eliminate', 'destroy'],
            'insert': ['add', 'create', 'insert', 'new', 'register', 'enroll']
        }
        
        # Context keywords that suggest continuation vs interruption
        self.continuation_keywords = {
            'update': ['customer', 'field', 'value', 'data', 'information'],
            'select': ['customer', 'list', 'search', 'find', 'show'],
            'delete': ['customer', 'record', 'data'],
            'insert': ['customer', 'data', 'information', 'details']
        }

    async def check_interruption(self, message: str, conversation_history: list = None, current_flow: str = None) -> dict:
        """
        Main method used by flows to check for interruptions.
        
        Returns:
            dict: {
                'is_interrupted': bool,
                'new_intent': str,  # 'select', 'update', 'delete', 'insert', 'none'
                'confidence': float,
                'reasoning': str,
                'suggested_response': str
            }
        """
        try:
            result = await self.detect_flow_interruption(message, current_flow, conversation_history)
            
            return {
                'is_interrupted': result['is_interruption'],
                'new_intent': result['target_flow'],
                'confidence': result['confidence'],
                'reasoning': result['reasoning'],
                'suggested_response': result.get('suggested_response')
            }
            
        except Exception as e:
            logger.error(f"[FlowInterruptionHandler] Error in check_interruption: {e}")
            return {
                'is_interrupted': False,
                'new_intent': 'none',
                'confidence': 0.0,
                'reasoning': f"Error: {e}",
                'suggested_response': None
            }

    async def detect_flow_interruption(self, message: str, current_flow: str, conversation_history: list = None) -> dict:
        """
        Detect if user wants to interrupt current flow and switch to another.
        
        Returns:
            dict: {
                'is_interruption': bool,
                'target_flow': str,  # 'select', 'update', 'delete', 'insert', 'none'
                'confidence': float,
                'reasoning': str,
                'should_preserve_state': bool,  # True if user wants to continue current operation
                'suggested_response': str
            }
        """
        try:
            # First check for negative vibe - this overrides everything
            negative_vibe = await negative_vibe_detector.detect_negative_vibe(message, conversation_history)
            if negative_vibe['is_negative']:
                return {
                    'is_interruption': True,
                    'target_flow': 'none',
                    'confidence': negative_vibe['confidence'],
                    'reasoning': f"Negative vibe detected: {negative_vibe['vibe_type']}",
                    'should_preserve_state': False,
                    'suggested_response': negative_vibe['suggested_response']
                }
            
            # Quick pattern-based detection
            pattern_result = self._pattern_based_interruption_detection(message, current_flow)
            if pattern_result['confidence'] > 0.8:
                return pattern_result
            
            # Use LLM for complex cases
            llm_result = await self._llm_based_interruption_detection(message, current_flow, conversation_history)
            
            # Combine results
            if llm_result['confidence'] > 0.6:
                return llm_result
            elif pattern_result['is_interruption']:
                return pattern_result
            else:
                return llm_result
                
        except Exception as e:
            logger.error(f"[FlowInterruptionHandler] Error in detection: {e}")
            return {
                'is_interruption': False,
                'target_flow': 'none',
                'confidence': 0.0,
                'reasoning': f"Error in detection: {e}",
                'should_preserve_state': True,
                'suggested_response': None
            }

    def _pattern_based_interruption_detection(self, message: str, current_flow: str) -> dict:
        """Quick pattern-based flow interruption detection."""
        message_lower = message.lower().strip()
        
        # Check for explicit flow keywords
        for flow, keywords in self.flow_keywords.items():
            if flow != current_flow:  # Only check other flows
                for keyword in keywords:
                    if keyword in message_lower:
                        return {
                            'is_interruption': True,
                            'target_flow': flow,
                            'confidence': 0.9,
                            'reasoning': f"Detected {flow} keyword: '{keyword}'",
                            'should_preserve_state': False,
                            'suggested_response': f"Switching to {flow} operation. {self._get_flow_guidance(flow)}"
                        }
        
        # Check for continuation keywords
        if current_flow in self.continuation_keywords:
            continuation_keywords = self.continuation_keywords[current_flow]
            for keyword in continuation_keywords:
                if keyword in message_lower:
                    return {
                        'is_interruption': False,
                        'target_flow': current_flow,
                        'confidence': 0.8,
                        'reasoning': f"Detected continuation keyword: '{keyword}'",
                        'should_preserve_state': True,
                        'suggested_response': None
                    }
        
        return {
            'is_interruption': False,
            'target_flow': 'none',
            'confidence': 0.1,
            'reasoning': "No clear interruption patterns detected",
            'should_preserve_state': True,
            'suggested_response': None
        }

    async def _llm_based_interruption_detection(self, message: str, current_flow: str, conversation_history: list = None) -> dict:
        """Advanced LLM-based flow interruption detection."""
        try:
            # Build context
            context = ""
            if conversation_history:
                recent_messages = conversation_history[-3:] if len(conversation_history) > 3 else conversation_history
                context = "Recent conversation:\n"
                for msg in recent_messages:
                    role = msg.get('role', 'unknown') if isinstance(msg, dict) else getattr(msg, 'role', 'unknown')
                    content = msg.get('content', '') if isinstance(msg, dict) else getattr(msg, 'content', '')
                    context += f"{role}: {content}\n"
            
            prompt = f"""You are an expert at detecting user intent in customer service conversations.

Current Flow: {current_flow}
User Message: "{message}"

{context}

Analyze if the user wants to:
1. Continue the current {current_flow} operation
2. Switch to a different operation (select/update/delete/insert)
3. Cancel/stop everything

Consider:
- Explicit action words (show, update, delete, add, etc.)
- Context from conversation history
- Whether user is providing information for current operation vs starting new one
- Ambiguous cases where user might want to search for customer vs select customer for update

Respond with ONLY a JSON object:
{{
    "is_interruption": true/false,
    "target_flow": "select|update|delete|insert|none",
    "confidence": 0.0-1.0,
    "reasoning": "brief explanation",
    "should_preserve_state": true/false,
    "suggested_response": "appropriate response or null"
}}

Examples:
- Current: update, User: "show me customers" → {{"is_interruption": true, "target_flow": "select", "confidence": 0.9, "reasoning": "explicit select request", "should_preserve_state": false, "suggested_response": "Switching to show customers. What would you like to search for?"}}
- Current: update, User: "CUS-000123" → {{"is_interruption": false, "target_flow": "update", "confidence": 0.8, "reasoning": "providing customer ID for update", "should_preserve_state": true, "suggested_response": null}}
- Current: select, User: "update that customer" → {{"is_interruption": true, "target_flow": "update", "confidence": 0.9, "reasoning": "explicit update request", "should_preserve_state": false, "suggested_response": "Switching to update operation. Which customer would you like to update?"}}"""

            response = await self.llm_service.chat([
                {"role": "system", "content": "You are an intent detection expert. Respond only with valid JSON."},
                {"role": "user", "content": prompt}
            ])
            
            # Parse LLM response
            import json
            result = json.loads(response.strip())
            
            # Validate result structure
            required_keys = ['is_interruption', 'target_flow', 'confidence', 'reasoning', 'should_preserve_state', 'suggested_response']
            if all(key in result for key in required_keys):
                return result
            else:
                logger.warning(f"[FlowInterruptionHandler] Invalid LLM response structure: {result}")
                return self._pattern_based_interruption_detection(message, current_flow)
                
        except json.JSONDecodeError as e:
            logger.warning(f"[FlowInterruptionHandler] Failed to parse LLM response as JSON: {e}")
            return self._pattern_based_interruption_detection(message, current_flow)
        except Exception as e:
            logger.error(f"[FlowInterruptionHandler] LLM detection error: {e}")
            return self._pattern_based_interruption_detection(message, current_flow)

    def _get_flow_guidance(self, flow: str) -> str:
        """Get guidance message for switching to a flow."""
        guidance = {
            'select': "What would you like to search for?",
            'update': "Which customer would you like to update?",
            'delete': "Which customer would you like to delete?",
            'insert': "What customer information would you like to add?"
        }
        return guidance.get(flow, "How can I help you?")

    def should_clear_state(self, current_flow: str, target_flow: str) -> bool:
        """Determine if state should be cleared when switching flows."""
        # Clear state when switching to different flow types
        if current_flow != target_flow:
            return True
        return False

    def get_state_preservation_advice(self, current_flow: str, target_flow: str) -> dict:
        """Get advice on what state to preserve when switching flows."""
        if current_flow == target_flow:
            return {
                'preserve_all': True,
                'reason': "Same flow, preserve all state"
            }
        
        # Preserve customer details when switching between update/delete
        if current_flow in ['update', 'delete'] and target_flow in ['update', 'delete']:
            return {
                'preserve_all': False,
                'preserve_customer_details': True,
                'reason': "Switching between update/delete, preserve customer info"
            }
        
        # Clear everything when switching to select/insert
        if target_flow in ['select', 'insert']:
            return {
                'preserve_all': False,
                'reason': "Switching to select/insert, clear all state"
            }
        
        return {
            'preserve_all': False,
            'reason': "Different flows, clear state"
        }

# Global instance
flow_interruption_handler = FlowInterruptionHandler()
