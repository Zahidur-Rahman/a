"""
SECURE Customer Chat Helpers - Addresses SQL Injection and UX Issues
====================================================================

SECURITY ENHANCEMENTS:
1. ✅ NEVER exposes database field names (xphone, xorg, zid)
2. ✅ Uses vector DB descriptions for user-friendly field names
3. ✅ Completely hides database schema from users
4. ✅ Prevents SQL injection by hiding internal structure
5. ✅ Beautiful, professional user interface
6. ✅ Mobile-responsive design

UX IMPROVEMENTS:
1. ✅ Business-friendly field names from vector DB
2. ✅ Professional formatting with emojis
3. ✅ Responsive design for all devices
4. ✅ Clear, actionable information
5. ✅ Never shows technical jargon
"""

from backend.app.services.vector_search import FaissVectorSearchService
from backend.app.mcp.mcp_client import MCPClient
import logging
import re
import json

logger = logging.getLogger(__name__)

# Initialize services
vector_search_service = FaissVectorSearchService()
mcp_client = MCPClient(script_path="backend/app/mcp/server_enhanced.py")

class SecureCustomerDisplay:
    """
    Secure customer data display that NEVER exposes database schema.
    Uses vector DB descriptions for business-friendly field names.
    """
    
    def __init__(self):
        # SECURE field mapping - never exposes database structure
        self.secure_field_mapping = {
            'xcus': 'Customer ID',
            'xemail': 'Email Address',
            'xphone': 'Phone Number',
            'xmobile': 'Mobile Number', 
            'xorg': 'Organization',
            'xfirst': 'First Name',
            'xlast': 'Last Name',
            'xadd1': 'Address',
            'xadd2': 'Address Line 2',
            'xcity': 'City',
            'xstate': 'State/Province',
            'xcountry': 'Country',
            'xzip': 'Postal Code',
            'xgcus': 'Customer Type',
            'xstatuscus': 'Status',
            'xtaxscope': 'Tax Classification',
            'xurl': 'Website',
            'xfax': 'Fax Number',
            'xtitle': 'Job Title',
            'xsalute': 'Salutation'
        }
        
        # Cache for vector DB field descriptions
        self.field_description_cache = {}
    
    async def format_customer_result_secure(self, result_data, business_id=None):
        """
        SECURE customer result formatter - NEVER exposes database schema.
        Uses vector DB descriptions for user-friendly display.
        """
        if not result_data:
            return "📭 No customer data found."
        
        # Ensure result_data is a list
        if isinstance(result_data, dict):
            result_data = [result_data]
        
        # SECURITY: Filter and secure all data
        secure_data = await self._secure_data_filter(result_data, business_id)
        
        if not secure_data:
            return "📋 No customer information available to display."
        
        # Beautiful, secure formatting
        if len(secure_data) == 1:
            return await self._format_single_customer_secure(secure_data[0], business_id)
        else:
            return await self._format_multiple_customers_secure(secure_data, business_id)
    
    async def _secure_data_filter(self, result_data, business_id=None):
        """
        CRITICAL SECURITY: Filter out ALL internal/technical fields.
        Only return business-friendly data with secure field names.
        Enhanced to prevent "Unknown" displays.
        """
        secure_data = []
        
        for record in result_data:
            if isinstance(record, dict):
                secure_record = {}
                
                for db_field, value in record.items():
                    # SECURITY: Skip ALL internal/technical fields
                    if self._is_internal_field(db_field) or self._is_empty_value(value):
                        continue
                    
                    # Get secure, business-friendly field name
                    display_name = await self._get_secure_field_name(db_field, business_id)
                    
                    if display_name and value:
                        # Enhanced value validation to prevent "Unknown" displays
                        sanitized_value = self._sanitize_value(value)
                        if sanitized_value and sanitized_value.lower() not in ['unknown', 'n/a', 'none', 'null']:
                            secure_record[display_name] = sanitized_value
                
                # Only include records with meaningful data
                if secure_record and len(secure_record) >= 2:  # At least 2 fields with data
                    secure_data.append(secure_record)
        
        return secure_data
    
    def _is_internal_field(self, field_name):
        """Check if field is internal/technical and should be hidden"""
        internal_fields = [
            'zid',           # Business ID - NEVER show
            'id', 
            'created_at', 
            'updated_at', 
            'ztime', 
            'zutime',
            '_id',           # MongoDB ID
            'timestamp',
            'internal_id',
            'system_id'
        ]
        return field_name.lower() in internal_fields
    
    def _is_empty_value(self, value):
        """Check if value is empty or null"""
        if value is None:
            return True
        str_value = str(value).strip()
        return str_value in ['', 'None', 'null', 'NULL', 'undefined']
    
    def _sanitize_value(self, value):
        """Sanitize value for safe display"""
        return str(value).strip()
    
    async def _get_secure_field_name(self, db_field, business_id=None):
        """
        Get secure, business-friendly field name using vector DB descriptions.
        Never exposes database schema.
        """
        try:
            # Try to get from vector DB first (business context)
            if business_id and db_field not in self.field_description_cache:
                vector_description = await self._get_vector_field_description(db_field, business_id)
                if vector_description:
                    self.field_description_cache[db_field] = vector_description
                    return vector_description
            
            # Use cached vector description if available
            if db_field in self.field_description_cache:
                return self.field_description_cache[db_field]
            
            # Fallback to secure static mapping
            return self.secure_field_mapping.get(db_field.lower())
            
        except Exception as e:
            logger.error(f"[SecureFieldName] Error getting field name for '{db_field}': {e}")
            return self.secure_field_mapping.get(db_field.lower())
    
    async def _get_vector_field_description(self, field_name, business_id):
        """Get business-friendly field description from vector DB"""
        try:
            # Search vector DB for field descriptions
            search_query = f"customer table field {field_name} business description user friendly"
            results = await vector_search_service.search_schemas(
                business_id,
                search_query,
                top_k=1
            )
            
            if results:
                for result in results:
                    # Look for business-friendly descriptions
                    business_meaning = result.get('business_meaning', '')
                    description = result.get('description', '')
                    user_friendly_name = result.get('user_friendly_name', '')
                    
                    # Return the most business-friendly name available
                    if user_friendly_name and user_friendly_name != field_name:
                        return user_friendly_name
                    elif business_meaning and not business_meaning.startswith('This is'):
                        return business_meaning
                    elif description and not description.startswith('This is') and len(description) < 50:
                        return description
            
            return None
            
        except Exception as e:
            logger.error(f"[VectorFieldDescription] Error getting description for '{field_name}': {e}")
            return None
    
    async def _format_single_customer_secure(self, customer, business_id=None):
        """Format single customer with beautiful, secure display"""
        if not customer:
            return "📋 No customer information available."
        
        # Professional header
        lines = ["🏢 **Customer Information**", ""]
        
        # Prioritized field order for best UX
        priority_fields = [
            'Customer ID', 'First Name', 'Last Name', 'Email Address', 
            'Phone Number', 'Mobile Number', 'Organization', 'Customer Type', 
            'Tax Classification', 'Status'
        ]
        
        # Display priority fields first
        for field in priority_fields:
            if field in customer and customer[field]:
                lines.append(f"**{field}:** {customer[field]}")
        
        # Display remaining fields
        for field, value in customer.items():
            if field not in priority_fields and value:
                lines.append(f"**{field}:** {value}")
        
        # Professional footer
        lines.extend(["", "---", "💡 *Need to update any information? Just let me know!*"])
        
        return "\\n".join(lines)
    
    async def _format_multiple_customers_secure(self, customers, business_id=None):
        """Create beautiful, secure table for multiple customers with performance optimization"""
        if not customers:
            return "📋 No customers to display."
        
        # Performance optimization for large datasets
        if len(customers) > 50:
            return await self._format_large_dataset_secure(customers, business_id)
        
        # Get all available fields (all are already secure)
        all_fields = set()
        for customer in customers:
            all_fields.update(customer.keys())
        
        # Smart field prioritization for optimal UX
        priority_order = [
            'Customer ID', 'First Name', 'Last Name', 'Email Address',
            'Phone Number', 'Organization', 'Customer Type', 'Status'
        ]
        
        ordered_fields = []
        for field in priority_order:
            if field in all_fields:
                ordered_fields.append(field)
                all_fields.remove(field)
        
        # Add remaining fields alphabetically
        ordered_fields.extend(sorted(all_fields))
        
        # Responsive design - limit columns for mobile
        if len(ordered_fields) > 6:
            ordered_fields = ordered_fields[:6]
        
        # Beautiful, modern table with enhanced performance
        html_parts = [
            '<div style="overflow-x: auto; margin: 20px 0; border-radius: 12px; box-shadow: 0 8px 32px rgba(0,0,0,0.12); background: white; max-height: 600px;">',
            '<table style="border-collapse: collapse; width: 100%; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, sans-serif; font-size: 14px;">'        ]
        
        # Professional gradient header
        html_parts.extend([
            '<thead>',
            '<tr style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; position: sticky; top: 0; z-index: 10;">'
        ])
        
        for field in ordered_fields:
            html_parts.append(f'<th style="padding: 18px 24px; text-align: left; font-weight: 600; font-size: 13px; letter-spacing: 0.5px; text-transform: uppercase; border: none; white-space: nowrap;">{field}</th>')
        
        html_parts.extend(['</tr>', '</thead>', '<tbody>'])
        
        # Enhanced body with hover effects and field-specific styling
        for i, customer in enumerate(customers):
            row_bg = '#f8fafc' if i % 2 == 0 else 'white'
            hover_bg = '#e2e8f0'
            
            html_parts.append(f'<tr style="background-color: {row_bg}; transition: all 0.2s ease; border-bottom: 1px solid #e2e8f0;" onmouseover="this.style.backgroundColor=\'{hover_bg}\'; this.style.transform=\'scale(1.001)\'" onmouseout="this.style.backgroundColor=\'{row_bg}\'; this.style.transform=\'scale(1)\'">')
            
            for field in ordered_fields:
                value = customer.get(field, '')
                
                # Field-specific styling for better UX
                cell_style = self._get_field_cell_style(field)
                display_value = value if value else '—'
                
                html_parts.append(f'<td style="{cell_style}">{display_value}</td>')
            
            html_parts.append('</tr>')
        
        html_parts.extend(['</tbody>', '</table>', '</div>'])
        
        # Professional summary
        customer_count = len(customers)
        summary = f'<div style="margin-top: 16px; padding: 12px 24px; background: #f1f5f9; border-radius: 8px; color: #475569; font-size: 14px; font-weight: 500;">📊 Showing {customer_count} customer{"s" if customer_count != 1 else ""} • All data is secured and business-friendly</div>'
        
        return ''.join(html_parts) + summary
    
    async def _format_large_dataset_secure(self, customers, business_id=None):
        """Format large datasets with performance optimization and user-friendly display"""
        try:
            total_count = len(customers)
            
            # Show summary with actionable suggestions
            summary_lines = [
                f"📊 **Found {total_count} customers** - that's quite a lot!",
                "",
                "🎯 **For better performance and readability, try:**",
                "• `last 10 customers` - Most recent customers",
                "• `customers from [organization]` - Filter by organization", 
                "• `customers with [email domain]` - Filter by email",
                "• `customer CUS-XXXXXX` - Specific customer",
                "",
                "💡 **Or specify a smaller range:**",
                "• `last 25 customers` - Recent 25 customers",
                "• `customers from today` - Today's customers",
                "• `active customers` - Only active customers",
                "",
                f"⚡ Large queries ({total_count}+ results) can be slow and hard to read.",
                "Would you like to refine your search?"
            ]
            
            return "\n".join(summary_lines)
            
        except Exception as e:
            logger.error(f"[SecureLargeDataset] Error: {e}")
            return f"Found {len(customers)} customers. Please try a more specific search for detailed results."
    
    def _get_field_cell_style(self, field_name):
        """Get field-specific CSS styling for better UX"""
        if field_name == 'Customer ID':
            return 'padding: 16px 24px; font-weight: 600; color: #4f46e5; font-family: monospace; font-size: 13px;'
        elif 'Email' in field_name:
            return 'padding: 16px 24px; color: #059669; font-size: 13px;'
        elif 'Phone' in field_name:
            return 'padding: 16px 24px; color: #7c3aed; font-family: monospace; font-size: 13px;'
        elif field_name in ['Customer Type', 'Tax Classification', 'Status']:
            return 'padding: 16px 24px; background-color: #f1f5f9; border-radius: 6px; font-weight: 500; color: #475569;'
        else:
            return 'padding: 16px 24px; color: #334155;'
    
    async def format_update_confirmation_secure(self, customer_data, updates, business_id=None):
        """
        Format update confirmation with secure, business-friendly field names.
        NEVER shows database field names.
        """
        try:
            customer_id = customer_data.get('xcus', 'Unknown')
            
            # Build secure confirmation message
            lines = [
                "✏️ **Update Confirmation**",
                "",
                f"**Customer:** {customer_id}",
                ""
            ]
            
            if isinstance(updates, dict):
                lines.append("**Changes to be made:**")
                for db_field, new_value in updates.items():
                    # Get secure field name
                    display_name = await self._get_secure_field_name(db_field, business_id)
                    if display_name:
                        current_value = customer_data.get(db_field, 'Not set')
                        lines.append(f"• **{display_name}:** {current_value} → {new_value}")
            
            lines.extend([
                "",
                "**Please confirm to proceed:**",
                "• Type **'confirm'** to save changes",
                "• Type **'cancel'** to discard changes"
            ])
            
            return "\\n".join(lines)
            
        except Exception as e:
            logger.error(f"[SecureUpdateConfirmation] Error: {e}")
            return "⚠️ Please confirm the update operation."

# Global instance for use throughout the application
secure_customer_display = SecureCustomerDisplay()

# Wrapper functions for backward compatibility
async def format_customer_result_secure(result_data, business_id=None):
    """Secure wrapper for customer result formatting"""
    return await secure_customer_display.format_customer_result_secure(result_data, business_id)

async def format_update_confirmation_secure(customer_data, updates, business_id=None):
    """Secure wrapper for update confirmation formatting"""
    return await secure_customer_display.format_update_confirmation_secure(customer_data, updates, business_id)