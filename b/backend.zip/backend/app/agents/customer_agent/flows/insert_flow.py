"""
OPTIMIZED DYNAMIC INSERT FLOW - Streamlined customer creation with:
- LLM-driven immediate data detection and validation
- Dynamic decision making throughout the pipeline
- Intelligent progressive data collection
- Enhanced performance and maintainability
- Secure field mapping and validation
"""
from backend.app.models.chat_graph_state import ChatGraphState
from backend.app.services.mistral_llm_service import MistralLLMService
from backend.app.services.vector_search import FaissVectorSearchService
from backend.app.mcp.mcp_client import MCPClient
from backend.app.agents.customer_agent.customer_chat_helpers import (
    get_next_customer_id, extract_customer_fields_from_message, format_customer_result,
    get_customer_schema_context_for_flow
)
from backend.app.agents.customer_agent.negative_vibe_detector import negative_vibe_detector
from backend.app.agents.customer_agent.flow_interruption_handler import flow_interruption_handler
import logging
import json
import re
import importlib

logger = logging.getLogger(__name__)

# Initialize services
llm_service = MistralLLMService()
vector_search_service = FaissVectorSearchService()
mcp_client = MCPClient(script_path="backend/app/mcp/server_enhanced.py")

def is_valid_email(email):
    """Validate email format."""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None

def is_valid_phone(phone):
    """Validate phone number (11 digits)."""
    if not phone or not phone.isdigit():
        return False
    return len(phone) in [11]

def extract_insert_fields_from_sql(sql):
    """Extract field names and values from INSERT SQL statement."""
    pattern = r'INSERT\s+INTO\s+\w+\s*\(([^)]+)\)\s*VALUES\s*\(([^)]+)\)'
    match = re.search(pattern, sql, re.IGNORECASE | re.DOTALL)
    
    if not match:
        return {}
    
    columns_str = match.group(1).strip()
    values_str = match.group(2).strip()
    
    columns = parse_sql_list(columns_str)
    values = parse_sql_list(values_str)
    
    fields = {}
    for i, col in enumerate(columns):
        if i < len(values):
            fields[col.strip()] = values[i].strip()
    
    return fields

def parse_sql_list(sql_list_str):
    """Parse SQL list handling commas inside quotes."""
    parts = []
    current = ""
    in_quotes = False
    quote_char = None
    
    for char in sql_list_str:
        if char in ["'", '"'] and not in_quotes:
            in_quotes = True
            quote_char = char
            current += char
        elif char == quote_char and in_quotes:
            in_quotes = False
            quote_char = None
            current += char
        elif char == ',' and not in_quotes:
            parts.append(current.strip())
            current = ""
        else:
            current += char
    
    if current.strip():
        parts.append(current.strip())
    
    return parts

async def generate_insert_sql_node(context):
    """🚀 DYNAMIC INSERT FLOW - Ultra-intelligent customer creation with immediate data detection"""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    logger.info(f"[🚀DynamicInsertFlow] Starting DYNAMIC INSERT flow for: {context.message}")
    
    context.current_flow = "insert"
    context.original_query = getattr(context, 'original_query', context.message)
    
    # Enhanced flow control with context awareness
    flow_control = await _check_flow_control(context)
    if flow_control['should_exit']:
        return _format_response(flow_control['response'])
    
    # Get enhanced schema context
    if not hasattr(context, 'schema_context') or not context.schema_context:
        context.schema_context = await get_customer_schema_context_for_flow(context.business_id, "insert")
    
    # Check for immediate complete data in single message
    immediate_data_result = await _check_immediate_complete_data(context)
    
    if immediate_data_result['is_complete']:
        logger.info(f"[🚀DynamicInsertFlow] IMMEDIATE COMPLETE DATA detected")
        context.collected_field_values = immediate_data_result['field_data']
        context.duplicate_check_done = False
        return await _proceed_with_complete_data(context, immediate_data_result)
    
    # Progressive data collection for incomplete data
    if not hasattr(context, 'collected_field_values') or not context.collected_field_values:
        context.collected_field_values = {}
    
    data_analysis = await _analyze_data_completeness(context)
    
    if not data_analysis['is_complete']:
        logger.info("[🚀DynamicInsertFlow] Customer data incomplete, using intelligent collection")
        
        new_fields = await _extract_fields_enhanced(context)
        context.collected_field_values.update(new_fields)
        
        context.response = await _generate_collection_prompt(context, data_analysis)
        context.pause_reason = "intelligent_data_collection"
        context.insert_phase = "progressive_collection"
        context.next = "PauseNode"
        return context.model_dump()
    
    logger.info("[🚀DynamicInsertFlow] All data collected, proceeding with creation")
    return await _proceed_with_complete_data(context, data_analysis)

async def validate_insert_fields_node(context):
    """Enhanced validation for customer insert operations with reactive error handling."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    logger.info(f"[ReactiveInsertValidation] Validating fields for SQL: {context.sql}")
    
    try:
        interruption_check = await _check_flow_interruption(context)
        if interruption_check['is_interrupted']:
            return interruption_check['response']
        
        negative_vibe = await negative_vibe_detector.detect_negative_vibe(
            context.message, context.conversation_history
        )
        
        if negative_vibe['is_negative']:
            logger.info("[ReactiveInsertValidation] Negative vibe detected, canceling flow")
            context = _clear_flow_state(context)
            context.response = negative_vibe['suggested_response']
            context.next = "CustomerResponse"
            return context.model_dump()
        
        required_fields = ['xemail', 'xphone', 'xgcus', 'xorg']
        sql_fields = extract_insert_fields_from_sql(context.sql)
        logger.info(f"[ReactiveInsertValidation] Extracted fields: {sql_fields}")
        
        validation_result = await _validate_fields(sql_fields, required_fields)
        
        if not hasattr(context, 'collected_field_values') or context.collected_field_values is None:
            context.collected_field_values = {}
        
        for field, value in sql_fields.items():
            if field in required_fields:
                clean_value = value.strip("'\"")
                if clean_value:
                    context.collected_field_values[field] = clean_value
        
        if validation_result['missing_fields'] or validation_result['validation_errors']:
            context.incomplete_sql = context.sql
            context.missing_mandatory_fields = validation_result['missing_fields']
            
            progress_message = await _generate_progress_message(
                context, required_fields, validation_result
            )
            
            context.pause_message = progress_message
            context.pause_reason = "missing_mandatory_fields"
            context.next = "PauseNode"
            
            logger.info(f"[ReactiveInsertValidation] Missing fields: {validation_result['missing_fields']}")
            return context.model_dump()
        
        logger.info("[ReactiveInsertValidation] All mandatory fields validated successfully")
        context.next = "CheckDuplicateCustomer"
        return context.model_dump()
        
    except Exception as e:
        logger.error(f"[ReactiveInsertValidation] Error during validation: {e}")
        context.response = "Error validating customer information. Please try again."
        context.next = "CustomerResponse"
        return context.model_dump()

async def collect_missing_fields_node(context):
    """📝 DYNAMIC FIELD COLLECTION - Enhanced collection with intelligent processing"""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    logger.info(f"[📝DynamicFieldCollection] Processing: {context.message}")
    
    try:
        flow_control = await _check_flow_control(context)
        if flow_control['should_exit']:
            return _format_response(flow_control['response'])
        
        if not hasattr(context, 'collected_field_values') or context.collected_field_values is None:
            context.collected_field_values = {}
        
        extracted_fields = await _extract_fields_enhanced(context)
        logger.info(f"[📝DynamicFieldCollection] Extracted from message: {extracted_fields}")
        
        fields_updated = False
        for field, value in extracted_fields.items():
            if value and value.strip():
                old_value = context.collected_field_values.get(field)
                context.collected_field_values[field] = value.strip()
                if old_value != value.strip():
                    fields_updated = True
                    logger.info(f"[📝DynamicFieldCollection] Updated {field}: {old_value} -> {value.strip()}")
        
        data_analysis = await _analyze_data_completeness(context)
        
        if data_analysis['is_complete']:
            logger.info("[📝DynamicFieldCollection] All mandatory fields collected, proceeding")
            context.duplicate_check_done = False
            context.insert_phase = "creation_pipeline"
            return await _proceed_with_complete_data(context, data_analysis)
        else:
            logger.info(f"[📝DynamicFieldCollection] Still missing: {data_analysis['missing_fields']}")
            
            if fields_updated:
                context.response = await _generate_collection_prompt(context, data_analysis)
            else:
                context.response = await _generate_clarification_prompt(context, data_analysis)
            
            context.pause_reason = "intelligent_data_collection"
            context.insert_phase = "progressive_collection"
            context.next = "PauseNode"
            return context.model_dump()
        
    except Exception as e:
        logger.error(f"[📝DynamicFieldCollection] Error: {e}")
        context.response = "Error processing the information. Please try again."
        context.next = "CustomerResponse"
        return context.model_dump()

async def generate_customer_id_node(context):
    """Enhanced customer ID generation node with better error handling."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    logger.info("[CustomerIDGeneration] Starting customer ID generation")
    
    try:
        from backend.app.agents.customer_agent import customer_chat_helpers
        importlib.reload(customer_chat_helpers)
        
        next_customer_id = await customer_chat_helpers.get_next_customer_id(context.business_id)
        logger.info(f"[CustomerIDGeneration] Generated ID: {next_customer_id}")
        
        if context.sql and next_customer_id:
            if 'xcus' not in context.sql.lower():
                insert_pattern = r'INSERT\s+INTO\s+(\w+)\s*\(([^)]+)\)\s*VALUES\s*\(([^)]+)\)'
                match = re.search(insert_pattern, context.sql, re.IGNORECASE)
                
                if match:
                    table_name = match.group(1)
                    columns = match.group(2).strip()
                    values = match.group(3).strip()
                    
                    new_columns = f"{columns}, xcus"
                    new_values = f"{values}, '{next_customer_id}'"
                    
                    context.sql = f"INSERT INTO {table_name} ({new_columns}) VALUES ({new_values})"
                    logger.info(f"[CustomerIDGeneration] Updated SQL with ID: {context.sql}")
        
        context.next = "ExecuteInsertSQL"
        return context.model_dump()
        
    except Exception as e:
        logger.error(f"[CustomerIDGeneration] Error: {e}")
        context.response = f"Error generating customer ID: {str(e)}"
        context.next = "CustomerResponse"
        return context.model_dump()

async def execute_insert_sql_node(context):
    """Execute customer INSERT SQL operations with enhanced error handling."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    logger.info(f"[ReactiveInsertExecution] Executing: {context.sql}")
    
    try:
        if not context.sql or 'INSERT' not in context.sql.upper():
            context.response = "Invalid SQL statement for customer creation. Please try again."
            context.next = "CustomerResponse"
            return context.model_dump()
        
        result = await mcp_client.execute_query(context.sql, context.business_id)
        
        if isinstance(result, dict) and 'content' in result:
            try:
                parsed = json.loads(result['content'][0]['text'])
                
                if parsed.get('success'):
                    success_message = await _generate_success_message(context, parsed)
                    context.response = success_message
                    context = _clear_flow_state(context)
                    logger.info("[ReactiveInsertExecution] Customer created successfully")
                else:
                    error_msg = parsed.get('error', 'Unknown error occurred')
                    context.response = await _handle_error(error_msg)
                    
            except (json.JSONDecodeError, KeyError, IndexError) as e:
                logger.error(f"[ReactiveInsertExecution] Error parsing result: {e}")
                context.response = "Customer creation completed but couldn't confirm details."
        else:
            context.response = "Customer creation request processed."
            
    except Exception as e:
        logger.error(f"[ReactiveInsertExecution] Execution error: {e}")
        
        error_str = str(e).lower()
        if 'duplicate' in error_str or 'unique' in error_str:
            context.response = (
                "❌ A customer with this email or phone number already exists. "
                "Please check the information and try again."
            )
        elif 'constraint' in error_str or 'foreign key' in error_str:
            context.response = (
                "❌ Invalid customer group or organization specified. "
                "Please check the customer group and organization values."
            )
        else:
            context.response = f"❌ Error creating customer: {str(e)}"
    
    context.next = "CustomerResponse"
    return context.model_dump()

async def check_duplicate_customer_node(context):
    """Check for duplicate customers before insertion."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    logger.info("[DuplicateCheck] Checking for duplicate customers")
    
    try:
        if hasattr(context, 'sql') and context.sql:
            sql_fields = extract_insert_fields_from_sql(context.sql)
        else:
            sql_fields = getattr(context, 'collected_field_values', {})
        
        duplicate_result = await _check_duplicates(context, sql_fields)
        
        if duplicate_result['has_duplicates']:
            context.response = await _generate_duplicate_prompt(context, duplicate_result)
            context.next = "CustomerResponse"
            return context.model_dump()
        
        context.next = "GenerateCustomerID"
        return context.model_dump()
        
    except Exception as e:
        logger.error(f"[DuplicateCheck] Error: {e}")
        context.next = "GenerateCustomerID"
        return context.model_dump()

# --- CORE HELPER FUNCTIONS ---

def _format_response(response_dict):
    """Format response dictionary for consistent output"""
    return response_dict

async def _check_flow_control(context):
    """Enhanced flow control with context awareness"""
    try:
        conversation_context = _build_conversation_context(context)
        
        flow_control_prompt = f"""Analyze user intent in customer creation operations.

CONVERSATION CONTEXT: {conversation_context}
CURRENT MESSAGE: "{context.message}"
OPERATION: Customer INSERT flow

Check for:
1. NEGATIVE SENTIMENT: cancel, stop, nevermind, quit
2. INTENT SWITCHING: update/delete/search customers
3. CONTINUATION: providing field values

Respond with JSON:
{{
    "should_exit": boolean,
    "exit_reason": "negative_sentiment|intent_switch|none",
    "new_intent": "update|delete|select|none",
    "confidence": 0.0-1.0,
    "suggested_response": "response if exiting"
}}"""
        
        response = await llm_service.chat([
            {"role": "system", "content": "Analyze intent. Respond with valid JSON only."},
            {"role": "user", "content": flow_control_prompt}
        ])
        
        try:
            result = _parse_json_response(response)
            logger.info(f"[FlowControl] Analysis: {result}")
            
            if result.get('should_exit', False) and result.get('confidence', 0) > 0.7:
                context = _clear_flow_state(context)
                
                exit_reason = result.get('exit_reason', 'unknown')
                new_intent = result.get('new_intent', 'none')
                
                response_content = result.get('suggested_response', 
                    "Customer creation cancelled." if exit_reason == 'negative_sentiment' 
                    else f"Switching to {new_intent} operation.")
                
                if exit_reason == 'negative_sentiment':
                    context.response = response_content
                    context.next = "CustomerResponse"
                elif exit_reason == 'intent_switch':
                    context = await _handle_intent_switch(context, new_intent, response_content)
                
                return {'should_exit': True, 'response': context.model_dump()}
            
            return {'should_exit': False}
            
        except json.JSONDecodeError as e:
            logger.error(f"[FlowControl] JSON parsing error: {e}")
            return {'should_exit': False}
            
    except Exception as e:
        logger.error(f"[FlowControl] Error: {e}")
        return {'should_exit': False}

def _build_conversation_context(context):
    """Build conversation context for LLM analysis"""
    conversation_context = ""
    if hasattr(context, 'conversation_history') and context.conversation_history:
        recent_messages = context.conversation_history[-4:]
        for i, msg in enumerate(recent_messages):
            role = msg.role if hasattr(msg, 'role') else msg.get('role', 'user')
            content = msg.content if hasattr(msg, 'content') else msg.get('content', '')
            conversation_context += f"{i+1}. {role.upper()}: {content}\n"
    return conversation_context

def _parse_json_response(response: str) -> dict:
    """Parse JSON response from LLM, handling markdown code blocks."""
    response = response.strip()
    
    if response.startswith('```json'):
        response = response[7:]
    elif response.startswith('```'):
        response = response[3:]
    
    if response.endswith('```'):
        response = response[:-3]
    
    response = response.strip()
    
    json_match = re.search(r'\{.*\}', response, re.DOTALL)
    if json_match:
        response = json_match.group(0)
    
    try:
        return json.loads(response)
    except json.JSONDecodeError as e:
        logger.error(f"[JSONParser] Failed to parse: {e}")
        raise

async def _check_immediate_complete_data(context):
    """Check if message contains complete customer data"""
    try:
        field_info = await _get_field_info(context.business_id)
        field_mappings = field_info.get('mappings', {})
        
        complete_data_prompt = f"""Analyze if this message contains COMPLETE customer data.

USER MESSAGE: "{context.message}"
REQUIRED FIELDS: {json.dumps(field_mappings, indent=2)}

Must have ALL mandatory components:
1. Email address (valid format)
2. Phone number (10-15 digits)  
3. Organization name
4. Customer group/type
5. Customer status
6. Tax scope

Respond with JSON:
{{
    "is_complete": boolean,
    "field_data": {{"database_field": "extracted_value"}},
    "confidence": 0.0-1.0,
    "missing_fields": ["list of missing fields"]
}}"""
        
        response = await llm_service.chat([
            {"role": "system", "content": "Analyze complete data. Respond with valid JSON."},
            {"role": "user", "content": complete_data_prompt}
        ])
        
        return _parse_json_response(response)
        
    except Exception as e:
        logger.error(f"[CompleteDataCheck] Error: {e}")
        return {'is_complete': False, 'field_data': {}, 'confidence': 0.0}

async def _get_field_info(business_id):
    """Get field information using vector DB context and LLM."""
    try:
        # Get schema context for the business
        schema_context = await get_customer_schema_context_for_flow(business_id, "insert")
        
        # Extract field information from schema context
        descriptions = {}
        mappings = {}
        
        if schema_context:
            for schema in schema_context:
                for col in schema.get('columns', []):
                    field_name = col.get('name', '')
                    description = col.get('description', '') or col.get('business_meaning', '') or field_name
                    
                    descriptions[field_name] = {
                        'description': description,
                        'type': col.get('type', ''),
                        'is_nullable': col.get('is_nullable', True)
                    }
                    
                    # Use the description as the user-friendly name
                    mappings[field_name] = description
        
        # Fallback for essential fields if not found in schema
        essential_fields = {
            'xemail': 'Email Address',
            'xphone': 'Phone Number',
            'xorg': 'Organization',
            'xgcus': 'Customer Group',
            'xstatuscus': 'Customer Status',
            'xtaxscope': 'Tax Scope'
        }
        
        for field, name in essential_fields.items():
            if field not in mappings:
                mappings[field] = name
            if field not in descriptions:
                descriptions[field] = {'description': name, 'type': 'text', 'is_nullable': False}
        
        return {
            'descriptions': descriptions,
            'mappings': mappings
        }
        
    except Exception as e:
        logger.error(f"[FieldInfo] Error getting field info: {e}")
        # Ultimate fallback
        return {
            'descriptions': {
                'xemail': {'description': 'Email address', 'type': 'text'},
                'xphone': {'description': 'Phone number', 'type': 'text'},
                'xorg': {'description': 'Organization', 'type': 'text'},
                'xgcus': {'description': 'Customer group', 'type': 'text'},
                'xstatuscus': {'description': 'Customer status', 'type': 'text'},
                'xtaxscope': {'description': 'Tax scope', 'type': 'text'}
            },
            'mappings': {
                'xemail': 'Email Address',
                'xphone': 'Phone Number',
                'xorg': 'Organization',
                'xgcus': 'Customer Group',
                'xstatuscus': 'Customer Status',
                'xtaxscope': 'Tax Scope'
            }
        }

async def _proceed_with_complete_data(context, data_result):
    """Proceed with customer creation using complete data"""
    try:
        duplicate_result = await _check_duplicates(context, context.collected_field_values)
        
        if duplicate_result['has_duplicates']:
            context.response = await _generate_duplicate_prompt(context, duplicate_result)
            context.pause_reason = "duplicate_customer_found"
            context.insert_phase = "duplicate_handling"
            context.next = "PauseNode"
            return context.model_dump()
        
        context.duplicate_check_done = True
        context.insert_phase = None
        context.pause_reason = None
        
        return await _generate_final_sql(context)
        
    except Exception as e:
        logger.error(f"[ProceedComplete] Error: {e}")
        context.response = f"Error processing customer data: {str(e)}"
        context.next = "CustomerResponse"
        return context.model_dump()

async def _extract_fields_enhanced(context):
    """Enhanced field extraction using LLM"""
    try:
        field_info = await _get_field_info(context.business_id)
        
        extraction_prompt = f"""Extract customer information from this message.

Message: "{context.message}"
Available Fields: {json.dumps(field_info['mappings'], indent=2)}

Extract if clearly present:
- Email (valid format)
- Phone (10-15 digits)
- Organization name
- Customer group/type
- Status
- Tax scope

Return JSON with database field names:
{{
    "xemail": "email_if_found",
    "xphone": "phone_if_found", 
    "xorg": "organization_if_found",
    "xgcus": "group_if_found",
    "xstatuscus": "status_if_found",
    "xtaxscope": "tax_if_found"
}}

Only include clearly present fields. Return {{}} if none found."""
        
        response = await llm_service.chat([
            {"role": "system", "content": "Extract customer data. Return valid JSON only."},
            {"role": "user", "content": extraction_prompt}
        ])
        
        clean_response = response.strip()
        if clean_response.startswith('```json'):
            clean_response = clean_response[7:-3].strip()
        elif clean_response.startswith('```'):
            clean_response = clean_response[3:-3].strip()
        
        extracted = json.loads(clean_response)
        
        validated_fields = {}
        for field, value in extracted.items():
            if field in ['xemail', 'xphone', 'xorg', 'xgcus', 'xstatuscus', 'xtaxscope'] and value and str(value).strip():
                validated_fields[field] = str(value).strip()
        
        return validated_fields
        
    except Exception as e:
        logger.debug(f"[FieldExtraction] Enhanced extraction failed: {e}")
        return await _extract_fields_basic(context)

async def _extract_fields_basic(context):
    """Basic field extraction fallback"""
    try:
        extracted_fields = extract_customer_fields_from_message(context.message)
        
        email_pattern = r'\b[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}\b'
        phone_pattern = r'\b\d{10,11}\b'
        
        email_match = re.search(email_pattern, context.message)
        phone_match = re.search(phone_pattern, context.message)
        
        if email_match and 'xemail' not in extracted_fields:
            extracted_fields['xemail'] = email_match.group()
            
        if phone_match and 'xphone' not in extracted_fields:
            extracted_fields['xphone'] = phone_match.group()
        
        cleaned_fields = {}
        for field, value in extracted_fields.items():
            clean_value = str(value).strip().strip("'\"")
            if clean_value:
                cleaned_fields[field] = clean_value
        
        return cleaned_fields
        
    except Exception as e:
        logger.error(f"[BasicExtraction] Error: {e}")
        return {}

async def _analyze_data_completeness(context):
    """Analyze customer data completeness"""
    try:
        if not hasattr(context, 'collected_field_values') or not context.collected_field_values:
            context.collected_field_values = {}
        
        current_fields = await _extract_fields_basic(context)
        all_fields = {**context.collected_field_values, **current_fields}
        
        required_fields = ['xemail', 'xphone', 'xorg', 'xgcus', 'xstatuscus', 'xtaxscope']
        
        missing_fields = []
        for field in required_fields:
            if field not in all_fields or not all_fields[field] or not all_fields[field].strip():
                missing_fields.append(field)
        
        field_names = {
            'xemail': 'Email Address',
            'xphone': 'Phone Number', 
            'xorg': 'Organization',
            'xgcus': 'Customer Group',
            'xstatuscus': 'Customer Status',
            'xtaxscope': 'Tax Scope'
        }
        
        suggested_questions = []
        for field in missing_fields:
            field_name = field_names.get(field, field)
            if field == 'xemail':
                suggested_questions.append("What is the customer's email address?")
            elif field == 'xphone':
                suggested_questions.append("What is their phone number?")
            elif field == 'xorg':
                suggested_questions.append("What organization do they belong to?")
            elif field == 'xgcus':
                suggested_questions.append("What customer group should they be assigned?")
            elif field == 'xstatuscus':
                suggested_questions.append("What is the customer's status?")
            elif field == 'xtaxscope':
                suggested_questions.append("What is their tax scope?")
        
        return {
            'is_complete': len(missing_fields) == 0,
            'missing_fields': missing_fields,
            'suggested_questions': suggested_questions,
            'collected_fields': all_fields,
            'confidence': 1.0 - (len(missing_fields) / len(required_fields))
        }
        
    except Exception as e:
        logger.error(f"[DataAnalysis] Error: {e}")
        return {
            'is_complete': False,
            'missing_fields': ['xemail', 'xphone', 'xorg', 'xgcus', 'xstatuscus', 'xtaxscope'],
            'suggested_questions': ['Please provide complete customer information'],
            'collected_fields': {},
            'confidence': 0.0
        }

async def _generate_collection_prompt(context, data_analysis):
    """Generate intelligent data collection prompt"""
    try:
        field_info = await _get_field_info(context.business_id)
        collected_fields = data_analysis.get('collected_fields', {})
        missing_fields = data_analysis.get('missing_fields', [])
        
        progress_items = []
        for field in ['xemail', 'xphone', 'xorg', 'xgcus', 'xstatuscus', 'xtaxscope']:
            field_name = field_info['mappings'].get(field, field)
            if field in collected_fields and collected_fields[field]:
                progress_items.append(f"✅ **{field_name}**: {collected_fields[field]}")
            else:
                progress_items.append(f"❌ **{field_name}**: Missing")
        
        examples = []
        if 'xemail' in missing_fields:
            examples.append("• `Email: john@company.com`")
        if 'xphone' in missing_fields:
            examples.append("• `Phone: 1234567890`")
        if 'xorg' in missing_fields:
            examples.append("• `Organization: ABC Corporation`")
        
        prompt_parts = [
            "📝 **Dynamic Customer Creation - Smart Data Collection**",
            "",
            "**Current Progress:**"
        ]
        prompt_parts.extend(progress_items)
        
        if missing_fields:
            prompt_parts.extend([
                "",
                "🎯 **You can provide the missing information:**",
                ""
            ])
            prompt_parts.extend(examples[:3])
            
            prompt_parts.extend([
                "",
                "**Multiple fields together:**",
                "• `Email: john@company.com, Phone: 1234567890, Organization: ABC Corp`",
                "",
                "**Natural language:**",
                "• `The customer's email is john@company.com and phone is 1234567890`",
                "",
                "Please provide the missing information:"
            ])
        
        return "\n".join(prompt_parts)
        
    except Exception as e:
        logger.error(f"[CollectionPrompt] Error: {e}")
        return "Please provide the remaining customer information to continue."

async def _generate_clarification_prompt(context, data_analysis):
    """Generate clarification prompt when no new fields were extracted"""
    try:
        missing_fields = data_analysis.get('missing_fields', [])
        field_info = await _get_field_info(context.business_id)
        
        missing_names = [field_info['mappings'].get(field, field) for field in missing_fields]
        
        prompt_parts = [
            "🔍 **I need more specific information**",
            "",
            f"I couldn't extract the required fields from your message. Still missing: **{', '.join(missing_names)}**",
            "",
            "📝 **Please provide in one of these formats:**",
            "• `Email: john@company.com`",
            "• `Phone: 1234567890`", 
            "• `Organization: ABC Corporation`",
            "• `Customer Group: Premium`",
            "• `Status: Active`",
            "• `Tax Scope: Domestic`",
            "",
            "📊 **Or all together:**",
            "• `Email: john@company.com, Phone: 1234567890, Organization: ABC Corp, Group: Premium, Status: Active, Tax: Domestic`"
        ]
        
        return "\n".join(prompt_parts)
        
    except Exception as e:
        logger.error(f"[ClarificationPrompt] Error: {e}")
        return "Please provide the missing customer information in a clear format."

async def _validate_fields(sql_fields, required_fields):
    """Enhanced validation of customer fields"""
    try:
        missing_fields = []
        validation_errors = []
        
        for field in required_fields:
            if field not in sql_fields or not sql_fields[field] or sql_fields[field].strip("'\"") == '':
                missing_fields.append(field)
        
        for field, value in sql_fields.items():
            clean_value = value.strip("'\"")
            
            if field == 'xemail' and clean_value:
                if not is_valid_email(clean_value):
                    validation_errors.append(f"Email format is invalid: {clean_value}")
                elif len(clean_value) > 100:
                    validation_errors.append(f"Email is too long (max 100 characters): {clean_value}")
                    
            elif field == 'xphone' and clean_value:
                if not is_valid_phone(clean_value):
                    validation_errors.append(f"Phone number must be 10 or 11 digits: {clean_value}")
                elif not clean_value.isdigit():
                    validation_errors.append(f"Phone number should contain only digits: {clean_value}")
                    
            elif field == 'xorg' and clean_value:
                if len(clean_value) > 200:
                    validation_errors.append(f"Organization name is too long (max 200 characters): {clean_value}")
                    
            elif field == 'xgcus' and clean_value:
                if len(clean_value) > 50:
                    validation_errors.append(f"Customer group is too long (max 50 characters): {clean_value}")
        
        return {
            'missing_fields': missing_fields,
            'validation_errors': validation_errors,
            'is_valid': len(missing_fields) == 0 and len(validation_errors) == 0
        }
        
    except Exception as e:
        logger.error(f"[FieldValidation] Error: {e}")
        return {
            'missing_fields': required_fields,
            'validation_errors': ['Error during validation'],
            'is_valid': False
        }

async def _generate_progress_message(context, required_fields, validation_result):
    """Generate progress message for validation"""
    try:
        progress_items = []
        
        field_names = {
            'xemail': 'Email Address',
            'xphone': 'Phone Number',
            'xgcus': 'Customer Group',
            'xorg': 'Organization'
        }
        
        for field in required_fields:
            field_name = field_names.get(field, field)
            
            if hasattr(context, 'collected_field_values') and field in context.collected_field_values:
                progress_items.append(f"✅ {field_name}: {context.collected_field_values[field]}")
            else:
                progress_items.append(f"❌ {field_name}: Missing")
        
        progress_message = "**Customer Creation Progress:**\n" + "\n".join(progress_items)
        
        if validation_result.get('validation_errors'):
            error_message = "\n\n**Validation Errors:**\n" + "\n".join([f"• {error}" for error in validation_result['validation_errors']])
            progress_message += error_message
        
        if validation_result.get('missing_fields'):
            missing_field_names = [field_names.get(field, field) for field in validation_result['missing_fields']]
            progress_message += f"\n\nPlease provide the missing information: {', '.join(missing_field_names)}"
        
        return progress_message
        
    except Exception as e:
        logger.error(f"[ProgressMessage] Error: {e}")
        return "Please provide the required customer information to continue."

async def _generate_final_sql(context):
    """Generate final INSERT SQL with enhanced validation"""
    try:
        collected_fields = getattr(context, 'collected_field_values', {})
        
        if not collected_fields:
            context.response = "No customer data collected. Please provide customer information."
            context.next = "CustomerResponse"
            return context.model_dump()
        
        required_fields = ['xemail', 'xphone', 'xorg', 'xgcus', 'xstatuscus', 'xtaxscope']
        missing_fields = [field for field in required_fields 
                         if field not in collected_fields or not collected_fields[field] or not collected_fields[field].strip()]
        
        if missing_fields:
            logger.warning(f"[FinalSQL] Missing fields: {missing_fields}")
            data_analysis = await _analyze_data_completeness(context)
            context.response = await _generate_collection_prompt(context, data_analysis)
            context.pause_reason = "intelligent_data_collection"
            context.insert_phase = "progressive_collection"
            context.next = "PauseNode"
            return context.model_dump()
        
        columns = ['zid']
        values = [str(context.business_id)]
        
        for field in required_fields:
            if field in collected_fields:
                columns.append(field)
                escaped_value = collected_fields[field].replace("'", "''")
                values.append(f"'{escaped_value}'")
        
        for field, value in collected_fields.items():
            if field not in required_fields and field not in columns:
                columns.append(field)
                escaped_value = value.replace("'", "''")
                values.append(f"'{escaped_value}'")
        
        columns_str = ', '.join(columns)
        values_str = ', '.join(values)
        context.sql = f"INSERT INTO cacus ({columns_str}) VALUES ({values_str})"
        
        logger.info(f"[FinalSQL] Generated: {context.sql}")
        
        context.insert_phase = None
        context.pause_reason = None
        context.next = "ValidateInsertFields"
        return context.model_dump()
        
    except Exception as e:
        logger.error(f"[FinalSQL] Error: {e}")
        context.response = f"Error generating customer creation SQL: {str(e)}"
        context.next = "CustomerResponse"
        return context.model_dump()

async def _check_duplicates(context, sql_fields):
    """Check for duplicate customers"""
    try:
        email = sql_fields.get('xemail', '').strip("'\"")
        phone = sql_fields.get('xphone', '').strip("'\"")
        
        if not email and not phone:
            return {'has_duplicates': False, 'duplicates': []}
        
        conditions = []
        if email:
            conditions.append(f"xemail = '{email}'")
        if phone:
            conditions.append(f"xphone = '{phone}'")
        
        duplicate_check_sql = f"""
        SELECT xcus, xemail, xphone, xorg, xfirst, xlast 
        FROM cacus 
        WHERE zid = {context.business_id} 
        AND ({' OR '.join(conditions)})
        """
        
        result = await mcp_client.execute_query(duplicate_check_sql, context.business_id)
        
        if isinstance(result, dict) and 'content' in result:
            try:
                parsed = json.loads(result['content'][0]['text'])
                duplicates = parsed.get('results', [])
                
                return {
                    'has_duplicates': len(duplicates) > 0,
                    'duplicates': duplicates,
                    'match_types': _analyze_duplicate_matches(duplicates, email, phone)
                }
            except (json.JSONDecodeError, KeyError, IndexError):
                pass
        
        return {'has_duplicates': False, 'duplicates': []}
        
    except Exception as e:
        logger.error(f"[DuplicateCheck] Error: {e}")
        return {'has_duplicates': False, 'duplicates': []}

def _analyze_duplicate_matches(duplicates, email, phone):
    """Analyze what type of duplicates were found"""
    match_types = []
    for dup in duplicates:
        if email and dup.get('xemail') == email:
            match_types.append('email')
        if phone and dup.get('xphone') == phone:
            match_types.append('phone')
    return list(set(match_types))

async def _generate_duplicate_prompt(context, duplicate_result):
    """Generate intelligent duplicate handling prompt"""
    try:
        duplicates = duplicate_result.get('duplicates', [])
        match_types = duplicate_result.get('match_types', [])
        
        duplicate_info = []
        for dup in duplicates[:3]:
            name_parts = [dup.get('xfirst', ''), dup.get('xlast', '')]
            name = ' '.join(filter(None, name_parts)) or 'Unknown'
            info = f"• **{dup.get('xcus', 'Unknown')}** - {name} ({dup.get('xemail', 'No email')})"
            if dup.get('xorg'):
                info += f" from {dup['xorg']}"
            duplicate_info.append(info)
        
        match_description = ""
        if 'email' in match_types and 'phone' in match_types:
            match_description = "A customer with the **same email AND phone number** already exists"
        elif 'email' in match_types:
            match_description = "A customer with the **same email address** already exists"
        elif 'phone' in match_types:
            match_description = "A customer with the **same phone number** already exists"
        
        prompt = (
            f"⚠️ **Duplicate Customer Detected**\n\n"
            f"{match_description}:\n\n"
            f"{''.join(duplicate_info)}\n\n"
            f"🤔 **What would you like to do?**\n"
            f"• **Update existing customer** - Modify the existing customer's information\n"
            f"• **Create anyway** - Create a new customer with different contact information\n"
            f"• **Cancel** - Stop the customer creation process\n\n"
            f"Please let me know how you'd like to proceed:"
        )
        
        return prompt
        
    except Exception as e:
        logger.error(f"[DuplicatePrompt] Error: {e}")
        return "Duplicate customer detected. Please choose how to proceed."

async def _generate_success_message(context, parsed_result):
    """Generate enhanced success message with customer details"""
    try:
        customer_id_match = re.search(r"'(CUS-\d{6})'", context.sql)
        if customer_id_match:
            new_customer_id = customer_id_match.group(1)
            
            fetch_sql = f"SELECT * FROM cacus WHERE zid = {context.business_id} AND xcus = '{new_customer_id}'"
            fetch_result = await mcp_client.execute_query(fetch_sql, context.business_id)
            
            if isinstance(fetch_result, dict) and 'content' in fetch_result:
                try:
                    parsed_fetch = json.loads(fetch_result['content'][0]['text'])
                    customer_data = parsed_fetch.get('results', [])
                    
                    if customer_data:
                        customer_details = format_customer_result(customer_data)
                        return f"🎉 **Customer Successfully Created!**\n\n{customer_details}"
                    else:
                        return f"✅ Customer successfully created! Customer ID: **{new_customer_id}**"
                except Exception:
                    return f"✅ Customer successfully created! Customer ID: **{new_customer_id}**"
        
        return "✅ Customer has been successfully created! The customer ID has been automatically generated."
        
    except Exception as e:
        logger.error(f"[SuccessMessage] Error: {e}")
        return "✅ Customer has been successfully created!"

async def _handle_error(error_msg):
    """Enhanced error handling for insert operations"""
    try:
        error_lower = error_msg.lower()
        
        if 'duplicate' in error_lower or 'unique' in error_lower:
            return (
                "❌ **Duplicate Customer Detected**\n\n"
                "A customer with this email or phone number already exists. "
                "Please check the information and try again with different details."
            )
        elif 'constraint' in error_lower or 'foreign key' in error_lower:
            return (
                "❌ **Invalid Reference Data**\n\n"
                "The customer group or organization specified is invalid. "
                "Please check these values and try again."
            )
        elif 'not null' in error_lower:
            return (
                "❌ **Missing Required Information**\n\n"
                "Some required fields are missing. Please provide all mandatory customer information."
            )
        else:
            return f"❌ **Customer Creation Failed**\n\nError: {error_msg}"
            
    except Exception as e:
        logger.error(f"[ErrorHandling] Error: {e}")
        return f"❌ Failed to create customer: {error_msg}"

async def _check_flow_interruption(context):
    """Check for flow interruption during insert operations"""
    try:
        interruption = await flow_interruption_handler.check_interruption(
            context.message, 
            context.conversation_history,
            current_flow="insert"
        )
        
        if interruption['is_interrupted']:
            logger.info(f"[FlowInterruption] Flow interrupted: {interruption['new_intent']}")
            
            context = _clear_flow_state(context)
            
            if interruption['new_intent'] in ['select', 'search', 'list']:
                context.query_classification = "SEARCH_CUSTOMER"
                context.next = "GenerateSelectSQL"
            elif interruption['new_intent'] == 'update':
                context.query_classification = "UPDATE_CUSTOMER"
                context.next = "GenerateUpdateSQL"
            elif interruption['new_intent'] == 'delete':
                context.query_classification = "DELETE_CUSTOMER"
                context.next = "GenerateDeleteSQL"
            else:
                context.next = "GeneralCustomerChat"
            
            return {
                'is_interrupted': True,
                'response': context.model_dump()
            }
        
        return {'is_interrupted': False}
        
    except Exception as e:
        logger.error(f"[FlowInterruption] Error: {e}")
        return {'is_interrupted': False}

async def _handle_intent_switch(context, new_intent, response_content):
    """Handle intent switching to other operations"""
    try:
        if new_intent == 'select':
            context.query_classification = "SEARCH_CUSTOMER"
            context.next = "GenerateSelectSQL"
        elif new_intent == 'update':
            context.query_classification = "UPDATE_CUSTOMER"
            context.next = "GenerateUpdateSQL"
        elif new_intent == 'delete':
            context.query_classification = "DELETE_CUSTOMER"
            context.next = "GenerateDeleteSQL"
        else:
            context.next = "GeneralCustomerChat"
        
        context.response = response_content
        return context
        
    except Exception as e:
        logger.error(f"[IntentSwitch] Error: {e}")
        context.response = "How can I help you?"
        context.next = "CustomerResponse"
        return context

def _clear_flow_state(context):
    """Clear all INSERT flow related state"""
    context.insert_phase = None
    context.pause_reason = None
    context.pause_message = None
    context.current_flow = None
    context.collected_field_values = None
    context.duplicate_check_done = None
    context.incomplete_sql = None
    context.missing_mandatory_fields = None
    
    return context

async def _get_user_friendly_field_name_dynamically(field_name, business_id):
    """Convert database field names to user-friendly names using vector DB context and LLM."""
    try:
        # Get schema context for the business
        schema_context = await get_customer_schema_context_for_flow(business_id, "insert")
        
        # Look for the field in the schema context
        for schema in schema_context:
            for col in schema.get('columns', []):
                if col.get('name', '') == field_name:
                    # Use description or business meaning if available
                    description = col.get('description', '') or col.get('business_meaning', '')
                    if description:
                        return description
                    
        # Fallback to LLM-based conversion if not found in schema
        conversion_prompt = f"""
Convert this database field name to a user-friendly name.

Field name: {field_name}

Provide a clear, business-friendly name that a non-technical user would understand.
Examples:
- xemail → Email Address
- xphone → Phone Number
- xorg → Organization
- xfirst → First Name
- xgcus → Customer Group

Respond with only the user-friendly name, nothing else.
"""
        
        response = await llm_service.chat([
            {"role": "system", "content": "You are an expert at converting technical field names to user-friendly names."},
            {"role": "user", "content": conversion_prompt}
        ])
        
        friendly_name = response.strip()
        if friendly_name and not friendly_name.startswith("x"):
            return friendly_name
        
        # Final fallback - basic transformation
        return field_name.replace('x', '').replace('_', ' ').title()
        
    except Exception as e:
        logger.error(f"[InsertFlow] Error getting user-friendly field name for {field_name}: {e}")
        # Ultimate fallback
        return field_name.replace('x', '').replace('_', ' ').title()

if __name__ == "__main__":
    # This is just to prevent syntax errors if the file is run directly
    pass