"""Reactive Customer Select Flow - Handles customer data retrieval with dynamic SQL generation and clarification"""
from backend.app.models.chat_graph_state import ChatGraphState
from backend.app.services.mistral_llm_service import MistralLLMService
from backend.app.services.vector_search import FaissVectorSearchService
from backend.app.mcp.mcp_client import MCPClient
from backend.app.agents.customer_agent.secure_customer_helpers import (
    format_customer_result_secure
)
from backend.app.agents.customer_agent.customer_chat_helpers import (
    build_customer_sql_prompt, clean_sql_from_llm,
    get_customer_schema_context_for_flow
)
from backend.app.agents.customer_agent.negative_vibe_detector import negative_vibe_detector
import logging
import json
import re

logger = logging.getLogger(__name__)

# Universal JSON parser for LLM responses
def _parse_llm_json_response(response: str) -> dict:
    """Parse JSON response from LLM, handling markdown code blocks and other formatting issues."""
    # Clean the response
    response = response.strip()
    
    # Remove markdown code blocks
    if response.startswith('```json'):
        response = response[7:]  # Remove ```json
    elif response.startswith('```'):
        response = response[3:]   # Remove ```
    
    if response.endswith('```'):
        response = response[:-3]  # Remove ending ```
    
    # Remove any extra whitespace
    response = response.strip()
    
    # Try to extract JSON if it's embedded in other text
    json_match = re.search(r'\{.*\}', response, re.DOTALL)
    if json_match:
        response = json_match.group(0)
    
    try:
        return json.loads(response)
    except json.JSONDecodeError as e:
        logger.error(f"[JSONParser] Failed to parse JSON: {e}, cleaned response: {response[:200]}...")
        # Return a basic fallback structure
        raise json.JSONDecodeError(f"Could not parse LLM JSON response: {e}", response, 0)

# Initialize services
llm_service = MistralLLMService()
vector_search_service = FaissVectorSearchService()
mcp_client = MCPClient(script_path="backend/app/mcp/server_enhanced.py")

async def vector_search_node(context):
    """🚀 ULTRA-REACTIVE vector search with intelligent query analysis and flow management."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    logger.info(f"[🎯ReactiveSelectFlow] Starting ultra-reactive analysis for: '{context.message}'")
    
    # Set current flow with context preservation
    context.current_flow = "select"
    context.original_query = getattr(context, 'original_query', context.message)
    
    # 🛡️ STEP 1: Advanced negative vibe detection with conversation context
    negative_vibe = await negative_vibe_detector.detect_negative_vibe(
        context.message, 
        context.conversation_history,
        current_flow="select"
    )
    
    if negative_vibe['is_negative']:
        logger.info(f"[🛡️ReactiveSelectFlow] Negative vibe detected: {negative_vibe['vibe_type']} - {negative_vibe['reasoning']}")
        context = _clear_select_flow_state(context)
        context.response = negative_vibe['suggested_response']
        context.next = "CustomerResponse"
        return context.model_dump()
    
    # 📊 STEP 2: Enhanced schema context using vector DB + conversation history
    context.schema_context = await get_customer_schema_context_for_flow(context.business_id, "select")
    
    # 🧠 STEP 3: Ultra-smart query clarity assessment with conversation continuity
    clarity_result = await _assess_query_clarity_with_conversation_context(context)
    
    context.is_query_clear = clarity_result['is_clear']
    context.clarity_confidence = clarity_result.get('confidence', 0.5)
    context.clarification_questions = clarity_result.get('clarification_questions', [])
    context.missing_information = clarity_result.get('missing_information', [])
    context.query_intent = clarity_result.get('intent_analysis', {})
    
    logger.info(f"[🧠ReactiveSelectFlow] Query clarity: {context.is_query_clear} (confidence: {context.clarity_confidence})")
    logger.info(f"[🧠ReactiveSelectFlow] Intent analysis: {context.query_intent}")
    
    # 🎯 STEP 4: Intelligent routing based on clarity + confidence
    if context.is_query_clear and context.clarity_confidence > 0.7:
        # High-confidence clear query - proceed directly to SQL
        logger.info("[🎯ReactiveSelectFlow] High-confidence clear query → Direct SQL generation")
        context.next = "GenerateSelectSQL"
    elif context.is_query_clear and context.clarity_confidence > 0.4:
        # Medium-confidence - quick validation then proceed
        logger.info("[🎯ReactiveSelectFlow] Medium-confidence query → Quick validation")
        context.needs_quick_validation = True
        context.next = "GenerateSelectSQL"
    else:
        # Unclear or low-confidence - activate reactive questioning
        logger.info("[🎯ReactiveSelectFlow] Unclear/Low-confidence query → Reactive questioning")
        context.reactive_questioning_active = True
        context.clarification_attempts = getattr(context, 'clarification_attempts', 0)
        context.questioning_strategy = clarity_result.get('questioning_strategy', 'standard')
        context.next = "ReactiveQuestioning"
    
    return context.model_dump()

async def generate_select_sql_node(context):
    """🚀 Ultra-reactive SQL generation with conversation-aware intelligence."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    logger.info(f"[🚀ReactiveSQL] Generating conversational SQL for: '{context.message}'")
    
    try:
        # 🛡️ STEP 1: Pre-SQL interruption check with enhanced detection
        interruption_check = await _check_select_flow_interruption_enhanced(context)
        if interruption_check['is_interrupted']:
            logger.info(f"[🛡️ReactiveSQL] Flow interruption detected: {interruption_check['reason']}")
            return interruption_check['response']
        
        # 📊 STEP 2: Ensure schema context with vector DB enhancement
        if not hasattr(context, 'schema_context') or not context.schema_context:
            context.schema_context = await get_customer_schema_context_for_flow(context.business_id, "select")
        
        # 🧠 STEP 3: Build ultra-smart SQL prompt with full conversation context
        sql_prompt = await _build_conversation_aware_sql_prompt(context)
        
        # 💬 STEP 4: Prepare conversation-enhanced messages
        messages = [
            {"role": "system", "content": sql_prompt}
        ]
        
        # Add recent conversation for rich context (up to 6 messages)
        if context.conversation_history:
            for msg in context.conversation_history[-6:]:
                role = msg.role if hasattr(msg, 'role') else msg.get('role', 'user')
                content = msg.content if hasattr(msg, 'content') else msg.get('content', '')
                messages.append({"role": role, "content": content})
        
        # Add current message
        messages.append({"role": "user", "content": context.message})
        
        logger.info(f"[🧠ReactiveSQL] Using {len(messages)} messages for context-aware SQL generation")
        
        # 🎯 STEP 5: Generate SQL with enhanced LLM context
        sql_response = await llm_service.chat(messages)
        
        # 📊 STEP 6: Clean, validate and enhance SQL
        context.sql = clean_sql_from_llm(sql_response)
        context.customer_action = "select"
        context.sql_generation_method = "conversation_aware"
        context.sql_confidence = getattr(context, 'clarity_confidence', 0.8)
        
        # 🚀 STEP 7: Smart routing based on confidence
        if getattr(context, 'needs_quick_validation', False) and context.sql_confidence < 0.6:
            # Low confidence - add validation step
            context.next = "ValidateSQL"
            context.validation_needed = True
        else:
            # High confidence - proceed to dependency check
            context.next = "SelectDependencyCheck"
        
        logger.info(f"[🎯ReactiveSQL] Generated: {context.sql} (confidence: {context.sql_confidence})")
        return context.model_dump()
        
    except Exception as e:
        logger.error(f"[❌ReactiveSQL] Error: {e}")
        # 🔄 Intelligent error handling with context preservation
        if hasattr(context, 'reactive_questioning_active') and not context.reactive_questioning_active:
            # First attempt failed - try reactive questioning
            context.reactive_questioning_active = True
            context.clarification_attempts = 0
            context.error_context = str(e)
            context.next = "ReactiveQuestioning"
            return context.model_dump()
        else:
            # Questioning also failed - provide helpful error
            context.response = f"🤔 I'm having trouble understanding your request. Could you please be more specific about which customer information you need? For example: 'show customer CUS-123' or 'list customers with gmail accounts'."
            context.next = "CustomerResponse"
            return context.model_dump()

async def execute_select_sql_node(context):
    """🚀 Execute customer SELECT SQL operations with enhanced performance and beautiful formatting."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    logger.info(f"[🚀CustomerSelectSQL] Executing: {context.sql}")
    
    try:
        # Check for potentially slow queries and optimize
        optimized_sql = await _optimize_sql_for_performance(context.sql, context.business_id)
        if optimized_sql != context.sql:
            logger.info(f"[🚀CustomerSelectSQL] SQL optimized: {optimized_sql}")
            context.sql = optimized_sql
        
        # Execute SQL via MCP with timeout handling
        logger.info(f"[🚀CustomerSelectSQL] Executing optimized SQL: {context.sql}")
        result = await mcp_client.execute_query(context.sql, context.business_id)
        logger.info(f"[🚀CustomerSelectSQL] Raw MCP result type: {type(result)}")
        
        if isinstance(result, dict) and 'content' in result:
            try:
                # Parse MCP response
                parsed = json.loads(result['content'][0]['text'])
                rows = parsed.get('results', [])
                logger.info(f"[🚀CustomerSelectSQL] Parsed rows count: {len(rows)}")
                
                if not rows:
                    context.response = "📭 No customers found matching your criteria. Would you like to try a different search or add a new customer?"
                else:
                    # ENHANCED: Use secure formatting with performance optimization
                    if len(rows) > 100:
                        # For very large results, show count and ask for refinement
                        context.response = (
                            f"📊 **Found {len(rows)} customers** - that's quite a lot!\n\n"
                            f"🎯 **For better performance and readability, try:**\n"
                            f"• `last 10 customers` - Most recent customers\n"
                            f"• `customers from [organization]` - Filter by organization\n"
                            f"• `customers with [email domain]` - Filter by email\n"
                            f"• `customer CUS-XXXXXX` - Specific customer\n\n"
                            f"💡 Would you like to refine your search?"
                        )
                    else:
                        # Use beautiful secure formatting for reasonable result sets
                        formatted_result = await format_customer_result_secure(rows, context.business_id)
                        logger.info(f"[🚀CustomerSelectSQL] Formatted result: {formatted_result[:100]}...")
                        
                        # Enhanced fallback if secure formatting fails
                        if not formatted_result or "No customer information available" in formatted_result:
                            logger.warning(f"[🚀CustomerSelectSQL] Secure formatting failed/empty for {len(rows)} rows, using enhanced fallback")
                            formatted_result = await _generate_beautiful_fallback_display(rows, context.business_id)
                        
                        context.response = formatted_result
                    
            except (json.JSONDecodeError, KeyError, IndexError) as e:
                logger.error(f"[🚀CustomerSelectSQL] Error parsing result: {e}")
                context.response = "I found some data but had trouble formatting it. Please try rephrasing your request."
        else:
            logger.warning(f"[🚀CustomerSelectSQL] Unexpected result format: {result}")
            context.response = "No results found for your customer query."
            
    except Exception as e:
        logger.error(f"[🚀CustomerSelectSQL] Execution error: {e}")
        
        # Enhanced error handling for different types of errors
        error_str = str(e).lower()
        if 'timeout' in error_str:
            context.response = (
                "⏱️ **Query taking too long!**\n\n"
                "🎯 **Try a more specific search:**\n"
                "• `last 10 customers` instead of `last 100 customers`\n"
                "• `customers from [organization]` for targeted results\n"
                "• `customer CUS-XXXXXX` for a specific customer\n\n"
                "💡 Large queries can be slow - let's narrow it down!"
            )
        else:
            context.response = f"I encountered an error while searching for customers: {str(e)}"
    
    context.next = "CustomerResponse"
    return context.model_dump()

async def _optimize_sql_for_performance(sql, business_id):
    """Optimize SQL queries for better performance"""
    try:
        # Add LIMIT for queries without one
        if 'LIMIT' not in sql.upper() and 'ORDER BY' in sql.upper():
            # Default limit for ordered queries
            sql += " LIMIT 50"
        elif 'LIMIT' not in sql.upper():
            # Default limit for unordered queries
            sql += " LIMIT 100"
        
        # Ensure proper indexing hint (if supported)
        if 'ORDER BY xcus' in sql and 'LIMIT' in sql:
            # Already optimized for customer ID ordering
            pass
        
        return sql
        
    except Exception as e:
        logger.error(f"[SQLOptimizer] Error optimizing SQL: {e}")
        return sql

async def _generate_beautiful_fallback_display(rows, business_id):
    """Generate beautiful fallback display when secure formatting fails"""
    try:
        if not rows:
            return "📭 No customer information available."
        
        # Simple but beautiful table format
        headers = []
        sample_row = rows[0] if rows else {}
        
        # Get user-friendly headers
        field_mapping = {
            'xcus': 'Customer ID',
            'xemail': 'Email Address', 
            'xphone': 'Phone Number',
            'xorg': 'Organization',
            'xgcus': 'Customer Type',
            'xstatuscus': 'Status',
            'xfirst': 'First Name',
            'xlast': 'Last Name'
        }
        
        # Build headers from available fields
        for field in ['xcus', 'xemail', 'xphone', 'xorg', 'xgcus', 'xstatuscus']:
            if field in sample_row:
                headers.append(field_mapping.get(field, field))
        
        # Limit to first 6 columns for readability
        headers = headers[:6]
        
        # Build table rows
        table_lines = []
        table_lines.append("\t".join(headers))
        table_lines.append("")
        
        for row in rows[:20]:  # Limit to first 20 rows for performance
            row_data = []
            for field in ['xcus', 'xemail', 'xphone', 'xorg', 'xgcus', 'xstatuscus'][:len(headers)]:
                value = row.get(field, '—')
                if value in [None, '', 'None', 'null']:
                    value = '—'
                row_data.append(str(value))
            table_lines.append("\t".join(row_data))
        
        # Add summary
        result = "\n".join(table_lines)
        if len(rows) > 20:
            result += f"\n\n📊 Showing first 20 of {len(rows)} customers • Use more specific search for complete results"
        else:
            result += f"\n\n📊 Showing {len(rows)} customer{'s' if len(rows) != 1 else ''} • All data is secured and business-friendly"
        
        return result
        
    except Exception as e:
        logger.error(f"[FallbackDisplay] Error generating fallback: {e}")
        return f"Found {len(rows)} customers. Please try a more specific search for detailed results."

async def reactive_questioning_node(context):
    """🧐 Ultra-reactive questioning with adaptive strategies and flow intelligence."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    logger.info(f"[🧐ReactiveQuestioning] Handling unclear query with strategy: {getattr(context, 'questioning_strategy', 'standard')}")
    
    # 🛡️ STEP 1: Check for negative sentiment during questioning
    negative_vibe = await negative_vibe_detector.detect_negative_vibe(
        context.message, 
        context.conversation_history,
        current_flow="select_questioning"
    )
    
    if negative_vibe['is_negative']:
        logger.info(f"[🛡️ReactiveQuestioning] Negative vibe during questioning: {negative_vibe['vibe_type']}")
        context = _clear_select_flow_state(context)
        context.response = negative_vibe['suggested_response']
        context.next = "CustomerResponse"
        return context.model_dump()
    
    # 📈 STEP 2: Track and manage questioning attempts with intelligence
    current_attempts = getattr(context, 'clarification_attempts', 0)
    # Handle None case explicitly
    if current_attempts is None:
        current_attempts = 0
    context.clarification_attempts = current_attempts + 1
    questioning_strategy = getattr(context, 'questioning_strategy', 'standard')
    
    # 🚫 STEP 3: Smart questioning limits with progressive strategy
    max_attempts = 4 if questioning_strategy == 'progressive' else 3
    
    if context.clarification_attempts > max_attempts:
        logger.info(f"[🚫ReactiveQuestioning] Max attempts ({max_attempts}) reached with strategy '{questioning_strategy}'")
        
        # Try one last time with best available information
        if hasattr(context, 'partial_criteria') and context.partial_criteria:
            logger.info("[🔄ReactiveQuestioning] Proceeding with partial criteria")
            context.response = "🚀 I'll proceed with the information provided so far."
            context.next = "GenerateSelectSQL"
        else:
            context.response = "🔍 **Customer Search Help**\n\nI'd be happy to help you find customer information! Here are some ways you can search:\n\n**🎯 Specific Examples:**\n• `show customer CUS-000107`\n• `find customers with gmail`\n• `list customers from ABC Corp`\n• `recent customers`\n• `customers in New York`\n\n**📊 Quick Options:**\n• Show recent customers: `recent customers`\n• Search by email domain: `customers with @company.com`\n• Search by organization: `customers from [company name]`\n\nWhat specific customer information are you looking for?"
            context.next = "CustomerResponse"
        
        return context.model_dump()
    
    # 🎯 STEP 4: Generate adaptive clarification questions based on strategy
    questions = context.clarification_questions or await _generate_adaptive_clarification_questions(context, questioning_strategy)
    
    if questions:
        # ✨ STEP 5: Use intelligent questions or format them progressively with schema context
        if context.clarification_questions:
            # Use pre-generated intelligent questions from clarity analysis
            context.response = questions[0] if isinstance(questions, list) else questions
        else:
            # Format questions with progressive enhancement and schema context
            formatted_response = await _format_progressive_clarification_questions(
                questions, 
                getattr(context, 'schema_context', []),
                context.clarification_attempts,
                questioning_strategy
            )
            context.response = formatted_response
        context.pause_reason = "adaptive_clarification_needed"
        context.questioning_timestamp = getattr(context, 'timestamp', 'unknown')
        context.next = "PauseNode"
    else:
        # No questions generated - proceed with best effort
        logger.info("[🎯ReactiveQuestioning] No questions generated, proceeding")
        context.response = "I'll try to help with the information provided."
        context.next = "GenerateSelectSQL"
    
    return context.model_dump()

async def handle_clarification_response_node(context):
    """Handle user's response to clarification questions with dynamic analysis."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    logger.info(f"[ClarificationResponse] Processing response: {context.message}")
    
    # Check for flow interruption during clarification
    interruption_check = await _check_select_flow_interruption(context)
    if interruption_check['is_interrupted']:
        return interruption_check['response']
    
    # Analyze the clarification response using LLM
    response_analysis = await _analyze_clarification_response(context)
    
    # Update context with extracted information
    if response_analysis.get('extracted_info'):
        context.clarification_provided = True
        context.extracted_criteria = response_analysis['extracted_info']
    
    if response_analysis.get('sufficient_info', False):
        # Enough information provided, proceed with SQL generation
        logger.info("[ClarificationResponse] Sufficient information provided")
        context.reactive_questioning_active = False
        context.pause_reason = None  # Clear pause state
        context.next = "GenerateSelectSQL"
    else:
        # Still need more information
        missing_info = response_analysis.get('still_missing', [])
        if missing_info and context.clarification_attempts < 3:
            context.missing_information = missing_info
            context.next = "ReactiveQuestioning"
        else:
            # Proceed with best effort after max attempts
            logger.info("[ClarificationResponse] Proceeding with available information")
            context.next = "GenerateSelectSQL"
    
    return context.model_dump()

async def select_dependency_check_node(context):
    """Check dependencies for SELECT operations (minimal checks needed)."""
    if isinstance(context, dict):
        context = ChatGraphState(**context)
    
    # SELECT operations typically don't need dependency checks
    # Just proceed to execution
    context.next = "ExecuteSelectSQL"
    return context.model_dump()

# --- Enhanced Helper Functions for Ultra-Reactive SELECT Flow ---

def _clear_select_flow_state(context):
    """Clear all SELECT flow related state with enhanced cleanup."""
    # Core flow state
    context.reactive_questioning_active = False
    context.clarification_attempts = 0
    context.pause_reason = None
    context.pause_message = None
    context.missing_information = []
    context.clarification_questions = []
    context.extracted_criteria = None
    context.clarification_provided = False
    context.current_flow = None
    
    # Enhanced reactive state
    context.clarity_confidence = None
    context.query_intent = None
    context.questioning_strategy = None
    context.needs_quick_validation = False
    context.sql_confidence = None
    context.sql_generation_method = None
    context.validation_needed = False
    
    return context

async def _assess_query_clarity_with_conversation_context(context):
    """🧠 Ultra-smart query clarity assessment using conversation context + vector DB."""
    try:
        # 💬 Build rich conversation context
        conversation_context = ""
        if context.conversation_history:
            recent_messages = context.conversation_history[-6:]  # More context for better understanding
            conversation_context = "\nConversation History:\n"
            for i, msg in enumerate(recent_messages):
                role = msg.role if hasattr(msg, 'role') else msg.get('role', 'unknown')
                content = msg.content if hasattr(msg, 'content') else msg.get('content', '')
                conversation_context += f"{i+1}. {role.upper()}: {content}\n"
        
        # 📊 Get vector DB context for customer fields
        vector_results = await vector_search_service.search_schemas(
            business_id=context.business_id,
            query=f"customer table fields columns {context.message}",
            top_k=8  # More context
        )
        
        schema_info = "\nCustomer Schema Context:\n"
        for result in vector_results[:5]:  # Top 5 most relevant
            schema_info += f"- {result.get('content', '')}\n"
        
        # 🚀 Enhanced clarity assessment prompt
        clarity_prompt = f"""
You are an ULTRA-SMART query analyzer for a customer management system. Analyze this query for SQL generation readiness.

💬 CONVERSATION CONTEXT:{conversation_context}

📋 CURRENT QUERY: "{context.message}"

📊 AVAILABLE CUSTOMER SCHEMA:{schema_info}

🎯 ANALYSIS REQUIREMENTS:
1. **Query Clarity**: Can I generate specific SQL? (Consider conversation context!)
2. **Intent Recognition**: What exactly does the user want?
3. **Context Continuity**: Does this relate to previous messages?
4. **Missing Information**: What specific details are needed?
5. **Confidence Level**: How sure am I about the intent?

📈 ENHANCED EXAMPLES:
Conversation: "show customers" → "with gmail" → CLEAR (building on previous context)
Conversation: "find customer" → "the last one we added" → CLEAR (contextual reference)
Standalone: "get customers" → UNCLEAR (no specific criteria)
Standalone: "show customer CUS-123" → CLEAR (specific ID)
Conversation: "I want to see" → "customers from yesterday" → CLEAR (temporal context)

Respond with JSON:
{{
    "is_clear": boolean,
    "confidence": 0.0-1.0,
    "intent_analysis": {{
        "primary_intent": "specific_customer|customer_list|filtered_search|contextual_reference",
        "search_criteria": "identified criteria or null",
        "context_dependent": boolean,
        "temporal_reference": "if any time reference"
    }},
    "missing_information": ["specific missing details"],
    "clarification_questions": ["targeted questions"],
    "questioning_strategy": "direct|guided|contextual|progressive",
    "sql_readiness": "ready|needs_clarification|impossible"
}}

Examples:
- "show me customers" → {{"is_clear": false, "confidence": 0.3, "missing_information": ["search criteria"], "questioning_strategy": "guided", "clarification_questions": ["What specific customers are you looking for? Try: 'recent customers', 'customers with gmail', or 'customer CUS-123456'"]}}
- "give me a customer" → {{"is_clear": false, "confidence": 0.2, "missing_information": ["search criteria"], "questioning_strategy": "guided", "clarification_questions": ["I can help you find customer information! Try: 'show recent customers', 'find customer CUS-123456', or 'customers from [company name]'"]}}
- "customer CUS-123" → {{"is_clear": true, "confidence": 0.95, "intent_analysis": {{"primary_intent": "specific_customer"}}}}
- "the last customer" (after discussing customers) → {{"is_clear": true, "confidence": 0.8, "intent_analysis": {{"context_dependent": true}}}}
"""
        
        # 🧠 Get LLM analysis
        response = await llm_service.chat([
            {"role": "system", "content": "You are an ultra-smart query analyzer. Always respond with valid JSON."},
            {"role": "user", "content": clarity_prompt}
        ])
        
        # 📊 Parse and validate response
        try:
            result = _parse_llm_json_response(response.strip())
            
            # ✨ Enhance result with reactive features
            result['analysis_timestamp'] = getattr(context, 'timestamp', 'unknown')
            result['conversation_length'] = len(context.conversation_history) if context.conversation_history else 0
            
            # 📊 Smart confidence adjustment based on conversation context
            if result.get('intent_analysis', {}).get('context_dependent') and result['conversation_length'] > 2:
                result['confidence'] = min(1.0, result['confidence'] + 0.2)  # Boost confidence for contextual queries
            
            # 🚀 BOOST confidence for common patterns that should be clear
            message_lower = context.message.lower()
            clear_patterns = [
                'last 5', 'last customer', 'recent customer', 'show customer', 'find customer',
                'customer cus-', 'customers with', 'customer from'
            ]
            if any(pattern in message_lower for pattern in clear_patterns):
                result['confidence'] = max(result['confidence'], 0.8)
                result['is_clear'] = True
                logger.info(f"[🧠ReactiveClarity] Boosted confidence for clear pattern: {context.message}")
            
            logger.info(f"[🧠ReactiveClarity] Analysis result: {result}")
            return result
            
        except json.JSONDecodeError as e:
            logger.warning(f"[🧠ReactiveClarity] JSON parsing failed: {e}")
            # 🔄 Intelligent fallback
            return {
                "is_clear": len(context.message.split()) > 3 and any(keyword in context.message.lower() for keyword in ['cus-', 'customer', 'email', 'phone']),
                "confidence": 0.4,
                "missing_information": ["search criteria"],
                "clarification_questions": ["What specific customer information are you looking for?"],
                "questioning_strategy": "direct",
                "sql_readiness": "needs_clarification"
            }
            
    except Exception as e:
        logger.error(f"[🧠ReactiveClarity] Error: {e}")
        # 🔄 Safe fallback
        return {
            "is_clear": True,  # Default to proceeding
            "confidence": 0.3,
            "missing_information": [],
            "clarification_questions": [],
            "questioning_strategy": "direct",
            "sql_readiness": "ready"
        }

async def _check_select_flow_interruption_enhanced(context):
    """🛡️ Enhanced flow interruption detection with conversation context."""
    try:
        # Build conversation context for better interruption detection
        conversation_context = ""
        if context.conversation_history:
            recent_msgs = context.conversation_history[-4:]
            conversation_context = "\nRecent conversation:\n"
            for msg in recent_msgs:
                role = msg.role if hasattr(msg, 'role') else msg.get('role', 'user')
                content = msg.content if hasattr(msg, 'content') else msg.get('content', '')
                conversation_context += f"{role}: {content}\n"
        
        interruption_prompt = f"""
Analyze if this user message interrupts the current SELECT flow with a different operation.

Current Flow: SELECT (customer search/retrieval)
User Message: "{context.message}"
Current Intent: {getattr(context, 'query_intent', 'unknown')}
{conversation_context}

Check for:
1. **CRUD SWITCHES**: Different operation (UPDATE/DELETE/INSERT)
2. **CANCELLATION**: Clear cancel intent ("stop", "cancel", "nevermind")
3. **TOPIC SHIFT**: Complete topic change away from customer search
4. **NEGATIVE SENTIMENT**: Frustration or confusion requiring help

IMPORTANT: Don't flag legitimate SELECT variations as interruptions!
- "show different customers" → NOT INTERRUPTION (still SELECT)
- "find another customer" → NOT INTERRUPTION (still SELECT) 
- "update customer info" → INTERRUPTION (different operation)
- "never mind" → INTERRUPTION (cancellation)

Respond with JSON:
{{
    "is_interrupted": boolean,
    "interruption_type": "crud_switch|cancellation|topic_shift|negative_sentiment|none",
    "target_operation": "select|update|delete|insert|cancel|help|none",
    "confidence": 0.0-1.0,
    "reason": "specific reason for interruption",
    "suggested_response": "response to user",
    "preserve_context": boolean
}}
"""
        
        response = await llm_service.chat([
            {"role": "system", "content": "You are an interruption detection expert. Always respond with valid JSON."},
            {"role": "user", "content": interruption_prompt}
        ])
        
        try:
            result = _parse_llm_json_response(response.strip())
            
            if result.get('is_interrupted', False):
                interruption_type = result.get('interruption_type', 'unknown')
                target_op = result.get('target_operation', 'none')
                
                logger.info(f"[🛡️ReactiveInterruption] Detected: {interruption_type} → {target_op}")
                
                if target_op == 'cancel':
                    context = _clear_select_flow_state(context)
                    context.response = result.get('suggested_response', "Operation canceled. How can I help you?")
                    context.next = "CustomerResponse"
                    return {'is_interrupted': True, 'response': context.model_dump(), 'reason': result.get('reason', 'cancellation')}
                    
                elif target_op in ['update', 'delete', 'insert']:
                    # Preserve some context if recommended
                    if not result.get('preserve_context', False):
                        context = _clear_select_flow_state(context)
                    context.current_flow = target_op
                    context.response = result.get('suggested_response', f"Switching to {target_op} operation.")
                    context.next = "GenerateCustomerSQL"
                    return {'is_interrupted': True, 'response': context.model_dump(), 'reason': f'crud_switch_to_{target_op}'}
                    
                elif target_op == 'help':
                    context.response = result.get('suggested_response', "I'm here to help! What would you like to know?")
                    context.next = "CustomerResponse"
                    return {'is_interrupted': True, 'response': context.model_dump(), 'reason': 'help_request'}
            
            return {'is_interrupted': False}
            
        except json.JSONDecodeError as e:
            logger.warning(f"[🛡️ReactiveInterruption] JSON parsing failed: {e}")
            return {'is_interrupted': False}
            
    except Exception as e:
        logger.error(f"[🛡️ReactiveInterruption] Error: {e}")
        return {'is_interrupted': False}

async def _build_conversation_aware_sql_prompt(context):
    """🚀 Build conversation-aware SQL prompt with performance optimization and smart limits."""
    try:
        # Enhanced schema context
        schema_context = context.schema_context or ""
        
        # Rich conversation context with intent analysis
        conversation_context = ""
        if context.conversation_history:
            recent_messages = context.conversation_history[-8:]  # Even more context
            conversation_context = "\n📜 CONVERSATION HISTORY:\n"
            for i, msg in enumerate(recent_messages):
                role = msg.role if hasattr(msg, 'role') else msg.get('role', 'unknown')
                content = msg.content if hasattr(msg, 'content') else msg.get('content', '')
                conversation_context += f"{i+1}. {role.upper()}: {content}\n"
        
        # Include clarification context if available
        clarification_context = ""
        if getattr(context, 'clarification_provided', False):
            extracted = getattr(context, 'extracted_criteria', {})
            clarification_context = f"\n🎯 CLARIFICATION PROVIDED: {extracted}\n"
        
        # Intent analysis context
        intent_context = ""
        if hasattr(context, 'query_intent') and context.query_intent:
            intent_context = f"\n🧠 DETECTED INTENT: {context.query_intent}\n"
        
        # Build ultra-smart SQL prompt with performance guidelines
        sql_prompt = f"""
🚀 You are an ULTRA-SMART SQL expert for customer data retrieval with PERFORMANCE OPTIMIZATION.

📊 CUSTOMER TABLE SCHEMA:
{schema_context}

🏢 BUSINESS ID: {context.business_id} (ALWAYS include as: WHERE zid = {context.business_id})
{conversation_context}{clarification_context}{intent_context}
📝 CURRENT QUERY: "{context.message}"

🎯 ENHANCED SQL GENERATION RULES:
1. **Context Awareness**: Use ENTIRE conversation to understand intent
2. **Reference Resolution**: Handle "last customer", "that one", "his phone" etc.
3. **Progressive Searches**: Build on previous queries if context suggests
4. **SMART PERFORMANCE**: Apply intelligent limits based on query type
5. **Partial Matching**: Use ILIKE for text searches

⚡ PERFORMANCE OPTIMIZATION GUIDELINES:
- **Small queries**: "last 5 customers" → LIMIT 5
- **Medium queries**: "last 10-25 customers" → LIMIT as requested
- **Large queries**: "last 50+ customers" → LIMIT 50 (prevent timeouts)
- **No limit specified**: Default LIMIT 20 for unfiltered queries
- **Specific searches**: No limit needed (customer ID, email, etc.)

💡 SMART LIMIT EXAMPLES:
- "last 5 customers" → LIMIT 5 ✅
- "last 100 customers" → LIMIT 50 ⚡ (performance optimization)
- "recent customers" → LIMIT 10 🎯 (reasonable default)
- "customer CUS-123" → No LIMIT needed ✅ (specific search)
- "customers with gmail" → LIMIT 30 🎯 (filtered search)

💡 CONTEXT-AWARE EXAMPLES:
Conversation: "show customers" → "with gmail" 
→ SELECT * FROM cacus WHERE zid = {context.business_id} AND xemail ILIKE '%gmail%' LIMIT 30;

Conversation: "find customer John" → "update his phone"
→ User wants UPDATE operation (not SELECT)

Conversation: "list customers" → "show the last one"
→ SELECT * FROM cacus WHERE zid = {context.business_id} ORDER BY xcus DESC LIMIT 1;

Conversation: "customers in New York" → "their email addresses"
→ SELECT xemail FROM cacus WHERE zid = {context.business_id} AND (xadd1 ILIKE '%New York%' OR xcity ILIKE '%New York%') LIMIT 25;

🔍 CONTEXTUAL REFERENCE HANDLING:
Conversation: "Customer Information: Customer ID: CUS-000107" → "his status?"
→ SELECT xstatuscus FROM cacus WHERE zid = {context.business_id} AND xcus = 'CUS-000107';

Conversation: "Updated customer CUS-000123" → "his phone?"
→ SELECT xphone FROM cacus WHERE zid = {context.business_id} AND xcus = 'CUS-000123';

Conversation: "Update Successful! Customer Code: CUS-000090" → "view last updated customer"
→ SELECT * FROM cacus WHERE zid = {context.business_id} AND xcus = 'CUS-000090';

Conversation: "last customer" showed CUS-000456 → "his details?"
→ SELECT * FROM cacus WHERE zid = {context.business_id} AND xcus = 'CUS-000456';

🏆 RECENT/UPDATED CUSTOMER PATTERNS:
- "view last updated customer" (after update operation) → Find customer from recent update context
- "show last customer" → ORDER BY xcus DESC LIMIT 1
- "recent customers" → ORDER BY xcus DESC LIMIT 10
- "last 5 customers" → ORDER BY xcus DESC LIMIT 5
- "last 25 customers" → ORDER BY xcus DESC LIMIT 25
- "last 50 customers" → ORDER BY xcus DESC LIMIT 50
- "last 100 customers" → ORDER BY xcus DESC LIMIT 50 ⚡ (performance limit)

📋 FIELD-SPECIFIC QUERIES:
- "his status" → SELECT xstatuscus FROM cacus WHERE...
- "his phone" → SELECT xphone FROM cacus WHERE...
- "his email" → SELECT xemail FROM cacus WHERE...
- "his details" → SELECT * FROM cacus WHERE...

🎯 STANDARD PATTERNS:
- Specific ID: "customer CUS-123" → WHERE xcus = 'CUS-123'
- Email search: "gmail customers" → WHERE xemail ILIKE '%gmail%' LIMIT 30
- Recent customers: "last 5" → ORDER BY xcus DESC LIMIT 5
- Phone numbers: "with phones" → WHERE xphone IS NOT NULL AND xphone != '' LIMIT 25
- Organization: "ABC Corp" → WHERE xorg ILIKE '%ABC Corp%' LIMIT 20

⚠️ PERFORMANCE CRITICAL:
- ALWAYS include appropriate LIMIT for large result sets
- Use ORDER BY xcus DESC for "last/recent" queries
- Apply LIMIT 50 maximum for unspecific large queries
- No LIMIT needed for specific searches (customer ID, email, etc.)

Generate ONLY the SQL query. Consider the FULL conversation context and PERFORMANCE requirements.
"""
        
        return sql_prompt
        
    except Exception as e:
        logger.error(f"[🚀ConversationSQL] Error building prompt: {e}")
        # Fallback to basic prompt
        return f"""
Generate SQL SELECT query for customer data with performance optimization.
Table: cacus
Business ID: {context.business_id}
Query: {context.message}
Always include: WHERE zid = {context.business_id}
Add appropriate LIMIT for performance (50 max for large queries).
"""

async def _assess_query_clarity_with_vectordb(context):
    """Assess query clarity using LLM with vector DB context."""
    try:
        # Get relevant schema information from vector DB
        vector_results = await vector_search_service.search_schemas(
            business_id=context.business_id,
            query=context.message,
            top_k=5
        )
        
        schema_info = "\n".join([result.get('content', '') for result in vector_results])
        
        clarity_prompt = f"""
You are analyzing a customer query for clarity in generating SQL SELECT statements.

Available Customer Schema Information:
{schema_info}

User Query: "{context.message}"

Analyze if this query is clear enough to generate a specific SQL SELECT statement.

Consider:
1. Are specific customer identifiers mentioned (ID, name, email, phone)?
2. Are search criteria clear (specific field values, ranges, patterns)?
3. Is the intent unambiguous?

Respond with JSON:
{{
    "is_clear": boolean,
    "missing_information": ["list of missing info needed"],
    "clarification_questions": ["specific questions to ask user"],
    "confidence": "high/medium/low"
}}

Examples:
- "show me customer CUS-000123" → is_clear: true
- "find customers" → is_clear: false, missing: ["search criteria"]
- "customers with gmail" → is_clear: true (clear criteria)
- "get some customers" → is_clear: false, missing: ["specific criteria"]
"""
        
        response = await llm_service.chat([
            {"role": "system", "content": clarity_prompt},
            {"role": "user", "content": context.message}
        ])
        
        # Parse LLM response
        import json
        try:
            result = _parse_llm_json_response(response)
            return result
        except json.JSONDecodeError:
            # Fallback if JSON parsing fails
            return {
                "is_clear": "specific" in context.message.lower() or "CUS-" in context.message,
                "missing_information": ["search criteria"],
                "clarification_questions": ["What specific customer information are you looking for?"]
            }
            
    except Exception as e:
        logger.error(f"[QueryClarity] Error: {e}")
        return {
            "is_clear": True,  # Default to clear to avoid blocking
            "missing_information": [],
            "clarification_questions": []
        }

async def _check_select_flow_interruption(context):
    """Check for flow interruption during SELECT operations."""
    try:
        interruption_prompt = f"""
Analyze if this user message interrupts the current SELECT flow with a different operation.

Current Flow: SELECT (customer search/retrieval)
User Message: "{context.message}"
Conversation Context: {[msg.content for msg in context.conversation_history[-3:]]}

Check for:
1. UPDATE/MODIFY requests ("update customer", "change", "modify")
2. DELETE requests ("delete", "remove")
3. INSERT/CREATE requests ("add customer", "create new")
4. Negative intent ("cancel", "stop", "nevermind")

Respond with JSON:
{{
    "is_interrupted": boolean,
    "target_operation": "select/update/delete/insert/cancel/none",
    "confidence": "high/medium/low",
    "suggested_response": "response to user"
}}
"""
        
        response = await llm_service.chat([
            {"role": "system", "content": interruption_prompt},
            {"role": "user", "content": context.message}
        ])
        
        import json
        try:
            result = _parse_llm_json_response(response.strip())
            
            if result.get('is_interrupted', False):
                target_op = result.get('target_operation', 'none')
                
                if target_op == 'cancel':
                    context = _clear_select_flow_state(context)
                    context.response = result.get('suggested_response', "Operation canceled. How can I help you?")
                    context.next = "CustomerResponse"
                    return {'is_interrupted': True, 'response': context.model_dump()}
                elif target_op in ['update', 'delete', 'insert']:
                    context = _clear_select_flow_state(context)
                    context.current_flow = target_op
                    context.response = result.get('suggested_response', f"Switching to {target_op} operation.")
                    context.next = "GenerateCustomerSQL"
                    return {'is_interrupted': True, 'response': context.model_dump()}
            
            return {'is_interrupted': False}
            
        except json.JSONDecodeError:
            return {'is_interrupted': False}
            
    except Exception as e:
        logger.error(f"[FlowInterruption] Error: {e}")
        return {'is_interrupted': False}

async def _build_dynamic_select_sql_prompt(context):
    """Build dynamic SQL prompt using vector DB context and conversation history."""
    # Get enhanced schema context
    schema_context = context.schema_context or ""
    
    # Build conversation context
    conversation_context = ""
    if context.conversation_history:
        recent_messages = context.conversation_history[-6:]
        conversation_context = "\n".join([
            f"{msg.role}: {msg.content}" for msg in recent_messages
        ])
    
    # Include clarification context if available
    clarification_context = ""
    if getattr(context, 'clarification_provided', False):
        clarification_context = f"\nClarification provided: {getattr(context, 'extracted_criteria', '')}"
    
    sql_prompt = f"""
You are a SQL expert generating SELECT queries for customer data retrieval.

Customer Table Schema and Context:
{schema_context}

Business ID (zid): {context.business_id} (ALWAYS include in WHERE clause as integer)

Recent Conversation:
{conversation_context}
{clarification_context}

Generate a precise SQL SELECT query based on the user's request.

Rules:
1. ALWAYS include WHERE zid = {context.business_id} (as integer, not string)
2. Use appropriate column names from the schema
3. Handle partial matches with ILIKE for text searches
4. Order results logically (usually by xcus DESC for latest customers)
5. Use LIMIT when appropriate for large result sets

Examples:
- "show me customer CUS-000123" → SELECT * FROM cacus WHERE zid = {context.business_id} AND xcus = 'CUS-000123';
- "customers with gmail" → SELECT * FROM cacus WHERE zid = {context.business_id} AND xemail ILIKE '%gmail%';
- "last 5 customers" → SELECT * FROM cacus WHERE zid = {context.business_id} ORDER BY xcus DESC LIMIT 5;
- "customers with phone numbers" → SELECT * FROM cacus WHERE zid = {context.business_id} AND xphone IS NOT NULL AND xphone != '';

Return only the SQL query, no explanations.
"""
    
    return sql_prompt

async def _generate_adaptive_clarification_questions(context, strategy):
    """🎯 Generate adaptive clarification questions based on strategy and context with schema awareness."""
    try:
        # Build rich context for question generation
        conversation_summary = ""
        if context.conversation_history:
            recent_msgs = context.conversation_history[-5:]
            conversation_summary = "\nRecent conversation:\n"
            for msg in recent_msgs:
                role = msg.role if hasattr(msg, 'role') else msg.get('role', 'user')
                content = msg.content if hasattr(msg, 'content') else msg.get('content', '')
                conversation_summary += f"{role}: {content}\n"
        
        # Get vector DB context for intelligent questioning with enhanced search
        vector_results = await vector_search_service.search_schemas(
            business_id=context.business_id,
            query=f"customer search help examples {context.message}",
            top_k=5
        )
        
        # Extract field information from schema context
        field_info = {}
        search_examples = []
        if vector_results:
            for result in vector_results[:3]:
                table_name = result.get('table_name', '')
                if 'customer' in table_name.lower() or 'cacus' in table_name.lower():
                    # Add schema description
                    schema_examples = f"Table: {table_name}\n"
                    schema_examples += f"Description: {result.get('schema_description', 'Customer data')}\n"
                    
                    # Add column information
                    columns = result.get('columns', [])
                    if columns:
                        schema_examples += "Searchable Fields:\n"
                        for col in columns[:8]:  # Limit to prevent overwhelming
                            field_name = col.get('name', '')
                            description = col.get('description', '') or col.get('business_meaning', '') or field_name
                            field_info[field_name] = description
                            schema_examples += f"  • {field_name}: {description}\n"
                    
                    search_examples.append(schema_examples)
        
        schema_examples_text = "\n".join(search_examples) if search_examples else "Customer table schema information"
        
        questioning_prompt = f"""
Generate adaptive clarification questions for customer search based on strategy with schema context.

STRATEGY: {strategy}
ATTEMPT: {context.clarification_attempts}
ORIGINAL QUERY: "{getattr(context, 'original_query', context.message)}"
CURRENT MESSAGE: "{context.message}"
MISSING INFO: {getattr(context, 'missing_information', [])}
{conversation_summary}

AVAILABLE CUSTOMER SCHEMA:
{schema_examples_text}

STRATEGY GUIDELINES:
- **direct**: Ask specific, focused questions (1-2 questions)
- **guided**: Provide examples and guide user (2-3 questions + examples)
- **contextual**: Build on conversation context (1-2 contextual questions)
- **progressive**: Start broad, get more specific (varies by attempt)

For ATTEMPT {context.clarification_attempts}:
- Attempt 1: Broad, helpful questions with schema context
- Attempt 2: More specific, targeted questions with field examples
- Attempt 3+: Very specific, with concrete examples using actual field names

Generate questions that:
1. Help user specify their search criteria using actual field names from the schema
2. Are appropriate for the attempt number
3. Match the questioning strategy
4. Consider conversation context
5. Provide concrete examples of what they can search for using real field names

Respond with JSON array: ["question1", "question2", "question3"]

Examples by strategy:
- direct: ["Which specific customer are you looking for?"]
- guided: ["Are you looking for a specific customer or a list?", "Do you have a customer ID, email, or name?"]
- contextual: ["Are you referring to the customer we discussed earlier?"]
- progressive: ["What type of customer information do you need?", "Any specific criteria like email domain or organization?"]
"""
        
        response = await llm_service.chat([
            {"role": "system", "content": "You are an adaptive questioning expert. Always respond with valid JSON array."},
            {"role": "user", "content": questioning_prompt}
        ])
        
        try:
            questions = _parse_llm_json_response(response.strip())
            if isinstance(questions, list) and questions:
                logger.info(f"[🎯AdaptiveQuestions] Generated {len(questions)} questions for strategy '{strategy}'")
                return questions
            else:
                return _get_fallback_questions_with_schema(strategy, context.clarification_attempts, field_info)
        except json.JSONDecodeError:
            return _get_fallback_questions_with_schema(strategy, context.clarification_attempts, field_info)
            
    except Exception as e:
        logger.error(f"[🎯AdaptiveQuestions] Error: {e}")
        return _get_fallback_questions_with_schema(strategy, context.clarification_attempts, {})

def _get_fallback_questions_with_schema(strategy, attempt, field_info):
    """🔄 Fallback questions based on strategy and attempt with schema context."""
    # Get top 5 most common/important fields
    common_fields = list(field_info.keys())[:5] if field_info else ['xcus', 'xemail', 'xphone', 'xorg', 'xfirst', 'xlast']
    
    # Create user-friendly field names dynamically
    user_friendly_fields = []
    for field in common_fields[:5]:
        # Simple transformation for fallback
        field_mapping = {
            'xcus': 'Customer ID',
            'xemail': 'Email Address',
            'xphone': 'Phone Number',
            'xorg': 'Organization',
            'xfirst': 'First Name',
            'xlast': 'Last Name',
            'xgcus': 'Customer Group',
            'xstatuscus': 'Customer Status',
            'xadd1': 'Address',
            'xcity': 'City'
        }
        user_friendly_name = field_mapping.get(field, field.replace('x', '').replace('_', ' ').title())
        user_friendly_fields.append(user_friendly_name)
    
    fallback_questions = {
        'direct': {
            1: ["What specific customer information are you looking for?"],
            2: [f"Do you have any of these details to search by: {', '.join(user_friendly_fields[:3])}?"],
            3: ["Could you provide a specific identifier like Customer ID or Email address?"]
        },
        'guided': {
            1: [
                "Are you looking for a specific customer or a list of customers?",
                f"You can search by any of these fields: {', '.join(user_friendly_fields)}",
                "For example: 'customer CUS-000107' or 'customers with gmail.com'"
            ],
            2: [
                "Could you provide more specific search criteria?",
                "Try one of these examples:",
                f"• 'customer CUS-000107' - Find specific customer by ID",
                f"• 'customers with gmail' - Find customers with gmail emails",
                f"• 'customers from TechCorp' - Find customers from an organization",
                f"• 'recent customers' - Show recently added customers"
            ],
            3: [
                "Let me help you with specific examples:",
                "🔍 Try these search patterns:",
                f"• 'customer CUS-000107' - Find by customer ID",
                f"• 'customers with @company.com' - Find by email domain",
                f"• 'last 5 customers' - Show most recent customers",
                f"• 'customers from [organization]' - Find by organization"
            ]
        },
        'contextual': {
            1: ["Based on our conversation, what customer details do you need?"],
            2: ["Are you referring to a customer we discussed before?"],
            3: ["Let me know the specific customer ID or details you're looking for."]
        },
        'progressive': {
            1: [
                "What type of customer information are you looking for?",
                f"Common search fields: {', '.join(user_friendly_fields)}",
                "• Customer ID (CUS-XXXXXX)",
                "• Email address",
                "• Organization name",
                "• Phone number",
                "• Recent customers"
            ],
            2: [
                "Could you narrow down your search criteria?",
                "Try searching with:",
                "• Email domain: 'customers with gmail.com'",
                "• Organization: 'customers from Company Name'",
                "• Recent additions: 'last 5 customers'",
                "• Specific customer: 'customer CUS-000107'"
            ],
            3: [
                "Let's be specific - could you provide:",
                "• Customer ID (like CUS-123)",
                "• Email address or domain",
                "• Organization name",
                "• Phone number"
            ]
        }
    }
    
    strategy_questions = fallback_questions.get(strategy, fallback_questions['direct'])
    attempt_questions = strategy_questions.get(attempt, strategy_questions.get(1, ["What customer information do you need?"]))
    
    return attempt_questions

async def _format_progressive_clarification_questions(questions, schema_context, attempt, strategy):
    """✨ Format clarification questions with progressive enhancement and schema context."""
    if not questions:
        return "Could you provide more specific information about what you're looking for?"
    
    # Extract field information from schema context
    field_info = {}
    if schema_context:
        for schema in schema_context:
            for col in schema.get('columns', []):
                field_name = col.get('name', '')
                description = col.get('description', '') or col.get('business_meaning', '') or field_name
                field_info[field_name] = description
    
    # Build response based on attempt and strategy
    if attempt == 1:
        response = f"😊 I need a bit more information to help you find the right customers:\n\n"
    elif attempt == 2:
        response = f"🎯 Let me get more specific to help you better:\n\n"
    else:
        response = f"🔍 Let's be very specific so I can help you:\n\n"
    
    # Add questions with appropriate formatting
    for i, question in enumerate(questions, 1):
        if len(questions) == 1:
            response += f"{question}\n\n"
        else:
            response += f"{i}. {question}\n"
    
    # Add examples based on attempt and schema context
    if attempt == 1:
        response += "\n💡 **Examples of what I can help with:**\n"
        
        # Use actual field names from schema if available
        if field_info:
            field_examples = list(field_info.items())[:5]
            for field_name, description in field_examples:
                # Simple transformation for display
                field_mapping = {
                    'xcus': 'Customer ID',
                    'xemail': 'Email Address',
                    'xphone': 'Phone Number',
                    'xorg': 'Organization',
                    'xfirst': 'First Name',
                    'xlast': 'Last Name',
                    'xgcus': 'Customer Group',
                    'xstatuscus': 'Customer Status',
                    'xadd1': 'Address',
                    'xcity': 'City'
                }
                user_friendly_name = field_mapping.get(field_name, field_name.replace('x', '').replace('_', ' ').title())
                response += f"• Find customers by {user_friendly_name.lower()}: `customers with specific {user_friendly_name.lower()}`\n"
        else:
            response += "• Find specific customer: `customer CUS-000123`\n"
            response += "• Search by email: `customers with gmail`\n"
            response += "• Recent customers: `last 10 customers`\n"
            response += "• Filter by organization: `customers from ABC Corp`\n"
            
    elif attempt == 2:
        response += "\n🎯 **Try being more specific:**\n"
        
        # Use actual field names from schema if available
        if field_info:
            field_examples = list(field_info.items())[:3]
            for field_name, description in field_examples:
                # Simple transformation for display
                field_mapping = {
                    'xcus': 'Customer ID',
                    'xemail': 'Email Address',
                    'xphone': 'Phone Number',
                    'xorg': 'Organization',
                    'xfirst': 'First Name',
                    'xlast': 'Last Name',
                    'xgcus': 'Customer Group',
                    'xstatuscus': 'Customer Status',
                    'xadd1': 'Address',
                    'xcity': 'City'
                }
                user_friendly_name = field_mapping.get(field_name, field_name.replace('x', '').replace('_', ' ').title())
                response += f"• Use {user_friendly_name.lower()}: `customers with specific {user_friendly_name.lower()}`\n"
        else:
            response += "• Use customer IDs like: `CUS-000123`\n"
            response += "• Mention email domains: `@gmail.com` or `@company.com`\n"
            response += "• Specify quantities: `last 5 customers` or `first customer`\n"
            
    elif attempt >= 3:
        response += "\n🚀 **Here are some examples that work well:**\n"
        response += "```\n"
        
        # Use actual field names from schema if available
        if field_info:
            field_examples = list(field_info.items())[:4]
            for i, (field_name, description) in enumerate(field_examples):
                # Simple transformation for display
                field_mapping = {
                    'xcus': 'CUS-000107',
                    'xemail': 'user@example.com',
                    'xphone': '123-456-7890',
                    'xorg': 'TechCorp',
                    'xfirst': 'John',
                    'xlast': 'Smith'
                }
                user_friendly_name = field_mapping.get(field_name, field_name.replace('x', '').replace('_', ' ').title())
                example_values = {
                    'xcus': 'CUS-000107',
                    'xemail': 'user@example.com',
                    'xphone': '123-456-7890',
                    'xorg': 'TechCorp',
                    'xfirst': 'John',
                    'xlast': 'Smith'
                }
                example_value = example_values.get(field_name, f'specific-{user_friendly_name.lower()}')
                response += f"show customers with {user_friendly_name.lower()} {example_value}\n"
        else:
            response += "show customer CUS-000107\n"
            response += "customers with gmail accounts\n"
            response += "last 5 customers added\n"
            response += "customers from ptech organization\n"
            
        response += "```"
    
    return response

async def _analyze_clarification_response(context):
    """Analyze user's clarification response using LLM."""
    try:
        analysis_prompt = f"""
Analyze the user's clarification response to extract customer search criteria.

Original Query: "{getattr(context, 'original_message', context.message)}"
Clarification Response: "{context.message}"
Previous Missing Info: {getattr(context, 'missing_information', [])}

Extract:
1. Specific search criteria provided
2. Whether enough information is now available for SQL generation
3. What information is still missing (if any)

Respond with JSON:
{{
    "sufficient_info": boolean,
    "extracted_info": {{
        "customer_id": "if provided",
        "name_pattern": "if provided",
        "email_pattern": "if provided",
        "phone_pattern": "if provided",
        "quantity": "if specified",
        "other_criteria": "any other criteria"
    }},
    "still_missing": ["list of still missing info"],
    "confidence": "high/medium/low"
}}
"""
        
        response = await llm_service.chat([
            {"role": "system", "content": analysis_prompt},
            {"role": "user", "content": context.message}
        ])
        
        import json
        try:
            result = _parse_llm_json_response(response)
            return result
        except json.JSONDecodeError:
            # Fallback analysis
            return {
                "sufficient_info": len(context.message.split()) > 2,
                "extracted_info": {"general_criteria": context.message},
                "still_missing": [],
                "confidence": "low"
            }
            
    except Exception as e:
        logger.error(f"[ClarificationAnalysis] Error: {e}")
        return {
            "sufficient_info": True,  # Default to proceed
            "extracted_info": {},
            "still_missing": []
        }
